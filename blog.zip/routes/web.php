<?php

use App\Http\Controllers\Admin\AboutController;
use App\Http\Controllers\Admin\AdminNavigationController;
use App\Http\Controllers\Admin\AiController;
use App\Http\Controllers\Admin\AdminLogController;
use App\Http\Controllers\Admin\AuthController;
use App\Http\Controllers\Admin\CaptchaController;
use App\Http\Controllers\Admin\CategoryController;
use App\Http\Controllers\Admin\CommentController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\InstallWizardController;
use App\Http\Controllers\Admin\FriendLinkController;
use App\Http\Controllers\Admin\MessageController;
use App\Http\Controllers\Admin\MediaController;
use App\Http\Controllers\Admin\MediaLibraryController;
use App\Http\Controllers\Admin\MaterialController;
use App\Http\Controllers\Admin\PostController;
use App\Http\Controllers\Admin\SettingController;
use App\Http\Controllers\Admin\SlideController;
use App\Http\Controllers\Admin\StatisticsController;
use App\Http\Controllers\Admin\TagController;
use App\Http\Controllers\Admin\UpdateController;
use App\Http\Controllers\Admin\UploadController;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\Admin\VisitController;
use App\Http\Controllers\BlogController;
use App\Http\Controllers\CaptchaController as CaptchaImageController;
use Illuminate\Support\Facades\Route;

// Installation routes (protected by global EnsureInstalled middleware)
require __DIR__.'/install.php';

// Frontend blog routes
Route::group([], function () {
    Route::get('/', [BlogController::class, 'index'])->name('blog.index');
    Route::get('/blog', [BlogController::class, 'index'])->name('blog.list');
    Route::get('/about', [BlogController::class, 'about'])->name('blog.about');
    Route::get('/guestbook', [BlogController::class, 'guestbook'])->name('blog.guestbook');
    Route::post('/guestbook', [BlogController::class, 'guestbookStore'])->name('blog.guestbook.store');
    Route::get('/post/{slug}', [BlogController::class, 'show'])->name('blog.show');
    Route::get('/category/{slug}', [BlogController::class, 'category'])->name('blog.category');
    Route::get('/search', [BlogController::class, 'search'])->name('blog.search');

    Route::post('/comment/{slug}', [BlogController::class, 'comment'])->name('blog.comment');
    Route::post('/post/{slug}/access', [BlogController::class, 'verifyAccess'])->name('blog.access');

    // 验证码图片（不受登录限制，供前台表单与登录页刷新）
    Route::get('/captcha/{scene}', [CaptchaImageController::class, 'image'])->name('captcha.image');
});

// Admin routes
Route::prefix('admin')->name('admin.')->group(function () {
    Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
    Route::post('/login', [AuthController::class, 'login']);
    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

    Route::middleware(['admin.auth'])->group(function () {
        Route::get('/', [DashboardController::class, 'index'])->name('dashboard');

        // 系统升级（仅超管）
        Route::middleware(['super.admin'])->group(function () {
            Route::get('update', [UpdateController::class, 'index'])->name('update.index');
            Route::post('update/check', [UpdateController::class, 'check'])->name('update.check');
            Route::post('update/upgrade', [UpdateController::class, 'upgrade'])->name('update.upgrade');
            Route::post('update/rollback', [UpdateController::class, 'rollback'])->name('update.rollback');
            Route::get('update/backups', [UpdateController::class, 'backups'])->name('update.backups');
        });

        Route::resource('posts', PostController::class);
        Route::post('posts/batch-destroy', [PostController::class, 'batchDestroy'])->name('posts.batch-destroy');
        Route::post('posts/batch-update', [PostController::class, 'batchUpdate'])->name('posts.batch-update');
        Route::post('posts/import', [PostController::class, 'batchImport'])->name('posts.import');
        Route::post('posts/{post}/toggle', [PostController::class, 'toggle'])->name('posts.toggle');
        Route::resource('categories', CategoryController::class)->except(['show']);
        Route::post('categories/{category}/move', [CategoryController::class, 'move'])->name('categories.move');
        Route::resource('tags', TagController::class)->except(['show']);

        Route::get('comments', [CommentController::class, 'index'])->name('comments.index');
        Route::post('comments/{comment}/approve', [CommentController::class, 'approve'])->name('comments.approve');
        Route::post('comments/{comment}/reject', [CommentController::class, 'reject'])->name('comments.reject');
        Route::post('comments/batch-destroy', [CommentController::class, 'batchDestroy'])->name('comments.batchDestroy');
        Route::delete('comments/{comment}', [CommentController::class, 'destroy'])->name('comments.destroy');

        Route::get('messages', [MessageController::class, 'index'])->name('messages.index');
        Route::post('messages/{message}/approve', [MessageController::class, 'approve'])->name('messages.approve');
        Route::post('messages/{message}/reject', [MessageController::class, 'reject'])->name('messages.reject');
        Route::post('messages/{message}/reply', [MessageController::class, 'reply'])->name('messages.reply');
        Route::delete('messages/{message}', [MessageController::class, 'destroy'])->name('messages.destroy');

        Route::get('about', [AboutController::class, 'edit'])->name('about.edit');
        Route::put('about', [AboutController::class, 'update'])->name('about.update');

        // 导航管理
        Route::resource('navigations', AdminNavigationController::class);
        Route::post('navigations/batch-destroy', [AdminNavigationController::class, 'batchDestroy'])->name('navigations.batch-destroy');
        Route::post('navigations/{navigation}/move-up', [AdminNavigationController::class, 'moveUp'])->name('navigations.move-up');
        Route::post('navigations/{navigation}/move-down', [AdminNavigationController::class, 'moveDown'])->name('navigations.move-down');
        Route::post('navigations/{navigation}/toggle', [AdminNavigationController::class, 'toggleEnable'])->name('navigations.toggle');
        Route::post('navigations/sort', [AdminNavigationController::class, 'sort'])->name('navigations.sort');

        Route::get('media', [MediaController::class, 'index'])->name('media.index');
        Route::post('media/upload', [MediaController::class, 'upload'])->name('media.upload');
        Route::delete('media/{mediaFile}', [MediaController::class, 'destroy'])->name('media.destroy');
        Route::patch('media/{mediaFile}', [MediaController::class, 'update'])->name('media.update');
        Route::post('media/bulk-destroy', [MediaController::class, 'bulkDestroy'])->name('media.bulk-destroy');
        Route::post('media/bulk-update', [MediaController::class, 'bulkUpdate'])->name('media.bulk-update');
        Route::post('media/bulk-copy', [MediaController::class, 'bulkCopy'])->name('media.bulk-copy');

        // Media Library API
        Route::get('media-library', [MediaLibraryController::class, 'index'])->name('media-library.index');
        Route::post('media-library/upload', [MediaLibraryController::class, 'upload'])->name('media-library.upload');
        Route::patch('media-library/{mediaFile}', [MediaLibraryController::class, 'update'])->name('media-library.update');
        Route::delete('media-library/{mediaFile}', [MediaLibraryController::class, 'destroy'])->name('media-library.destroy');
        Route::post('media-library/bulk-destroy', [MediaLibraryController::class, 'bulkDestroy'])->name('media-library.bulk-destroy');
        Route::post('media-library/bulk-copy', [MediaLibraryController::class, 'bulkCopy'])->name('media-library.bulk-copy');
        Route::post('media-library/bulk-update', [MediaLibraryController::class, 'bulkUpdate'])->name('media-library.bulk-update');

        // 系统设置 - 二级菜单
        Route::get('settings', [SettingController::class, 'base'])->name('settings.index');
        Route::post('settings', [SettingController::class, 'baseUpdate'])->name('settings.update');
        Route::get('settings/base', [SettingController::class, 'base'])->name('settings.base');
        Route::post('settings/base', [SettingController::class, 'baseUpdate'])->name('settings.base.update');
        Route::get('settings/appearance', [SettingController::class, 'appearance'])->name('settings.appearance');
        Route::post('settings/appearance', [SettingController::class, 'appearanceUpdate'])->name('settings.appearance.update');
        Route::get('settings/ai', [SettingController::class, 'ai'])->name('settings.ai');
        Route::post('settings/ai', [SettingController::class, 'aiUpdate'])->name('settings.ai.update');
        Route::get('settings/custom-code', [SettingController::class, 'customCode'])->name('settings.custom-code');
        Route::post('settings/custom-code', [SettingController::class, 'customCodeUpdate'])->name('settings.custom-code.update');
        Route::get('settings/image-compress', [SettingController::class, 'imageCompress'])->name('settings.image-compress');
        Route::post('settings/image-compress', [SettingController::class, 'imageCompressUpdate'])->name('settings.image-compress.update');
        Route::get('settings/blog', [SettingController::class, 'blog'])->name('settings.blog');
        Route::post('settings/blog', [SettingController::class, 'blogUpdate'])->name('settings.blog.update');
        Route::post('settings/update-config', [SettingController::class, 'updateConfig'])->name('settings.update-config');

        // 系统升级（仅超管）
        Route::get('update', [UpdateController::class, 'index'])->name('update.index');
        Route::post('update/check', [UpdateController::class, 'check'])->name('update.check');
        Route::post('update/upgrade', [UpdateController::class, 'upgrade'])->name('update.upgrade');
        Route::post('update/rollback', [UpdateController::class, 'rollback'])->name('update.rollback');
        Route::get('update/backups', [UpdateController::class, 'backups'])->name('update.backups');

        Route::post('upload/image', [UploadController::class, 'image'])->name('upload.image');
        Route::post('upload/file', [UploadController::class, 'file'])->name('upload.file');

        Route::resource('users', UserController::class);

        Route::get('logs', [AdminLogController::class, 'index'])->name('logs.index');
        Route::delete('logs/{log}', [AdminLogController::class, 'destroy'])->name('logs.destroy');
        Route::post('logs/clear', [AdminLogController::class, 'clear'])->name('logs.clear');

        // 动态验证码设置
        Route::get('captcha', [CaptchaController::class, 'index'])->name('captcha.index');
        Route::post('captcha', [CaptchaController::class, 'update'])->name('captcha.update');

        // 浏览量统计
        Route::get('visits', [VisitController::class, 'index'])->name('visits.index');

        // 浏览统计
        Route::get('statistics', [StatisticsController::class, 'index'])->name('statistics.index');

        Route::resource('slides', SlideController::class);
        Route::resource('materials', MaterialController::class);
        Route::resource('friend-links', FriendLinkController::class);

        // 当前管理员：修改密码
        Route::get('password', [AuthController::class, 'showPasswordForm'])->name('password.edit');
        Route::post('password', [AuthController::class, 'updatePassword'])->name('password.update');

        // 清除缓存
        Route::post('cache/clear', [DashboardController::class, 'clearCache'])->name('cache.clear');

        // 移除安装向导（仅超级管理员）
        Route::post('install-wizard/remove', [InstallWizardController::class, 'remove'])->name('install-wizard.remove');

        // 安装包下载（仅超管）
        Route::get('packages/{name}', [\App\Http\Controllers\Admin\PackageController::class, 'download'])->name('packages.download');
        Route::post('packages/{name}/download', [\App\Http\Controllers\Admin\PackageController::class, 'triggerDownload'])->name('packages.trigger-download');

        // AI 写作与配图生成（文章、关于页等富文本编辑器使用）
        Route::post('ai/write', [AiController::class, 'write'])->name('ai.write');
        Route::post('ai/generate-image', [AiController::class, 'generateImage'])->name('ai.generateImage');
    });
});

<?php

use App\Http\Controllers\InstallController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| 安装向导路由
|--------------------------------------------------------------------------
|
| 本文件由 routes/web.php 引入，所有安装请求都会先经过全局
| EnsureInstalled 中间件：未安装时放行，已安装时返回 403。
|
*/

Route::prefix('install')->name('install.')->controller(InstallController::class)->group(function () {
    Route::get('/', 'index')->name('index');
    Route::get('/step1', 'step1')->name('step1');
    Route::get('/step2', 'step2')->name('step2');
    Route::post('/step2', 'saveStep2')->name('step2.save');
    Route::get('/step3', 'step3')->name('step3');
    Route::post('/step3', 'runMigration')->name('step3.run');
    Route::get('/step4', 'step4')->name('step4');
    Route::post('/step4', 'createAdmin')->name('step4.save');
    Route::get('/complete', 'complete')->name('complete');
});

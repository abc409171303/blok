<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('site_configs', function (Blueprint $table) {
            $table->string('site_avatar', 255)->nullable()->after('site_favicon');
            $table->string('site_domain', 255)->nullable()->after('site_description');
            $table->string('site_color', 20)->nullable()->default('#2563eb')->after('site_domain');
            $table->string('icp_number', 100)->nullable()->after('site_color');
            $table->string('police_record_text', 100)->nullable()->after('icp_number');
            $table->string('police_record_link', 255)->nullable()->after('police_record_text');
            $table->string('contact_email', 100)->nullable()->after('police_record_link');
            $table->string('contact_phone', 50)->nullable()->after('contact_email');
            $table->string('contact_address', 255)->nullable()->after('contact_phone');
            $table->string('contact_qrcode', 255)->nullable()->after('contact_address');
        });
    }

    public function down(): void
    {
        Schema::table('site_configs', function (Blueprint $table) {
            $table->dropColumn([
                'site_avatar', 'site_domain', 'site_color',
                'icp_number', 'police_record_text', 'police_record_link',
                'contact_email', 'contact_phone', 'contact_address', 'contact_qrcode',
            ]);
        });
    }
};

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('site_configs', function (Blueprint $table) {
            $table->string('ai_api_base_url', 500)->nullable()->after('custom_footer_js');
            $table->string('ai_api_key', 500)->nullable()->after('ai_api_base_url');
            $table->string('ai_model', 100)->nullable()->default('qwen-plus')->after('ai_api_key');
        });
    }

    public function down(): void
    {
        Schema::table('site_configs', function (Blueprint $table) {
            $table->dropColumn(['ai_api_base_url', 'ai_api_key', 'ai_model']);
        });
    }
};

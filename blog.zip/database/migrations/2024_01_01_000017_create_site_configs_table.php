<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('site_configs', function (Blueprint $table) {
            $table->id();
            $table->string('site_name', 100)->default('My Blog');
            $table->string('site_description', 255)->nullable();
            $table->string('site_keywords', 255)->nullable();
            $table->string('site_logo', 255)->nullable();
            $table->string('site_favicon', 255)->nullable();
            $table->string('site_copyright', 255)->nullable();
            $table->integer('page_size')->default(10);
            $table->boolean('installed')->default(false);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('site_configs');
    }
};

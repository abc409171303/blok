<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('posts', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->foreignId('category_id')->nullable()->constrained()->onDelete('set null');
            $table->string('title', 255);
            $table->string('slug', 191)->unique();
            $table->string('summary', 500)->nullable();
            $table->longText('content');
            $table->string('cover', 255)->nullable();
            $table->integer('views')->default(0);
            $table->string('status', 20)->default('draft');
            $table->boolean('is_top')->default(false);
            $table->boolean('is_recommend')->default(false);
            $table->timestamp('published_at')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('posts');
    }
};

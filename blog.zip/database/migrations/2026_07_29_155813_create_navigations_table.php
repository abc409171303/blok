<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('navigations', function (Blueprint $table) {
            $table->id();
            $table->string('position')->default('header')->comment('header/footer');
            $table->string('name');
            $table->string('icon')->nullable();
            $table->string('url');
            $table->boolean('enabled')->default(true);
            $table->string('target')->default('_self')->comment('_self/_blank');
            $table->unsignedBigInteger('parent_id')->nullable();
            $table->integer('sort_order')->default(0);
            $table->timestamps();

            $table->foreign('parent_id')->references('id')->on('navigations')->onDelete('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('navigations');
    }
};

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('site_configs', function (Blueprint $table) {
            $table->string('system_update_server', 500)->nullable()->after('captcha_admin_login');
            $table->string('system_update_key', 255)->nullable()->after('system_update_server');
        });
    }

    public function down(): void
    {
        Schema::table('site_configs', function (Blueprint $table) {
            $table->dropColumn(['system_update_server', 'system_update_key']);
        });
    }
};

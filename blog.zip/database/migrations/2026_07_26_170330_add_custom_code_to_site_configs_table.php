<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('site_configs', function (Blueprint $table) {
            $table->text('custom_header_html')->nullable()->after('contact_qrcode');
            $table->text('custom_footer_js')->nullable()->after('custom_header_html');
        });
    }

    public function down(): void
    {
        Schema::table('site_configs', function (Blueprint $table) {
            $table->dropColumn(['custom_header_html', 'custom_footer_js']);
        });
    }
};

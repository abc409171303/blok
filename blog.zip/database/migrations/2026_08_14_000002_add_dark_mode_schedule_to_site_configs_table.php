<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('site_configs', function (Blueprint $table) {
            $table->string('dark_mode_mode', 20)->default('always')->after('enable_dark_mode');
            $table->string('dark_mode_start', 5)->nullable()->default('19:00')->after('dark_mode_mode');
            $table->string('dark_mode_end', 5)->nullable()->default('07:00')->after('dark_mode_start');
        });

        // 将已有 enable_dark_mode 布尔值迁移为 mode
        DB::table('site_configs')->update([
            'dark_mode_mode' => DB::raw("CASE WHEN enable_dark_mode = 1 THEN 'always' ELSE 'never' END"),
        ]);
    }

    public function down(): void
    {
        Schema::table('site_configs', function (Blueprint $table) {
            $table->dropColumn(['dark_mode_mode', 'dark_mode_start', 'dark_mode_end']);
        });
    }
};

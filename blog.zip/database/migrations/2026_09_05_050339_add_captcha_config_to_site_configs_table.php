<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('site_configs', function (Blueprint $table) {
            $table->boolean('captcha_enabled')->default(false)->after('auto_approve_comments');
            $table->boolean('captcha_comment')->default(true)->after('captcha_enabled');
            $table->boolean('captcha_message')->default(true)->after('captcha_comment');
            $table->boolean('captcha_admin_login')->default(true)->after('captcha_message');
        });
    }

    public function down(): void
    {
        Schema::table('site_configs', function (Blueprint $table) {
            $table->dropColumn(['captcha_enabled', 'captcha_comment', 'captcha_message', 'captcha_admin_login']);
        });
    }
};

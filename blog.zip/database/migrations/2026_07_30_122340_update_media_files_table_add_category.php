<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('media_files', function (Blueprint $table) {
            $table->string('category')->default('uncategorized')->after('file_name')->comment('分类：uncategorized/images/videos');
            $table->string('title')->nullable()->after('category')->comment('备注/标题');
            $table->unsignedInteger('width')->nullable()->after('title');
            $table->unsignedInteger('height')->nullable()->after('width');
            $table->index('category');
            $table->index('file_type');
        });
    }

    public function down(): void
    {
        Schema::table('media_files', function (Blueprint $table) {
            $table->dropIndex(['category']);
            $table->dropIndex(['file_type']);
            $table->dropColumn(['category', 'title', 'width', 'height']);
        });
    }
};

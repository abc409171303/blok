<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        // 删除旧表重新创建
        Schema::dropIfExists('navigations');
        
        Schema::create('navigations', function (Blueprint $table) {
            $table->id();
            $table->string('position')->default('head')->comment('位置：head 头部，foot 底部');
            $table->string('name')->comment('导航名称');
            $table->string('icon')->nullable()->comment('图标');
            $table->string('url')->comment('链接');
            $table->tinyInteger('is_enable')->default(1)->comment('是否启用 (0/1)');
            $table->string('target')->default('_self')->comment('打开方式：_self 当前窗口，_blank 新窗口');
            $table->unsignedInteger('sort')->default(0)->comment('排序数字');
            $table->timestamps();
            
            $table->index('position');
            $table->index('is_enable');
            $table->index('sort');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('navigations');
    }
};

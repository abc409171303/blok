<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * 网站访问记录表：访问时间、访客IP、访问页面URL、浏览器UA。
     * 爬虫请求不写入；同一访客 30 分钟内访问同一页面只记录 1 次。
     */
    public function up(): void
    {
        Schema::create('site_visits', function (Blueprint $table) {
            $table->id();
            $table->string('ip', 45)->index();
            $table->string('url', 500);
            $table->text('user_agent');
            // 访客标识：md5(ip|ua)，用于 UV 统计与防重复
            $table->string('visitor_key', 32)->index();
            $table->timestamps();

            $table->index('created_at');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('site_visits');
    }
};

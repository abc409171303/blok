<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('friend_links', function (Blueprint $table) {
            $table->id();
            $table->string('name', 200)->comment('网站名称');
            $table->string('url', 500)->comment('链接地址');
            $table->string('logo', 500)->nullable()->comment('网站 Logo');
            $table->string('description', 500)->nullable()->comment('描述');
            $table->boolean('status')->default(true)->comment('状态：1显示 0隐藏');
            $table->integer('sort_order')->default(0)->comment('排序');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('friend_links');
    }
};

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('slides', function (Blueprint $table) {
            $table->string('video_url')->nullable()->after('image')->comment('视频 URL');
            $table->string('video_cover')->nullable()->after('video_url')->comment('视频封面图');
        });
    }

    public function down(): void
    {
        Schema::table('slides', function (Blueprint $table) {
            $table->dropColumn(['video_url', 'video_cover']);
        });
    }
};

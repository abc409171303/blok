<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * 将 friend_links 表的 name/url 字段重命名为 site_name/site_url。
     *
     * 注意：Laravel 12 的 renameColumn 在 MySQL < 8.0.3 上会先查询
     * information_schema.columns.generation_expression，而该列是 MySQL 5.7.6
     * 才引入的，MySQL 5.6 不存在，会报 Unknown column 'GENERATION_EXPRESSION'。
     * 因此这里对 MySQL/MariaDB 改用原生 information_schema 存在性判断 + CHANGE 语句，
     * 兼容 MySQL 5.6 / 5.7 / 8.0 与 MariaDB。
     */
    public function up(): void
    {
        $this->renameColumn('name', 'site_name', 'VARCHAR(200) NOT NULL');
        $this->renameColumn('url', 'site_url', 'VARCHAR(500) NOT NULL');
    }

    public function down(): void
    {
        $this->renameColumn('site_name', 'name', 'VARCHAR(200) NOT NULL');
        $this->renameColumn('site_url', 'url', 'VARCHAR(500) NOT NULL');
    }

    /**
     * 若旧列存在则重命名；列不存在（全新安装已是新字段名）时安全跳过。
     */
    protected function renameColumn(string $from, string $to, string $definition): void
    {
        if (!Schema::hasTable('friend_links')) {
            return;
        }

        $connection = DB::connection();
        $driver = $connection->getDriverName();

        if ($driver === 'mysql' || $driver === 'mariadb') {
            $table = $connection->getTablePrefix() . 'friend_links';

            $exists = $connection->selectOne(
                'select count(*) as total from information_schema.columns '
                . 'where table_schema = database() and table_name = ? and column_name = ?',
                [$table, $from]
            );

            if (! $exists || (int) $exists->total === 0) {
                return;
            }

            $connection->statement(sprintf(
                'alter table `%s` change `%s` `%s` %s',
                $table,
                $from,
                $to,
                $definition
            ));

            return;
        }

        if (! Schema::hasColumn('friend_links', $from)) {
            return;
        }

        Schema::table('friend_links', function (Blueprint $table) use ($from, $to) {
            $table->renameColumn($from, $to);
        });
    }
};

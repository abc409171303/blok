<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('site_configs', function (Blueprint $table) {
            $table->string('site_seo_title', 255)->nullable()->after('site_name');
            $table->string('site_tagline', 255)->nullable()->after('site_seo_title');
            $table->string('contact_qq', 100)->nullable()->after('contact_qrcode');
            $table->string('contact_weibo', 255)->nullable()->after('contact_qq');
            $table->string('contact_wechat', 100)->nullable()->after('contact_weibo');
            $table->unsignedInteger('sidebar_tag_count')->default(0)->after('contact_wechat');
            $table->boolean('enable_dark_mode')->default(true)->after('sidebar_tag_count');
            $table->string('search_driver', 50)->default('builtin')->after('enable_dark_mode');
            $table->boolean('enable_comments')->default(true)->after('search_driver');
        });
    }

    public function down(): void
    {
        Schema::table('site_configs', function (Blueprint $table) {
            $table->dropColumn([
                'site_seo_title', 'site_tagline', 'contact_qq',
                'contact_weibo', 'contact_wechat', 'sidebar_tag_count',
                'enable_dark_mode', 'search_driver', 'enable_comments',
            ]);
        });
    }
};

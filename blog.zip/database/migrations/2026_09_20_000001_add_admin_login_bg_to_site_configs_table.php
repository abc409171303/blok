<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * 补齐站点外观中的登录页背景配置列。
 *
 * 这两列只存在于安装包内置的旧版 SQLite 数据中，历史迁移从未创建它们。
 * 使用 MySQL（全新执行迁移）时列缺失，而站点外观表单始终会提交
 * admin_login_bg_opacity（range 输入），导致 update 报 Unknown column，
 * 整次保存失败、站点 Logo 等设置随之丢失。此处补建以修复 MySQL 场景。
 */
return new class extends Migration
{
    public function up(): void
    {
        $missing = [];

        if (! Schema::hasColumn('site_configs', 'admin_login_bg')) {
            $missing[] = 'admin_login_bg';
        }

        if (! Schema::hasColumn('site_configs', 'admin_login_bg_opacity')) {
            $missing[] = 'admin_login_bg_opacity';
        }

        if ($missing === []) {
            return;
        }

        Schema::table('site_configs', function (Blueprint $table) use ($missing) {
            if (in_array('admin_login_bg', $missing, true)) {
                $table->string('admin_login_bg', 255)->nullable()->after('contact_qrcode');
            }

            if (in_array('admin_login_bg_opacity', $missing, true)) {
                $table->unsignedTinyInteger('admin_login_bg_opacity')->default(85)->after('admin_login_bg');
            }
        });
    }

    public function down(): void
    {
        Schema::table('site_configs', function (Blueprint $table) {
            $table->dropColumn(['admin_login_bg', 'admin_login_bg_opacity']);
        });
    }
};

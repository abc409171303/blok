<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('materials', function (Blueprint $table) {
            $table->id();
            $table->string('name', 200)->comment('物料名称');
            $table->string('code', 100)->nullable()->comment('物料编码');
            $table->string('specification', 200)->nullable()->comment('规格型号');
            $table->string('unit', 50)->nullable()->comment('单位');
            $table->decimal('price', 10, 2)->default(0)->comment('单价');
            $table->integer('stock')->default(0)->comment('库存数量');
            $table->boolean('status')->default(true)->comment('状态：1启用 0停用');
            $table->string('remark', 500)->nullable()->comment('备注');
            $table->integer('sort_order')->default(0)->comment('排序');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('materials');
    }
};

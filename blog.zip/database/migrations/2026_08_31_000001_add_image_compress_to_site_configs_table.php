<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('site_configs', function (Blueprint $table) {
            $table->boolean('image_compress_enabled')->default(true)->after('site_start_date');
            $table->unsignedTinyInteger('image_compress_quality')->default(80)->after('image_compress_enabled');
            $table->unsignedInteger('image_compress_max_width')->default(1920)->after('image_compress_quality');
            $table->unsignedInteger('image_compress_max_height')->default(1920)->after('image_compress_max_width');
            $table->unsignedInteger('image_compress_max_kb')->default(0)->after('image_compress_max_height');
        });
    }

    public function down(): void
    {
        Schema::table('site_configs', function (Blueprint $table) {
            $table->dropColumn([
                'image_compress_enabled',
                'image_compress_quality',
                'image_compress_max_width',
                'image_compress_max_height',
                'image_compress_max_kb',
            ]);
        });
    }
};

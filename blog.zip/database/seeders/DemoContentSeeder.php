<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\Comment;
use App\Models\FriendLink;
use App\Models\Message;
use App\Models\Navigation;
use App\Models\Post;
use App\Models\Slide;
use App\Models\Tag;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;

/**
 * 安装完成后植入演示数据（分类、标签、导航、幻灯片、文章、评论、留言、友链）。
 *
 * 设计要点：
 *  - 幂等：按数据表是否已有内容分段判断，绝不覆盖或清空用户已有数据；
 *  - 非破坏：只做 firstOrCreate / create，不执行 delete / truncate；
 *  - 资源自包含：演示图片存放于 database/seeders/assets/，运行时释放到 storage/app/public/；
 *  - 演示文章归属于已存在的超级管理员，若不存在则创建演示作者账号。
 */
class DemoContentSeeder extends Seeder
{
    public function run(): void
    {
        $this->publishAssets();

        $data = $this->loadData();
        if (!$data) {
            return;
        }

        $authorId = $this->resolveAuthorId();

        $this->seedCategories($data['categories'] ?? []);
        $this->seedTags($data['tags'] ?? []);
        $this->seedNavigations($data['navigations'] ?? []);
        $this->seedSlides($data['slides'] ?? []);
        $this->seedPosts($data['posts'] ?? [], $authorId);
        $this->seedComments($data['comments'] ?? []);
        $this->seedMessages($data['messages'] ?? []);
        $this->seedFriendLinks($data['friend_links'] ?? []);
        $this->seedSiteConfig($data['site'] ?? []);
    }

    /**
     * 读取演示数据定义文件。
     */
    protected function loadData(): ?array
    {
        $path = database_path('seeders/data/demo-content.json');
        if (!is_file($path)) {
            return null;
        }

        $data = json_decode((string) file_get_contents($path), true);

        return is_array($data) ? $data : null;
    }

    /**
     * 将随包分发的演示图片释放到 storage/app/public/ 下，已存在则跳过。
     */
    protected function publishAssets(): void
    {
        $source = database_path('seeders/assets');
        if (!is_dir($source)) {
            return;
        }

        $target = storage_path('app/public');

        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($source, \FilesystemIterator::SKIP_DOTS)
        );

        foreach ($iterator as $file) {
            if (!$file->isFile()) {
                continue;
            }
            $relative = ltrim(str_replace($source, '', $file->getPathname()), DIRECTORY_SEPARATOR);
            $relative = str_replace(DIRECTORY_SEPARATOR, '/', $relative);
            $dest = $target . '/' . $relative;

            if (is_file($dest)) {
                continue;
            }
            $dir = dirname($dest);
            if (!is_dir($dir)) {
                @mkdir($dir, 0775, true);
            }
            @copy($file->getPathname(), $dest);
        }
    }

    /**
     * 决定演示文章的作者：优先超级管理员，其次任一用户，最后创建演示作者。
     */
    protected function resolveAuthorId(): int
    {
        $admin = User::where('role', 'super_admin')->orderBy('id')->first();
        if ($admin) {
            return (int) $admin->id;
        }

        $any = User::orderBy('id')->first();
        if ($any) {
            return (int) $any->id;
        }

        $author = User::create([
            'name' => '博主',
            'email' => 'author@example.com',
            'password' => Hash::make(bin2hex(random_bytes(8))),
            'role' => 'super_admin',
            'display_name' => '博主',
        ]);

        return (int) $author->id;
    }

    protected function seedCategories(array $rows): void
    {
        if (Category::count() > 0) {
            return;
        }

        foreach ($rows as $row) {
            Category::create([
                'name' => $row['name'],
                'slug' => $row['slug'],
                'description' => $row['description'] ?? null,
                'parent_id' => null,
                'sort_order' => $row['sort_order'] ?? 0,
            ]);
        }
    }

    protected function seedTags(array $rows): void
    {
        if (Tag::count() > 0) {
            return;
        }

        foreach ($rows as $row) {
            Tag::firstOrCreate(
                ['slug' => $row['slug']],
                ['name' => $row['name'], 'parent_id' => null]
            );
        }
    }

    protected function seedNavigations(array $rows): void
    {
        if (Navigation::count() > 0) {
            return;
        }

        foreach ($rows as $row) {
            Navigation::create([
                'position' => $row['position'],
                'name' => $row['name'],
                'icon' => $row['icon'] ?? null,
                'url' => $row['url'],
                'is_enable' => $row['is_enable'] ?? 1,
                'target' => $row['target'] ?? '_self',
                'sort' => $row['sort'] ?? 0,
            ]);
        }
    }

    protected function seedSlides(array $rows): void
    {
        if (Slide::count() > 0) {
            return;
        }

        foreach ($rows as $row) {
            Slide::create([
                'title' => $row['title'],
                'subtitle' => $row['subtitle'] ?? null,
                'image' => $row['image'] ?? null,
                'video_url' => $row['video_url'] ?? null,
                'video_cover' => $row['video_cover'] ?? null,
                'position' => $row['position'] ?? '首页顶部轮播',
                'bg_color' => $row['bg_color'] ?? '#1f2937',
                'link_url' => $row['link_url'] ?? null,
                'sort_order' => $row['sort_order'] ?? 0,
                'status' => 1,
            ]);
        }
    }

    protected function seedPosts(array $rows, int $authorId): void
    {
        if (Post::count() > 0) {
            return;
        }

        $categoryIds = Category::pluck('id', 'slug')->all();
        $tagIds = Tag::pluck('id', 'name')->all();

        foreach ($rows as $row) {
            $post = Post::create([
                'user_id' => $authorId,
                'category_id' => $categoryIds[$row['category']] ?? null,
                'title' => $row['title'],
                'slug' => $row['slug'],
                'summary' => $row['summary'] ?? null,
                'content' => $row['content'],
                'cover' => $row['cover'] ?? null,
                'views' => $row['views'] ?? 0,
                'status' => 'published',
                'is_top' => (int) ($row['is_top'] ?? 0),
                'is_recommend' => (int) ($row['is_recommend'] ?? 0),
                'is_hot' => (int) ($row['is_hot'] ?? 0),
                'access_mode' => $row['access_mode'] ?? 'public',
                'published_at' => $row['published_at'] ?? now(),
            ]);

            $attach = [];
            foreach ($row['tags'] ?? [] as $tagName) {
                if (isset($tagIds[$tagName])) {
                    $attach[] = $tagIds[$tagName];
                }
            }
            if ($attach) {
                $post->tags()->sync($attach);
            }
        }
    }

    protected function seedComments(array $rows): void
    {
        if (Comment::count() > 0) {
            return;
        }

        $postIds = Post::pluck('id', 'slug')->all();

        // 先建立顶层评论，便于处理回复关系
        $created = [];
        foreach ($rows as $row) {
            if (!empty($row['reply_to'])) {
                continue;
            }
            $postId = $postIds[$row['post']] ?? null;
            if (!$postId) {
                continue;
            }
            $comment = Comment::create([
                'post_id' => $postId,
                'user_id' => null,
                'parent_id' => null,
                'author' => $row['author'],
                'email' => $row['email'] ?? null,
                'content' => $row['content'],
                'status' => $row['status'] ?? 'approved',
            ]);
            $this->applyTimestamps($comment, $row['created_at'] ?? null);
            $created[$row['author']] = $comment->id;
        }

        // 处理回复：reply_to 指向同一批顶层评论的作者
        foreach ($rows as $row) {
            if (empty($row['reply_to']) || empty($created[$row['reply_to']])) {
                continue;
            }
            $postId = $postIds[$row['post']] ?? null;
            if (!$postId) {
                continue;
            }
            $reply = Comment::create([
                'post_id' => $postId,
                'user_id' => null,
                'parent_id' => $created[$row['reply_to']],
                'author' => $row['author'],
                'email' => $row['email'] ?? null,
                'content' => $row['content'],
                'status' => $row['status'] ?? 'approved',
            ]);
            $this->applyTimestamps($reply, $row['created_at'] ?? null);
        }
    }

    protected function seedMessages(array $rows): void
    {
        if (Message::count() > 0) {
            return;
        }

        foreach ($rows as $row) {
            $message = Message::create([
                'author' => $row['author'],
                'email' => $row['email'] ?? null,
                'content' => $row['content'],
                'status' => $row['status'] ?? 'approved',
                'reply' => $row['reply'] ?? null,
            ]);
            $this->applyTimestamps($message, $row['created_at'] ?? null);
        }
    }

    protected function seedFriendLinks(array $rows): void
    {
        if (FriendLink::count() > 0) {
            return;
        }

        foreach ($rows as $row) {
            FriendLink::create([
                'site_name' => $row['site_name'],
                'site_url' => $row['site_url'],
                'logo' => $row['logo'] ?? null,
                'description' => $row['description'] ?? null,
                'status' => $row['status'] ?? 1,
                'sort_order' => $row['sort_order'] ?? 0,
            ]);
        }
    }

    /**
     * 仅在站点配置相应字段为空时补全演示内容，不覆盖用户已有配置。
     */
    protected function seedSiteConfig(array $site): void
    {
        if (!$site || !class_exists(\App\Models\SiteConfig::class)) {
            return;
        }

        $config = \App\Models\SiteConfig::getInstance();
        $updates = [];

        foreach (['about_content', 'site_logo', 'site_avatar'] as $field) {
            if (array_key_exists($field, $site) && blank($config->{$field})) {
                $updates[$field] = $site[$field];
            }
        }

        if ($updates) {
            $config->update($updates);
        }
    }

    /**
     * 按演示数据中的时间回填 created_at / updated_at。
     */
    protected function applyTimestamps($model, ?string $createdAt): void
    {
        if (empty($createdAt)) {
            return;
        }

        $model->timestamps = false;
        $model->created_at = $createdAt;
        $model->updated_at = $createdAt;
        $model->save();
    }
}

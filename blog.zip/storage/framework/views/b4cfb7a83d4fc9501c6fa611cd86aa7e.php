
<div class="px-5 py-6 text-center">
    <div class="avatar-ring w-32 h-32 mx-auto rounded-full shadow flex items-center justify-center">
        <?php if($config->site_avatar): ?>
        <img src="<?php echo e(Storage::url($config->site_avatar)); ?>" alt="" class="w-28 h-28 rounded-full object-cover">
        <?php else: ?>
        <div class="w-28 h-28 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center text-white text-3xl font-bold">
            <?php echo e(mb_substr($config->site_name ?? 'B', 0, 1)); ?>

        </div>
        <?php endif; ?>
    </div>
    <div class="text-xl font-semibold text-gray-800 mt-4"><?php echo e($config->site_name ?? '博客'); ?></div>
    <div class="text-gray-400 mt-3 text-sm leading-relaxed"><?php echo e($config->site_tagline ?: ($config->site_description ?? "记录点滴，分享生活")); ?></div>
</div>
<?php /**PATH C:\web1\resources\views/partials/author-card.blade.php ENDPATH**/ ?>
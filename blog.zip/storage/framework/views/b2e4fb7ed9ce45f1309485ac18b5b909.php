<!DOCTYPE html>
<html lang="zh-CN" class="h-full">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>管理后台 - <?php echo e(\App\Models\SiteConfig::getInstance()->site_name ?? 'Blog'); ?></title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <script src="<?php echo e(asset('static/alpine/cdn.min.js')); ?>" defer></script>
            <svg id="vditorIconScript" style="position:absolute;width:0;height:0;overflow:hidden" version="1.1" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <symbol id="vditor-icon-comment" viewBox="0 0 24 24"><path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-headings" viewBox="0 0 24 24"><path d="M6 12h12"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M6 20V4"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M18 20V4"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-bold" viewBox="0 0 24 24"><path d="M6 12h9a4 4 0 0 1 0 8H7a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1h7a4 4 0 0 1 0 8"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-italic" viewBox="0 0 24 24"><line x1="19" x2="10" y1="4" y2="4"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <line x1="14" x2="5" y1="20" y2="20"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <line x1="15" x2="9" y1="4" y2="20"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-strike" viewBox="0 0 24 24"><path d="M16 4H9a3 3 0 0 0-2.83 4"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M14 12a4 4 0 0 1 0 8H6"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <line x1="4" x2="20" y1="12" y2="12"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-line" viewBox="0 0 24 24"><path d="M5 12h14"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-quote" viewBox="0 0 24 24"><path d="M16 3a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2 1 1 0 0 1 1 1v1a2 2 0 0 1-2 2 1 1 0 0 0-1 1v2a1 1 0 0 0 1 1 6 6 0 0 0 6-6V5a2 2 0 0 0-2-2z"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M5 3a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2 1 1 0 0 1 1 1v1a2 2 0 0 1-2 2 1 1 0 0 0-1 1v2a1 1 0 0 0 1 1 6 6 0 0 0 6-6V5a2 2 0 0 0-2-2z"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-link" viewBox="0 0 24 24"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-upload" viewBox="0 0 24 24"><path d="M12 13v8"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M4 14.899A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.242"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="m8 17 4-4 4 4"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-table" viewBox="0 0 24 24"><path d="M12 3v18"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <rect width="18" height="18" x="3" y="3" rx="2"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M3 9h18"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M3 15h18"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-code" viewBox="0 0 24 24"><polyline points="16 18 22 12 16 6"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <polyline points="8 6 2 12 8 18"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-list" viewBox="0 0 24 24"><path d="M3 12h.01"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M3 18h.01"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M3 6h.01"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M8 12h13"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M8 18h13"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M8 6h13"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-ordered-list" viewBox="0 0 24 24"><path d="M10 12h11"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M10 18h11"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M10 6h11"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M4 10h2"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M4 6h1v4"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M6 18H4c0-1 2-2 2-3s-1-1.5-2-1"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-check" viewBox="0 0 24 24"><rect width="18" height="18" x="3" y="3" rx="2"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="m9 12 2 2 4-4"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-outdent" viewBox="0 0 24 24"><path d="M21 12H11"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M21 18H11"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M21 6H11"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="m7 8-4 4 4 4"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-indent" viewBox="0 0 24 24"><path d="M21 12H11"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M21 18H11"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M21 6H11"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="m3 8 4 4-4 4"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-undo" viewBox="0 0 24 24"><path d="M9 14 4 9l5-5"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M4 9h10.5a5.5 5.5 0 0 1 5.5 5.5a5.5 5.5 0 0 1-5.5 5.5H11"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-redo" viewBox="0 0 24 24"><path d="m15 14 5-5-5-5"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M20 9H9.5A5.5 5.5 0 0 0 4 14.5A5.5 5.5 0 0 0 9.5 20H13"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-record" viewBox="0 0 24 24"><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M19 10v2a7 7 0 0 1-14 0v-2"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <line x1="12" x2="12" y1="19" y2="22"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-edit-mode" viewBox="0 0 24 24"><path d="M12 20h9"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M16.376 3.622a1 1 0 0 1 3.002 3.002L7.368 18.635a2 2 0 0 1-.855.506l-2.872.838a.5.5 0 0 1-.62-.62l.838-2.872a2 2 0 0 1 .506-.854z"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-both" viewBox="0 0 24 24"><rect width="18" height="18" x="3" y="3" rx="2"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M12 3v18"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-preview" viewBox="0 0 24 24"><path d="M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <circle cx="12" cy="12" r="3"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-fullscreen" viewBox="0 0 24 24"><path d="M8 3H5a2 2 0 0 0-2 2v3"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M21 8V5a2 2 0 0 0-2-2h-3"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M3 16v3a2 2 0 0 0 2 2h3"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M16 21h3a2 2 0 0 0 2-2v-3"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-outline" viewBox="0 0 24 24"><path d="m3 10 2.5-2.5L3 5"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="m3 19 2.5-2.5L3 14"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M10 6h11"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M10 12h11"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M10 18h11"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-code-theme" viewBox="0 0 24 24"><circle cx="13.5" cy="6.5" r=".5"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <circle cx="17.5" cy="10.5" r=".5"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <circle cx="8.5" cy="7.5" r=".5"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <circle cx="6.5" cy="12.5" r=".5"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-content-theme" viewBox="0 0 24 24"><circle cx="12" cy="12" r="4"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M12 2v2"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M12 20v2"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="m4.93 4.93 1.41 1.41"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="m17.66 17.66 1.41 1.41"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M2 12h2"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M20 12h2"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="m6.34 17.66-1.41 1.41"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="m19.07 4.93-1.41 1.41"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-export" viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <polyline points="7 10 12 15 17 10"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <line x1="12" x2="12" y1="15" y2="3"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-info" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M12 16v-4"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M12 8h.01"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-help" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M12 17h.01"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-resize" viewBox="0 0 24 24"><polyline points="15 3 21 3 21 9"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <polyline points="9 21 3 21 3 15"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <line x1="21" x2="14" y1="3" y2="10"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <line x1="3" x2="10" y1="21" y2="14"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-edit" viewBox="0 0 24 24"><path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="m15 5 4 4"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-copy" viewBox="0 0 24 24"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-trashcan" viewBox="0 0 24 24"><path d="M3 6h18"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <line x1="10" x2="10" y1="11" y2="17"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <line x1="14" x2="14" y1="11" y2="17"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-more" viewBox="0 0 24 24"><circle cx="12" cy="12" r="1"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <circle cx="19" cy="12" r="1"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <circle cx="5" cy="12" r="1"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-bug" viewBox="0 0 24 24"><path d="m8 2 1.88 1.88"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M14.12 3.88 16 2"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M9 7.13v-1a3.003 3.003 0 1 1 6 0v1"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M12 20c-3.3 0-6-2.7-6-6v-3a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v3c0 3.3-2.7 6-6 6"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M12 20v-9"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M6.53 9C4.6 8.8 3 7.1 3 5"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M6 13H2"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M3 21c0-2.1 1.7-3.9 3.8-4"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M20.97 5c0 2.1-1.6 3.8-3.5 4"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M22 13h-4"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M17.2 17c2.1.1 3.8 1.9 3.8 4"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-contract" viewBox="0 0 24 24"><polyline points="4 14 10 14 10 20"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <polyline points="20 10 14 10 14 4"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <line x1="14" x2="21" y1="10" y2="3"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <line x1="3" x2="10" y1="21" y2="14"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-down" viewBox="0 0 24 24"><path d="m6 9 6 6 6-6"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-up" viewBox="0 0 24 24"><path d="m18 15-6-6-6 6"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-theme" viewBox="0 0 24 24"><path d="M12 8a2.83 2.83 0 0 0 4 4 4 4 0 1 1-4-4"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M12 2v2"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M12 20v2"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="m4.9 4.9 1.4 1.4"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="m17.7 17.7 1.4 1.4"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M2 12h2"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M20 12h2"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="m6.3 17.7-1.4 1.4"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="m19.1 4.9-1.4 1.4"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-align-center" viewBox="0 0 24 24"><path d="M17 12H7"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M19 18H5"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M21 6H3"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-align-left" viewBox="0 0 24 24"><path d="M15 12H3"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M17 18H3"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M21 6H3"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-align-right" viewBox="0 0 24 24"><path d="M21 12H9"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M21 18H7"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M21 6H3"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-pause" viewBox="0 0 24 24"><rect x="14" y="4" width="4" height="16" rx="1"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <rect x="6" y="4" width="4" height="16" rx="1"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-play" viewBox="0 0 24 24"><polygon points="6 3 20 12 6 21 6 3"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-mp-wechat" viewBox="0 0 24 24"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-emoji" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M8 14s1.5 2 4 2 4-2 4-2"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <line x1="9" x2="9.01" y1="9" y2="9"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <line x1="15" x2="15.01" y1="9" y2="9"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-video" viewBox="0 0 24 24"><path d="m16 13 5.223 3.482a.5.5 0 0 0 .777-.416V7.87a.5.5 0 0 0-.752-.432L16 10.5"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <rect x="2" y="6" width="14" height="12" rx="2"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-ai-write" viewBox="0 0 24 24"><path d="M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M20 3v4"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M22 5h-4"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M4 17v2"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="M5 18H3"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-ai-image" viewBox="0 0 24 24"><rect width="18" height="18" x="3" y="3" rx="2" ry="2"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <circle cx="9" cy="9" r="2"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /> <path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"  fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" /></symbol>
        <symbol id="vditor-icon-before" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" d="M3 9h12m-4-4 4 4-4 4M15 15h6"/></symbol>
        <symbol id="vditor-icon-after" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" d="M3 15h12m-4 4-4-4 4-4M15 9h6"/></symbol>
        <symbol id="vditor-icon-delete-row" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" d="M3 8h10m4 0h4M3 16h10m4 0h4M21 3l-6 6M15 3l6 6"/></symbol>
        <symbol id="vditor-icon-delete-column" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" d="M8 3v10m0 4v4M16 3v10m0 4v4M3 21l6-6M3 15l6 6"/></symbol>
        <symbol id="vditor-icon-insert-row" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" d="M3 12h12m-4-4 4 4-4 4"/></symbol>
        <symbol id="vditor-icon-insert-rowb" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" d="M3 12h12m-4 4 4-4-4-4"/></symbol>
        <symbol id="vditor-icon-insert-column" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" d="M12 3v12m-4-4 4 4 4-4"/></symbol>
        <symbol id="vditor-icon-insert-columnb" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" d="M12 3v12m-4 4 4-4 4 4"/></symbol>
        <symbol id="vditor-icon-inline-code" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" d="m8 7-5 5 5 5m8 0 5-5-5-5"/></symbol>
        <symbol id="vditor-icon-math" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" d="M18 7V5H6v4l5 3-5 3v4h12v-2M6 5h12v2"/></symbol>
        <symbol id="vditor-icon-mermaid" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" d="M4 4h7v7H4z"/><path fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" d="M13 13h7v7h-7z"/><path fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" d="M11 11v0c.7 1.4 1.6 2 2 2"/><path fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" d="M7.5 11v5.5M7.5 16.5c2 0 3.5-1.5 3.5-3.5"/></symbol>
        <symbol id="vditor-icon-zhihu" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" d="M4 7c6 0 10-2 12-3 0 4-2 8-5 11l-3 5c6-2 10-6 12-9"/></symbol>
      </defs>
    </svg>

    

    <style>
        /* ========== Vditor 图标统一样式：24px viewBox / 1.7 线宽 / 圆角 / 16px 展示 ========== */
        .vditor-toolbar svg,
        .vditor-menu svg,
        .vditor-panel svg,
        .vditor-popover svg,
        .vditor-hint svg,
        .vditor-icon {
            width: 16px !important;
            height: 16px !important;
            fill: none !important;
            color: #4b5563 !important;
        }
        .vditor-toolbar__item:hover svg,
        .vditor-toolbar__item--active svg,
        .vditor-menu__item:hover svg,
        .vditor-menu__item--current svg {
            color: #2563eb !important;
        }
        .vditor-toolbar__item--disabled svg {
            color: #c0c4cc !important;
        }

        /* ========== 工具栏布局：flex 整齐排列，避免按钮重叠错位 ========== */
        .vditor-toolbar {
            display: flex !important;
            flex-wrap: wrap !important;
            align-items: center;
            row-gap: 2px;
        }
        .vditor-toolbar__item {
            float: none !important;
        }
    </style>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body class="bg-gray-100 dark:bg-gray-900 h-screen h-dvh overflow-hidden" x-data="adminLayout()">

    <div class="flex h-full">

        
        <div x-show="mobileSidebarOpen"
             @click="mobileSidebarOpen = false"
             x-transition:enter="transition-opacity ease-linear duration-300"
             x-transition:enter-start="opacity-0"
             x-transition:enter-end="opacity-100"
             x-transition:leave="transition-opacity ease-linear duration-300"
             x-transition:leave-start="opacity-100"
             x-transition:leave-end="opacity-0"
             class="fixed inset-0 bg-black bg-opacity-50 z-40 md:hidden"
             style="display: none;"></div>

        
        <aside
            :class="mobileSidebarOpen ? 'translate-x-0' : ''"
            class="w-52 bg-gray-800 text-white flex flex-col fixed inset-y-0 left-0 z-50 -translate-x-full md:translate-x-0 transition-transform duration-300 ease-in-out overflow-hidden">

            
            <div class="flex items-center justify-between h-16 border-b border-gray-700 px-3 flex-shrink-0">
                <a href="<?php echo e(route('admin.dashboard')); ?>"
                   class="text-xl font-bold tracking-wide truncate transition-opacity duration-200">
                    <?php echo e(\App\Models\SiteConfig::getInstance()->site_name ?? 'Blog'); ?>

                </a>

                
                <button @click="mobileSidebarOpen = false"
                        class="md:hidden p-2 rounded-lg text-gray-400 hover:text-white hover:bg-gray-700 transition-colors flex-shrink-0">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                    </svg>
                </button>
            </div>

                <?php
                $blogRoutes = ['admin.posts.*', 'admin.categories.*', 'admin.tags.*', 'admin.comments.*', 'admin.messages.*', 'admin.settings.blog', 'admin.about.*'];
                $blogActive = collect($blogRoutes)->contains(fn($r) => request()->routeIs($r));
                $settingsRoutes = ['admin.settings.*', 'admin.update.*'];
                $settingsActive = collect($settingsRoutes)->contains(fn($r) => request()->routeIs($r));
                $adminRoutes = ['admin.users.*', 'admin.logs.*', 'admin.captcha.*', 'admin.visits.*'];
                $adminActive = collect($adminRoutes)->contains(fn($r) => request()->routeIs($r));
            ?>

            
            <nav class="flex-1 overflow-y-auto py-4 px-3 space-y-1">
                
                <a href="<?php echo e(route('admin.dashboard')); ?>"
                   @click="navigateToPage()"
                   class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm <?php echo e(request()->routeIs('admin.dashboard') ? 'bg-gray-700 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white'); ?> transition-colors whitespace-nowrap overflow-hidden">
                    <svg class="w-5 h-5 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/></svg>
                    <span>控制台</span>
                </a>

                
                <div>
                    <button @click="toggleSubmenu()"
                            class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm w-full text-left <?php echo e($blogActive ? 'text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white'); ?> transition-colors whitespace-nowrap overflow-hidden">
                        <svg class="w-5 h-5 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z"/></svg>
                        <span class="flex-1">博客管理</span>
                        <svg class="w-4 h-4 shrink-0 transition-transform"
                             :class="submenuOpen ? 'rotate-90' : ''"
                             fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
                        </svg>
                    </button>

                    
                    <div x-show="submenuOpen"
                         x-cloak
                         x-transition:enter="transition ease-out duration-200"
                         x-transition:enter-start="opacity-0 -translate-y-2"
                         x-transition:enter-end="opacity-100 translate-y-0"
                         x-transition:leave="transition ease-in duration-150"
                         x-transition:leave-start="opacity-100 translate-y-0"
                         x-transition:leave-end="opacity-0 -translate-y-2"
                         class="ml-6 mt-1 space-y-1">
                        <a href="<?php echo e(route('admin.posts.index')); ?>"
                           @click="navigateToPage()"
                           class="flex items-center gap-2 px-3 py-2 rounded-lg text-sm <?php echo e(request()->routeIs('admin.posts.*') ? 'bg-gray-700 text-white' : 'text-gray-400 hover:bg-gray-700 hover:text-white'); ?> transition-colors whitespace-nowrap">
                            <span class="w-1 h-1 rounded-full <?php echo e(request()->routeIs('admin.posts.*') ? 'bg-blue-400' : 'bg-gray-500'); ?>"></span>
                            博客文章
                        </a>
                        <a href="<?php echo e(route('admin.categories.index')); ?>"
                           @click="navigateToPage()"
                           class="flex items-center gap-2 px-3 py-2 rounded-lg text-sm <?php echo e(request()->routeIs('admin.categories.*') ? 'bg-gray-700 text-white' : 'text-gray-400 hover:bg-gray-700 hover:text-white'); ?> transition-colors whitespace-nowrap">
                             <span class="w-1 h-1 rounded-full <?php echo e(request()->routeIs('admin.categories.*') ? 'bg-blue-400' : 'bg-gray-500'); ?>"></span>
                            博客分类
                        </a>
                        <a href="<?php echo e(route('admin.tags.index')); ?>"
                           @click="navigateToPage()"
                           class="flex items-center gap-2 px-3 py-2 rounded-lg text-sm <?php echo e(request()->routeIs('admin.tags.*') ? 'bg-gray-700 text-white' : 'text-gray-400 hover:bg-gray-700 hover:text-white'); ?> transition-colors whitespace-nowrap">
                            <span class="w-1 h-1 rounded-full <?php echo e(request()->routeIs('admin.tags.*') ? 'bg-blue-400' : 'bg-gray-500'); ?>"></span>
                            博客标签
                        </a>
                        <a href="<?php echo e(route('admin.comments.index')); ?>"
                           @click="navigateToPage()"
                           class="flex items-center gap-2 px-3 py-2 rounded-lg text-sm <?php echo e(request()->routeIs('admin.comments.*') ? 'bg-gray-700 text-white' : 'text-gray-400 hover:bg-gray-700 hover:text-white'); ?> transition-colors whitespace-nowrap">
                            <span class="w-1 h-1 rounded-full <?php echo e(request()->routeIs('admin.comments.*') ? 'bg-blue-400' : 'bg-gray-500'); ?>"></span>
                            博客评论
                        </a>
                        <a href="<?php echo e(route('admin.messages.index')); ?>"
                           @click="navigateToPage()"
                           class="flex items-center gap-2 px-3 py-2 rounded-lg text-sm <?php echo e(request()->routeIs('admin.messages.*') ? 'bg-gray-700 text-white' : 'text-gray-400 hover:bg-gray-700 hover:text-white'); ?> transition-colors whitespace-nowrap">
                            <span class="w-1 h-1 rounded-full <?php echo e(request()->routeIs('admin.messages.*') ? 'bg-blue-400' : 'bg-gray-500'); ?>"></span>
                            博客留言
                        </a>
                        <a href="<?php echo e(route('admin.settings.blog')); ?>"
                           @click="navigateToPage()"
                           class="flex items-center gap-2 px-3 py-2 rounded-lg text-sm <?php echo e(request()->routeIs('admin.settings.blog') ? 'bg-gray-700 text-white' : 'text-gray-400 hover:bg-gray-700 hover:text-white'); ?> transition-colors whitespace-nowrap">
                            <span class="w-1 h-1 rounded-full <?php echo e(request()->routeIs('admin.settings.blog') ? 'bg-blue-400' : 'bg-gray-500'); ?>"></span>
                            博客设置
                        </a>
                        <a href="<?php echo e(route('admin.about.edit')); ?>"
                           @click="navigateToPage()"
                           class="flex items-center gap-2 px-3 py-2 rounded-lg text-sm <?php echo e(request()->routeIs('admin.about.*') ? 'bg-gray-700 text-white' : 'text-gray-400 hover:bg-gray-700 hover:text-white'); ?> transition-colors whitespace-nowrap">
                            <span class="w-1 h-1 rounded-full <?php echo e(request()->routeIs('admin.about.*') ? 'bg-blue-400' : 'bg-gray-500'); ?>"></span>
                            关于博主
                        </a>
                    </div>
                </div>

                
                <div>
                    <button @click="toggleSettingsSubmenu()"
                            class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm w-full text-left <?php echo e($settingsActive ? 'text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white'); ?> transition-colors whitespace-nowrap overflow-hidden">
                        <svg class="w-5 h-5 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                        <span class="flex-1">系统设置</span>
                        <svg class="w-4 h-4 shrink-0 transition-transform"
                             :class="settingsSubmenuOpen ? 'rotate-90' : ''"
                             fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
                        </svg>
                    </button>

                    
                    <div x-show="settingsSubmenuOpen"
                         x-cloak
                         x-transition:enter="transition ease-out duration-200"
                         x-transition:enter-start="opacity-0 -translate-y-2"
                         x-transition:enter-end="opacity-100 translate-y-0"
                         x-transition:leave="transition ease-in duration-150"
                         x-transition:leave-start="opacity-100 translate-y-0"
                         x-transition:leave-end="opacity-0 -translate-y-2"
                         class="ml-6 mt-1 space-y-1">
                        <a href="<?php echo e(route('admin.settings.base')); ?>"
                           @click="navigateToPage()"
                           class="flex items-center gap-2 px-3 py-2 rounded-lg text-sm <?php echo e(request()->routeIs('admin.settings.base') ? 'bg-gray-700 text-white' : 'text-gray-400 hover:bg-gray-700 hover:text-white'); ?> transition-colors whitespace-nowrap">
                            <span class="w-1 h-1 rounded-full <?php echo e(request()->routeIs('admin.settings.base') ? 'bg-blue-400' : 'bg-gray-500'); ?>"></span>
                            基础设置
                        </a>
                        <a href="<?php echo e(route('admin.settings.appearance')); ?>"
                           @click="navigateToPage()"
                           class="flex items-center gap-2 px-3 py-2 rounded-lg text-sm <?php echo e(request()->routeIs('admin.settings.appearance') ? 'bg-gray-700 text-white' : 'text-gray-400 hover:bg-gray-700 hover:text-white'); ?> transition-colors whitespace-nowrap">
                            <span class="w-1 h-1 rounded-full <?php echo e(request()->routeIs('admin.settings.appearance') ? 'bg-blue-400' : 'bg-gray-500'); ?>"></span>
                            站点外观
                        </a>
                        <a href="<?php echo e(route('admin.settings.ai')); ?>"
                           @click="navigateToPage()"
                           class="flex items-center gap-2 px-3 py-2 rounded-lg text-sm <?php echo e(request()->routeIs('admin.settings.ai') ? 'bg-gray-700 text-white' : 'text-gray-400 hover:bg-gray-700 hover:text-white'); ?> transition-colors whitespace-nowrap">
                            <span class="w-1 h-1 rounded-full <?php echo e(request()->routeIs('admin.settings.ai') ? 'bg-blue-400' : 'bg-gray-500'); ?>"></span>
                            AI配置
                        </a>
                        <a href="<?php echo e(route('admin.settings.custom-code')); ?>"
                           @click="navigateToPage()"
                           class="flex items-center gap-2 px-3 py-2 rounded-lg text-sm <?php echo e(request()->routeIs('admin.settings.custom-code') ? 'bg-gray-700 text-white' : 'text-gray-400 hover:bg-gray-700 hover:text-white'); ?> transition-colors whitespace-nowrap">
                            <span class="w-1 h-1 rounded-full <?php echo e(request()->routeIs('admin.settings.custom-code') ? 'bg-blue-400' : 'bg-gray-500'); ?>"></span>
                            自定义代码
                        </a>
                        <a href="<?php echo e(route('admin.settings.image-compress')); ?>"
                            @click="navigateToPage()"
                            class="flex items-center gap-2 px-3 py-2 rounded-lg text-sm <?php echo e(request()->routeIs('admin.settings.image-compress') ? 'bg-gray-700 text-white' : 'text-gray-400 hover:bg-gray-700 hover:text-white'); ?> transition-colors whitespace-nowrap">
                             <span class="w-1 h-1 rounded-full <?php echo e(request()->routeIs('admin.settings.image-compress') ? 'bg-blue-400' : 'bg-gray-500'); ?>"></span>
                             图片压缩
                         </a>
                        <a href="<?php echo e(route('admin.update.index')); ?>"
                            @click="navigateToPage()"
                            class="flex items-center gap-2 px-3 py-2 rounded-lg text-sm <?php echo e(request()->routeIs('admin.update.*') ? 'bg-gray-700 text-white' : 'text-gray-400 hover:bg-gray-700 hover:text-white'); ?> transition-colors whitespace-nowrap">
                             <span class="w-1 h-1 rounded-full <?php echo e(request()->routeIs('admin.update.*') ? 'bg-blue-400' : 'bg-gray-500'); ?>"></span>
                             在线升级
                         </a>
                    </div>
                </div>

                
                <div>
                    <button @click="toggleAdminSubmenu()"
                            class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm w-full text-left <?php echo e($adminActive ? 'text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white'); ?> transition-colors whitespace-nowrap overflow-hidden">
                        <svg class="w-5 h-5 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z"/></svg>
                        <span class="flex-1">后台管理</span>
                        <svg class="w-4 h-4 shrink-0 transition-transform"
                              :class="adminSubmenuOpen ? 'rotate-90' : ''"
                              fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
                        </svg>
                    </button>

                    
                    <div x-show="adminSubmenuOpen"
                         x-cloak
                         x-transition:enter="transition ease-out duration-200"
                         x-transition:enter-start="opacity-0 -translate-y-2"
                         x-transition:enter-end="opacity-100 translate-y-0"
                         x-transition:leave="transition ease-in duration-150"
                         x-transition:leave-start="opacity-100 translate-y-0"
                         x-transition:leave-end="opacity-0 -translate-y-2"
                         class="ml-6 mt-1 space-y-1">
                         <a href="<?php echo e(route('admin.users.index')); ?>"
                            @click="navigateToPage()"
                            class="flex items-center gap-2 px-3 py-2 rounded-lg text-sm <?php echo e(request()->routeIs('admin.users.*') ? 'bg-gray-700 text-white' : 'text-gray-400 hover:bg-gray-700 hover:text-white'); ?> transition-colors whitespace-nowrap">
                             <span class="w-1 h-1 rounded-full <?php echo e(request()->routeIs('admin.users.*') ? 'bg-blue-400' : 'bg-gray-500'); ?>"></span>
                             用户管理
                         </a>
                         <a href="<?php echo e(route('admin.logs.index')); ?>"
                            @click="navigateToPage()"
                            class="flex items-center gap-2 px-3 py-2 rounded-lg text-sm <?php echo e(request()->routeIs('admin.logs.*') ? 'bg-gray-700 text-white' : 'text-gray-400 hover:bg-gray-700 hover:text-white'); ?> transition-colors whitespace-nowrap">
                             <span class="w-1 h-1 rounded-full <?php echo e(request()->routeIs('admin.logs.*') ? 'bg-blue-400' : 'bg-gray-500'); ?>"></span>
                             管理日志
                         </a>
                         <a href="<?php echo e(route('admin.captcha.index')); ?>"
                            @click="navigateToPage()"
                            class="flex items-center gap-2 px-3 py-2 rounded-lg text-sm <?php echo e(request()->routeIs('admin.captcha.*') ? 'bg-gray-700 text-white' : 'text-gray-400 hover:bg-gray-700 hover:text-white'); ?> transition-colors whitespace-nowrap">
                             <span class="w-1 h-1 rounded-full <?php echo e(request()->routeIs('admin.captcha.*') ? 'bg-blue-400' : 'bg-gray-500'); ?>"></span>
                             动态验证码
                         </a>
                         <a href="<?php echo e(route('admin.visits.index')); ?>"
                            @click="navigateToPage()"
                            class="flex items-center gap-2 px-3 py-2 rounded-lg text-sm <?php echo e(request()->routeIs('admin.visits.*') ? 'bg-gray-700 text-white' : 'text-gray-400 hover:bg-gray-700 hover:text-white'); ?> transition-colors whitespace-nowrap">
                             <span class="w-1 h-1 rounded-full <?php echo e(request()->routeIs('admin.visits.*') ? 'bg-blue-400' : 'bg-gray-500'); ?>"></span>
                             浏览量
                         </a>
                 </div>
             </div>

                 
                <a href="<?php echo e(route('admin.navigations.index', ['position' => 'head'])); ?>"
                   @click="navigateToPage()"
                   class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm <?php echo e(request()->routeIs('admin.navigations.*') ? 'bg-gray-700 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white'); ?> transition-colors whitespace-nowrap overflow-hidden">
                    <svg class="w-5 h-5 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h8m-8 6h16"/></svg>
                    <span>导航设置</span>
                </a>

                
                <a href="<?php echo e(route('admin.slides.index')); ?>"
                   @click="navigateToPage()"
                   class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm <?php echo e(request()->routeIs('admin.slides.*') ? 'bg-gray-700 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white'); ?> transition-colors whitespace-nowrap overflow-hidden">
                    <svg class="w-5 h-5 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 4v16l13-8z"/></svg>
                    <span>幻灯片轮播</span>
                </a>

                
                <a href="<?php echo e(route('admin.friend-links.index')); ?>"
                   @click="navigateToPage()"
                   class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm <?php echo e(request()->routeIs('admin.friend-links.*') ? 'bg-gray-700 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white'); ?> transition-colors whitespace-nowrap overflow-hidden">
                    <svg class="w-5 h-5 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"/></svg>
                    <span>友情链接</span>
                </a>

            </nav>
        </aside>

        
        <div class="flex-1 flex flex-col min-w-0 ms-0 md:ms-52">

            <header class="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 h-16 flex items-center justify-between px-4 sm:px-6 sticky top-0 z-20">
                <div class="flex items-center gap-3 min-w-0">
                    
                    <button @click="mobileSidebarOpen = true"
                            class="md:hidden p-2 text-gray-500 hover:text-gray-700 rounded-lg hover:bg-gray-100 transition-colors shrink-0">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/>
                        </svg>
                    </button>
                    <div class="text-sm text-gray-500 truncate">
                        <?php echo $__env->yieldContent('page-title', '管理后台'); ?>
                    </div>
                </div>

                
                <div class="flex items-center gap-0.5 sm:gap-1 shrink-0 min-w-0">

                    
                    <a href="<?php echo e(route('blog.index')); ?>" target="_blank" title="访问首页"
                       class="group relative p-2 text-gray-500 hover:text-gray-700 rounded-lg hover:bg-gray-100 transition-colors">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/></svg>
                        <span class="pointer-events-none absolute -bottom-8 left-1/2 -translate-x-1/2 whitespace-nowrap bg-gray-900 text-white text-xs px-2 py-1 rounded-md opacity-0 group-hover:opacity-100 transition-opacity z-50 shadow-lg">访问首页</span>
                    </a>

                    
                    <button type="button" @click="toggleFullscreen()" title="全屏"
                            class="group relative p-2 text-gray-500 hover:text-gray-700 rounded-lg hover:bg-gray-100 transition-colors">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 8V6a2 2 0 012-2h2M17 4h2a2 2 0 012 2v2M20 16v2a2 2 0 01-2 2h-2M8 20H6a2 2 0 01-2-2v-2"/></svg>
                        <span class="pointer-events-none absolute -bottom-8 left-1/2 -translate-x-1/2 whitespace-nowrap bg-gray-900 text-white text-xs px-2 py-1 rounded-md opacity-0 group-hover:opacity-100 transition-opacity z-50 shadow-lg">全屏</span>
                    </button>

                    
                    <form action="<?php echo e(route('admin.cache.clear')); ?>" method="POST" class="group relative" onsubmit="return confirm('确定要清除缓存吗？')">
                        <?php echo csrf_field(); ?>
                        <button type="submit" title="清除缓存"
                                class="p-2 text-gray-500 hover:text-gray-700 rounded-lg hover:bg-gray-100 transition-colors">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                        </button>
                        <span class="pointer-events-none absolute -bottom-8 left-1/2 -translate-x-1/2 whitespace-nowrap bg-gray-900 text-white text-xs px-2 py-1 rounded-md opacity-0 group-hover:opacity-100 transition-opacity z-50 shadow-lg">清除缓存</span>
                    </form>

                    
                    <div class="relative ml-1 sm:ml-2" x-data="{ userMenuOpen: false }">
                        <button @click="userMenuOpen = !userMenuOpen" title="<?php echo e(auth()->user()->name ?? 'admin'); ?>"
                                class="flex items-center gap-2 text-sm text-gray-700 rounded-lg hover:bg-gray-100 p-1.5 pr-2 transition-colors">
                            <div class="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center text-xs font-medium text-gray-600 shrink-0">
                                <?php echo e(mb_substr(auth()->user()->name ?? 'A', 0, 1)); ?>

                            </div>
                            <span class="hidden sm:inline max-w-[6rem] truncate"><?php echo e(auth()->user()->name ?? ''); ?></span>
                            <svg class="w-4 h-4 text-gray-400 shrink-0 transition-transform" :class="userMenuOpen ? 'rotate-180' : ''" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
                        </button>

                        <div x-show="userMenuOpen" @click.outside="userMenuOpen = false" x-cloak
                             x-transition:enter="transition ease-out duration-100"
                             x-transition:enter-start="opacity-0 scale-95"
                             x-transition:enter-end="opacity-100 scale-100"
                             x-transition:leave="transition ease-in duration-75"
                             x-transition:leave-start="opacity-100 scale-100"
                             x-transition:leave-end="opacity-0 scale-95"
                             class="absolute right-0 mt-2 w-44 bg-white rounded-lg shadow-lg border border-gray-200 py-1 z-50">
                            <a href="<?php echo e(route('admin.password.edit')); ?>" @click="userMenuOpen = false"
                               class="flex items-center gap-2 px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 transition-colors">
                                <svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/></svg>
                                修改密码
                            </a>
                            <form action="<?php echo e(route('admin.logout')); ?>" method="POST" @submit="userMenuOpen = false">
                                <?php echo csrf_field(); ?>
                                <button type="submit"
                                        class="flex items-center gap-2 w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50 transition-colors">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/></svg>
                                    注销退出登录
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </header>

            <main class="flex-1 p-6 overflow-y-auto admin-main-scroll" style="height: calc(100vh - 64px); height: calc(100dvh - 64px);">
                <?php echo $__env->yieldContent('content'); ?>

                
                <?php if($settingsActive): ?>
                <div class="h-24 md:h-28 shrink-0" aria-hidden="true"></div>
                <?php endif; ?>
            </main>
        </div>
    </div>

    
    <script>
        function adminLayout() {
            return {
                // [移动端] 抽屉打开/关闭状态
                mobileSidebarOpen: false,
                // 博客管理子菜单展开状态
                submenuOpen: <?php echo e($blogActive ? 'true' : 'false'); ?>,
                 // 系统设置子菜单展开状态
                 settingsSubmenuOpen: <?php echo e($settingsActive ? 'true' : 'false'); ?>,
                 // 后台管理子菜单展开状态
                 adminSubmenuOpen: <?php echo e($adminActive ? 'true' : 'false'); ?>,

                // 切换博客管理子菜单
                toggleSubmenu() {
                    this.submenuOpen = !this.submenuOpen;
                },
                // 切换系统设置子菜单
                toggleSettingsSubmenu() {
                    this.settingsSubmenuOpen = !this.settingsSubmenuOpen;
                },
                // 切换后台管理子菜单
                toggleAdminSubmenu() {
                    this.adminSubmenuOpen = !this.adminSubmenuOpen;
                },

                // 切换浏览器全屏
                toggleFullscreen() {
                    if (!document.fullscreenElement) {
                        document.documentElement.requestFullscreen();
                    } else {
                        document.exitFullscreen();
                    }
                },

                // 点击任意一级/二级菜单跳转页面后：关闭抽屉（仅移动端生效）
                navigateToPage() {
                    this.mobileSidebarOpen = false;
                },
            }
        }
    </script>

    
    <style>
        [x-cloak] { display: none !important; }

        /* 隐藏滚动条 */
        aside::-webkit-scrollbar { width: 0; background: transparent; }
        aside { -ms-overflow-style: none; scrollbar-width: none; }

        /* ===== 主内容统一滚动容器 =====
           保证鼠标滚轮（含 iPad 外接鼠标）与触屏滑动行为一致，
           全部作用于右侧主内容区域整体滚动，避免局部滚动异常 */
        .admin-main-scroll {
            -webkit-overflow-scrolling: touch;   /* iOS 触屏平滑滚动 */
            overscroll-behavior-y: contain;      /* 阻止滚动冒泡到页面/局部区域 */
            scrollbar-width: thin;
        }
        .admin-main-scroll::-webkit-scrollbar { width: 6px; height: 6px; }
        .admin-main-scroll::-webkit-scrollbar-thumb { background: rgba(156, 163, 175, 0.35); border-radius: 3px; }
        .admin-main-scroll::-webkit-scrollbar-track { background: transparent; }

        /* ===== 全局提示弹窗 ===== */
        #global-notify {
            position: fixed;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            z-index: 9999;
            width: auto;
            max-width: calc(100vw - 32px);
            pointer-events: none;
        }
        .notify-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 12px 16px;
            background: #fff;
            border: 1px solid #e5e7eb;
            border-radius: 10px;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.12);
            font-size: 14px;
            color: #374151;
            pointer-events: auto;
            opacity: 0;
            transform: translateY(-8px);
            transition: opacity 0.25s ease, transform 0.25s ease;
        }
        .notify-item.show {
            opacity: 1;
            transform: translateY(0);
        }
        .notify-icon {
            width: 20px;
            height: 20px;
            border-radius: 50%;
            flex-shrink: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            font-weight: 700;
            color: #fff;
        }
        .notify-icon.success { background: #10b981; }
        .notify-icon.error { background: #ef4444; }
        .notify-close {
            margin-left: 6px;
            padding: 2px;
            border: none;
            background: transparent;
            color: #9ca3af;
            font-size: 16px;
            line-height: 1;
            cursor: pointer;
            border-radius: 4px;
            display: flex;
        }
        .notify-close:hover { color: #4b5563; }
        /* 移动端适配：弹窗全宽展示 */
        @media (max-width: 640px) {
            #global-notify {
                top: 12px;
                left: 16px;
                right: 16px;
                transform: none;
                max-width: none;
            }
            .notify-item { width: 100%; }
        }
    </style>

    
    <div id="global-notify"></div>

    
    <script>
        (function () {
            var container = document.getElementById('global-notify');
            var current = null;

            window.notify = function (message, type) {
                type = type || 'success';
                // 移除已有弹窗，避免堆叠
                if (current) { current.remove(); current = null; }

                var item = document.createElement('div');
                item.className = 'notify-item';

                var icon = document.createElement('span');
                icon.className = 'notify-icon ' + (type === 'error' ? 'error' : 'success');
                icon.textContent = type === 'error' ? '✕' : '✓';

                var text = document.createElement('span');
                text.textContent = message;

                var close = document.createElement('button');
                close.type = 'button';
                close.className = 'notify-close';
                close.setAttribute('aria-label', '关闭');
                close.innerHTML = '&times;';

                item.appendChild(icon);
                item.appendChild(text);
                item.appendChild(close);
                container.appendChild(item);

                // 触发入场动画
                requestAnimationFrame(function () {
                    item.classList.add('show');
                });

                // 手动关闭
                close.addEventListener('click', function () { dismiss(); });

                var timer = setTimeout(dismiss, type === 'error' ? 4000 : 3000);

                function dismiss() {
                    clearTimeout(timer);
                    item.classList.remove('show');
                    setTimeout(function () {
                        item.remove();
                        if (current === item) { current = null; }
                    }, 250);
                }
                current = item;
            };
        })();

        // 服务端 flash 消息 → 弹窗
        document.addEventListener('DOMContentLoaded', function () {
            <?php if(session('success')): ?>
                window.notify(<?php echo json_encode(session('success')); ?>, 'success');
            <?php endif; ?>
            <?php if(session('error')): ?>
                window.notify(<?php echo json_encode(session('error')); ?>, 'error');
            <?php endif; ?>
        });
    </script>
</body>
</html>
<?php /**PATH C:\web1\resources\views/layouts/admin.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', '步骤四：创建管理员'); ?>

<?php $__env->startSection('content'); ?>
    <h2 class="text-lg font-semibold text-gray-900 mb-1">创建管理员</h2>
    <p class="text-sm text-gray-500 mb-6">设置站点信息并创建后台超级管理员账户</p>

    <form action="<?php echo e(route('install.step4.save')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="mb-6">
            <h3 class="text-sm font-semibold text-gray-700 mb-3 flex items-center">
                <i class="fa-solid fa-globe text-blue-500 mr-2"></i>站点信息
            </h3>

            <div class="mb-4">
                <label for="site_name" class="block text-sm font-medium text-gray-700 mb-2">站点名称 <span class="text-red-500">*</span></label>
                <input type="text" name="site_name" id="site_name" value="<?php echo e(old('site_name', '我的博客')); ?>" required placeholder="我的博客" class="w-full px-4 py-2.5 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                <?php $__errorArgs = ['site_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-xs text-red-500"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="mb-8">
            <h3 class="text-sm font-semibold text-gray-700 mb-3 flex items-center">
                <i class="fa-solid fa-user-shield text-blue-500 mr-2"></i>超级管理员账户
            </h3>

            <div class="mb-4">
                <label for="admin_name" class="block text-sm font-medium text-gray-700 mb-2">管理员用户名 <span class="text-red-500">*</span></label>
                <input type="text" name="admin_name" id="admin_name" value="<?php echo e(old('admin_name', 'admin')); ?>" required placeholder="请输入管理员用户名" class="w-full px-4 py-2.5 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                <?php $__errorArgs = ['admin_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-xs text-red-500"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-4">
                <label for="admin_email" class="block text-sm font-medium text-gray-700 mb-2">管理员邮箱 <span class="text-red-500">*</span></label>
                <input type="email" name="admin_email" id="admin_email" value="<?php echo e(old('admin_email', 'admin@admin.com')); ?>" required placeholder="admin@example.com" class="w-full px-4 py-2.5 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                <?php $__errorArgs = ['admin_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-xs text-red-500"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-4">
                <label for="admin_password" class="block text-sm font-medium text-gray-700 mb-2">管理员密码 <span class="text-red-500">*</span></label>
                <input type="password" name="admin_password" id="admin_password" value="<?php echo e(old('admin_password', 'admin')); ?>" required placeholder="请输入密码（至少5位）" class="w-full px-4 py-2.5 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                <?php $__errorArgs = ['admin_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-xs text-red-500"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-4">
                <label for="admin_password_confirmation" class="block text-sm font-medium text-gray-700 mb-2">确认密码 <span class="text-red-500">*</span></label>
                <input type="password" name="admin_password_confirmation" id="admin_password_confirmation" value="<?php echo e(old('admin_password_confirmation', 'admin')); ?>" required placeholder="请再次输入密码" class="w-full px-4 py-2.5 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
            </div>
        </div>

        <div class="flex items-center justify-between pt-4 border-t border-gray-100">
            <a href="<?php echo e(route('install.step3')); ?>" class="inline-flex items-center px-4 py-2.5 text-sm font-medium text-gray-700 hover:text-gray-900 transition-colors">
                <i class="fa-solid fa-arrow-left mr-2"></i>上一步
            </a>
            <button type="submit" class="inline-flex items-center px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium rounded-lg transition-colors">
                <i class="fa-solid fa-check mr-2"></i>完成安装
            </button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('install.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\web1\resources\views/install/step4.blade.php ENDPATH**/ ?>
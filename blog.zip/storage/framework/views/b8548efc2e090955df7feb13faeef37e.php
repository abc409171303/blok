<?php $__env->startSection('page-title', '浏览量'); ?>

<?php $__env->startSection('content'); ?>
<div>
    <h1 class="text-2xl font-bold text-gray-800 mb-6">浏览量</h1>

    
    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-4 mb-4">
        <form method="GET" action="<?php echo e(route('admin.visits.index')); ?>" class="flex flex-wrap items-end gap-3">
            <div>
                <label for="start" class="block text-xs text-gray-500 mb-1">开始日期</label>
                <input type="date" id="start" name="start" value="<?php echo e($start->format('Y-m-d')); ?>"
                       class="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none">
            </div>
            <div>
                <label for="end" class="block text-xs text-gray-500 mb-1">结束日期</label>
                <input type="date" id="end" name="end" value="<?php echo e($end->format('Y-m-d')); ?>"
                       class="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none">
            </div>
            <button type="submit"
                    class="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm transition-colors">查询</button>
            <a href="<?php echo e(route('admin.visits.index', ['start' => now()->subDays(6)->format('Y-m-d'), 'end' => now()->format('Y-m-d')])); ?>"
               class="px-4 py-2 rounded-lg text-sm transition-colors border border-gray-300 text-gray-600 hover:bg-gray-50 <?php echo e($start->format('Y-m-d') === now()->subDays(6)->format('Y-m-d') && $end->format('Y-m-d') === now()->format('Y-m-d') ? 'bg-blue-50 border-blue-300 text-blue-600' : ''); ?>">近7天</a>
        </form>
    </div>

    
    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-5">
            <div class="flex items-center justify-between mb-3">
                <div class="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                    <svg class="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
                </div>
            </div>
            <div class="text-3xl font-bold text-gray-800"><?php echo e(number_format($pv)); ?></div>
            <div class="text-sm text-gray-500 mt-1">访问量 PV <span class="text-gray-400">（<?php echo e($start->format('Y-m-d')); ?> ~ <?php echo e($end->format('Y-m-d')); ?>）</span></div>
        </div>

        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-5">
            <div class="flex items-center justify-between mb-3">
                <div class="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                    <svg class="w-5 h-5 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
                </div>
            </div>
            <div class="text-3xl font-bold text-gray-800"><?php echo e(number_format($uv)); ?></div>
            <div class="text-sm text-gray-500 mt-1">独立访客 UV <span class="text-gray-400">（<?php echo e($start->format('Y-m-d')); ?> ~ <?php echo e($end->format('Y-m-d')); ?>）</span></div>
        </div>
    </div>

    
    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-5 mb-4">
        <h2 class="text-base font-semibold text-gray-800 mb-4">访问趋势</h2>
        <div id="visit-chart" style="width: 100%; height: 360px;"></div>
        <p class="text-xs text-gray-400 mt-2 hidden" id="chart-fallback-tip">图表组件加载失败，仅影响本图表显示。</p>
    </div>

    
    <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div class="px-5 py-4 border-b border-gray-100">
            <h2 class="text-base font-semibold text-gray-800">访客访问明细</h2>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead>
                    <tr class="bg-gray-50 text-gray-500 text-left">
                        <th class="px-5 py-3 font-medium whitespace-nowrap">访问时间</th>
                        <th class="px-5 py-3 font-medium">访客 IP</th>
                        <th class="px-5 py-3 font-medium">访问页面地址</th>
                        <th class="px-5 py-3 font-medium">浏览器 UA</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php $__empty_1 = true; $__currentLoopData = $visits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-gray-50 transition-colors">
                        <td class="px-5 py-3 text-gray-600 whitespace-nowrap"><?php echo e($visit->created_at->format('Y-m-d H:i:s')); ?></td>
                        <td class="px-5 py-3 font-mono text-gray-700 whitespace-nowrap"><?php echo e($visit->ip); ?></td>
                        <td class="px-5 py-3 max-w-[240px]">
                            <span class="text-blue-600 break-all line-clamp-1" title="/<?php echo e($visit->url); ?>">/<?php echo e($visit->url); ?></span>
                        </td>
                        <td class="px-5 py-3 max-w-[260px]">
                            <span class="text-gray-500 block truncate" title="<?php echo e($visit->user_agent); ?>"><?php echo e($visit->user_agent); ?></span>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4" class="px-5 py-10 text-center text-gray-400">该时间段暂无访问记录</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="px-5 py-4 border-t border-gray-100">
            <?php echo e($visits->links()); ?>

        </div>
    </div>
</div>


<script>
(function () {
    var chartData = <?php echo json_encode($chart); ?>;
    var el = document.getElementById('visit-chart');
    var tip = document.getElementById('chart-fallback-tip');
    if (!el || !chartData) { return; }

    function initChart() {
        if (!window.echarts) { return; }
        var chart = echarts.init(el);
        chart.setOption({
            color: ['#3b82f6', '#f59e0b'],
            tooltip: {
                trigger: 'axis',
                backgroundColor: 'rgba(31,41,55,0.9)',
                borderWidth: 0,
                textStyle: { color: '#f9fafb' },
                axisPointer: { type: 'cross', crossStyle: { color: '#999' } }
            },
            legend: { data: ['访问量PV', '访客数UV'], top: 0, textStyle: { color: '#6b7280' } },
            grid: { left: 10, right: 16, top: 40, bottom: 0, containLabel: true },
            xAxis: {
                type: 'category',
                boundaryGap: false,
                data: chartData.dates,
                axisLine: { lineStyle: { color: '#e5e7eb' } },
                axisLabel: { color: '#6b7280' }
            },
            yAxis: {
                type: 'value',
                minInterval: 1,
                axisLine: { show: false },
                splitLine: { lineStyle: { color: '#f3f4f6' } },
                axisLabel: { color: '#6b7280' }
            },
            series: [
                {
                    name: '访问量PV',
                    type: 'line',
                    smooth: true,
                    showSymbol: false,
                    data: chartData.pv,
                    lineStyle: { width: 2 },
                    areaStyle: { opacity: 0.06 }
                },
                {
                    name: '访客数UV',
                    type: 'line',
                    smooth: true,
                    showSymbol: false,
                    data: chartData.uv,
                    lineStyle: { width: 2 },
                    areaStyle: { opacity: 0.06 }
                }
            ]
        });
        window.addEventListener('resize', function () {
            var inst = echarts.getInstanceByDom(el);
            if (inst) { inst.resize(); }
        });
    }

    // 主 CDN：jsDelivr
    var s = document.createElement('script');
    s.src = 'https://cdn.jsdelivr.net/npm/echarts@5.4.3/dist/echarts.min.js';
    s.onload = initChart;
    s.onerror = function () {
        // 兜底 CDN：unpkg
        var s2 = document.createElement('script');
        s2.src = 'https://unpkg.com/echarts@5.4.3/dist/echarts.min.js';
        s2.onload = initChart;
        s2.onerror = function () {
            // 双 CDN 均失败：图表留白，页面其余功能与表格不受影响
            if (tip) { tip.classList.remove('hidden'); }
        };
        document.head.appendChild(s2);
    };
    document.head.appendChild(s);
})();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\web1\resources\views/admin/visits/index.blade.php ENDPATH**/ ?>
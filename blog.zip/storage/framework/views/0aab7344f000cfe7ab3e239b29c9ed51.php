<div class="bg-white rounded-lg shadow-sm overflow-hidden">
    <div class="px-5 py-8 text-center">
        <div class="avatar-ring w-32 h-32 mx-auto rounded-full shadow flex items-center justify-center">
            <?php if($config->site_avatar): ?>
            <img src="<?php echo e(Storage::url($config->site_avatar)); ?>" alt="" class="w-28 h-28 rounded-full object-cover">
            <?php else: ?>
            <div class="w-28 h-28 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center text-white text-3xl font-bold">
                <?php echo e(mb_substr($config->site_name ?? 'B', 0, 1)); ?>

            </div>
            <?php endif; ?>
        </div>
        <div class="text-xl font-semibold text-gray-800 mt-4"><?php echo e($config->site_name ?? '博客'); ?></div>
        <div class="text-gray-400 mt-3 text-base leading-relaxed"><?php echo e($config->site_tagline ?: ($config->site_description ?? "记录点滴，分享生活")); ?></div>
        <?php if(count($contactItems) > 0): ?>
        <div class="mt-4 pt-4 border-t <?php echo e($enableDark ? 'border-[#2a2d42]' : 'border-gray-100'); ?> space-y-2 text-base text-gray-500">
            <?php $__currentLoopData = $contactItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="flex items-center justify-center gap-2">
                <i class="<?php echo e($item['icon']); ?> <?php echo e($item['color']); ?>"></i>
                <span><?php echo e($item['name']); ?></span>
                <?php if($item['url']): ?>
                <a href="<?php echo e($item['url']); ?>" target="_blank" rel="noopener" class="truncate max-w-[220px] <?php echo e($enableDark ? 'hover:text-[#9197ed]' : 'hover:text-blue-600'); ?> transition-colors"><?php echo e($item['label']); ?></a>
                <?php else: ?>
                <span class="truncate max-w-[220px]"><?php echo e($item['label']); ?></span>
                <?php endif; ?>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\web1\resources\views/partials/mobile-author-card.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title', '安装向导'); ?> - 博客安装</title>
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=instrument-sans:400,500,600" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css']); ?>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body class="bg-gray-100 min-h-screen flex items-center justify-center py-10 px-4">
    <div class="w-full max-w-2xl">
        <div class="text-center mb-8">
            <h1 class="text-2xl font-bold text-gray-900 mb-1">
                <i class="fa-solid fa-blog text-blue-600 mr-2"></i>博客安装向导
            </h1>
            <p class="text-sm text-gray-500">请按照步骤完成博客系统的安装</p>
        </div>

        <div class="bg-white rounded-2xl shadow-sm overflow-hidden">
            <?php
                $routeName = request()->route()?->getName() ?? '';
                $currentStep = 1;
                if (str_contains($routeName, 'step2')) { $currentStep = 2; }
                elseif (str_contains($routeName, 'step3')) { $currentStep = 3; }
                elseif (str_contains($routeName, 'step4')) { $currentStep = 4; }
                elseif (str_contains($routeName, 'complete')) { $currentStep = 5; }

                $steps = ['环境检查', '数据库配置', '导入数据表', '创建管理员', '完成'];
            ?>
            <div class="flex items-start justify-between px-2 sm:px-6 py-4 border-b border-gray-200">
                <?php $__currentLoopData = $steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $num = $index + 1; ?>
                    <?php if($index > 0): ?>
                        <div class="flex-1 h-0.5 mt-4 -mx-2 <?php echo e($currentStep > $index ? 'bg-blue-600' : 'bg-gray-200'); ?>"></div>
                    <?php endif; ?>
                    <div class="flex flex-col items-center" style="min-width:56px">
                        <div class="w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold <?php echo e($currentStep >= $num ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-500'); ?>">
                            <?php if($currentStep > $num): ?><i class="fa-solid fa-check text-xs"></i><?php else: ?> <?php echo e($num); ?> <?php endif; ?>
                        </div>
                        <p class="text-xs mt-2 whitespace-nowrap <?php echo e($currentStep >= $num ? 'text-blue-600 font-medium' : 'text-gray-400'); ?>"><?php echo e($label); ?></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="p-6 md:p-8">
                <?php if(session('error')): ?>
                    <div class="mb-6 p-4 bg-red-50 border border-red-200 rounded-xl text-sm text-red-700 flex items-center">
                        <i class="fa-solid fa-circle-exclamation text-red-500 mr-2"></i>
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?>
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>

        <p class="text-center text-xs text-gray-400 mt-6">
            Powered by Blog CMS
        </p>
    </div>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\web1\resources\views/install/layout.blade.php ENDPATH**/ ?>
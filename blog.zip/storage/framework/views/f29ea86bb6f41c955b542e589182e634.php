<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['scene', 'containerClass' => '']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['scene', 'containerClass' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php if(\App\Services\Captcha::enabled($scene)): ?>
<?php $captchaId = 'captcha_img_' . $scene . '_' . uniqid(); ?>
<div class="flex items-center gap-2 flex-wrap <?php echo e($containerClass); ?>">
    <input type="text" name="captcha" value="<?php echo e(old('captcha')); ?>" placeholder="验证码"
           required maxlength="6" autocomplete="off"
           class="px-3 py-2 text-base border border-gray-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-400 focus:border-blue-400 <?php echo e($attributes->get('class')); ?>" <?php echo e($attributes); ?>>
    <img src="<?php echo e(route('captcha.image', ['scene' => $scene])); ?>?v=<?php echo e(time()); ?>"
         alt="验证码" title="点击刷新验证码" style="cursor:pointer;height:40px;border-radius:6px;flex-shrink:0;"
         onclick="this.src='<?php echo e(route('captcha.image', ['scene' => $scene])); ?>?v='+Date.now();">
    <?php echo e($slot); ?>

</div>
<?php $__errorArgs = ['captcha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-sm text-red-500 mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<?php endif; ?>
<?php /**PATH C:\web1\resources\views/components/captcha-input.blade.php ENDPATH**/ ?>
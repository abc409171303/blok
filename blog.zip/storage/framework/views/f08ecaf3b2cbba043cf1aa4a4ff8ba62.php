<?php $__env->startSection('page-title', '基础设置'); ?>

<?php $__env->startSection('content'); ?>
<div>
    <h1 class="text-2xl font-bold text-gray-800 dark:text-white mb-6">基础设置</h1>

    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <form action="<?php echo e(route('admin.settings.base.update')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="space-y-8">
                <!-- 网站信息 -->
                <div>
                    <h2 class="text-lg font-semibold text-gray-800 dark:text-white mb-4 pb-2 border-b border-gray-200 dark:border-gray-700">网站信息</h2>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label for="site_name" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">网站名称 <span class="text-red-500">*</span></label>
                            <input type="text" name="site_name" id="site_name" value="<?php echo e(old('site_name', $config->site_name)); ?>" required
                                class="w-full px-4 py-2.5 border border-gray-300 dark:border-gray-600 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none bg-white dark:bg-gray-700 text-gray-900 dark:text-white">
                        </div>
                        <div>
                            <label for="site_domain" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">网站域名</label>
                            <input type="text" name="site_domain" id="site_domain" value="<?php echo e(old('site_domain', $config->site_domain)); ?>"
                                class="w-full px-4 py-2.5 border border-gray-300 dark:border-gray-600 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                                placeholder="albb.xx.kg">
                        </div>
                        <div>
                            <label for="site_keywords" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">网站关键词</label>
                            <input type="text" name="site_keywords" id="site_keywords" value="<?php echo e(old('site_keywords', $config->site_keywords)); ?>"
                                class="w-full px-4 py-2.5 border border-gray-300 dark:border-gray-600 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                                placeholder="以逗号分隔的关键词">
                        </div>
                        <div>
                            <label for="site_copyright" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">版权信息</label>
                            <input type="text" name="site_copyright" id="site_copyright" value="<?php echo e(old('site_copyright', $config->site_copyright)); ?>"
                                class="w-full px-4 py-2.5 border border-gray-300 dark:border-gray-600 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                                placeholder="Copyright &copy; 2024">
                        </div>
                        <div class="md:col-span-2">
                            <label for="site_description" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">网站描述</label>
                            <textarea name="site_description" id="site_description" rows="3"
                                class="w-full px-4 py-2.5 border border-gray-300 dark:border-gray-600 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none resize-none bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                                placeholder="简要描述您的站点"><?php echo e(old('site_description', $config->site_description)); ?></textarea>
                        </div>
                    </div>
                </div>

                <!-- 主题设置 -->
                <div>
                    <h2 class="text-lg font-semibold text-gray-800 dark:text-white mb-4 pb-2 border-b border-gray-200 dark:border-gray-700">主题设置</h2>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label for="site_color" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">网站主色调</label>
                            <div class="flex items-center gap-3">
                                <input type="color" name="site_color" id="site_color" value="<?php echo e(old('site_color', $config->site_color ?? '#2563eb')); ?>"
                                    class="w-10 h-10 rounded border border-gray-300 dark:border-gray-600 cursor-pointer p-0.5">
                                <span class="text-sm text-gray-500 dark:text-gray-400"><?php echo e(old('site_color', $config->site_color ?? '#2563eb')); ?></span>
                            </div>
                        </div>
                        <div>
                            <label for="page_size" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">每页显示数量</label>
                            <input type="number" name="page_size" id="page_size" value="<?php echo e(old('page_size', $config->page_size)); ?>" min="1" max="100"
                                class="w-full px-4 py-2.5 border border-gray-300 dark:border-gray-600 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none bg-white dark:bg-gray-700 text-gray-900 dark:text-white">
                        </div>
                    </div>
                </div>

                <!-- 备案信息 -->
                <div>
                    <h2 class="text-lg font-semibold text-gray-800 dark:text-white mb-4 pb-2 border-b border-gray-200 dark:border-gray-700">备案信息</h2>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label for="icp_number" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">ICP备案编号</label>
                            <input type="text" name="icp_number" id="icp_number" value="<?php echo e(old('icp_number', $config->icp_number)); ?>"
                                class="w-full px-4 py-2.5 border border-gray-300 dark:border-gray-600 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                                placeholder="如：苏ICP备2020068439号">
                        </div>
                        <div>
                            <label for="police_record_text" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">公安备案文字</label>
                            <input type="text" name="police_record_text" id="police_record_text" value="<?php echo e(old('police_record_text', $config->police_record_text)); ?>"
                                class="w-full px-4 py-2.5 border border-gray-300 dark:border-gray-600 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                                placeholder="如：苏公网安备 32021402001978号">
                        </div>
                        <div class="md:col-span-2">
                            <label for="police_record_link" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">公安备案链接</label>
                            <input type="text" name="police_record_link" id="police_record_link" value="<?php echo e(old('police_record_link', $config->police_record_link)); ?>"
                                class="w-full px-4 py-2.5 border border-gray-300 dark:border-gray-600 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                                placeholder="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=...">
                        </div>
                    </div>
                </div>

                <!-- 联系信息 -->
                <div>
                    <h2 class="text-lg font-semibold text-gray-800 dark:text-white mb-4 pb-2 border-b border-gray-200 dark:border-gray-700">联系信息</h2>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label for="contact_email" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">邮箱</label>
                            <input type="email" name="contact_email" id="contact_email" value="<?php echo e(old('contact_email', $config->contact_email)); ?>"
                                class="w-full px-4 py-2.5 border border-gray-300 dark:border-gray-600 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                                placeholder="admin@example.com">
                        </div>
                        <div>
                            <label for="contact_phone" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">电话</label>
                            <input type="text" name="contact_phone" id="contact_phone" value="<?php echo e(old('contact_phone', $config->contact_phone)); ?>"
                                class="w-full px-4 py-2.5 border border-gray-300 dark:border-gray-600 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                                placeholder="400-xxx-xxxx">
                        </div>
                        <div class="md:col-span-2">
                            <label for="contact_address" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">地址</label>
                            <input type="text" name="contact_address" id="contact_address" value="<?php echo e(old('contact_address', $config->contact_address)); ?>"
                                class="w-full px-4 py-2.5 border border-gray-300 dark:border-gray-600 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                                placeholder="江苏省无锡市xx区xx路xx号">
                        </div>
                    </div>
                </div>
            </div>

            <div class="flex items-center gap-3 mt-8 pt-6 border-t border-gray-200 dark:border-gray-700">
                <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2.5 rounded-lg text-sm font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 dark:focus:ring-offset-gray-900">
                    保存设置
                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\web1\resources\views/admin/settings/base.blade.php ENDPATH**/ ?>
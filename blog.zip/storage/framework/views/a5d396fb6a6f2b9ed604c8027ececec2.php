<?php $__env->startSection('title', '安装完成'); ?>

<?php $__env->startSection('content'); ?>
    <div class="text-center py-4">
        <div class="w-16 h-16 mx-auto rounded-full bg-green-100 flex items-center justify-center mb-4">
            <i class="fa-solid fa-check text-green-600 text-2xl"></i>
        </div>
        <h2 class="text-lg font-semibold text-gray-900 mb-2">安装完成</h2>
        <p class="text-sm text-gray-500 mb-6">博客系统已成功安装，安装锁文件 <code class="px-1.5 py-0.5 bg-gray-100 rounded text-xs">install.lock</code> 已生成，安装向导已失效。</p>

        <div class="bg-amber-50 border border-amber-200 rounded-xl p-4 text-sm text-amber-700 mb-6 text-left">
            <div class="flex items-start">
                <i class="fa-solid fa-shield-halved text-amber-500 mr-2 mt-0.5"></i>
                <div>
                    <p class="font-medium mb-1">安全提示</p>
                    <p class="text-amber-600 text-xs">建议登录后台后，在控制台使用"一键移除安装向导"删除安装程序文件，避免安装向导残留带来的重复安装风险。</p>
                </div>
            </div>
        </div>

        <a href="<?php echo e(route('admin.login')); ?>" class="inline-flex items-center px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium rounded-lg transition-colors">
            <i class="fa-solid fa-right-to-bracket mr-2"></i>前往后台登录
        </a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('install.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\web1\resources\views/install/complete.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', '步骤一：环境检查'); ?>

<?php $__env->startSection('content'); ?>
    <h2 class="text-lg font-semibold text-gray-900 mb-1">环境检查</h2>
    <p class="text-sm text-gray-500 mb-6">检查服务器环境是否满足博客系统的运行要求</p>

    <div class="mb-6">
        <h3 class="text-sm font-semibold text-gray-700 mb-3 flex items-center">
            <i class="fa-solid fa-server text-blue-500 mr-2"></i>系统要求
        </h3>
        <div class="space-y-2">
            <?php $__currentLoopData = $requirements ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $passed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex items-center justify-between px-4 py-3 rounded-lg <?php echo e($passed ? 'bg-green-50' : 'bg-red-50'); ?> border <?php echo e($passed ? 'border-green-200' : 'border-red-200'); ?>">
                    <span class="text-sm <?php echo e($passed ? 'text-gray-700' : 'text-red-700'); ?>"><?php echo e($name); ?></span>
                    <?php if($passed): ?>
                        <span class="w-6 h-6 rounded-full bg-green-100 flex items-center justify-center">
                            <i class="fa-solid fa-check text-green-600 text-xs"></i>
                        </span>
                    <?php else: ?>
                        <span class="w-6 h-6 rounded-full bg-red-100 flex items-center justify-center">
                            <i class="fa-solid fa-xmark text-red-600 text-xs"></i>
                        </span>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <div class="mb-8">
        <h3 class="text-sm font-semibold text-gray-700 mb-3 flex items-center">
            <i class="fa-solid fa-folder-open text-blue-500 mr-2"></i>目录权限
        </h3>
        <div class="space-y-2">
            <?php $__currentLoopData = $writable ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $path => $passed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex items-center justify-between px-4 py-3 rounded-lg <?php echo e($passed ? 'bg-green-50' : 'bg-red-50'); ?> border <?php echo e($passed ? 'border-green-200' : 'border-red-200'); ?>">
                    <span class="text-sm <?php echo e($passed ? 'text-gray-700' : 'text-red-700'); ?>"><?php echo e($path); ?></span>
                    <?php if($passed): ?>
                        <span class="text-xs <?php echo e($passed ? 'text-green-600' : 'text-red-600'); ?> font-medium">
                            <i class="fa-solid fa-check mr-1"></i>可写
                        </span>
                    <?php else: ?>
                        <span class="text-xs text-red-600 font-medium">
                            <i class="fa-solid fa-xmark mr-1"></i>不可写
                        </span>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <?php if(in_array(false, $writable ?? [], true)): ?>
            <div class="mt-3 px-4 py-3 rounded-lg bg-amber-50 border border-amber-200 text-xs text-amber-800 leading-relaxed">
                <p class="font-semibold mb-1">如何修复目录权限</p>
                <p>Windows / IIS：右键站点目录 → 属性 → 安全 → 编辑，为 <code class="px-1 bg-amber-100 rounded">IIS_IUSRS</code> 和 <code class="px-1 bg-amber-100 rounded">IUSR</code> 勾选「修改」「写入」，确定后重启站点。</p>
                <p class="mt-1">Linux / 宝塔：执行 <code class="px-1 bg-amber-100 rounded">chmod -R 775 storage bootstrap/cache database</code>，并将所有者改为运行 PHP 的账户。</p>
                <p class="mt-1">站点根目录：<code class="px-1 bg-amber-100 rounded"><?php echo e(base_path()); ?></code></p>
            </div>
        <?php endif; ?>
    </div>

    <?php
        $allPassed = true;
        foreach (($requirements ?? []) as $passed) { if (!$passed) { $allPassed = false; break; } }
        if ($allPassed) {
            foreach (($writable ?? []) as $passed) { if (!$passed) { $allPassed = false; break; } }
        }
        $dbDriverRequirement = $requirements['数据库驱动（SQLite / MySQL 至少一种）'] ?? false;
        $dbDriverLabel = $requirements['数据库驱动（SQLite / MySQL 至少一种）'] ?? false;
    ?>

    <div class="flex items-center justify-between pt-4 border-t border-gray-100">
        <?php if($allPassed): ?>
            <div class="flex items-center text-green-600 text-sm">
                <i class="fa-solid fa-circle-check mr-2"></i>所有检查项已通过
            </div>
        <?php else: ?>
            <div class="flex items-center text-red-600 text-sm">
                <i class="fa-solid fa-circle-exclamation mr-2"></i>部分检查项未通过，请修复后再继续
            </div>
        <?php endif; ?>
        <a href="<?php echo e($allPassed ? route('install.step2') : '#'); ?>"
           class="inline-flex items-center px-6 py-2.5 rounded-lg text-sm font-medium text-white transition-colors <?php echo e($allPassed ? 'bg-blue-600 hover:bg-blue-700' : 'bg-gray-300 cursor-not-allowed'); ?>"
           <?php if(!$allPassed): ?> onclick="return false;" <?php endif; ?>>
            下一步 <i class="fa-solid fa-arrow-right ml-2"></i>
        </a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('install.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\web1\resources\views/install/step1.blade.php ENDPATH**/ ?>
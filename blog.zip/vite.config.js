import { defineConfig } from 'vite';
import laravel from 'laravel-vite-plugin';
import tailwindcss from '@tailwindcss/vite';
import vue from '@vitejs/plugin-vue';

export default defineConfig({
    plugins: [
        vue(),
        laravel({
            input: ['resources/css/app.css', 'resources/js/app.js', 'resources/js/article-lightbox.js'],
            refresh: true,
        }),
        tailwindcss(),
    ],
    server: {
        allowedHosts: ['.monkeycode-ai.online'],
        watch: {
            ignored: ['**/storage/framework/views/**'],
        },
    },
});

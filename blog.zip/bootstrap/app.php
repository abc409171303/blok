<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Support\Facades\Route;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
        then: function (): void {
            // 兜底提供 /storage/* 文件：Windows（宝塔/IIS）禁用 symlink/exec 时，
            // public/storage 可能无法成为软链接，上传图片会 404。此路由不挂 web
            // 中间件（不启会话），仅在 Web 服务器未命中物理文件时被匹配。
            Route::get('storage/{path}', [\App\Http\Controllers\StorageController::class, 'show'])
                ->where('path', '.*');
        },
    )
    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->alias([
            'check.installed' => \App\Http\Middleware\CheckInstalled::class,
            'admin.auth' => \App\Http\Middleware\AdminAuth::class,
            'super.admin' => \App\Http\Middleware\SuperAdmin::class,
        ]);

        $middleware->web(prepend: [
            \App\Http\Middleware\UseFileSessionForInstall::class,
        ]);

        $middleware->web(append: [
            \App\Http\Middleware\EnsureInstalled::class,
            \App\Http\Middleware\RecordSiteVisit::class,
        ]);

        // 位于反向代理（宝塔/IIS ARR/平台预览网关）之后时，信任本机与内网代理
        // 转发来的 X-Forwarded-* 头，才能识别外部真实协议（HTTPS）。否则 https
        // 页面会生成 http 资源地址，被浏览器按混合内容拦截，导致样式/脚本失效。
        // 直连部署（无代理）不受影响，也不会强制 HTTPS。
        $middleware->trustProxies(at: [
            '127.0.0.1',
            '::1',
            '10.0.0.0/8',
            '172.16.0.0/12',
            '192.168.0.0/16',
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        //
    })->create();

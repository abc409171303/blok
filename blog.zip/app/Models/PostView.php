<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class PostView extends Model
{
    protected $table = 'post_views';

    protected $fillable = [
        'post_id',
        'ip_address',
        'country',
        'province',
        'city',
        'user_agent',
    ];

    public function post(): BelongsTo
    {
        return $this->belongsTo(Post::class);
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;

class Slide extends Model
{
    use HasFactory;

    protected $fillable = [
        'title',
        'subtitle',
        'image',
        'video_url',
        'video_cover',
        'position',
        'bg_color',
        'link_url',
        'sort_order',
        'status',
    ];

    protected $casts = [
        'status' => 'boolean',
        'sort_order' => 'integer',
    ];

    public function getImageUrlAttribute(): string
    {
        if (empty($this->image)) {
            return '';
        }

        return preg_match('/^https?:\/\//', $this->image)
            ? $this->image
            : Storage::url($this->image);
    }

    public function getVideoCoverUrlAttribute(): string
    {
        if (empty($this->video_cover)) {
            return '';
        }

        return preg_match('/^https?:\/\//', $this->video_cover)
            ? $this->video_cover
            : Storage::url($this->video_cover);
    }

    public function scopeActive($query)
    {
        return $query->where('status', true);
    }

    public function scopeOrdered($query)
    {
        return $query->orderBy('sort_order')->orderBy('id');
    }
}

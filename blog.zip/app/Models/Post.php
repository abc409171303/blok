<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;

class Post extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'category_id',
        'title',
        'slug',
        'summary',
        'content',
        'cover',
        'views',
        'status',
        'is_top',
        'is_recommend',
        'is_hot',
        'access_mode',
        'access_password',
        'published_at',
    ];

    protected function casts(): array
    {
        return [
            'views' => 'integer',
            'is_top' => 'boolean',
            'is_recommend' => 'boolean',
            'is_hot' => 'boolean',
            'published_at' => 'datetime',
        ];
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function tags()
    {
        return $this->belongsToMany(Tag::class);
    }

    public function comments()
    {
        return $this->hasMany(Comment::class);
    }

    public function scopePublished($query)
    {
        return $query->where('status', 'published');
    }

    public function scopeByCategory($query, $slug)
    {
        return $query->whereHas('category', function ($q) use ($slug) {
            $q->where('slug', $slug);
        });
    }

    public function scopeSearch($query, $keyword)
    {
        return $query->where(function ($q) use ($keyword) {
            $q->where('title', 'like', "%{$keyword}%")
              ->orWhere('summary', 'like', "%{$keyword}%");
        });
    }

    public function getRouteKeyName()
    {
        return 'id';
    }

    public function getExcerptAttribute(): string
    {
        return mb_substr(strip_tags($this->content_html), 0, 200);
    }

    /**
     * 文章内容渲染为 HTML。
     * 编辑器（Vditor）以 Markdown 存储，前台展示前转换为 HTML；
     * 纯 HTML 内容（旧文章）也会被 CommonMark 原样保留（html_input=allow）。
     */
    public function getContentHtmlAttribute(): string
    {
        if (empty($this->content)) {
            return '';
        }

        static $converter = null;

        if ($converter === null) {
            $converter = new \League\CommonMark\GithubFlavoredMarkdownConverter([
                'html_input' => 'allow',
                'allow_unsafe_links' => false,
            ]);
        }

        return $converter->convert($this->content)->getContent();
    }

    /**
     * 封面完整可访问 URL，兼容三种存储格式：
     * 完整 URL（http(s)://...）、/storage/ 前缀相对路径、纯相对路径（content/xxx.jpg）。
     */
    public function getCoverUrlAttribute(): ?string
    {
        if (!$this->cover || trim($this->cover) === '') {
            return null;
        }

        $cover = trim($this->cover);

        if (preg_match('#^https?://#i', $cover)) {
            return $cover;
        }

        if (str_starts_with($cover, '/')) {
            return asset($cover);
        }

        return asset(Storage::url($cover));
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;

class MediaFile extends Model
{
    use HasFactory;

    protected $fillable = [
        'file_name',
        'title',
        'file_path',
        'file_type',
        'category',
        'file_size',
        'mime_type',
        'width',
        'height',
        'uploaded_by',
    ];

    protected $casts = [
        'width' => 'integer',
        'height' => 'integer',
        'uploaded_by' => 'integer',
    ];

    protected $appends = ['url'];

    public function getUrlAttribute()
    {
        return Storage::disk('public')->url($this->file_path);
    }

    public function uploader()
    {
        return $this->belongsTo(User::class, 'uploaded_by');
    }

    public function scopeOrdered($query)
    {
        return $query->latest();
    }

    public function scopeType($query, $type)
    {
        return $query->where('file_type', $type);
    }

    public function scopeCategory($query, $category)
    {
        return $query->where('category', $category);
    }

    public function scopeImage($query)
    {
        return $query->where('file_type', 'image');
    }

    public function scopeVideo($query)
    {
        return $query->where('file_type', 'video');
    }
}

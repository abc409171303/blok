<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Navigation extends Model
{
    use HasFactory;

    protected $fillable = [
        'position',
        'name',
        'icon',
        'url',
        'is_enable',
        'target',
        'sort',
    ];

    protected $casts = [
        'is_enable' => 'boolean',
        'sort' => 'integer',
    ];

    /**
     * 按排序顺序作用域（数值升序）
     */
    public function scopeOrdered($query)
    {
        return $query->orderBy('sort', 'asc');
    }

    /**
     * 按位置筛选作用域
     */
    public function scopePosition($query, $position)
    {
        return $query->where('position', $position);
    }

    /**
     * 仅启用作用域
     */
    public function scopeActive($query)
    {
        return $query->where('is_enable', 1);
    }

    /**
     * 顶部导航作用域
     */
    public function scopeHead($query)
    {
        return $query->position('head');
    }

    /**
     * 底部导航作用域
     */
    public function scopeFoot($query)
    {
        return $query->position('foot');
    }
}

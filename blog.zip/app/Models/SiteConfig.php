<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SiteConfig extends Model
{
    use HasFactory;

    protected $fillable = [
        'site_name',
        'site_seo_title',
        'site_tagline',
        'site_description',
        'site_keywords',
        'site_logo',
        'site_favicon',
        'site_avatar',
        'site_copyright',
        'site_domain',
        'page_size',
        'installed',
        'site_color',
        'icp_number',
        'police_record_text',
        'police_record_link',
        'contact_email',
        'contact_phone',
        'contact_address',
        'contact_qrcode',
        'contact_qq',
        'contact_weibo',
        'contact_wechat',
        'admin_login_bg',
        'admin_login_bg_opacity',
        'sidebar_tag_count',
        'enable_dark_mode',
        'dark_mode_mode',
        'dark_mode_start',
        'dark_mode_end',
        'search_driver',
        'enable_comments',
        'custom_header_html',
        'custom_footer_js',
        'site_start_date',
        'ai_api_base_url',
        'ai_api_key',
        'ai_model',
        'ai_image_model',
        'about_content',
        'image_compress_enabled',
        'image_compress_quality',
        'image_compress_max_width',
        'image_compress_max_height',
        'image_compress_max_kb',
        'post_detail_sidebar_author',
        'auto_approve_comments',
        'captcha_enabled',
        'captcha_comment',
        'captcha_message',
        'captcha_admin_login',
        'system_update_server',
        'system_update_key',
    ];

    protected $casts = [
        'image_compress_enabled' => 'boolean',
        'image_compress_quality' => 'integer',
        'image_compress_max_width' => 'integer',
        'image_compress_max_height' => 'integer',
        'image_compress_max_kb' => 'integer',
        'post_detail_sidebar_author' => 'boolean',
        'auto_approve_comments' => 'boolean',
        'captcha_enabled' => 'boolean',
        'captcha_comment' => 'boolean',
        'captcha_message' => 'boolean',
        'captcha_admin_login' => 'boolean',
        'admin_login_bg_opacity' => 'integer',
    ];

    public static function getInstance()
    {
        return static::firstOrCreate([]);
    }
}

<?php

namespace App\Providers;

use App\Database\MySqlConnection;
use Illuminate\Database\Connection;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        // 不做任何全站 HTTPS 强制；网站按访问协议（默认 HTTP）运行。

        // MySQL 5.7 / InnoDB 默认索引长度限制 767 字节，utf8mb4 一个字符占 4 字节，
        // 因此字符串索引最大只能到 191 个字符；SQL Server / SQLite 不受影响。
        Schema::defaultStringLength(191);

        // 让 mysql 连接使用「版本感知」的 Schema 语法：查询 information_schema.columns
        // 时按服务器版本决定是否包含 generation_expression，兼容 MySQL 5.6 / 5.7 / 8.0。
        // 通过连接解析器注册，DB::purge 后重建连接也会生效。
        Connection::resolverFor('mysql', function ($connection, $database, $prefix, $config) {
            return new MySqlConnection($connection, $database, $prefix, $config);
        });
    }
}

<?php

namespace App\Services;

use App\Models\SiteConfig;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Str;

class ImageCompressor
{
    public function maybeCompress(?UploadedFile $file): ?UploadedFile
    {
        if (!$file || !$file->isValid()) {
            return $file;
        }

        $mime = (string) $file->getMimeType();
        if (!str_starts_with($mime, 'image/')) {
            return $file;
        }

        if (in_array($mime, [
            'image/gif',
            'image/svg+xml',
            'image/x-icon',
            'image/vnd.microsoft.icon',
        ], true)) {
            return $file;
        }

        $config = SiteConfig::getInstance();
        if (!($config->image_compress_enabled ?? false)) {
            return $file;
        }

        try {
            return $this->compressFile($file, [
                'quality' => (int) ($config->image_compress_quality ?? 80),
                'max_width' => (int) ($config->image_compress_max_width ?? 0),
                'max_height' => (int) ($config->image_compress_max_height ?? 0),
                'max_kb' => (int) ($config->image_compress_max_kb ?? 0),
            ]);
        } catch (\Throwable $e) {
            report($e);

            return $file;
        }
    }

    /**
     * @param  array{quality?:int,max_width?:int,max_height?:int,max_kb?:int}  $options
     */
    public function compressFile(UploadedFile $file, array $options): UploadedFile
    {
        $quality = max(1, min(100, (int) ($options['quality'] ?? 80)));
        $maxWidth = max(0, (int) ($options['max_width'] ?? 0));
        $maxHeight = max(0, (int) ($options['max_height'] ?? 0));
        $maxKb = max(0, (int) ($options['max_kb'] ?? 0));

        $sourcePath = $file->getRealPath();
        if (!$sourcePath || !is_file($sourcePath)) {
            return $file;
        }

        $info = @getimagesize($sourcePath);
        if (!$info) {
            return $file;
        }

        [$origW, $origH, $type] = $info;
        $src = $this->createImageResource($sourcePath, (int) $type);
        if (!$src) {
            return $file;
        }

        [$newW, $newH] = $this->fitSize((int) $origW, (int) $origH, $maxWidth, $maxHeight);
        $resized = ($newW !== (int) $origW) || ($newH !== (int) $origH);

        if ($resized) {
            $dst = imagecreatetruecolor($newW, $newH);
            $this->preserveTransparency($dst, (int) $type);
            imagecopyresampled($dst, $src, 0, 0, 0, 0, $newW, $newH, (int) $origW, (int) $origH);
            imagedestroy($src);
            $src = $dst;
        }

        $outputType = $this->outputType((int) $type);
        $tmpPath = sys_get_temp_dir() . DIRECTORY_SEPARATOR . Str::random(24) . '.' . $this->extensionForType($outputType);

        $this->encode($src, $tmpPath, $outputType, $quality);

        if ($maxKb > 0) {
            $q = $quality;
            while (is_file($tmpPath) && filesize($tmpPath) > $maxKb * 1024 && $q > 40) {
                $q -= 10;
                $this->encode($src, $tmpPath, $outputType, $q);
            }

            if (
                $outputType === IMAGETYPE_PNG
                && is_file($tmpPath)
                && filesize($tmpPath) > $maxKb * 1024
            ) {
                $jpegPath = sys_get_temp_dir() . DIRECTORY_SEPARATOR . Str::random(24) . '.jpg';
                $q = min($quality, 80);
                $this->encode($src, $jpegPath, IMAGETYPE_JPEG, $q);
                while (is_file($jpegPath) && filesize($jpegPath) > $maxKb * 1024 && $q > 40) {
                    $q -= 10;
                    $this->encode($src, $jpegPath, IMAGETYPE_JPEG, $q);
                }
                @unlink($tmpPath);
                $tmpPath = $jpegPath;
                $outputType = IMAGETYPE_JPEG;
            }
        }

        imagedestroy($src);

        if (!is_file($tmpPath)) {
            return $file;
        }

        $originalSize = (int) $file->getSize();
        $newSize = (int) filesize($tmpPath);
        if (!$resized && $newSize >= $originalSize && $originalSize > 0) {
            @unlink($tmpPath);

            return $file;
        }

        register_shutdown_function(static function () use ($tmpPath) {
            if (is_file($tmpPath)) {
                @unlink($tmpPath);
            }
        });

        $originalName = pathinfo($file->getClientOriginalName(), PATHINFO_FILENAME);
        $newName = ($originalName !== '' ? $originalName : 'image') . '.' . $this->extensionForType($outputType);

        return new UploadedFile(
            $tmpPath,
            $newName,
            $this->mimeForType($outputType),
            null,
            true
        );
    }

    /**
     * @return array{0:int,1:int}
     */
    private function fitSize(int $width, int $height, int $maxWidth, int $maxHeight): array
    {
        if ($width <= 0 || $height <= 0) {
            return [$width, $height];
        }

        $scale = 1.0;
        if ($maxWidth > 0 && $width > $maxWidth) {
            $scale = min($scale, $maxWidth / $width);
        }
        if ($maxHeight > 0 && $height > $maxHeight) {
            $scale = min($scale, $maxHeight / $height);
        }

        if ($scale >= 1.0) {
            return [$width, $height];
        }

        return [
            max(1, (int) round($width * $scale)),
            max(1, (int) round($height * $scale)),
        ];
    }

    /**
     * @return \GdImage|false
     */
    private function createImageResource(string $path, int $type)
    {
        return match ($type) {
            IMAGETYPE_JPEG => @imagecreatefromjpeg($path),
            IMAGETYPE_PNG => @imagecreatefrompng($path),
            IMAGETYPE_WEBP => @imagecreatefromwebp($path),
            IMAGETYPE_BMP => function_exists('imagecreatefrombmp') ? @imagecreatefrombmp($path) : false,
            default => false,
        };
    }

    private function outputType(int $type): int
    {
        return match ($type) {
            IMAGETYPE_PNG => IMAGETYPE_PNG,
            IMAGETYPE_WEBP => IMAGETYPE_WEBP,
            default => IMAGETYPE_JPEG,
        };
    }

    /**
     * @param  \GdImage  $image
     */
    private function preserveTransparency($image, int $type): void
    {
        if (!in_array($type, [IMAGETYPE_PNG, IMAGETYPE_WEBP], true)) {
            return;
        }

        imagealphablending($image, false);
        imagesavealpha($image, true);
        $transparent = imagecolorallocatealpha($image, 0, 0, 0, 127);
        imagefill($image, 0, 0, $transparent);
    }

    /**
     * @param  \GdImage  $image
     */
    private function encode($image, string $path, int $type, int $quality): void
    {
        if ($type === IMAGETYPE_JPEG) {
            $width = imagesx($image);
            $height = imagesy($image);
            $canvas = imagecreatetruecolor($width, $height);
            $white = imagecolorallocate($canvas, 255, 255, 255);
            imagefill($canvas, 0, 0, $white);
            imagecopy($canvas, $image, 0, 0, 0, 0, $width, $height);
            imagejpeg($canvas, $path, $quality);
            imagedestroy($canvas);

            return;
        }

        if ($type === IMAGETYPE_WEBP) {
            imagewebp($image, $path, $quality);

            return;
        }

        $level = (int) round((100 - $quality) / 11.11);
        $level = max(0, min(9, $level));
        imagepng($image, $path, $level);
    }

    private function extensionForType(int $type): string
    {
        return match ($type) {
            IMAGETYPE_PNG => 'png',
            IMAGETYPE_WEBP => 'webp',
            default => 'jpg',
        };
    }

    private function mimeForType(int $type): string
    {
        return match ($type) {
            IMAGETYPE_PNG => 'image/png',
            IMAGETYPE_WEBP => 'image/webp',
            default => 'image/jpeg',
        };
    }
}

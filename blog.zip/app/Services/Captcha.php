<?php

namespace App\Services;

use App\Models\SiteConfig;
use Illuminate\Support\Str;

class Captcha
{
    /** 合法场景 */
    public const SCENES = ['comment', 'message', 'admin_login'];

    /**
     * 判断某场景当前是否需要验证码。
     */
    public static function enabled(string $scene): bool
    {
        $config = SiteConfig::getInstance();

        if (!($config->captcha_enabled ?? false)) {
            return false;
        }

        return match ($scene) {
            'comment' => (bool) ($config->captcha_comment ?? true),
            'message' => (bool) ($config->captcha_message ?? true),
            'admin_login' => (bool) ($config->captcha_admin_login ?? true),
            default => false,
        };
    }

    /**
     * 校验用户输入是否正确（忽略大小写）。
     * 无论对错都会清空旧验证码，防止复用。
     */
    public static function verify(string $scene, ?string $input): bool
    {
        $key = self::sessionKey($scene);
        $expected = (string) session()->pull($key);

        if ($expected === '' || $input === null) {
            return false;
        }

        return Str::lower($expected) === Str::lower(trim($input));
    }

    /**
     * 生成图片验证码：将正确答案写入 session，返回 PNG 图片二进制。
     */
    public static function image(string $scene): string
    {
        $code = Str::upper(Str::random(4, 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'));

        session()->put(self::sessionKey($scene), Str::lower($code));

        $width = 130;
        $height = 40;

        $image = imagecreatetruecolor($width, $height);

        // 背景
        $bg = imagecolorallocate($image, 246, 248, 252);
        imagefill($image, 0, 0, $bg);

        // 干扰线条
        for ($i = 0; $i < 4; $i++) {
            $line = imagecolorallocate($image, random_int(180, 220), random_int(180, 220), random_int(180, 220));
            imageline($image, random_int(0, $width), random_int(0, $height), random_int(0, $width), random_int(0, $height), $line);
        }

        // 干扰点
        for ($i = 0; $i < 80; $i++) {
            $dot = imagecolorallocate($image, random_int(170, 230), random_int(170, 230), random_int(170, 230));
            imagesetpixel($image, random_int(0, $width), random_int(0, $height), $dot);
        }

        // 字符
        $charCount = strlen($code);
        $charWidth = intdiv($width, $charCount + 1);

        for ($i = 0; $i < $charCount; $i++) {
            $color = imagecolorallocate($image, random_int(30, 120), random_int(30, 120), random_int(30, 120));
            $angle = random_int(-25, 25);
            $size = random_int(20, 26);
            $x = 12 + $i * $charWidth;
            $y = random_int(28, 32);
            imagettftext($image, $size, $angle, $x, $y, $color, self::fontPath(), $code[$i]);
        }

        ob_start();
        imagepng($image);
        $png = (string) ob_get_clean();
        imagedestroy($image);

        return $png;
    }

    private static function sessionKey(string $scene): string
    {
        return 'captcha_' . $scene;
    }

    private static function fontPath(): string
    {
        // 中文字体目录：优先使用系统字体，找不到则回退到 GD 内置字体（此时不再用 imagettftext）
        $candidates = [
            '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',
            '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
            '/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf',
        ];

        foreach ($candidates as $font) {
            if (file_exists($font)) {
                return $font;
            }
        }

        throw new \RuntimeException('No TTF font available for captcha');
    }
}

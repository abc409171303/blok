<?php

namespace App\Support;

/**
 * 安装状态判定辅助类。
 *
 * 安装锁文件 install.lock 是访问控制的唯一权威标记：
 * 锁文件存在即视为已安装，删除锁文件即可重新进入安装向导（应急重装入口）。
 * 数据库 site_configs.installed 作为数据状态保留，不参与访问控制。
 */
class InstallState
{
    /**
     * 锁文件路径（项目根目录）。
     */
    public static function lockPath(): string
    {
        return base_path('install.lock');
    }

    /**
     * 判断系统是否已安装，以锁文件是否存在为唯一依据。
     */
    public static function isInstalled(): bool
    {
        return is_file(self::lockPath());
    }

    /**
     * 写入锁文件，重复调用保持幂等。
     */
    public static function writeLock(): bool
    {
        $path = self::lockPath();

        if (is_file($path)) {
            return true;
        }

        return @file_put_contents($path, 'installed at ' . date('Y-m-d H:i:s')) !== false;
    }

    /**
     * 判断安装向导源码是否仍然存在。
     */
    public static function wizardExists(): bool
    {
        return is_file(base_path('routes/install.php'))
            || is_file(app_path('Http/Controllers/InstallController.php'))
            || is_dir(resource_path('views/install'));
    }
}

<?php

namespace App\Rules;

use App\Services\Captcha;
use Closure;
use Illuminate\Contracts\Validation\ValidationRule;

class CaptchaRule implements ValidationRule
{
    public function __construct(protected string $scene)
    {
    }

    public function validate(string $attribute, mixed $value, Closure $fail): void
    {
        if (!Captcha::verify($this->scene, $value)) {
            $fail('验证码错误，请重新输入。');
        }
    }
}

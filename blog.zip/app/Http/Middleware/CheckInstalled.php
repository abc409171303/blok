<?php

namespace App\Http\Middleware;

use App\Models\SiteConfig;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Symfony\Component\HttpFoundation\Response;

class CheckInstalled
{
    public function handle(Request $request, Closure $next): Response
    {
        $installed = SiteConfig::getInstance()->installed ?? false;

        if (!$installed && !Str::startsWith($request->path(), 'install')) {
            return redirect()->route('install.index');
        }

        if ($installed && Str::startsWith($request->path(), 'install')) {
            return redirect('/');
        }

        return $next($request);
    }
}

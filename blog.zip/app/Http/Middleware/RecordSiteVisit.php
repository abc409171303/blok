<?php

namespace App\Http\Middleware;

use App\Models\SiteVisit;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

class RecordSiteVisit
{
    /**
     * 爬虫/蜘蛛 UA 关键词：命中则跳过记录，不计入 PV/UV。
     */
    protected const ROBOT_KEYWORDS = [
        'bot', 'spider', 'crawler', 'crawl', 'slurp',
        'baiduspider', 'yisouspider', 'sogou', '360spider', 'haosouspider',
        'googlebot', 'bingbot', 'bingpreview', 'yandex', 'duckduckbot',
        'bytespider', 'petalbot', 'applebot', 'facebookexternalhit',
        'ia_archiver', 'archive.org_bot', 'semrushbot', 'ahrefsbot',
        'mj12bot', 'exabot', 'uptimerobot', 'monitor', 'pingdom',
        'python-requests', 'go-http-client', 'scrapy', 'curl', 'wget',
        'headlesschrome', 'phantomjs', 'java/', 'okhttp', 'axios',
        'postman', 'httpclient', 'libwww', 'lighthouse',
    ];

    /**
     * 不参与统计的路径前缀（后台、安装、静态资源等）。
     */
    protected const EXCLUDED_PREFIXES = [
        '/admin', '/install', '/captcha', '/build', '/storage',
        '/media', '/uploads', '/vendor', '/up', '/api',
    ];

    public function handle(Request $request, Closure $next): Response
    {
        $response = $next($request);

        try {
            $this->record($request, $response);
        } catch (\Throwable $e) {
            // 统计写入失败绝不影响正常访问
            Log::debug('site visit record failed: ' . $e->getMessage());
        }

        return $response;
    }

    protected function record(Request $request, Response $response): void
    {
        if (!$request->isMethod('GET')) {
            return;
        }
        if ($response->getStatusCode() !== 200) {
            return;
        }
        if ($request->ajax() || $request->expectsJson()) {
            return;
        }

        $path = $request->path();
        if ($this->isExcluded($path)) {
            return;
        }

        $ua = (string) $request->userAgent();
        if ($this->isRobot($ua)) {
            return;
        }

        $ip = $this->clientIp($request);
        $visitorKey = md5($ip . '|' . mb_strtolower($ua));

        // 防重复统计：同一访客 30 分钟内访问同一页面只计 1 次 PV
        $duplicated = SiteVisit::query()
            ->where('visitor_key', $visitorKey)
            ->where('url', $path)
            ->where('created_at', '>=', now()->subMinutes(30))
            ->exists();
        if ($duplicated) {
            return;
        }

        SiteVisit::create([
            'ip' => $ip,
            'url' => $path,
            'user_agent' => mb_substr($ua, 0, 500),
            'visitor_key' => $visitorKey,
        ]);
    }

    protected function isExcluded(string $path): bool
    {
        foreach (self::EXCLUDED_PREFIXES as $prefix) {
            if ($path === trim($prefix, '/') || str_starts_with($path, trim($prefix, '/'))) {
                return true;
            }
        }
        return false;
    }

    protected function isRobot(string $ua): bool
    {
        $haystack = mb_strtolower($ua);
        foreach (self::ROBOT_KEYWORDS as $keyword) {
            if (str_contains($haystack, $keyword)) {
                return true;
            }
        }
        return false;
    }

    protected function clientIp(Request $request): string
    {
        $forwarded = $request->header('X-Forwarded-For');
        if ($forwarded) {
            $ips = explode(',', $forwarded);
            return trim($ips[0]);
        }
        return $request->ip() ?: 'unknown';
    }
}

<?php

namespace App\Http\Middleware;

use App\Support\InstallState;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * 安装向导期间使用文件 Session。
 *
 * 默认 Session 驱动为 database，但安装过程中目标数据库的 sessions 表
 * 尚未建立，若继续使用数据库 Session 会导致步骤间会话丢失或请求异常。
 * 该中间件在 web 中间件组最前执行，早于 StartSession，可安全切换驱动。
 */
class UseFileSessionForInstall
{
    public function handle(Request $request, Closure $next): Response
    {
        // 未安装时全站使用文件 Session，避免 database 驱动的查询报 500。
        if (!InstallState::isInstalled()) {
            config(['session.driver' => 'file']);
        } elseif ($request->is('install') || $request->is('install/*')) {
            config(['session.driver' => 'file']);
        }

        return $next($request);
    }
}

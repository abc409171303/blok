<?php

namespace App\Http\Middleware;

use App\Support\InstallState;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * 全局安装状态守卫。
 *
 * - 未安装时，除安装向导与健康检查外的请求统一重定向到安装向导；
 * - 已安装时，安装向导路径统一返回 403 禁止重复安装提示。
 */
class EnsureInstalled
{
    public function handle(Request $request, Closure $next): Response
    {
        $installed = InstallState::isInstalled();
        $isInstallPath = $request->is('install') || $request->is('install/*');
        $isCompletePage = $request->is('install/complete');

        if ($isInstallPath) {
            // 已安装时封锁安装向导，但放行安装完成页用于展示结果
            if ($installed && !$isCompletePage) {
                return response()->view('errors.installed', [], 403);
            }

            return $next($request);
        }

        if (!$installed && !$request->is('up')) {
            // 本地开发预览：开启 PREVIEW_FRONTEND 时，未安装也允许直接浏览前台，
            // 便于查看首页与页面效果；安装向导本身仍可正常访问。生产环境不开启。
            if (!config('app.preview_frontend')) {
                return redirect()->route('install.index');
            }
        }

        return $next($request);
    }
}

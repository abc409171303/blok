<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class AdminAuth
{
    public function handle(Request $request, Closure $next): Response
    {
        if (!Auth::check() || !Auth::user()->isAdmin()) {
            // JSON / XHR 请求（如移动端封面图上传）若返回 302 跳转，浏览器会
            // 跟随跳转拿到登录页 HTML 并返回 200，前端 JSON.parse 失败后只能
            // 提示「上传响应异常」。这里对声明 JSON 的请求返回 401 JSON。
            if ($request->expectsJson()) {
                return response()->json([
                    'success' => false,
                    'message' => '登录已过期，请重新登录',
                ], 401);
            }

            return redirect()->route('admin.login');
        }

        return $next($request);
    }
}

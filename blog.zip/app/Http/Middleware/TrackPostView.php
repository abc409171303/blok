<?php

namespace App\Http\Middleware;

use App\Models\PostView;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\Response;

class TrackPostView
{
    public function handle(Request $request, Closure $next): Response
    {
        $response = $next($request);

        if ($request->route('slug') && $request->route('post')) {
            $this->trackView($request, $request->route('post'));
        }

        return $response;
    }

    protected function trackView($request, $post): void
    {
        try {
            $ip = $this->getClientIp($request);

            $geo = $this->getGeoLocation($ip);

            DB::table('post_views')->insert([
                'post_id' => $post->id,
                'ip_address' => $ip,
                'country' => $geo['country'] ?? null,
                'province' => $geo['province'] ?? null,
                'city' => $geo['city'] ?? null,
                'user_agent' => $request->userAgent(),
                'created_at' => now(),
                'updated_at' => now(),
            ]);

            $post->increment('views');
        } catch (\Exception $e) {
            // 记录失败不影响用户访问
        }
    }

    protected function getClientIp($request): string
    {
        $ip = $request->header('X-Forwarded-For');
        if ($ip) {
            $ips = explode(',', $ip);
            return trim($ips[0]);
        }
        return $request->ip() ?: 'unknown';
    }

    protected function getGeoLocation(string $ip): array
    {
        $cacheKey = 'geo_' . md5($ip);
        $cached = cache()->get($cacheKey);
        if ($cached) {
            return $cached;
        }

        $result = [
            'country' => null,
            'province' => null,
            'city' => null,
        ];

        try {
            $url = "https://ipinfo.io/{$ip}/json?token=";
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 3);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            if ($httpCode === 200 && $response) {
                $data = json_decode($response, true);
                if ($data) {
                    $loc = $data['loc'] ?? '';
                    if ($loc) {
                        $coords = explode(',', $loc);
                        $result['city'] = $data['city'] ?? null;
                        $result['province'] = $data['region'] ?? null;
                        $result['country'] = $data['country'] ?? null;
                    }
                }
            }
        } catch (\Exception $e) {
            // 获取地理位置失败，使用默认值
        }

        cache()->put($cacheKey, $result, 60 * 60 * 24);
        return $result;
    }
}

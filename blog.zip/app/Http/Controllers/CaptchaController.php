<?php

namespace App\Http\Controllers;

use App\Services\Captcha;
use Illuminate\Http\Response;

class CaptchaController extends Controller
{
    public function image(string $scene): Response
    {
        if (!in_array($scene, Captcha::SCENES, true)) {
            abort(404);
        }

        $png = Captcha::image($scene);

        return response($png, 200, ['Content-Type' => 'image/png']);
    }
}

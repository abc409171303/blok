<?php

namespace App\Http\Controllers;

use App\Models\SiteConfig;
use App\Models\User;
use App\Support\InstallState;
use Database\Seeders\DemoContentSeeder;
use function symlink;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;
use Illuminate\View\View;

class InstallController extends Controller
{
    /**
     * 安装向导入口，统一跳转到步骤一。
     */
    public function index(): RedirectResponse
    {
        if (InstallState::isInstalled()) {
            return redirect()->route('install.complete');
        }

        return redirect()->route('install.step1');
    }

    /**
     * 步骤一：环境检测。
     */
    public function step1(): View
    {
        $requirements = $this->requirements();
        $writable = $this->writablePaths();

        $allPassed = !in_array(false, $requirements, true)
            && !in_array(false, $writable, true);

        return view('install.step1', compact('requirements', 'writable', 'allPassed'));
    }

    /**
     * 步骤二：数据库配置（展示）。
     */
    public function step2(): View|RedirectResponse
    {
        if (InstallState::isInstalled()) {
            return redirect()->route('install.complete');
        }

        $config = session('install_db', []);

        return view('install.step2', compact('config'));
    }

    /**
     * 步骤二：测试连接并写入数据库配置。
     */
    public function saveStep2(Request $request): RedirectResponse
    {
        if (InstallState::isInstalled()) {
            return redirect()->route('install.complete');
        }

        $type = $request->input('db_connection', 'mysql');

        $rules = [
            'db_connection' => 'required|in:mysql,mssql,sqlite',
            'db_prefix' => 'nullable|string|max:32|regex:/^[A-Za-z0-9_]*$/',
        ];

        if ($type === 'sqlite') {
            $rules['db_database'] = 'nullable|string';
        } else {
            $rules['db_host'] = 'required|string';
            $rules['db_port'] = 'required|numeric|between:1,65535';
            $rules['db_database'] = 'required|string';
            $rules['db_username'] = 'required|string';
            $rules['db_password'] = 'nullable|string';
        }

        $request->validate($rules, [
            'db_prefix.regex' => '数据表前缀只能包含字母、数字和下划线。',
        ]);

        $config = $this->resolveDatabaseConfig($request);
        $connection = $config['db_connection'];

        // 运行时应用配置并测试连接，避免连接失败时写坏 .env
        $this->applyDatabaseConfig($config);

        try {
            DB::connection($connection)->getPdo();
        } catch (\Throwable $e) {
            return back()->with('error', '数据库连接失败：' . $e->getMessage())->withInput();
        }

        $this->writeEnv($config);

        session(['install_db' => $config]);
        session()->forget(['install_migrated', 'install_admin_created']);

        return redirect()->route('install.step3');
    }

    /**
     * 步骤三：导入数据表结构（展示）。
     */
    public function step3(): View|RedirectResponse
    {
        if (InstallState::isInstalled()) {
            return redirect()->route('install.complete');
        }

        $config = session('install_db');
        if (!$config) {
            return redirect()->route('install.step2');
        }

        return view('install.step3', compact('config'));
    }

    /**
     * 步骤三：执行数据表结构导入。
     */
    public function runMigration(): RedirectResponse
    {
        if (InstallState::isInstalled()) {
            return redirect()->route('install.complete');
        }

        $config = session('install_db');
        if (!$config) {
            return redirect()->route('install.step2');
        }

        // 幂等：已导入过则直接进入下一步
        if (session('install_migrated')) {
            return redirect()->route('install.step4');
        }

        $this->applyDatabaseConfig($config);

        $this->extendExecutionTime();

        try {
            Artisan::call('migrate', ['--force' => true]);
        } catch (\Throwable $e) {
            // 首次导入若中途失败，会留下「已建表但迁移未记录」的半成品状态
            // （例如低版本 MySQL 建表成功、添加唯一索引时超过 767 字节限制）。
            // 此时直接重试会因“数据表已存在”再次失败，因此先清理本系统残留表再重试一次。
            if (!$this->cleanupLeftoverTables()) {
                return redirect()->route('install.step3')
                    ->with('error', '导入数据表失败：' . $e->getMessage());
            }

            try {
                Artisan::call('migrate', ['--force' => true]);
            } catch (\Throwable $retryError) {
                return redirect()->route('install.step3')
                    ->with('error', '导入数据表失败：' . $retryError->getMessage());
            }
        }

        session(['install_migrated' => true]);

        return redirect()->route('install.step4');
    }

    /**
     * 清理本系统迁移失败后残留的数据表（含 migrations 记录表），
     * 使导入可以重新从干净状态开始。返回是否确实清理了残留表。
     */
    protected function cleanupLeftoverTables(): bool
    {
        $tables = $this->collectCmsTables();
        $tables[] = 'migrations';

        $existing = [];
        foreach (array_unique($tables) as $table) {
            if (Schema::hasTable($table)) {
                $existing[] = $table;
            }
        }

        if (empty($existing)) {
            return false;
        }

        Schema::disableForeignKeyConstraints();
        foreach ($existing as $table) {
            try {
                Schema::dropIfExists($table);
            } catch (\Throwable $e) {
                // 单个表清理失败不影响其余表，重试迁移时会再次暴露真实错误
            }
        }
        Schema::enableForeignKeyConstraints();

        return true;
    }

    /**
     * 从迁移文件中解析本系统创建的数据表名（不含表前缀）。
     */
    protected function collectCmsTables(): array
    {
        $tables = [];

        foreach (glob(database_path('migrations/*.php')) ?: [] as $file) {
            $contents = (string) file_get_contents($file);
            if (preg_match_all('/Schema::create\(\s*[\'"]([^\'"]+)[\'"]/', $contents, $matches)) {
                foreach ($matches[1] as $name) {
                    $tables[$name] = true;
                }
            }
        }

        return array_keys($tables);
    }

    /**
     * 步骤四：创建管理员（展示）。
     */
    public function step4(): View|RedirectResponse
    {
        if (InstallState::isInstalled()) {
            return redirect()->route('install.complete');
        }

        if (!session('install_db')) {
            return redirect()->route('install.step2');
        }

        if (!session('install_migrated')) {
            return redirect()->route('install.step3');
        }

        $config = session('install_db', []);

        return view('install.step4', compact('config'));
    }

    /**
     * 步骤四：创建超级管理员并写入安装锁。
     */
    public function createAdmin(Request $request): RedirectResponse
    {
        if (InstallState::isInstalled()) {
            return redirect()->route('install.complete');
        }

        $config = session('install_db');
        if (!$config) {
            return redirect()->route('install.step2');
        }

        $request->validate([
            'site_name' => 'required|string|max:100',
            'admin_name' => 'required|string|max:100',
            'admin_email' => 'required|email|max:191',
            'admin_password' => 'required|string|min:5|max:191|confirmed',
        ]);

        try {
            $this->applyDatabaseConfig($config);
            $this->syncAppUrl($request);
            $this->extendExecutionTime();

            // 幂等：邮箱已存在时不重复创建
            $user = User::where('email', $request->admin_email)->first();
            if (!$user) {
                User::create([
                    'name' => $request->admin_name,
                    'email' => $request->admin_email,
                    'password' => Hash::make($request->admin_password),
                    'role' => 'super_admin',
                    'display_name' => $request->admin_name,
                ]);
            }

            $siteConfig = SiteConfig::getInstance();
            $siteConfig->update([
                'site_name' => $request->site_name,
                'installed' => true,
            ]);

            // 植入演示数据并确保上传目录可访问。演示数据失败不应阻断安装流程，
            // 因此单独捕获异常，仅记录日志。
            $this->seedDemoContent();
            $this->ensureStorageLink();
        } catch (\Throwable $e) {
            // 捕获并回显真实错误，避免低版本 MySQL 等环境问题被通用错误页掩盖。
            Log::error('完成安装失败：' . $e->getMessage(), ['exception' => $e]);

            return back()
                ->with('error', '完成安装失败：' . $e->getMessage())
                ->withInput();
        }

        if (!InstallState::writeLock()) {
            return back()
                ->with('error', '安装锁文件写入失败，请检查项目根目录写权限后重试。')
                ->withInput();
        }

        session(['install_admin_created' => true]);

        return redirect()->route('install.complete');
    }

    /**
     * 步骤五：安装完成。
     */
    public function complete(): View|RedirectResponse
    {
        if (!InstallState::isInstalled()) {
            return redirect()->route('install.step1');
        }

        return view('install.complete');
    }

    /**
     * 安装完成后植入演示数据（导航、幻灯片、文章、评论、留言等）。
     */
    protected function seedDemoContent(): void
    {
        try {
            Artisan::call('db:seed', [
                '--class' => DemoContentSeeder::class,
                '--force' => true,
            ]);
        } catch (\Throwable $e) {
            Log::warning('演示数据植入失败：' . $e->getMessage());
        }
    }

    /**
     * 确保 public/storage 指向 storage/app/public。
     *
     * 优先创建软链接；Windows 下软链接可能因权限失败，退化为 junction；
     * 仍失败时创建实体目录并同步文件，保证演示图片可访问。
     */
    protected function ensureStorageLink(): void
    {
        $link = public_path('storage');
        $target = storage_path('app/public');

        if (!is_dir($target)) {
            return;
        }

        if (is_link($link)) {
            if (realpath($link) === realpath($target)) {
                return;
            }
            @unlink($link);
        } elseif (is_dir($link)) {
            $this->copyDirectory($target, $link);

            return;
        }

        // 宝塔 Windows 等环境常在 disable_functions 中禁用 symlink；
        // 被禁用的函数调用会抛致命错误（@ 无法抑制），必须先判断是否存在。
        if (function_exists('symlink') && @symlink($target, $link)) {
            return;
        }

        if (stripos(PHP_OS_FAMILY, 'Windows') !== false && function_exists('exec')) {
            $cmd = 'cmd /c mklink /J ' . escapeshellarg($link) . ' ' . escapeshellarg($target);
            @exec($cmd, $output, $code);
            if (($code ?? 1) === 0 && is_dir($link)) {
                return;
            }
        }

        // 最终兜底：创建实体目录并复制文件（禁用 symlink/exec 时仍可正常访问图片）。
        if (!is_dir($link) && !@mkdir($link, 0777, true)) {
            return;
        }

        $this->copyDirectory($target, $link);
    }

    /**
     * 递归复制目录（仅用于软链接创建失败时的兜底方案）。
     */
    protected function copyDirectory(string $source, string $destination): void
    {
        if (!is_dir($source)) {
            return;
        }

        if (!is_dir($destination) && !@mkdir($destination, 0775, true)) {
            return;
        }

        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($source, \FilesystemIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::SELF_FIRST
        );

        foreach ($iterator as $item) {
            $relative = ltrim(substr($item->getPathname(), strlen($source)), DIRECTORY_SEPARATOR);
            $dest = $destination . DIRECTORY_SEPARATOR . $relative;

            if ($item->isDir()) {
                if (!is_dir($dest)) {
                    @mkdir($dest, 0775, true);
                }
            } elseif (!is_file($dest)) {
                @copy($item->getPathname(), $dest);
            }
        }
    }

    /**
     * 系统要求检测项。
     */
    protected function requirements(): array
    {
        return [
            'PHP >= 8.2' => version_compare(PHP_VERSION, '8.2.0', '>='),
            'PDO 扩展' => extension_loaded('pdo'),
            '数据库驱动（SQLite / MySQL 至少一种）' => (extension_loaded('pdo_sqlite') || extension_loaded('pdo_mysql')),
            'Mbstring 扩展' => extension_loaded('mbstring'),
            'Tokenizer 扩展' => extension_loaded('tokenizer'),
            'XML 扩展' => extension_loaded('xml'),
            'Ctype 扩展' => extension_loaded('ctype'),
            'JSON 扩展' => extension_loaded('json'),
            'Fileinfo 扩展' => extension_loaded('fileinfo'),
        ];
    }

    /**
     * 目录可写检测项。
     *
     * 检测前先尝试创建缺失的运行时目录（Windows 解压 zip 时空目录常丢失），
     * 并用「真实写入探测文件」代替 is_writable，避免 ACL / 只读属性误判。
     */
    protected function writablePaths(): array
    {
        $this->ensureRuntimeDirectories();

        return [
            'storage/' => $this->isPathWritable(base_path('storage')),
            'bootstrap/cache/' => $this->isPathWritable(base_path('bootstrap/cache')),
            'database/' => $this->isPathWritable(database_path()),
            '项目根目录（写入 install.lock）' => $this->isPathWritable(base_path()),
        ];
    }

    /**
     * 创建 Laravel 运行所需的目录与子目录（幂等）。
     */
    protected function ensureRuntimeDirectories(): void
    {
        $directories = [
            base_path('bootstrap/cache'),
            storage_path('app'),
            storage_path('app/public'),
            storage_path('framework'),
            storage_path('framework/cache'),
            storage_path('framework/cache/data'),
            storage_path('framework/sessions'),
            storage_path('framework/views'),
            storage_path('logs'),
        ];

        foreach ($directories as $directory) {
            if (!is_dir($directory)) {
                @mkdir($directory, 0777, true);
            }
        }
    }

    /**
     * 判断目录是否真正可写：创建并删除一个探测文件。
     *
     * Windows 下会顺带清理 zip 解压可能带上的只读属性。
     */
    protected function isPathWritable(string $path): bool
    {
        if (!is_dir($path)) {
            @mkdir($path, 0777, true);
        }

        if (!is_dir($path)) {
            return false;
        }

        if (stripos(PHP_OS_FAMILY, 'Windows') !== false) {
            @chmod($path, 0777);
        }

        $probe = rtrim($path, "\\/") . DIRECTORY_SEPARATOR . '.write_probe_' . uniqid();

        if (@file_put_contents($probe, 'ok') === false) {
            return false;
        }

        @unlink($probe);

        return true;
    }

    /**
     * 解析并规范化数据库配置。
     */
    protected function resolveDatabaseConfig(Request $request): array
    {
        $type = $request->input('db_connection', 'mysql');
        $connection = $type === 'mssql' ? 'sqlsrv' : $type;
        $prefix = (string) $request->input('db_prefix', '');

        if ($connection === 'sqlite') {
            $database = trim((string) $request->input('db_database'));
            if ($database === '') {
                $database = database_path('database.sqlite');
            } elseif (!str_starts_with($database, '/') && !preg_match('/^[A-Za-z]:[\\\\\\/]/', $database)) {
                $database = base_path($database);
            }

            $dir = dirname($database);
            if (!is_dir($dir)) {
                @mkdir($dir, 0775, true);
            }
            if (!file_exists($database)) {
                @touch($database);
            }

            return [
                'db_connection' => 'sqlite',
                'db_label' => 'SQLite',
                'db_host' => '',
                'db_port' => '',
                'db_database' => $database,
                'db_username' => '',
                'db_password' => '',
                'db_prefix' => $prefix,
            ];
        }

        return [
            'db_connection' => $connection,
            'db_label' => $connection === 'sqlsrv' ? 'MSSQL / SQL Server' : 'MySQL',
            'db_host' => (string) $request->input('db_host'),
            'db_port' => (string) $request->input('db_port'),
            'db_database' => (string) $request->input('db_database'),
            'db_username' => (string) $request->input('db_username'),
            'db_password' => (string) $request->input('db_password', ''),
            'db_prefix' => $prefix,
        ];
    }

    /**
     * 将数据库配置应用到运行时，并清除已解析的连接缓存。
     */
    protected function applyDatabaseConfig(array $config): void
    {
        $connection = $config['db_connection'];
        $prefix = $config['db_prefix'] ?? '';

        config(['database.default' => $connection]);
        config(["database.connections.{$connection}.prefix" => $prefix]);

        if ($connection === 'sqlite') {
            config(['database.connections.sqlite.database' => $config['db_database']]);
        } else {
            config([
                "database.connections.{$connection}.host" => $config['db_host'],
                "database.connections.{$connection}.port" => $config['db_port'],
                "database.connections.{$connection}.database" => $config['db_database'],
                "database.connections.{$connection}.username" => $config['db_username'],
                "database.connections.{$connection}.password" => $config['db_password'],
            ]);
        }

        // 应用启动时默认连接可能已被解析并缓存，必须清除后按新配置重连。
        DB::purge($connection);
        DB::purge('sqlite');
    }

    /**
     * 写入 .env 的数据库配置，先清除旧 DB_ 行避免重复。
     */
    protected function writeEnv(array $config): void
    {
        $envPath = base_path('.env');
        $envContent = file_exists($envPath) ? file_get_contents($envPath) : '';
        $envContent = preg_replace('/^#?\s*DB_[A-Z_]+\s*=.*\R?/m', '', $envContent);
        $envContent = rtrim($envContent) . "\n\n";

        $envContent .= "DB_CONNECTION={$config['db_connection']}\n";
        if ($config['db_connection'] === 'sqlite') {
            $envContent .= "DB_DATABASE={$config['db_database']}\n";
        } else {
            $envContent .= "DB_HOST={$config['db_host']}\n";
            $envContent .= "DB_PORT={$config['db_port']}\n";
            $envContent .= "DB_DATABASE={$config['db_database']}\n";
            $envContent .= "DB_USERNAME={$config['db_username']}\n";
            $envContent .= "DB_PASSWORD={$config['db_password']}\n";
        }
        $envContent .= "DB_PREFIX={$config['db_prefix']}\n";

        file_put_contents($envPath, $envContent);
    }

    /**
     * 依据当前访问主机同步 .env 的 APP_URL。
     *
     * 安装包内置的 APP_URL 可能是打包环境地址，若不同步会导致资源链接
     * 指向错误域名。这里统一写入 http:// 开头，网站默认以 HTTP 运行，
     * 不检测、不强制 HTTPS；后续如需 HTTPS，由服务器面板（如宝塔）单独配置。
     */
    protected function syncAppUrl(Request $request): void
    {
        $envPath = base_path('.env');
        if (!file_exists($envPath)) {
            return;
        }

        $appUrl = 'http://' . $request->getHttpHost();

        $envContent = file_get_contents($envPath);
        $envContent = preg_replace('/^#?\s*APP_URL\s*=.*\R?/m', '', $envContent);
        // 清理历史遗留的 FORCE_HTTPS 配置，程序不再使用该开关。
        $envContent = preg_replace('/^#?\s*FORCE_HTTPS\s*=.*\R?/m', '', $envContent);
        $envContent = rtrim($envContent) . "\n";
        $envContent .= "APP_URL={$appUrl}\n";

        file_put_contents($envPath, $envContent);
    }

    /**
     * 放宽安装过程中的执行时间限制。
     */
    protected function extendExecutionTime(): void
    {
        if (function_exists('set_time_limit')) {
            @set_time_limit(180);
        }
    }
}

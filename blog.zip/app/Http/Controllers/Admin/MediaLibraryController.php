<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\MediaFile;
use App\Services\ImageCompressor;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;

class MediaLibraryController extends Controller
{
    /**
     * 获取素材列表（支持分页、筛选、搜索）
     */
    public function index(Request $request): JsonResponse
    {
        // 把设置页（站点外观/博客设置）已上传但尚未登记的图片补录进文件库，
        // 解决历史图片/其它入口上传的图片「文件库里看不到」的问题。
        $this->syncSettingsImages();

        $type = $request->get('type', 'all'); // image/video/all
        $search = $request->get('search', '');
        $page = $request->get('page', 1);
        $perPage = 24;

        $query = MediaFile::query();

        // 类型筛选
        if ($type && $type !== 'all') {
            $query->where('file_type', $type);
        }

        // 搜索
        if ($search) {
            $query->where(function($q) use ($search) {
                $q->where('file_name', 'like', "%{$search}%")
                  ->orWhere('title', 'like', "%{$search}%");
            });
        }

        $files = $query->ordered()->paginate($perPage, ['*'], 'page', $page);

        return response()->json([
            'success' => true,
            'data' => [
                'files' => $files->items(),
                'pagination' => [
                    'current_page' => $files->currentPage(),
                    'last_page' => $files->lastPage(),
                    'per_page' => $files->perPage(),
                    'total' => $files->total(),
                    'from' => $files->firstItem(),
                    'to' => $files->lastItem(),
                ],
                'stats' => [
                    'total' => MediaFile::count(),
                    'images' => MediaFile::where('file_type', 'image')->count(),
                    'videos' => MediaFile::where('file_type', 'video')->count(),
                ],
            ],
        ]);
    }

    /**
     * 上传文件
     */
    public function upload(Request $request): JsonResponse
    {
        $request->validate([
            'file' => 'required|file|max:20480',
        ]);

        $file = $request->file('file');
        $category = $request->get('category', 'uncategorized');
        $title = $request->get('title', $file->getClientOriginalName());

        if (str_starts_with((string) $file->getMimeType(), 'image/')) {
            $file = app(ImageCompressor::class)->maybeCompress($file);
        }

        // 保存文件
        $path = $file->store('media/' . date('Y-m-d'), 'public');
        $fileType = str_contains($file->getMimeType(), 'image') ? 'image' : 'video';
        if (str_contains($file->getMimeType(), 'video')) {
            $fileType = 'video';
            $category = 'videos';
        } else {
            $category = 'images';
        }

        // 获取图片尺寸
        $width = null;
        $height = null;
        if ($fileType === 'image') {
            try {
                $imageInfo = getimagesize($file->getRealPath());
                if ($imageInfo) {
                    $width = $imageInfo[0];
                    $height = $imageInfo[1];
                }
            } catch (\Exception $e) {
                // 忽略错误
            }
        }

        $mediaFile = MediaFile::create([
            'file_name' => $file->getClientOriginalName(),
            'title' => $title,
            'file_path' => $path,
            'file_type' => $fileType,
            'category' => $category,
            'file_size' => $file->getSize(),
            'mime_type' => $file->getMimeType(),
            'width' => $width,
            'height' => $height,
            'uploaded_by' => auth()->id(),
        ]);

        return response()->json([
            'success' => true,
            'data' => [
                'id' => $mediaFile->id,
                'file_name' => $mediaFile->file_name,
                'title' => $mediaFile->title,
                'url' => Storage::url($mediaFile->file_path),
                'file_type' => $mediaFile->file_type,
                'category' => $mediaFile->category,
            ],
            'message' => '文件上传成功',
        ]);
    }

    /**
     * 更新素材信息（编辑）
     */
    public function update(Request $request, MediaFile $mediaFile): JsonResponse
    {
        $validated = $request->validate([
            'title' => 'nullable|string|max:255',
            'category' => 'nullable|string|max:50',
        ]);

        $mediaFile->update($validated);

        return response()->json([
            'success' => true,
            'data' => $mediaFile,
            'message' => '素材信息已更新',
        ]);
    }

    /**
     * 删除素材
     */
    public function destroy(MediaFile $mediaFile): JsonResponse
    {
        try {
            // 删除物理文件
            $deleted = Storage::disk('public')->delete($mediaFile->file_path);
            
            // 删除数据库记录
            $mediaFile->delete();

            return response()->json([
                'success' => true,
                'message' => '文件已删除',
            ]);
        } catch (\Exception $e) {
            \Log::error('删除文件失败: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => '删除失败：' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * 批量删除
     */
    public function bulkDestroy(Request $request): JsonResponse
    {
        $request->validate([
            'ids' => 'required|array',
            'ids.*' => 'exists:media_files,id',
        ]);

        $count = 0;
        $errors = [];
        
        foreach ($request->ids as $id) {
            $mediaFile = MediaFile::find($id);
            if ($mediaFile) {
                try {
                    Storage::disk('public')->delete($mediaFile->file_path);
                    $mediaFile->delete();
                    $count++;
                } catch (\Exception $e) {
                    \Log::error('批量删除文件失败 ID=' . $id . ': ' . $e->getMessage());
                    $errors[] = $mediaFile->file_name;
                }
            }
        }

        if (count($errors) > 0) {
            return response()->json([
                'success' => false,
                'message' => "部分删除失败：未能删除 " . count($errors) . " 个文件",
                'errors' => $errors,
            ], 500);
        }

        return response()->json([
            'success' => true,
            'message' => "已删除 {$count} 个文件",
        ]);
    }

    /**
     * 批量复制链接
     */
    public function bulkCopy(Request $request): JsonResponse
    {
        $request->validate([
            'ids' => 'required|array',
            'ids.*' => 'exists:media_files,id',
        ]);

        $urls = MediaFile::whereIn('id', $request->ids)->pluck('url')->toArray();

        return response()->json([
            'success' => true,
            'urls' => $urls,
            'message' => '已复制 ' . count($urls) . ' 个链接',
        ]);
    }

    /**
     * 批量更新
     */
    public function bulkUpdate(Request $request): JsonResponse
    {
        $request->validate([
            'ids' => 'required|array',
            'ids.*' => 'exists:media_files,id',
            'title' => 'nullable|string|max:255',
            'category' => 'nullable|string|max:50',
        ]);

        $count = 0;
        foreach ($request->ids as $id) {
            $mediaFile = MediaFile::find($id);
            if ($mediaFile) {
                $mediaFile->update([
                    'title' => $request->title,
                    'category' => $request->category,
                ]);
                $count++;
            }
        }

        return response()->json([
            'success' => true,
            'message' => "已更新 {$count} 个文件",
        ]);
    }

    /**
     * 将 public 磁盘 settings/ 目录下尚未登记的图片补录到文件库（幂等）。
     * 仅登记图片，避免把非图片的配置文件误纳入素材库。
     */
    private function syncSettingsImages(): void
    {
        $disk = Storage::disk('public');

        if (!$disk->exists('settings')) {
            return;
        }

        $registered = MediaFile::where('file_path', 'like', 'settings/%')->pluck('file_path')->all();

        foreach ($disk->files('settings') as $path) {
            if (in_array($path, $registered, true)) {
                continue;
            }

            $mime = (string) $disk->mimeType($path);
            if (!str_starts_with($mime, 'image/')) {
                continue;
            }

            $width = null;
            $height = null;
            try {
                $info = @getimagesize($disk->path($path));
                if ($info) {
                    $width = (int) $info[0];
                    $height = (int) $info[1];
                }
            } catch (\Throwable $e) {
                // 忽略无法解析的图片（如 ico）
            }

            MediaFile::create([
                'file_name' => basename($path),
                'title' => basename($path),
                'file_path' => $path,
                'file_type' => 'image',
                'category' => 'images',
                'file_size' => $disk->size($path),
                'mime_type' => $mime,
                'width' => $width,
                'height' => $height,
                'uploaded_by' => auth()->id(),
            ]);
        }
    }
}

<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Message;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class MessageController extends Controller
{
    public function index(): View
    {
        $messages = Message::latest()->paginate(20);

        return view('admin.messages.index', compact('messages'));
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'author' => 'required|string|max:100',
            'email' => 'required|email|max:100',
            'content' => 'required|string',
        ]);

        $validated['status'] = 'pending';

        Message::create($validated);

        return back()->with('success', '留言提交成功，等待审核。');
    }

    public function approve(int $id): RedirectResponse
    {
        $message = Message::findOrFail($id);
        $message->update(['status' => 'approved']);

        return redirect()->route('admin.messages.index')
            ->with('success', '留言已审核通过。');
    }

    public function reject(int $id): RedirectResponse
    {
        $message = Message::findOrFail($id);
        $message->update(['status' => 'rejected']);

        return redirect()->route('admin.messages.index')
            ->with('success', '留言已拒绝。');
    }

    public function reply(Request $request, int $id): RedirectResponse
    {
        $validated = $request->validate([
            'reply' => 'required|string|max:2000',
        ]);

        $message = Message::findOrFail($id);
        $message->update(['reply' => $validated['reply']]);

        return redirect()->route('admin.messages.index')
            ->with('success', '回复已保存。');
    }

    public function destroy(int $id): RedirectResponse
    {
        $message = Message::findOrFail($id);
        $message->delete();

        return redirect()->route('admin.messages.index')
            ->with('success', '留言已删除。');
    }
}

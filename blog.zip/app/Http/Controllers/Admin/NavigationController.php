<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Navigation;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\JsonResponse;

class NavigationController extends Controller
{
    /**
     * 导航列表页
     */
    public function index(Request $request): View
    {
        $position = $request->get('position', 'header');
        $navigations = Navigation::query()
            ->position($position)
            ->ordered()
            ->get();

        return view('admin.navigations.index', compact('navigations', 'position'));
    }

    /**
     * 存储导航
     */
    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'url' => 'required|string|max:2048',
            'icon' => 'nullable|string|max:255',
            'position' => 'required|string|max:50',
            'target' => 'required|in:_self,_blank',
            'is_active' => 'nullable|boolean',
        ]);

        $validated['is_active'] = $validated['is_active'] ?? true;
        
        // 自动设置排序值
        $maxSort = Navigation::where('position', $validated['position'])->max('sort_order');
        $validated['sort_order'] = $maxSort ? $maxSort + 1 : 0;

        Navigation::create($validated);

        return redirect()->route('admin.navigations.index', ['position' => $validated['position']])
            ->with('success', '导航已添加。');
    }

    /**
     * 更新导航
     */
    public function update(Request $request, Navigation $navigation): RedirectResponse
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'url' => 'required|string|max:2048',
            'icon' => 'nullable|string|max:255',
            'position' => 'required|string|max:50',
            'target' => 'required|in:_self,_blank',
            'is_active' => 'nullable|boolean',
        ]);

        $validated['is_active'] = $validated['is_active'] ?? true;

        $navigation->update($validated);

        return redirect()->route('admin.navigations.index', ['position' => $validated['position']])
            ->with('success', '导航已更新。');
    }

    /**
     * 删除导航
     */
    public function destroy(Navigation $navigation): RedirectResponse
    {
        $position = $navigation->position;
        $navigation->delete();

        return redirect()->route('admin.navigations.index', ['position' => $position])
            ->with('success', '导航已删除。');
    }

    /**
     * 切换启用/禁用状态 (Ajax)
     */
    public function toggleStatus(Navigation $navigation): JsonResponse
    {
        $navigation->update(['is_active' => !$navigation->is_active]);

        return response()->json([
            'success' => true,
            'is_active' => $navigation->is_active,
            'message' => '状态已更新',
        ]);
    }

    /**
     * 上移/下移排序 (核心功能)
     */
    public function move(Request $request, Navigation $navigation): JsonResponse
    {
        $direction = $request->get('direction', 'up');
        $position = $navigation->position;
        $currentSort = $navigation->sort_order;

        if ($direction === 'up') {
            // 找到上一个导航
            $targetNav = Navigation::where('position', $position)
                ->where('sort_order', '<', $currentSort)
                ->orderBy('sort_order', 'desc')
                ->first();
        } else {
            // 找到下一个导航
            $targetNav = Navigation::where('position', $position)
                ->where('sort_order', '>', $currentSort)
                ->orderBy('sort_order', 'asc')
                ->first();
        }

        if ($targetNav) {
            // 交换排序值
            \Illuminate\Support\Facades\DB::transaction(function () use ($navigation, $targetNav) {
                $temp = $navigation->sort_order;
                $navigation->update(['sort_order' => $targetNav->sort_order]);
                $targetNav->update(['sort_order' => $temp]);
            });

            return response()->json([
                'success' => true,
                'message' => '排序已更新',
            ]);
        }

        return response()->json([
            'success' => false,
            'message' => '已经到' . ($direction === 'up' ? '顶部' : '底部') . '了',
        ]);
    }
}

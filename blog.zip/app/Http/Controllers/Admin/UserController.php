<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\AdminLog;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\View\View;

class UserController extends Controller
{
    public function index(): View
    {
        $users = User::orderBy('created_at', 'desc')->paginate(15);
        return view('admin.users.index', compact('users'));
    }

    public function create(): View
    {
        return view('admin.users.create');
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'name' => 'required|string|max:50|unique:users,name',
            'email' => 'nullable|email|max:100|unique:users,email',
            'password' => 'required|string|min:6',
            'role' => $this->roleRule(),
        ]);

        User::create([
            'name' => $validated['name'],
            'email' => $validated['email'] ?? null,
            'password' => Hash::make($validated['password']),
            'role' => $validated['role'],
        ]);

        AdminLog::log('创建', '创建用户: ' . $validated['name'], 'user', null);

        return redirect()->route('admin.users.index')->with('success', '用户创建成功。');
    }

    public function edit(User $user): View
    {
        if ($user->isSuperAdmin() && !auth()->user()?->isSuperAdmin()) {
            abort(403, '无权修改超级管理员账号。');
        }

        return view('admin.users.edit', compact('user'));
    }

    public function update(Request $request, User $user): RedirectResponse
    {
        if ($user->isSuperAdmin() && !auth()->user()?->isSuperAdmin()) {
            return redirect()->route('admin.users.index')->with('error', '无权修改超级管理员账号。');
        }

        $validated = $request->validate([
            'name' => 'required|string|max:50|unique:users,name,' . $user->id,
            'email' => 'nullable|email|max:100|unique:users,email,' . $user->id,
            'password' => 'nullable|string|min:6',
            'role' => $this->roleRule(),
        ]);

        $data = [
            'name' => $validated['name'],
            'email' => $validated['email'] ?? null,
            'role' => $validated['role'],
        ];

        if (!empty($validated['password'])) {
            $data['password'] = Hash::make($validated['password']);
        }

        $user->update($data);

        AdminLog::log('更新', '更新用户: ' . $user->name, 'user', $user->id);

        return redirect()->route('admin.users.index')->with('success', '用户更新成功。');
    }

    public function destroy(User $user): RedirectResponse
    {
        if ($user->id === auth()->id()) {
            return redirect()->route('admin.users.index')->with('error', '不能删除当前登录的账号。');
        }

        $user->delete();

        AdminLog::log('删除', '删除用户: ' . $user->name, 'user', $user->id);

        return redirect()->route('admin.users.index')->with('success', '用户已删除。');
    }

    /**
     * 角色分配规则：仅超级管理员可分配 super_admin 角色。
     */
    protected function roleRule(): string
    {
        return auth()->user()?->isSuperAdmin()
            ? 'required|in:admin,super_admin,user'
            : 'required|in:admin,user';
    }
}

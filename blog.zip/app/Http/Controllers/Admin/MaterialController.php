<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Material;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class MaterialController extends Controller
{
    public function index(): View
    {
        $materials = Material::orderBy('sort_order')->orderBy('id')->paginate(15);
        return view('admin.materials.index', compact('materials'));
    }

    public function create(): View
    {
        return view('admin.materials.create');
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'name' => 'required|string|max:200',
            'code' => 'nullable|string|max:100',
            'specification' => 'nullable|string|max:200',
            'unit' => 'nullable|string|max:50',
            'price' => 'nullable|numeric|min:0',
            'stock' => 'nullable|integer|min:0',
            'status' => 'nullable|boolean',
            'remark' => 'nullable|string|max:500',
            'sort_order' => 'nullable|integer|min:0',
        ]);

        $validated['status'] = $request->has('status');

        Material::create($validated);

        return redirect()->route('admin.materials.index')->with('success', '物料创建成功。');
    }

    public function edit(Material $material): View
    {
        return view('admin.materials.edit', compact('material'));
    }

    public function update(Request $request, Material $material): RedirectResponse
    {
        $validated = $request->validate([
            'name' => 'required|string|max:200',
            'code' => 'nullable|string|max:100',
            'specification' => 'nullable|string|max:200',
            'unit' => 'nullable|string|max:50',
            'price' => 'nullable|numeric|min:0',
            'stock' => 'nullable|integer|min:0',
            'status' => 'nullable|boolean',
            'remark' => 'nullable|string|max:500',
            'sort_order' => 'nullable|integer|min:0',
        ]);

        $validated['status'] = $request->has('status');

        $material->update($validated);

        return redirect()->route('admin.materials.index')->with('success', '物料更新成功。');
    }

    public function destroy(Material $material): RedirectResponse
    {
        $material->delete();

        return redirect()->route('admin.materials.index')->with('success', '物料已删除。');
    }
}

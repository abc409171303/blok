<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Navigation;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class AdminNavigationController extends Controller
{
    /**
     * 导航管理页面
     */
    public function index(Request $request): View
    {
        $position = $request->get('position', 'head');

        $navigations = Navigation::query()
            ->where('position', $position)
            ->ordered()
            ->get();

        return view('admin.navigations.index', compact('navigations', 'position'));
    }

    /**
     * 显示创建表单
     */
    public function create(): View
    {
        return view('admin.navigations.create');
    }

    /**
     * 存储导航
     */
    public function store(Request $request): RedirectResponse|JsonResponse
    {
        $validated = $this->validateData($request);

        $validated['is_enable'] = $validated['is_enable'] ?? 1;

        $maxSort = Navigation::where('position', $validated['position'])->max('sort');
        $validated['sort'] = $maxSort !== null ? $maxSort + 1 : 0;

        $navigation = Navigation::create($validated);

        if ($request->wantsJson()) {
            return response()->json(['success' => true, 'message' => '导航项已添加。', 'data' => $navigation]);
        }

        return redirect()->route('admin.navigations.index', ['position' => $validated['position']])
            ->with('success', '导航项已添加。');
    }

    /**
     * 显示编辑表单
     */
    public function edit(Navigation $navigation): View
    {
        return view('admin.navigations.edit', compact('navigation'));
    }

    /**
     * 更新导航
     */
    public function update(Request $request, Navigation $navigation): RedirectResponse|JsonResponse
    {
        $validated = $this->validateData($request);

        $validated['is_enable'] = $validated['is_enable'] ?? 1;

        $navigation->update($validated);

        if ($request->wantsJson()) {
            return response()->json(['success' => true, 'message' => '导航项已更新。', 'data' => $navigation]);
        }

        return redirect()->route('admin.navigations.index', ['position' => $validated['position']])
            ->with('success', '导航项已更新。');
    }

    /**
     * 删除导航
     */
    public function destroy(Request $request, Navigation $navigation): RedirectResponse|JsonResponse
    {
        $position = $navigation->position;
        $navigation->delete();

        if ($request->wantsJson()) {
            return response()->json(['success' => true, 'message' => '导航项已删除。']);
        }

        return redirect()->route('admin.navigations.index', ['position' => $position])
            ->with('success', '导航项已删除。');
    }

    /**
     * 批量删除
     */
    public function batchDestroy(Request $request): RedirectResponse|JsonResponse
    {
        $request->validate([
            'ids' => 'required|array',
            'ids.*' => 'exists:navigations,id',
        ]);

        $position = Navigation::whereIn('id', $request->ids)->value('position');
        Navigation::whereIn('id', $request->ids)->delete();

        if ($request->wantsJson()) {
            return response()->json([
                'success' => true,
                'message' => '已删除选中的 ' . count($request->ids) . ' 个导航项。',
            ]);
        }

        return redirect()->route('admin.navigations.index', ['position' => $position ?? 'head'])
            ->with('success', '已删除选中的 ' . count($request->ids) . ' 个导航项。');
    }

    /**
     * 上移排序
     */
    public function moveUp(Request $request, Navigation $navigation): RedirectResponse|JsonResponse
    {
        $position = $navigation->position;

        $previousNav = Navigation::where('position', $position)
            ->where('sort', '<', $navigation->sort)
            ->orderBy('sort', 'desc')
            ->first();

        if ($previousNav) {
            $this->swapSort($navigation, $previousNav);
        }

        if ($request->wantsJson()) {
            return response()->json(['success' => true, 'message' => '导航已上移。']);
        }

        return redirect()->route('admin.navigations.index', ['position' => $position])
            ->with('success', '导航已上移。');
    }

    /**
     * 下移排序
     */
    public function moveDown(Request $request, Navigation $navigation): RedirectResponse|JsonResponse
    {
        $position = $navigation->position;

        $nextNav = Navigation::where('position', $position)
            ->where('sort', '>', $navigation->sort)
            ->orderBy('sort', 'asc')
            ->first();

        if ($nextNav) {
            $this->swapSort($navigation, $nextNav);
        }

        if ($request->wantsJson()) {
            return response()->json(['success' => true, 'message' => '导航已下移。']);
        }

        return redirect()->route('admin.navigations.index', ['position' => $position])
            ->with('success', '导航已下移。');
    }

    /**
     * 拖拽排序：接收排序后的 id 数组，按顺序重排 sort 值
     */
    public function sort(Request $request): JsonResponse
    {
        $request->validate([
            'ids' => 'required|array|min:1',
            'ids.*' => 'integer',
            'position' => 'required|in:head,foot',
        ]);

        DB::transaction(function () use ($request) {
            foreach (array_values($request->ids) as $index => $id) {
                Navigation::where('id', $id)
                    ->where('position', $request->position)
                    ->update(['sort' => $index]);
            }
        });

        return response()->json(['success' => true, 'message' => '排序已更新。']);
    }

    /**
     * 切换启用状态
     */
    public function toggleEnable(Request $request, Navigation $navigation): RedirectResponse|JsonResponse
    {
        $navigation->update(['is_enable' => !$navigation->is_enable]);

        if ($request->wantsJson()) {
            return response()->json([
                'success' => true,
                'is_enable' => $navigation->is_enable,
                'message' => '状态已更新。',
            ]);
        }

        return redirect()->route('admin.navigations.index', ['position' => $navigation->position])
            ->with('success', '状态已更新。');
    }

    /**
     * 校验并归一化表单数据
     */
    private function validateData(Request $request): array
    {
        $validated = $request->validate([
            'position' => 'required|in:head,foot',
            'name' => 'required|string|max:255',
            'icon' => 'nullable|string|max:255',
            'url' => 'required|string|max:2048',
            'is_enable' => 'nullable|boolean',
            'target' => 'required|in:_self,_blank',
            'sort' => 'nullable|integer|min:0',
        ]);

        return $validated;
    }

    /**
     * 交换两个导航的排序值
     */
    private function swapSort(Navigation $a, Navigation $b): void
    {
        DB::transaction(function () use ($a, $b) {
            $temp = $a->sort;
            $a->update(['sort' => $b->sort]);
            $b->update(['sort' => $temp]);
        });
    }
}

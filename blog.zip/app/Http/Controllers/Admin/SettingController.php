<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\MediaFile;
use App\Models\SiteConfig;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;

class SettingController extends Controller
{
    /**
     * 基础设置页
     */
    public function base(): View
    {
        $config = SiteConfig::getInstance();

        return view('admin.settings.base', compact('config'));
    }

    /**
     * 保存基础设置
     */
    public function baseUpdate(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'site_name' => 'required|string|max:255',
            'site_domain' => 'nullable|string|max:255',
            'site_description' => 'nullable|string|max:500',
            'site_keywords' => 'nullable|string|max:255',
            'site_color' => 'nullable|string|max:20',
            'icp_number' => 'nullable|string|max:100',
            'police_record_text' => 'nullable|string|max:100',
            'police_record_link' => 'nullable|string|max:255',
            'contact_email' => 'nullable|string|max:100',
            'contact_phone' => 'nullable|string|max:50',
            'contact_address' => 'nullable|string|max:255',
            'site_copyright' => 'nullable|string|max:255',
            'page_size' => 'nullable|integer|min:1|max:100',
        ]);

        $config = SiteConfig::getInstance();
        $config->update($validated);

        return redirect()->route('admin.settings.base')
            ->with('success', '基础设置保存成功。');
    }

    /**
     * 站点外观页（移除博主头像）
     */
    public function appearance(): View
    {
        $config = SiteConfig::getInstance();

        return view('admin.settings.appearance', compact('config'));
    }

    /**
     * 保存站点外观设置
     */
    public function appearanceUpdate(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'site_logo' => 'nullable|image|mimes:jpeg,png,jpg,gif,webp|max:1024',
            'site_favicon' => 'nullable|image|mimes:ico,png|max:512',
            'contact_qrcode' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:1024',
            'admin_login_bg' => 'nullable|image|mimes:jpeg,png,jpg,webp|max:2048',
        ]);

        $config = SiteConfig::getInstance();

        foreach (['site_logo', 'site_favicon', 'contact_qrcode'] as $field) {
            if ($request->hasFile($field)) {
                // 本地上传：入库并同步登记到文件库，便于在「文件库」中查看/复用
                $validated[$field] = $this->storeSettingImage($request->file($field), $config->$field);
            } elseif ($request->filled($field . '_path')) {
                $validated[$field] = $request->input($field . '_path');
            }
        }

        // 处理后台登录页背景图
        if ($request->hasFile('admin_login_bg')) {
            $validated['admin_login_bg'] = $this->storeSettingImage($request->file('admin_login_bg'), $config->admin_login_bg);
        } elseif ($request->filled('admin_login_bg_path')) {
            $validated['admin_login_bg'] = $request->input('admin_login_bg_path');
        } elseif ($request->boolean('reset_admin_login_bg')) {
            // 恢复默认背景
            $this->deleteSettingImage($config->admin_login_bg);
            $validated['admin_login_bg'] = null;
        }

        // 处理背景图透明度
        if ($request->filled('admin_login_bg_opacity')) {
            $opacity = (int)$request->input('admin_login_bg_opacity');
            if ($opacity >= 0 && $opacity <= 100) {
                $validated['admin_login_bg_opacity'] = $opacity;
            }
        }

        // 文章详情页是否显示侧边博主卡片（纯净阅读模式开关）
        $validated['post_detail_sidebar_author'] = $request->boolean('post_detail_sidebar_author');

        $config->update($validated);

        return redirect()->route('admin.settings.appearance')
            ->with('success', '站点外观设置保存成功。');
    }

    /**
     * AI配置页
     */
    public function ai(): View
    {
        $config = SiteConfig::getInstance();

        return view('admin.settings.ai', compact('config'));
    }

    /**
     * 保存AI配置
     */
    public function aiUpdate(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'ai_api_base_url' => 'nullable|string|max:500',
            'ai_api_key' => 'nullable|string|max:500',
            'ai_model' => 'nullable|string|max:100',
            'ai_image_model' => 'nullable|string|max:100',
        ]);

        $config = SiteConfig::getInstance();
        $config->update($validated);

        return redirect()->route('admin.settings.ai')
            ->with('success', 'AI配置保存成功。');
    }

    /**
     * 自定义代码页
     */
    public function customCode(): View
    {
        $config = SiteConfig::getInstance();

        return view('admin.settings.custom-code', compact('config'));
    }

    /**
     * 保存自定义代码
     */
    public function customCodeUpdate(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'custom_header_html' => 'nullable|string',
            'custom_footer_js' => 'nullable|string',
            'site_start_date' => 'nullable|string|max:20',
        ]);

        $config = SiteConfig::getInstance();
        $config->update($validated);

        return redirect()->route('admin.settings.custom-code')
            ->with('success', '自定义代码保存成功。');
    }

    /**
     * 图片压缩设置页
     */
    public function imageCompress(): View
    {
        $config = SiteConfig::getInstance();

        return view('admin.settings.image-compress', compact('config'));
    }

    /**
     * 保存图片压缩设置
     */
    public function imageCompressUpdate(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'image_compress_quality' => 'required|integer|min:1|max:100',
            'image_compress_max_width' => 'nullable|integer|min:0|max:10000',
            'image_compress_max_height' => 'nullable|integer|min:0|max:10000',
            'image_compress_max_kb' => 'nullable|integer|min:0|max:10240',
        ]);

        $validated['image_compress_enabled'] = $request->boolean('image_compress_enabled');
        $validated['image_compress_max_width'] = (int) ($validated['image_compress_max_width'] ?? 0);
        $validated['image_compress_max_height'] = (int) ($validated['image_compress_max_height'] ?? 0);
        $validated['image_compress_max_kb'] = (int) ($validated['image_compress_max_kb'] ?? 0);

        $config = SiteConfig::getInstance();
        $config->update($validated);

        return redirect()->route('admin.settings.image-compress')
            ->with('success', '图片压缩设置保存成功。');
    }

    /**
     * 博客设置页（博客管理 -> 博客设置）：SEO设置、内容设置、功能设置
     */
    public function blog(): View
    {
        $config = SiteConfig::getInstance();

        return view('admin.settings.blog', compact('config'));
    }

    /**
     * 保存博客设置
     */
    public function blogUpdate(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'site_seo_title' => 'nullable|string|max:255',
            'site_keywords' => 'nullable|string|max:255',
            'site_description' => 'nullable|string|max:500',
            'site_name' => 'required|string|max:255',
            'site_tagline' => 'nullable|string|max:255',
            'site_avatar' => 'nullable|image|mimes:jpeg,png,jpg,gif,webp|max:1024',
            'contact_qq' => 'nullable|string|max:100',
            'contact_weibo' => 'nullable|string|max:255',
            'contact_wechat' => 'nullable|string|max:100',
            'contact_qrcode' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:1024',
            'sidebar_tag_count' => 'nullable|integer|min:0|max:100',
            'enable_dark_mode' => 'nullable|boolean',
            'dark_mode_mode' => 'nullable|string|in:always,never,schedule',
            'dark_mode_start' => 'nullable|string|max:5',
            'dark_mode_end' => 'nullable|string|max:5',
            'search_driver' => 'nullable|string|max:50',
            'enable_comments' => 'nullable|boolean',
            'auto_approve_comments' => 'nullable|boolean',
        ]);

        $config = SiteConfig::getInstance();

        // 博客头像：文件上传优先，其次文件库选择，最后保留原值
        if ($request->hasFile('site_avatar')) {
            $validated['site_avatar'] = $this->storeSettingImage($request->file('site_avatar'), $config->site_avatar);
        } elseif ($request->filled('site_avatar_path')) {
            $validated['site_avatar'] = $request->input('site_avatar_path');
        } elseif ($request->input('remove_site_avatar')) {
            $this->deleteSettingImage($config->site_avatar);
            $validated['site_avatar'] = null;
        }

        $validated['enable_dark_mode'] = $request->boolean('enable_dark_mode');

        // 联系二维码：文件上传优先，其次文件库选择，最后保留原值
        if ($request->hasFile('contact_qrcode')) {
            $validated['contact_qrcode'] = $this->storeSettingImage($request->file('contact_qrcode'), $config->contact_qrcode);
        } elseif ($request->filled('contact_qrcode_path')) {
            $validated['contact_qrcode'] = $request->input('contact_qrcode_path');
        } elseif ($request->input('remove_contact_qrcode')) {
            $this->deleteSettingImage($config->contact_qrcode);
            $validated['contact_qrcode'] = null;
        }

        // 暗黑模式：始终开启 / 始终关闭 / 定时（时间段）
        $darkModeMode = $request->input('dark_mode_mode', 'always');
        $validated['dark_mode_mode'] = $darkModeMode;
        $validated['enable_dark_mode'] = $darkModeMode === 'always'
            || ($darkModeMode === 'never' ? false : $request->boolean('enable_dark_mode'));

        if ($darkModeMode === 'schedule') {
            $start = $this->normalizeTime($request->input('dark_mode_start'));
            $end = $this->normalizeTime($request->input('dark_mode_end'));

            if ($start) {
                $validated['dark_mode_start'] = $start;
            }
            if ($end) {
                $validated['dark_mode_end'] = $end;
            }
        } else {
            // 非定时模式时保留默认时间段，供切换到定时时直接使用
            $validated['dark_mode_start'] = $this->normalizeTime($request->input('dark_mode_start')) ?: ($config->dark_mode_start ?: '19:00');
            $validated['dark_mode_end'] = $this->normalizeTime($request->input('dark_mode_end')) ?: ($config->dark_mode_end ?: '07:00');
        }

        $validated['enable_comments'] = $request->boolean('enable_comments');
        $validated['auto_approve_comments'] = $request->boolean('auto_approve_comments');

        $config->update($validated);

        return redirect()->route('admin.settings.blog')
            ->with('success', '博客设置保存成功。');
    }

    /**
     * 保存升级配置
     */
    public function updateConfig(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'system_update_server' => 'nullable|url|max:500',
            'system_update_key' => 'nullable|string|max:255',
        ]);

        $config = SiteConfig::getInstance();
        $config->update($validated);

        return redirect()->back()
            ->with('success', '升级配置保存成功。');
    }

    /**
     * 保存设置页本地上传的图片，并登记到文件库（media_files），
     * 使「站点外观」「博客设置」等页面上传的图片能在文件库中看到并复用。
     *
     * @param  string|null  $oldPath  被替换的旧图片路径（物理文件与文件库记录一并清理）
     */
    private function storeSettingImage(UploadedFile $file, ?string $oldPath = null): string
    {
        $this->deleteSettingImage($oldPath);

        [$width, $height] = $this->imageDimensions($file);
        $path = $file->store('settings', 'public');

        MediaFile::create([
            'file_name' => $file->getClientOriginalName(),
            'title' => $file->getClientOriginalName(),
            'file_path' => $path,
            'file_type' => 'image',
            'category' => 'images',
            'file_size' => $file->getSize(),
            'mime_type' => $file->getMimeType(),
            'width' => $width,
            'height' => $height,
            'uploaded_by' => auth()->id(),
        ]);

        return $path;
    }

    /**
     * 删除设置页旧图片（物理文件 + 对应文件库记录），保持文件库与设置一致。
     */
    private function deleteSettingImage(?string $path): void
    {
        if (!$path) {
            return;
        }

        Storage::disk('public')->delete($path);
        MediaFile::where('file_path', $path)->delete();
    }

    /**
     * 读取图片宽高，无法解析时返回 [null, null]。
     *
     * @return array{0:int|null,1:int|null}
     */
    private function imageDimensions(UploadedFile $file): array
    {
        try {
            $info = @getimagesize($file->getRealPath());
            if ($info) {
                return [(int) $info[0], (int) $info[1]];
            }
        } catch (\Throwable $e) {
            // 忽略无法解析的图片（如 ico）
        }

        return [null, null];
    }

    /**
     * 规范化时间输入为 H:i 格式，非法输入返回 null。
     */
    private function normalizeTime(?string $time): ?string
    {
        if (!$time || !preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $time)) {
            return null;
        }

        return $time;
    }

    /**
     * 兼容旧路由：重定向到基础设置页
     */
    public function index()
    {
        return redirect()->route('admin.settings.base');
    }

    /**
     * 兼容旧路由：重定向到基础设置页
     */
    public function update(Request $request)
    {
        return redirect()->route('admin.settings.base');
    }
}

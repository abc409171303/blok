<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

class PackageController extends Controller
{
    protected array $packages = [
        'workspace-fresh-install' => [
            'file' => 'workspace-fresh-install.zip',
            'name' => 'BlogCMS 全新安装版（含依赖，推荐首次部署）',
        ],
        'blog-cms-source' => [
            'file' => 'blog-cms-source-1.0.0.zip',
            'name' => 'BlogCMS 源码头文件（不含依赖）',
        ],
        'workspace-deploy' => [
            'file' => 'workspace-deploy.zip',
            'name' => 'Workspace 部署包（含 vendor，不含 node_modules）',
        ],
    ];

    public function download(string $name)
    {
        if (!auth()->check() || auth()->user()->role !== 'super_admin') {
            abort(403);
        }

        $basename = basename($name);
        if (!isset($this->packages[$basename])) {
            abort(404);
        }

        $pkg = $this->packages[$basename];
        $path = public_path($pkg['file']);
        if (!file_exists($path)) {
            abort(404);
        }

        return response()->download($path, $basename . '.zip');
    }

    public function triggerDownload(Request $request, string $name)
    {
        if (!auth()->check() || auth()->user()->role !== 'super_admin') {
            abort(403);
        }

        $basename = basename($name);
        if (!isset($this->packages[$basename])) {
            abort(404);
        }

        $pkg = $this->packages[$basename];
        $path = public_path($pkg['file']);
        if (!file_exists($path)) {
            abort(404);
        }

        return response()->download($path, $basename . '.zip');
    }
}

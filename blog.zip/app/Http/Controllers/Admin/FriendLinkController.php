<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\FriendLink;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;

class FriendLinkController extends Controller
{
    public function index(): View
    {
        $friendLinks = FriendLink::orderBy('sort_order')->orderBy('id')->paginate(15);
        return view('admin.friend-links.index', compact('friendLinks'));
    }

    public function create(): View
    {
        return view('admin.friend-links.create');
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'site_name' => 'required|string|max:200',
            'site_url' => 'required|string|max:500',
            'logo' => 'nullable|image|mimes:jpeg,png,jpg,gif,webp,svg|max:2048',
            'description' => 'nullable|string|max:500',
            'status' => 'nullable|boolean',
            'sort_order' => 'nullable|integer|min:0',
        ]);

        if ($request->hasFile('logo')) {
            $validated['logo'] = $request->file('logo')->store('friend-links', 'public');
        } elseif ($request->filled('logo_path')) {
            // 从文件库选择
            $validated['logo'] = $request->input('logo_path');
        }

        $validated['status'] = $request->has('status');

        FriendLink::create($validated);

        return redirect()->route('admin.friend-links.index')->with('success', '友情链接创建成功。');
    }

    public function edit(FriendLink $friendLink): View
    {
        return view('admin.friend-links.edit', compact('friendLink'));
    }

    public function update(Request $request, FriendLink $friendLink): RedirectResponse
    {
        $validated = $request->validate([
            'site_name' => 'required|string|max:200',
            'site_url' => 'required|string|max:500',
            'logo' => 'nullable|image|mimes:jpeg,png,jpg,gif,webp,svg|max:2048',
            'description' => 'nullable|string|max:500',
            'status' => 'nullable|boolean',
            'sort_order' => 'nullable|integer|min:0',
        ]);

        if ($request->hasFile('logo')) {
            if ($friendLink->logo) {
                Storage::disk('public')->delete($friendLink->logo);
            }
            $validated['logo'] = $request->file('logo')->store('friend-links', 'public');
        } elseif ($request->filled('logo_path') && $request->input('logo_path') !== $friendLink->logo) {
            // 从文件库选择（更换）
            if ($friendLink->logo) {
                Storage::disk('public')->delete($friendLink->logo);
            }
            $validated['logo'] = $request->input('logo_path');
        } elseif ($request->input('remove_logo')) {
            // 移除 Logo
            if ($friendLink->logo) {
                Storage::disk('public')->delete($friendLink->logo);
            }
            $validated['logo'] = null;
        }

        $validated['status'] = $request->has('status');

        $friendLink->update($validated);

        return redirect()->route('admin.friend-links.index')->with('success', '友情链接更新成功。');
    }

    public function destroy(FriendLink $friendLink): RedirectResponse
    {
        if ($friendLink->logo) {
            Storage::disk('public')->delete($friendLink->logo);
        }
        $friendLink->delete();

        return redirect()->route('admin.friend-links.index')->with('success', '友情链接已删除。');
    }
}

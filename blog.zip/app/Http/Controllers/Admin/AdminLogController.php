<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AdminLog;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class AdminLogController extends Controller
{
    public function index(Request $request): View
    {
        $query = AdminLog::with('user')
            ->orderBy('created_at', 'desc');

        if ($request->filled('user_id')) {
            $query->where('user_id', $request->user_id);
        }

        if ($request->filled('action')) {
            $query->where('action', $request->action);
        }

        $logs = $query->paginate(20);

        $actions = AdminLog::distinct()->pluck('action')->toArray();

        return view('admin.logs.index', compact('logs', 'actions'));
    }

    public function destroy(AdminLog $log): RedirectResponse
    {
        $log->delete();

        return redirect()->route('admin.logs.index')
            ->with('success', '日志已删除。');
    }

    public function clear(): RedirectResponse
    {
        AdminLog::truncate();

        return redirect()->route('admin.logs.index')
            ->with('success', '所有日志已清空。');
    }
}

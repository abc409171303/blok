<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\SiteConfig;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class AboutController extends Controller
{
    public function edit(): View
    {
        $config = SiteConfig::getInstance();

        return view('admin.about.edit', compact('config'));
    }

    public function update(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'about_content' => 'required|string',
        ]);

        $config = SiteConfig::getInstance();
        $config->update($validated);

        return redirect()->route('admin.about.edit')
            ->with('success', '关于博主页面更新成功。');
    }
}

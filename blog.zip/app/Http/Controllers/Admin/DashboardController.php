<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Comment;
use App\Models\Post;
use App\Models\Tag;
use App\Models\AdminLog;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\View\View;

class DashboardController extends Controller
{
    public function index(): View
    {
        $stats = [
            'posts' => Post::count(),
            'comments' => Comment::count(),
            'categories' => Category::count(),
            'tags' => Tag::count(),
            'views' => Post::sum('views'),
            'published' => Post::where('status', 'published')->count(),
            'draft' => Post::where('status', 'draft')->count(),
        ];

        $server = [
            'php_version' => PHP_VERSION,
            'laravel_version' => app()->version(),
            'os' => PHP_OS,
            'server_software' => $_SERVER['SERVER_SOFTWARE'] ?? 'PHP Development Server',
            'upload_max' => ini_get('upload_max_filesize'),
            'memory_limit' => ini_get('memory_limit') ?: '未知',
            'max_execution_time' => ini_get('max_execution_time') . 's',
            'server_time' => \Carbon\Carbon::now('Asia/Shanghai')->format('Y-m-d H:i:s'),
            'db_version' => $this->databaseVersion(),
            'timezone' => 'Asia/Shanghai',
        ];

        $installWizardExists = \App\Support\InstallState::wizardExists();

        return view('admin.dashboard', compact('stats', 'server', 'installWizardExists'));
    }

    protected function databaseVersion(): string
    {
        try {
            $connection = \Illuminate\Support\Facades\DB::connection();
            $version = $connection->getPdo()->getAttribute(\PDO::ATTR_SERVER_VERSION);
            $driver = $connection->getDriverName();

            return $driver . ' ' . $version;
        } catch (\Throwable $e) {
            return '未知';
        }
    }

    public function clearCache(Request $request): RedirectResponse
    {
        try {
            Artisan::call('optimize:clear');
            AdminLog::log('设置', '清除系统缓存');
            $message = '缓存已清除。';
        } catch (\Throwable $e) {
            $message = '缓存清除失败：' . $e->getMessage();
        }

        return back()->with('success', $message);
    }
}

<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Tag;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\View\View;

class TagController extends Controller
{
    public function index(): View
    {
        $tags = Tag::with('parent')->withCount('posts')->latest()->paginate(20);
        $parents = Tag::whereNull('parent_id')->orderBy('name')->get();

        return view('admin.tags.index', compact('tags', 'parents'));
    }

    public function create(): View
    {
        $parents = Tag::whereNull('parent_id')->orderBy('name')->get();

        return view('admin.tags.create', compact('parents'));
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'name' => 'required|string|max:50|unique:tags',
            'parent_id' => 'nullable|exists:tags,id',
        ]);

        $validated['slug'] = Str::slug($validated['name']) ?: 'tag-' . uniqid();
        if (empty($validated['parent_id'])) {
            unset($validated['parent_id']);
        }

        Tag::create($validated);

        return redirect()->route('admin.tags.index')
            ->with('success', '标签创建成功');
    }

    public function edit(Tag $tag): View
    {
        $parents = Tag::whereNull('parent_id')
            ->where('id', '!=', $tag->id)
            ->orderBy('name')
            ->get();

        return view('admin.tags.edit', compact('tag', 'parents'));
    }

    public function update(Request $request, Tag $tag): RedirectResponse
    {
        $validated = $request->validate([
            'name' => 'required|string|max:50|unique:tags,name,' . $tag->id,
            'parent_id' => 'nullable|exists:tags,id',
        ]);

        $validated['slug'] = Str::slug($validated['name']) ?: 'tag-' . uniqid();
        if (empty($validated['parent_id'])) {
            $validated['parent_id'] = null;
        }
        // 防止将自身设为父级
        if ($validated['parent_id'] == $tag->id) {
            return back()->withErrors(['parent_id' => '不能将自身设为所属分类。'])->withInput();
        }

        $tag->update($validated);

        return redirect()->route('admin.tags.index')
            ->with('success', '标签更新成功');
    }

    public function destroy(Tag $tag): RedirectResponse
    {
        $tag->posts()->detach();
        // 子级标签提升为一级（parent_id 置空）
        Tag::where('parent_id', $tag->id)->update(['parent_id' => null]);
        $tag->delete();

        return redirect()->route('admin.tags.index')
            ->with('success', '标签删除成功');
    }
}

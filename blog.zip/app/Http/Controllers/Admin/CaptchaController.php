<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\SiteConfig;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class CaptchaController extends Controller
{
    public function index(): View
    {
        $config = SiteConfig::getInstance();

        return view('admin.captcha.index', compact('config'));
    }

    public function update(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'captcha_enabled' => 'nullable|boolean',
            'captcha_comment' => 'nullable|boolean',
            'captcha_message' => 'nullable|boolean',
            'captcha_admin_login' => 'nullable|boolean',
        ]);

        $config = SiteConfig::getInstance();

        $config->update([
            'captcha_enabled' => $request->boolean('captcha_enabled'),
            'captcha_comment' => $request->boolean('captcha_comment'),
            'captcha_message' => $request->boolean('captcha_message'),
            'captcha_admin_login' => $request->boolean('captcha_admin_login'),
        ]);

        return redirect()->route('admin.captcha.index')
            ->with('success', '验证码设置已保存。');
    }
}

<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Slide;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;

class SlideController extends Controller
{
    public function index(): View
    {
        $slides = Slide::orderBy('sort_order')->orderBy('id')->paginate(15);
        return view('admin.slides.index', compact('slides'));
    }

    public function create(): View
    {
        return view('admin.slides.create');
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'title' => 'required|string|max:200',
            'subtitle' => 'nullable|string|max:500',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif,webp|max:2048',
            'video_url' => 'nullable|string|max:500',
            'video_cover' => 'nullable|image|mimes:jpeg,png,jpg,gif,webp|max:2048',
            'position' => 'nullable|string|max:50',
            'bg_color' => 'nullable|string|max:20',
            'link_url' => 'nullable|string|max:500',
            'sort_order' => 'nullable|integer|min:0',
            'status' => 'nullable|boolean',
        ]);

        // 验证：图片和视频至少需要一个
        if (empty($validated['image']) && empty($validated['video_url']) && !$request->has('image_data_url') && !$request->filled('image_path')) {
            return back()->withErrors(['image' => '请上传背景图片或填写视频 URL'])->withInput();
        }

        if ($request->hasFile('image')) {
            $validated['image'] = $request->file('image')->store('slides', 'public');
        } elseif ($request->has('image_data_url')) {
            // Handle base64 image data
            $validated['image'] = $this->processBase64Image($request->image_data_url, 'slides');
        } elseif ($request->filled('image_path')) {
            // 从文件库选择
            $validated['image'] = $request->input('image_path');
        }

        if ($request->hasFile('video_cover')) {
            $validated['video_cover'] = $request->file('video_cover')->store('slides', 'public');
        } elseif ($request->filled('video_cover_path')) {
            // 从文件库选择
            $validated['video_cover'] = $request->input('video_cover_path');
        }

        $validated['status'] = $request->has('status');

        Slide::create($validated);

        return redirect()->route('admin.slides.index')->with('success', '幻灯片创建成功。');
    }

    public function edit(Slide $slide): View
    {
        return view('admin.slides.edit', compact('slide'));
    }

    public function update(Request $request, Slide $slide): RedirectResponse
    {
        $validated = $request->validate([
            'title' => 'required|string|max:200',
            'subtitle' => 'nullable|string|max:500',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif,webp|max:2048',
            'video_url' => 'nullable|string|max:500',
            'video_cover' => 'nullable|image|mimes:jpeg,png,jpg,gif,webp|max:2048',
            'position' => 'nullable|string|max:50',
            'bg_color' => 'nullable|string|max:20',
            'link_url' => 'nullable|string|max:500',
            'sort_order' => 'nullable|integer|min:0',
            'status' => 'nullable|boolean',
        ]);

        $validated['status'] = $request->has('status');

        if ($request->hasFile('image')) {
            if ($slide->image) {
                Storage::disk('public')->delete($slide->image);
            }
            $validated['image'] = $request->file('image')->store('slides', 'public');
        } elseif ($request->has('image_data_url') && !empty($request->image_data_url)) {
            if ($slide->image) {
                Storage::disk('public')->delete($slide->image);
            }
            $validated['image'] = $this->processBase64Image($request->image_data_url, 'slides');
        } elseif ($request->filled('image_path')) {
            // 从文件库选择
            $validated['image'] = $request->input('image_path');
        }

        if ($request->hasFile('video_cover')) {
            if ($slide->video_cover) {
                Storage::disk('public')->delete($slide->video_cover);
            }
            $validated['video_cover'] = $request->file('video_cover')->store('slides', 'public');
        } elseif ($request->filled('video_cover_path')) {
            // 从文件库选择
            $validated['video_cover'] = $request->input('video_cover_path');
        }

        $slide->update($validated);

        return redirect()->route('admin.slides.index')->with('success', '幻灯片更新成功。');
    }

    private function processBase64Image($dataUrl, $folder)
    {
        if (preg_match('/^data:image\/(\w+);base64,/', $dataUrl, $type)) {
            $dataUrl = substr($dataUrl, strpos($dataUrl, ',') + 1);
            $type = strtolower($type[1]);
            $data = base64_decode($dataUrl);

            if ($data === false) return null;

            $filename = uniqid() . '.' . $type;
            Storage::disk('public')->put($folder . '/' . $filename, $data);
            return $folder . '/' . $filename;
        }
        return null;
    }

    public function destroy(Slide $slide): RedirectResponse
    {
        if ($slide->image) {
            Storage::disk('public')->delete($slide->image);
        }
        $slide->delete();

        return redirect()->route('admin.slides.index')->with('success', '幻灯片已删除。');
    }
}

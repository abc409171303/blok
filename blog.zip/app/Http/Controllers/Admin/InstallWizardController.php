<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AdminLog;
use App\Support\InstallState;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Auth;

/**
 * 后台安装向导残留清理。
 *
 * 仅超级管理员可用，删除安装向导源码文件并保留 install.lock 锁文件。
 */
class InstallWizardController extends Controller
{
    public function remove(): RedirectResponse
    {
        if (!Auth::check() || !Auth::user()->isSuperAdmin()) {
            abort(403, '只有超级管理员可以移除安装向导。');
        }

        // 幂等：安装向导已不存在时直接返回成功
        if (!InstallState::wizardExists()) {
            return back()->with('success', '安装向导已移除，无法再次重复安装。');
        }

        $results = $this->deleteWizardFiles();
        $failed = array_filter($results, fn ($ok) => !$ok);

        if (!empty($failed)) {
            return back()->with('error', '部分安装向导文件删除失败，请检查文件权限后手动删除：' . implode('、', array_keys($failed)));
        }

        // 清除路由缓存，确保删除后的路由立即失效
        try {
            Artisan::call('route:clear');
        } catch (\Throwable $e) {
            // 路由缓存清除失败不影响删除结果
        }

        AdminLog::log('设置', '移除安装向导');

        return back()->with('success', '安装向导已移除，无法再次重复安装。');
    }

    /**
     * 删除安装向导相关文件，返回每项的删除结果。
     */
    protected function deleteWizardFiles(): array
    {
        return [
            'routes/web.php 引用' => $this->removeRequireFromWebRoutes(),
            'routes/install.php' => $this->deleteFile(base_path('routes/install.php')),
            'InstallController.php' => $this->deleteFile(app_path('Http/Controllers/InstallController.php')),
            'resources/views/install' => $this->deleteDirectory(resource_path('views/install')),
        ];
    }

    /**
     * 从 routes/web.php 中移除对 install.php 的引用。
     */
    protected function removeRequireFromWebRoutes(): bool
    {
        $path = base_path('routes/web.php');
        if (!is_file($path)) {
            return true;
        }

        $content = file_get_contents($path);
        if ($content === false) {
            return false;
        }

        $needle = "require __DIR__.'/install.php';";
        if (!str_contains($content, $needle)) {
            return true;
        }

        // 连同上方注释一并移除，避免留下孤立注释
        $content = str_replace(
            "// Installation routes (protected by global EnsureInstalled middleware)\nrequire __DIR__.'/install.php';",
            '',
            $content
        );
        $content = str_replace($needle, '', $content);

        return file_put_contents($path, $content) !== false;
    }

    protected function deleteFile(string $path): bool
    {
        if (!is_file($path)) {
            return true;
        }

        return @unlink($path);
    }

    protected function deleteDirectory(string $path): bool
    {
        if (!is_dir($path)) {
            return true;
        }

        $items = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($path, \FilesystemIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::CHILD_FIRST
        );

        foreach ($items as $item) {
            $ok = $item->isDir() ? @rmdir($item->getPathname()) : @unlink($item->getPathname());
            if (!$ok) {
                return false;
            }
        }

        return @rmdir($path);
    }
}

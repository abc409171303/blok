<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\MediaFile;
use App\Services\ImageCompressor;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class UploadController extends Controller
{
    public function image(Request $request): JsonResponse
    {
        $request->validate([
            'image' => 'required|image|mimes:jpeg,png,jpg,gif,webp,bmp|max:5120',
        ]);

        $file = app(ImageCompressor::class)->maybeCompress($request->file('image'));
        $filename = Str::random(20) . '_' . time() . '.' . $file->getClientOriginalExtension();
        $path = $file->storeAs('content', $filename, 'public');

        // 同步写入文件库
        $width = null;
        $height = null;
        try {
            $imageInfo = getimagesize($file->getRealPath());
            if ($imageInfo) {
                $width = $imageInfo[0];
                $height = $imageInfo[1];
            }
        } catch (\Exception $e) {
            // 忽略错误
        }

        MediaFile::create([
            'file_name' => $file->getClientOriginalName(),
            'title' => $file->getClientOriginalName(),
            'file_path' => $path,
            'file_type' => 'image',
            'category' => 'images',
            'file_size' => $file->getSize(),
            'mime_type' => $file->getMimeType(),
            'width' => $width,
            'height' => $height,
            'uploaded_by' => auth()->id(),
        ]);

        return response()->json([
            'success' => true,
            'url' => asset(Storage::url($path)),
            'path' => $path,
        ]);
    }

    public function file(Request $request): JsonResponse
    {
        $request->validate([
            'file' => 'required|file|mimes:jpeg,png,jpg,gif,webp,bmp,mp4,webm,ogg,mp3,wav|max:102400',
        ]);

        $file = $request->file('file');
        if (str_starts_with((string) $file->getMimeType(), 'image/')) {
            $file = app(ImageCompressor::class)->maybeCompress($file);
        }
        $ext = strtolower($file->getClientOriginalExtension());

        if (in_array($ext, ['mp4', 'webm', 'ogg'])) {
            $fileType = 'video';
        } elseif (in_array($ext, ['mp3', 'wav', 'ogg', 'aac', 'flac'])) {
            $fileType = 'audio';
        } else {
            $fileType = 'image';
        }

        $filename = Str::random(20) . '_' . time() . '.' . $ext;
        $path = $file->storeAs('content', $filename, 'public');

        $width = null;
        $height = null;
        if ($fileType === 'image') {
            try {
                $imageInfo = getimagesize($file->getRealPath());
                if ($imageInfo) {
                    $width = $imageInfo[0];
                    $height = $imageInfo[1];
                }
            } catch (\Exception $e) {
                // 忽略错误
            }
        }

        MediaFile::create([
            'file_name' => $file->getClientOriginalName(),
            'title' => $file->getClientOriginalName(),
            'file_path' => $path,
            'file_type' => $fileType,
            'category' => $fileType . 's',
            'file_size' => $file->getSize(),
            'mime_type' => $file->getMimeType(),
            'width' => $width,
            'height' => $height,
            'uploaded_by' => auth()->id(),
        ]);

        return response()->json([
            'success' => true,
            'url' => asset(Storage::url($path)),
            'path' => $path,
        ]);
    }
}

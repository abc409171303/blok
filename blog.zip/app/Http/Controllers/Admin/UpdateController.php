<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\SiteConfig;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;
use RuntimeException;

class UpdateController extends Controller
{
    private const TEMP_DIR = '/tmp/blog-updates';
    private const BACKUP_DIR = '/tmp/blog-backups';

    /**
     * 系统升级页面
     */
    public function index(): View
    {
        $config = SiteConfig::getInstance();
        $updateInfo = $this->checkUpdate($config);

        return view('admin.update.index', compact('config', 'updateInfo'));
    }

    /**
     * 检查更新
     */
    public function check(Request $request): JsonResponse
    {
        $config = SiteConfig::getInstance();
        $updateInfo = $this->checkUpdate($config);

        return response()->json([
            'success' => true,
            'data' => $updateInfo,
        ]);
    }

    /**
     * 执行升级
     */
    public function upgrade(Request $request): JsonResponse
    {
        try {
            DB::beginTransaction();

            $config = SiteConfig::getInstance();
            $server = trim($config->system_update_server ?? '');
            $key = trim($config->system_update_key ?? '');

            if (empty($server)) {
                return response()->json([
                    'success' => false,
                    'message' => '请先在系统设置中配置远程更新服务器地址。',
                ], 422);
            }

            if (empty($key)) {
                return response()->json([
                    'success' => false,
                    'message' => '请先在系统设置中配置更新密钥。',
                ], 422);
            }

            // 1. 获取版本信息
            $versionJson = $this->fetchVersionJson($server);
            $versionData = json_decode($versionJson, true);

            if (!$versionData || !isset($versionData['version'])) {
                return response()->json([
                    'success' => false,
                    'message' => '无法获取版本信息，远程服务器响应格式错误。',
                ], 500);
            }

            $remoteVersion = $versionData['version'];
            $currentVersion = config('app.version', '1.0.0');
            $downloadUrl = $versionData['download_url'] ?? '';
            $md5Hash = $versionData['md5'] ?? '';
            $changelog = $versionData['changelog'] ?? '';

            if ($remoteVersion <= $currentVersion) {
                return response()->json([
                    'success' => true,
                    'data' => [
                        'current_version' => $currentVersion,
                        'remote_version' => $remoteVersion,
                        'need_upgrade' => false,
                        'message' => '当前已是最新版本。',
                    ],
                ]);
            }

            // 2. 备份源码
            $backupPath = $this->backupSourceCode();

            // 3. 备份数据库
            $dbBackupPath = $this->backupDatabase();

            // 4. 下载升级包
            $zipPath = $this->downloadPackage($downloadUrl, $server, $key);

            // 5. 校验 MD5
            if (!empty($md5Hash)) {
                $actualMd5 = md5_file($zipPath);
                if ($actualMd5 !== $md5Hash) {
                    $this->cleanupTempFiles([$zipPath]);
                    return response()->json([
                        'success' => false,
                        'message' => '升级包校验失败，文件可能被篡改。',
                    ], 400);
                }
            }

            // 6. 解压并覆盖文件
            $extractDir = self::TEMP_DIR . '/' . time();
            $this->extractPackage($zipPath, $extractDir);
            $this->applyFiles($extractDir);

            // 7. 执行升级 SQL
            $this->runMigrations($extractDir);

            DB::commit();

            // 8. 清理临时文件
            $this->cleanupTempFiles([$zipPath, $extractDir]);

            // 9. 更新版本号
            $config->update(['system_last_version' => $remoteVersion]);

            return response()->json([
                'success' => true,
                'data' => [
                    'current_version' => $currentVersion,
                    'new_version' => $remoteVersion,
                    'backup_path' => $backupPath,
                    'db_backup_path' => $dbBackupPath,
                    'changelog' => $changelog,
                    'message' => '升级成功！',
                ],
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            $this->cleanupTempFiles();

            return response()->json([
                'success' => false,
                'message' => '升级失败：' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * 回滚升级
     */
    public function rollback(Request $request): JsonResponse
    {
        try {
            DB::beginTransaction();

            $backupId = $request->input('backup_id');
            if (empty($backupId)) {
                return response()->json([
                    'success' => false,
                    'message' => '请提供备份ID。',
                ], 422);
            }

            $backupPath = self::BACKUP_DIR . '/' . $backupId;
            $dbBackupPath = $backupPath . '.sql';

            if (!is_dir($backupPath) && !file_exists($dbBackupPath)) {
                return response()->json([
                    'success' => false,
                    'message' => '找不到对应的备份文件。',
                ], 404);
            }

            // 恢复源码
            if (is_dir($backupPath)) {
                $this->restoreSourceCode($backupPath);
            }

            // 恢复数据库
            if (file_exists($dbBackupPath)) {
                $this->restoreDatabase($dbBackupPath);
            }

            $config = SiteConfig::getInstance();
            $config->update(['system_last_version' => $backupId]);

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => '回滚成功！',
            ]);

        } catch (\Exception $e) {
            DB::rollBack();

            return response()->json([
                'success' => false,
                'message' => '回滚失败：' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * 获取备份列表
     */
    public function backups(): JsonResponse
    {
        $backups = [];
        if (is_dir(self::BACKUP_DIR)) {
            $files = scandir(self::BACKUP_DIR);
            foreach ($files as $file) {
                if ($file !== '.' && $file !== '..' && is_dir(self::BACKUP_DIR . '/' . $file)) {
                    $backups[] = [
                        'id' => $file,
                        'path' => self::BACKUP_DIR . '/' . $file,
                        'size' => $this->getDirSize(self::BACKUP_DIR . '/' . $file),
                        'created_at' => filemtime(self::BACKUP_DIR . '/' . $file),
                    ];
                }
            }
        }

        return response()->json([
            'success' => true,
            'data' => array_reverse($backups),
        ]);
    }

    /**
     * 检查更新信息
     */
    private function checkUpdate(SiteConfig $config): array
    {
        $server = trim($config->system_update_server ?? '');
        $key = trim($config->system_update_key ?? '');
        $currentVersion = config('app.version', '1.0.0');

        if (empty($server) || empty($key)) {
            return [
                'current_version' => $currentVersion,
                'remote_version' => null,
                'need_upgrade' => false,
                'message' => empty($server) ? '未配置远程更新服务器地址' : '未配置更新密钥',
            ];
        }

        try {
            $versionJson = $this->fetchVersionJson($server);
            $versionData = json_decode($versionJson, true);

            if (!$versionData || !isset($versionData['version'])) {
                return [
                    'current_version' => $currentVersion,
                    'remote_version' => null,
                    'need_upgrade' => false,
                    'message' => '获取版本信息失败',
                ];
            }

            return [
                'current_version' => $currentVersion,
                'remote_version' => $versionData['version'],
                'need_upgrade' => $versionData['version'] > $currentVersion,
                'message' => $versionData['version'] > $currentVersion ? '有新版本可用' : '当前已是最新版本',
                'changelog' => $versionData['changelog'] ?? '',
            ];
        } catch (\Exception $e) {
            return [
                'current_version' => $currentVersion,
                'remote_version' => null,
                'need_upgrade' => false,
                'message' => '检查更新失败：' . $e->getMessage(),
            ];
        }
    }

    /**
     * 获取版本 JSON
     */
    private function fetchVersionJson(string $server): string
    {
        $response = Http::withOptions([
            'timeout' => 30,
            'verify' => true,
        ])->get(rtrim($server, '/') . '/version.json');

        if (!$response->successful()) {
            throw new RuntimeException('无法连接到远程更新服务器');
        }

        return $response->body();
    }

    /**
     * 备份源码
     */
    private function backupSourceCode(): string
    {
        $backupId = 'src_' . date('Ymd_His');
        $backupPath = self::BACKUP_DIR . '/' . $backupId;

        mkdir($backupPath, 0755, true);

        $items = [
            'app',
            'config',
            'database',
            'resources',
            'routes',
            'public/*',
            '.env',
        ];

        foreach ($items as $item) {
            $src = base_path($item);
            $dst = $backupPath . '/' . basename($item);
            if (file_exists($src)) {
                if (is_dir($src)) {
                    $this->copyDirectory($src, $dst);
                } else {
                    copy($src, $dst);
                }
            }
        }

        return $backupPath;
    }

    /**
     * 备份数据库
     */
    private function backupDatabase(): string
    {
        $backupId = 'db_' . date('Ymd_His');
        $backupPath = self::BACKUP_DIR . '/' . $backupId . '.sql';

        $connection = config('database.default');
        $config = config("database.connections.{$connection}");

        if ($connection === 'mysql' || $connection === 'mariadb') {
            $cmd = sprintf(
                'mysqldump -h%s -P%s -u%s %s --single-transaction --quick --lock-tables=false > %s 2>&1',
                $config['host'] ?? 'localhost',
                $config['port'] ?? 3306,
                escapeshellarg($config['username'] ?? ''),
                escapeshellarg($config['database'] ?? ''),
                escapeshellarg($backupPath)
            );
            exec($cmd, $output, $returnCode);
        } elseif ($connection === 'sqlite') {
            $dbPath = $config['database'];
            if (file_exists($dbPath)) {
                copy($dbPath, $backupPath);
            }
        } else {
            // SQL Server / PostgreSQL 等暂无自动备份实现。升级会改动数据库结构，
            // 没有备份时继续执行有数据丢失风险，因此明确中止而不是静默跳过。
            throw new \RuntimeException(
                '当前数据库驱动（' . $connection . '）暂不支持自动数据库备份，已中止升级以保护数据。'
            );
        }

        return $backupPath;
    }

    /**
     * 下载升级包
     */
    private function downloadPackage(string $url, string $server, string $key): string
    {
        $zipPath = self::TEMP_DIR . '/' . time() . '.zip';
        mkdir(self::TEMP_DIR, 0755, true);

        $response = Http::withOptions([
            'timeout' => 300,
            'verify' => true,
        ])->withHeaders([
            'Authorization' => 'Bearer ' . $key,
            'X-Update-Key' => $key,
        ])->sink($zipPath)->get($url);

        if (!$response->successful()) {
            throw new RuntimeException('下载升级包失败');
        }

        return $zipPath;
    }

    /**
     * 解压升级包
     */
    private function extractPackage(string $zipPath, string $extractDir): void
    {
        mkdir($extractDir, 0755, true);

        $zip = new \ZipArchive;
        if ($zip->open($zipPath) !== true) {
            throw new RuntimeException('无法打开升级包');
        }

        $zip->extractTo($extractDir);
        $zip->close();
    }

    /**
     * 应用文件
     */
    private function applyFiles(string $extractDir): void
    {
        $items = ['app', 'config', 'database', 'resources', 'routes', 'public'];

        foreach ($items as $item) {
            $src = $extractDir . '/' . $item;
            $dst = base_path($item);
            if (is_dir($src)) {
                $this->copyDirectory($src, $dst, true);
            }
        }

        // 处理 .env
        $envSrc = $extractDir . '/.env';
        if (file_exists($envSrc)) {
            copy($envSrc, base_path('.env'));
        }
    }

    /**
     * 执行迁移
     */
    private function runMigrations(string $extractDir): void
    {
        $migrationsDir = $extractDir . '/database/migrations';
        if (is_dir($migrationsDir)) {
            $files = glob($migrationsDir . '/*.php');
            foreach ($files as $file) {
                require $file;
                $className = class_basename(str_replace('/', '.', substr($file, strlen($migrationsDir) + 1)));
                $migration = new $className();
                $migration->up();
            }
        }
    }

    /**
     * 恢复源码
     */
    private function restoreSourceCode(string $backupPath): void
    {
        $items = ['app', 'config', 'database', 'resources', 'routes', 'public'];

        foreach ($items as $item) {
            $src = $backupPath . '/' . $item;
            $dst = base_path($item);
            if (is_dir($src)) {
                $this->copyDirectory($src, $dst, true);
            }
        }

        $envSrc = $backupPath . '/.env';
        if (file_exists($envSrc)) {
            copy($envSrc, base_path('.env'));
        }
    }

    /**
     * 恢复数据库
     */
    private function restoreDatabase(string $dbBackupPath): void
    {
        $connection = config('database.default');
        $config = config("database.connections.{$connection}");

        if ($connection === 'mysql' || $connection === 'mariadb') {
            $cmd = sprintf(
                'mysql -h%s -P%s -u%s %s < %s 2>&1',
                $config['host'] ?? 'localhost',
                $config['port'] ?? 3306,
                escapeshellarg($config['username'] ?? ''),
                escapeshellarg($config['database'] ?? ''),
                escapeshellarg($dbBackupPath)
            );
            exec($cmd, $output, $returnCode);
        } elseif ($connection === 'sqlite') {
            $dbPath = $config['database'];
            copy($dbBackupPath, $dbPath);
        } else {
            throw new \RuntimeException(
                '当前数据库驱动（' . $connection . '）暂不支持自动数据库回滚，已中止操作。'
            );
        }
    }

    /**
     * 复制目录
     */
    private function copyDirectory(string $src, string $dst, bool $overwrite = false): void
    {
        if (!is_dir($src)) {
            return;
        }

        if (!is_dir($dst)) {
            mkdir($dst, 0755, true);
        }

        $items = scandir($src);
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') {
                continue;
            }

            $srcPath = $src . '/' . $item;
            $dstPath = $dst . '/' . $item;

            if (is_dir($srcPath)) {
                $this->copyDirectory($srcPath, $dstPath, $overwrite);
            } else {
                if (!$overwrite || !file_exists($dstPath)) {
                    copy($srcPath, $dstPath);
                }
            }
        }
    }

    /**
     * 清理临时文件
     */
    private function cleanupTempFiles(array $exclude = []): void
    {
        if (is_dir(self::TEMP_DIR)) {
            $items = scandir(self::TEMP_DIR);
            foreach ($items as $item) {
                if ($item === '.' || $item === '..') {
                    continue;
                }
                $path = self::TEMP_DIR . '/' . $item;
                if (!in_array($path, $exclude)) {
                    if (is_dir($path)) {
                        $this->deleteDirectory($path);
                    } else {
                        @unlink($path);
                    }
                }
            }
        }
    }

    /**
     * 删除目录
     */
    private function deleteDirectory(string $dir): void
    {
        if (!is_dir($dir)) {
            return;
        }

        $items = scandir($dir);
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') {
                continue;
            }

            $path = $dir . '/' . $item;
            if (is_dir($path)) {
                $this->deleteDirectory($path);
            } else {
                @unlink($path);
            }
        }

        @rmdir($dir);
    }

    /**
     * 获取目录大小
     */
    private function getDirSize(string $dir): int
    {
        $size = 0;
        $items = scandir($dir);
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') {
                continue;
            }
            $path = $dir . '/' . $item;
            if (is_dir($path)) {
                $size += $this->getDirSize($path);
            } else {
                $size += filesize($path);
            }
        }
        return $size;
    }
}

<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\AdminLog;
use App\Rules\CaptchaRule;
use App\Services\Captcha;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\View\View;

class AuthController extends Controller
{
    public function showLoginForm(): View
    {
        return view('admin.login');
    }

    public function login(Request $request): RedirectResponse
    {
        $rules = [
            'account' => 'required|string',
            'password' => 'required|string',
        ];

        if (Captcha::enabled('admin_login')) {
            $rules['captcha'] = ['required', new CaptchaRule('admin_login')];
        }

        $credentials = $request->validate($rules);

        $user = User::where('name', $credentials['account'])->first();

        if ($user && Hash::check($credentials['password'], $user->password)) {
            if (!$user->isAdmin()) {
                return redirect()->route('admin.login')->with('error', '您没有管理员权限。');
            }

            Auth::login($user);
            $request->session()->regenerate();

            AdminLog::log('登录', '管理员登录系统');

            return redirect()->intended(route('admin.dashboard'));
        }

        return redirect()->route('admin.login')
            ->with('error', '账号或密码错误。')
            ->withInput($request->only('account'));
    }

    public function logout(): RedirectResponse
    {
        AdminLog::log('退出', '管理员退出系统');
        Auth::logout();

        return redirect()->route('admin.login')->with('success', '您已成功退出。');
    }

    public function showPasswordForm(): View
    {
        return view('admin.password');
    }

    public function updatePassword(Request $request): RedirectResponse
    {
        $request->validate([
            'current_password' => 'required|string',
            'password' => 'required|string|min:6|confirmed',
        ]);

        $user = Auth::user();
        if (!$user) {
            return redirect()->route('admin.login');
        }

        if (!Hash::check($request->current_password, $user->password)) {
            return back()->withErrors(['current_password' => '当前密码不正确。'])->withInput();
        }

        $user->password = Hash::make($request->password);
        $user->save();

        return redirect()->route('admin.dashboard')->with('success', '密码修改成功。');
    }
}

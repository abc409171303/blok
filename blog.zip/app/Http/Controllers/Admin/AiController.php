<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\MediaFile;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class AiController extends Controller
{
    private function getConfig()
    {
        $config = \App\Models\SiteConfig::getInstance();
        return [
            'base_url' => $config->ai_api_base_url,
            'api_key' => $config->ai_api_key,
            'model' => $config->ai_model ?: 'qwen-plus',
            'ai_image_model' => $config->ai_image_model ?: 'wanx2.1-t2i-turbo',
        ];
    }

    public function write(Request $request): Response|StreamedResponse
    {
        $request->validate([
            'prompt' => 'required|string|max:2000',
            'title' => 'nullable|string|max:255',
            'image' => 'nullable|string|max:2000',
            'stream' => 'nullable|boolean',
        ]);

        $cfg = $this->getConfig();
        if (!$cfg['base_url'] || !$cfg['api_key']) {
            return response()->json(['error' => '请先在系统设置中配置 AI API 密钥。'], 400);
        }

        // 组装消息：标题作为参考上下文 + 用户提示词 + 可选图片（图生文）
        $userParts = [];
        if ($request->filled('title')) {
            $userParts[] = '【文章标题】' . $request->title . '，请围绕该标题展开写作';
        }
        $userParts[] = $request->prompt;

        $userContent = implode("\n\n", $userParts);
        $imageDataUrl = $request->filled('image') ? $this->resolveImageDataUrl($request->input('image')) : null;

        if ($imageDataUrl) {
            $messages = [
                ['role' => 'system', 'content' => '你是一个博客写作助手。用中文回复，输出适合发布到博客的文章内容，使用 Markdown 格式。'],
                ['role' => 'user', 'content' => [
                    ['type' => 'text', 'text' => $userContent],
                    ['type' => 'image_url', 'image_url' => ['url' => $imageDataUrl]],
                ]],
            ];
        } else {
            $messages = [
                ['role' => 'system', 'content' => '你是一个博客写作助手。用中文回复，输出适合发布到博客的文章内容，使用 Markdown 格式。'],
                ['role' => 'user', 'content' => $userContent],
            ];
        }

        $payload = [
            'model' => $cfg['model'],
            'messages' => $messages,
            'temperature' => 0.8,
            'max_tokens' => 2048,
        ];

        // 流式输出（SSE），支持中途停止
        if ($request->boolean('stream')) {
            $payload['stream'] = true;
            return $this->streamChat($cfg, $payload);
        }

        try {
            $response = Http::timeout(60)->withHeaders([
                'Authorization' => 'Bearer ' . $cfg['api_key'],
                'Content-Type' => 'application/json',
            ])->post(rtrim($cfg['base_url'], '/') . '/chat/completions', $payload);

            if ($response->successful()) {
                $content = $response->json('choices.0.message.content') ?? 'AI 未返回内容。';
                return response()->json(['content' => $content]);
            }

            return response()->json(['error' => 'AI API 请求失败: ' . $response->status()], 500);
        } catch (\Exception $e) {
            return response()->json(['error' => 'AI 请求异常: ' . $e->getMessage()], 500);
        }
    }

    /**
     * 将本地图片（相对路径或 URL）转为 OpenAI 兼容的 data URL 供图生文使用。
     */
    private function resolveImageDataUrl(?string $image): ?string
    {
        if (!$image || trim($image) === '') {
            return null;
        }

        $image = trim($image);

        // 远程完整 URL 直接透传（由模型侧读取）
        if (preg_match('#^https?://#i', $image)) {
            return $image;
        }

        // 本地相对路径：兼容 storage/content/xxx 与 content/xxx
        $path = ltrim($image, '/');
        $path = preg_replace('#^storage/#', '', $path);
        $fullPath = storage_path('app/public/' . $path);

        if (file_exists($fullPath)) {
            $mime = function_exists('mime_content_type') ? mime_content_type($fullPath) : 'image/jpeg';
            return 'data:' . $mime . ';base64,' . base64_encode(file_get_contents($fullPath));
        }

        return null;
    }

    /**
     * 流式调用 chat/completions，逐 token 推送 SSE 事件 data: {"content": "..."}，结束发 data: [DONE]。
     */
    private function streamChat(array $cfg, array $payload)
    {
        return response()->stream(function () use ($cfg, $payload) {
            try {
                $response = Http::withOptions(['stream' => true, 'timeout' => 180])
                    ->withHeaders([
                        'Authorization' => 'Bearer ' . $cfg['api_key'],
                        'Content-Type' => 'application/json',
                        'Accept' => 'text/event-stream',
                    ])
                    ->post(rtrim($cfg['base_url'], '/') . '/chat/completions', $payload);

                if (!$response->successful()) {
                    echo "data: " . json_encode(['error' => 'AI API 请求失败: ' . $response->status()]) . "\n\n";
                    flush();
                    return;
                }

                $body = $response->getBody();
                $buffer = '';
                while (!$body->eof()) {
                    // 客户端断开（点击停止生成）时及时退出
                    if (connection_aborted()) {
                        break;
                    }
                    $chunk = $body->read(1024);
                    if ($chunk === '' || $chunk === false) {
                        break;
                    }
                    $buffer .= $chunk;

                    // 按 SSE 事件边界（空行）拆分
                    while (($pos = strpos($buffer, "\n\n")) !== false) {
                        $event = substr($buffer, 0, $pos);
                        $buffer = substr($buffer, $pos + 2);
                        foreach (explode("\n", $event) as $line) {
                            if (!str_starts_with($line, 'data:')) {
                                continue;
                            }
                            $data = trim(substr($line, 5));
                            if ($data === '[DONE]') {
                                echo "data: [DONE]\n\n";
                                flush();
                                return;
                            }
                            $json = json_decode($data, true);
                            $delta = $json['choices'][0]['delta']['content'] ?? null;
                            if (is_string($delta) && $delta !== '') {
                                echo "data: " . json_encode(['content' => $delta], JSON_UNESCAPED_UNICODE) . "\n\n";
                                flush();
                            }
                        }
                    }
                }
                echo "data: [DONE]\n\n";
                flush();
            } catch (\Exception $e) {
                echo "data: " . json_encode(['error' => 'AI 请求异常: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE) . "\n\n";
                flush();
            }
        }, 200, [
            'Content-Type' => 'text/event-stream',
            'Cache-Control' => 'no-cache',
            'X-Accel-Buffering' => 'no',
            'Connection' => 'keep-alive',
        ]);
    }

    public function generateImage(Request $request): JsonResponse
    {
        $request->validate(['prompt' => 'required|string|max:1000']);

        $cfg = $this->getConfig();
        if (!$cfg['base_url'] || !$cfg['api_key']) {
            return response()->json(['error' => '请先在系统设置中配置 AI API 密钥。'], 400);
        }

        try {
            // 阿里云通义万相（DashScope）：异步文生图任务
            $synthesisResponse = Http::timeout(60)->withHeaders([
                'Authorization' => 'Bearer ' . $cfg['api_key'],
                'Content-Type' => 'application/json',
                'X-DashScope-Async' => 'enable',
            ])->post('https://dashscope.aliyuncs.com/api/v1/services/aigc/text2image/image-synthesis', [
                'model' => $cfg['ai_image_model'] ?: 'wanx2.1-t2i-turbo',
                'input' => [
                    'prompt' => $request->prompt,
                ],
                'parameters' => [
                    'size' => '1024*1024',
                    'n' => 1,
                ],
            ]);

            if (!$synthesisResponse->successful()) {
                return response()->json(['error' => '图片生成请求失败: ' . $synthesisResponse->body()], 500);
            }

            $taskId = $synthesisResponse->json('output.task_id');
            if (!$taskId) {
                return response()->json(['error' => '图片生成任务创建失败'], 500);
            }

            // 轮询任务结果
            for ($i = 0; $i < 30; $i++) {
                sleep(2);
                $taskResponse = Http::timeout(30)->withToken($cfg['api_key'])
                    ->get('https://dashscope.aliyuncs.com/api/v1/tasks/' . $taskId);

                if (!$taskResponse->successful()) {
                    return response()->json(['error' => '查询图片任务失败'], 500);
                }

                $status = $taskResponse->json('output.task_status');
                if ($status === 'SUCCEEDED') {
                    $remoteUrl = $taskResponse->json('output.results.0.url');
                    if ($remoteUrl) {
                        $url = $this->persistImage($remoteUrl);
                        return response()->json(['url' => $url]);
                    }
                }

                if (in_array($status, ['FAILED', 'CANCELED', 'UNKNOWN'])) {
                    return response()->json(['error' => '图片生成失败'], 500);
                }
            }

            return response()->json(['error' => '图片生成超时，请稍后重试'], 500);
        } catch (\Exception $e) {
            return response()->json(['error' => 'AI 请求异常: ' . $e->getMessage()], 500);
        }
    }

    private function persistImage(string $remoteUrl): string
    {
        try {
            $downloaded = Http::timeout(60)->get($remoteUrl);
            if ($downloaded->successful()) {
                $filename = Str::random(20) . '_' . time() . '.png';
                $path = 'content/' . $filename;
                Storage::disk('public')->put($path, $downloaded->body());

                MediaFile::create([
                    'file_name' => $filename,
                    'title' => 'AI 生成配图',
                    'file_path' => $path,
                    'file_type' => 'image',
                    'category' => 'ai',
                    'file_size' => $downloaded->header('Content-Length') ?: strlen($downloaded->body()),
                    'mime_type' => 'image/png',
                    'uploaded_by' => auth()->id(),
                ]);

                return asset(Storage::url($path));
            }
        } catch (\Exception $e) {
            // 下载失败时回退到远程链接
        }

        return $remoteUrl;
    }
}

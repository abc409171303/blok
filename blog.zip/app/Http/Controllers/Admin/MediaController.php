<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\MediaFile;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;

class MediaController extends Controller
{
    public function index(Request $request): View
    {
        $query = MediaFile::with('uploader')->ordered();

        if ($request->filled('type')) {
            $query->where('file_type', $request->type);
        }

        if ($request->filled('search')) {
            $keyword = trim($request->search);
            $query->where(function ($q) use ($keyword) {
                $q->where('file_name', 'like', "%{$keyword}%")
                  ->orWhere('title', 'like', "%{$keyword}%");
            });
        }

        $files = $query->paginate(24);

        $stats = [
            'total' => MediaFile::count(),
            'images' => MediaFile::where('file_type', 'image')->count(),
            'videos' => MediaFile::where('file_type', 'video')->count(),
        ];

        return view('admin.media.index', compact('files', 'stats'));
    }

    public function upload(Request $request): JsonResponse
    {
        $request->validate([
            'file' => 'required|file|max:10240',
        ]);

        $file = $request->file('file');
        $path = $file->store('media/' . date('Y-m-d'), 'public');

        $fileType = str_contains($file->getMimeType(), 'image') ? 'image' : 'video';
        if (str_contains($file->getMimeType(), 'video')) {
            $fileType = 'video';
        }

        $mediaFile = MediaFile::create([
            'file_name' => $file->getClientOriginalName(),
            'file_path' => $path,
            'file_type' => $fileType,
            'file_size' => $file->getSize(),
            'mime_type' => $file->getMimeType(),
            'uploaded_by' => auth()->id(),
        ]);

        return response()->json([
            'success' => true,
            'data' => [
                'id' => $mediaFile->id,
                'file_name' => $mediaFile->file_name,
                'url' => $mediaFile->url,
                'file_type' => $mediaFile->file_type,
            ],
        ]);
    }

    public function update(Request $request, MediaFile $mediaFile): JsonResponse
    {
        $request->validate([
            'file_name' => 'required|string|max:255',
            'title' => 'nullable|string|max:255',
        ]);

        $mediaFile->update([
            'file_name' => trim($request->file_name),
            'title' => trim((string) $request->input('title', $mediaFile->title)),
        ]);

        return response()->json([
            'success' => true,
            'message' => '文件信息已更新',
        ]);
    }

    public function destroy(MediaFile $mediaFile): JsonResponse
    {
        Storage::disk('public')->delete($mediaFile->file_path);
        $mediaFile->delete();

        return response()->json([
            'success' => true,
            'message' => '文件已删除',
        ]);
    }

    public function bulkDestroy(Request $request): JsonResponse
    {
        $request->validate([
            'ids' => 'required|array',
            'ids.*' => 'exists:media_files,id',
        ]);

        foreach ($request->ids as $id) {
            $mediaFile = MediaFile::find($id);
            if ($mediaFile) {
                Storage::disk('public')->delete($mediaFile->file_path);
                $mediaFile->delete();
            }
        }

        return response()->json([
            'success' => true,
            'message' => '已删除 ' . count($request->ids) . ' 个文件',
        ]);
    }

    public function bulkUpdate(Request $request): JsonResponse
    {
        $request->validate([
            'ids' => 'required|array',
            'ids.*' => 'exists:media_files,id',
            'file_name' => 'required|string|max:255',
        ]);

        $count = 0;
        foreach ($request->ids as $id) {
            $mediaFile = MediaFile::find($id);
            if ($mediaFile) {
                $mediaFile->update(['file_name' => trim($request->file_name)]);
                $count++;
            }
        }

        return response()->json([
            'success' => true,
            'message' => '已更新 ' . $count . ' 个文件',
        ]);
    }

    public function bulkCopy(Request $request): JsonResponse
    {
        $request->validate([
            'ids' => 'required|array',
            'ids.*' => 'exists:media_files,id',
        ]);

        $urls = MediaFile::whereIn('id', $request->ids)->pluck('url')->toArray();

        return response()->json([
            'success' => true,
            'urls' => $urls,
            'message' => '已复制 ' . count($urls) . ' 个链接',
        ]);
    }
}

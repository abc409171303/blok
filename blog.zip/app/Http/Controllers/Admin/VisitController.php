<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\SiteVisit;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class VisitController extends Controller
{
    public function index(Request $request): View
    {
        // 时间范围：默认近 7 天（含今天），支持自定义 开始日期 ~ 结束日期
        $end = $this->parseDate($request->get('end')) ?? Carbon::today();
        $start = $this->parseDate($request->get('start')) ?? (clone $end)->subDays(6);

        if ($start->gt($end)) {
            [$start, $end] = [$end, $start];
        }

        $startOfDay = (clone $start)->startOfDay();
        $endOfDay = (clone $end)->endOfDay();

        $query = SiteVisit::whereBetween('created_at', [$startOfDay, $endOfDay]);

        // ① 总访问量 PV ② 独立访客 UV
        $pv = (clone $query)->count();
        $uv = (clone $query)->distinct('visitor_key')->count('visitor_key');

        // 按日聚合（PV/UV），供折线图使用。
        // 使用跨数据库的日表达式，并对表达式本身分组：SQL Server 不支持
        // date() 函数，也不允许在 GROUP BY 中引用列别名。
        $dayExpression = $this->dayExpression();

        $daily = (clone $query)
            ->selectRaw("{$dayExpression} as day, count(*) as pv, count(distinct visitor_key) as uv")
            ->groupByRaw($dayExpression)
            ->orderBy('day')
            ->get()
            ->keyBy('day');

        // 补齐区间内无数据的日期
        $chart = [
            'dates' => [],
            'pv' => [],
            'uv' => [],
        ];
        for ($d = clone $start; $d->lte($end); $d->addDay()) {
            $key = $d->format('Y-m-d');
            $chart['dates'][] = $key;
            $chart['pv'][] = (int) ($daily[$key]->pv ?? 0);
            $chart['uv'][] = (int) ($daily[$key]->uv ?? 0);
        }

        // 访客明细（分页）
        $visits = SiteVisit::orderByDesc('created_at')
            ->paginate(15)
            ->withQueryString();

        return view('admin.visits.index', compact('start', 'end', 'pv', 'uv', 'chart', 'visits'));
    }

    protected function parseDate(?string $value): ?Carbon
    {
        if (!$value) {
            return null;
        }
        try {
            return Carbon::createFromFormat('Y-m-d', $value);
        } catch (\Throwable $e) {
            return null;
        }
    }

    /**
     * 返回把 created_at 截断到「天」的跨数据库 SQL 表达式。
     *
     * MySQL/MariaDB 用 date()，SQL Server/PostgreSQL 用 cast(... as date)，
     * SQLite 用 strftime('%Y-%m-%d', ...)。统一返回 'YYYY-MM-DD' 文本，
     * 便于后续按同名 key 对齐。
     */
    protected function dayExpression(): string
    {
        return match (DB::connection()->getDriverName()) {
            'mysql', 'mariadb' => 'date(created_at)',
            'sqlsrv', 'pgsql' => 'cast(created_at as date)',
            default => "strftime('%Y-%m-%d', created_at)",
        };
    }
}

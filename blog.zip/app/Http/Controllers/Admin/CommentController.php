<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Comment;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class CommentController extends Controller
{
    public function index(Request $request): View
    {
        $query = Comment::with(['post', 'user'])->latest();

        if ($request->filled('id')) {
            $query->where('id', (int) $request->id);
        }
        if ($request->filled('author')) {
            $query->where('author', 'like', '%' . $request->author . '%');
        }
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }
        if ($request->filled('keyword')) {
            $query->where('content', 'like', '%' . $request->keyword . '%');
        }

        $comments = $query->paginate(20)->withQueryString();

        return view('admin.comments.index', compact('comments'));
    }

    public function batchDestroy(Request $request): RedirectResponse
    {
        $request->validate([
            'ids' => 'required|array',
            'ids.*' => 'exists:comments,id',
        ]);

        Comment::whereIn('id', $request->ids)->delete();

        return redirect()->route('admin.comments.index')
            ->with('success', '已删除 ' . count($request->ids) . ' 条评论。');
    }

    public function approve(int $id): RedirectResponse
    {
        $comment = Comment::findOrFail($id);
        $comment->update(['status' => 'approved']);

        return redirect()->route('admin.comments.index')
            ->with('success', '评论审核通过');
    }

    public function reject(int $id): RedirectResponse
    {
        $comment = Comment::findOrFail($id);
        $comment->update(['status' => 'rejected']);

        return redirect()->route('admin.comments.index')
            ->with('success', '评论已拒绝');
    }

    public function destroy(int $id): RedirectResponse
    {
        $comment = Comment::findOrFail($id);
        $comment->delete();

        return redirect()->route('admin.comments.index')
            ->with('success', '评论删除成功');
    }
}

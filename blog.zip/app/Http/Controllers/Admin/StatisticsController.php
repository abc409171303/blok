<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Post;
use App\Models\PostView;
use Illuminate\View\View;

class StatisticsController extends Controller
{
    public function index(): View
    {
        $overview = [
            'views' => (int) Post::sum('views'),
            'today_records' => PostView::whereDate('created_at', today())->count(),
            'records' => PostView::count(),
            'month_records' => PostView::where('created_at', '>=', now()->subDays(30))->count(),
        ];

        return view('admin.statistics.index', compact('overview'));
    }
}

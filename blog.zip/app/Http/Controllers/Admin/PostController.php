<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Post;
use App\Models\Tag;
use App\Services\ImageCompressor;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\View\View;

class PostController extends Controller
{
    /**
     * 生成唯一 slug：中文标题等 Str::slug 结果为空时回退为 post-，
     * 已存在的 slug 自动追加数字后缀，避免 UNIQUE 约束冲突。
     *
     * slug 列在低版本 MySQL（InnoDB 767 字节索引上限）下为 191 字符，
     * 这里对基础 slug 截断，给数字后缀留出空间，防止插入时被截断或报错。
     */
    private function generateUniqueSlug(string $title, ?int $ignoreId = null): string
    {
        $base = Str::limit(Str::slug($title), 180, '');
        if ($base === '') {
            $base = 'post';
        }

        $slug = $base;
        $i = 2;
        while (Post::where('slug', $slug)
            ->when($ignoreId, fn ($q) => $q->where('id', '!=', $ignoreId))
            ->exists()) {
            $slug = $base . '-' . $i++;
        }

        return $slug;
    }

    public function index(Request $request): View
    {
        $query = Post::with(['category', 'user', 'tags']);

        if ($request->filled('search')) {
            $query->search($request->search);
        }

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        if ($request->filled('category_id')) {
            $query->where('category_id', $request->category_id);
        }

        if ($request->filled('tag_id')) {
            $query->whereHas('tags', fn ($q) => $q->where('tags.id', $request->tag_id));
        }

        if ($request->filled('access_mode')) {
            $query->where('access_mode', $request->access_mode);
        }

        if ($request->filled('is_top')) {
            $query->where('is_top', $request->boolean('is_top'));
        }

        if ($request->filled('is_hot')) {
            $query->where('is_hot', $request->boolean('is_hot'));
        }

        if ($request->filled('is_recommend')) {
            $query->where('is_recommend', $request->boolean('is_recommend'));
        }

        $perPage = in_array((int) $request->input('per_page', 10), [10, 20, 50, 100]) ? (int) $request->input('per_page', 10) : 10;
        $posts = $query->latest()->paginate($perPage)->withQueryString();
        $categories = Category::orderBy('sort_order')->get();
        $tags = Tag::orderBy('name')->get();

        return view('admin.posts.index', compact('posts', 'categories', 'tags'));
    }

    public function create(): View
    {
        $categories = Category::orderBy('sort_order')->get();
        $tagGroups = Tag::whereNull('parent_id')->with('children')->orderBy('name')->get();

        return view('admin.posts.create', compact('categories', 'tagGroups'));
    }

    /**
     * 封面地址统一为标准相对路径（如 content/xxx.jpg）后入库，
     * 兼容三种前端来源：完整 URL、/storage/ 前缀相对路径、纯相对路径。
     */
    private function normalizeCoverUrl(?string $url): ?string
    {
        if (!$url || trim($url) === '') {
            return null;
        }

        $url = trim($url);

        // 完整 URL → 取路径部分
        if (preg_match('#^https?://#i', $url)) {
            $path = parse_url($url, PHP_URL_PATH) ?? '';
            $url = $path;
        }

        // 去掉 /storage/ 前缀，剩 content/xxx.jpg 或 /content/xxx.jpg
        $url = preg_replace('#^/?(storage/)?#', '', $url);

        return $url === '' ? null : $url;
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'category_id' => 'nullable|exists:categories,id',
            'summary' => 'nullable|string|max:500',
            'content' => 'required|string',
            'cover' => 'nullable|image|mimes:jpeg,png,jpg,gif,webp|max:2048',
            'tags' => 'nullable|array',
            'tags.*' => 'exists:tags,id',
            'status' => 'required|in:draft,published',
            'is_top' => 'boolean',
            'is_recommend' => 'boolean',
            'is_hot' => 'boolean',
            'access_mode' => 'nullable|in:public,private',
            'access_password' => 'nullable|string|max:255',
            'published_at' => 'nullable|date',
        ]);

        $validated['user_id'] = auth()->id();
        $validated['slug'] = $this->generateUniqueSlug($validated['title']);
        $validated['is_top'] = $request->boolean('is_top');
        $validated['is_recommend'] = $request->boolean('is_recommend');
        $validated['is_hot'] = $request->boolean('is_hot');
        $validated['access_mode'] = $request->input('access_mode', 'public');

        if ($validated['access_mode'] === 'private') {
            $password = trim((string) $request->input('access_password', ''));
            if ($password === '') {
                return back()->withErrors(['access_password' => '密码访问模式必须设置访问密码。'])->withInput();
            }
            $validated['access_password'] = $password;
        } else {
            $validated['access_password'] = null;
        }

        if ($request->hasFile('cover')) {
            $cover = app(ImageCompressor::class)->maybeCompress($request->file('cover'));
            $validated['cover'] = $cover->store('covers', 'public');
        } elseif ($request->filled('cover_url')) {
            // 从文件库选择或上传的封面（标准化为相对路径）
            $validated['cover'] = $this->normalizeCoverUrl($request->input('cover_url'));
        }

        if (($validated['status'] ?? null) === 'published' && empty($validated['published_at'])) {
            $validated['published_at'] = now();
        }

        $post = Post::create($validated);

        if ($request->filled('tags')) {
            $post->tags()->sync($request->tags);
        }

        return redirect()->route('admin.posts.index')
            ->with('success', '文章创建成功');
    }

    public function edit(Post $post): View
    {
        $categories = Category::orderBy('sort_order')->get();
        $tagGroups = Tag::whereNull('parent_id')->with('children')->orderBy('name')->get();

        return view('admin.posts.edit', compact('post', 'categories', 'tagGroups'));
    }

    public function update(Request $request, Post $post): RedirectResponse
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'category_id' => 'nullable|exists:categories,id',
            'summary' => 'nullable|string|max:500',
            'content' => 'required|string',
            'cover' => 'nullable|image|mimes:jpeg,png,jpg,gif,webp|max:2048',
            'tags' => 'nullable|array',
            'tags.*' => 'exists:tags,id',
            'status' => 'required|in:draft,published',
            'is_top' => 'boolean',
            'is_recommend' => 'boolean',
            'is_hot' => 'boolean',
            'access_mode' => 'nullable|in:public,private',
            'access_password' => 'nullable|string|max:255',
            'published_at' => 'nullable|date',
        ]);

        $validated['slug'] = $this->generateUniqueSlug($validated['title'], $post->id);
        $validated['is_top'] = $request->boolean('is_top');
        $validated['is_recommend'] = $request->boolean('is_recommend');
        $validated['is_hot'] = $request->boolean('is_hot');
        $validated['access_mode'] = $request->input('access_mode', 'public');

        if ($validated['access_mode'] === 'private') {
            $password = trim((string) $request->input('access_password', ''));
            if ($password === '') {
                return back()->withErrors(['access_password' => '密码访问模式必须设置访问密码。'])->withInput();
            }
            $validated['access_password'] = $password;
        } else {
            $validated['access_password'] = null;
        }

        if ($request->hasFile('cover')) {
            $cover = app(ImageCompressor::class)->maybeCompress($request->file('cover'));
            $validated['cover'] = $cover->store('covers', 'public');
        } elseif ($request->filled('cover_url')) {
            // 从文件库选择或上传的封面（标准化为相对路径）
            $validated['cover'] = $this->normalizeCoverUrl($request->input('cover_url'));
        } elseif ($request->boolean('remove_cover')) {
            // 用户点击删除按钮移除已有封面
            $validated['cover'] = null;
        }

        $post->update($validated);

        $post->tags()->sync($request->tags ?? []);

        return redirect()->route('admin.posts.index')
            ->with('success', '文章更新成功');
    }

    public function destroy(Post $post): RedirectResponse
    {
        $post->tags()->detach();
        $post->delete();

        return redirect()->route('admin.posts.index')
            ->with('success', '文章删除成功');
    }

    public function batchDestroy(Request $request): RedirectResponse
    {
        $request->validate([
            'ids' => 'required|array',
            'ids.*' => 'exists:posts,id',
        ]);

        Post::whereIn('id', $request->ids)->each(function($post) {
            $post->tags()->detach();
        });
        Post::whereIn('id', $request->ids)->delete();

        return redirect()->route('admin.posts.index')
            ->with('success', '已删除选中的 ' . count($request->ids) . ' 篇文章。');
    }

    public function batchUpdate(Request $request): RedirectResponse
    {
        $request->validate([
            'ids' => 'required|array',
            'ids.*' => 'exists:posts,id',
            'category_id' => 'nullable|exists:categories,id',
            'status' => 'nullable|in:draft,published',
            'is_top' => 'nullable|boolean',
            'is_recommend' => 'nullable|boolean',
            'is_hot' => 'nullable|boolean',
            'access_mode' => 'nullable|in:public,private',
            'access_password' => 'nullable|string|max:255',
            'published_at' => 'nullable|date',
        ]);

        $updateData = [];
        if ($request->filled('category_id')) {
            $updateData['category_id'] = $request->category_id;
        }
        if ($request->filled('status')) {
            $updateData['status'] = $request->status;
            if ($request->status === 'published') {
                $updateData['published_at'] = $request->filled('published_at') ? $request->published_at : now();
            }
        }
        if ($request->has('is_top')) {
            $updateData['is_top'] = $request->boolean('is_top');
        }
        if ($request->has('is_recommend')) {
            $updateData['is_recommend'] = $request->boolean('is_recommend');
        }
        if ($request->has('is_hot')) {
            $updateData['is_hot'] = $request->boolean('is_hot');
        }
        if ($request->filled('access_mode')) {
            if ($request->access_mode === 'private') {
                $password = trim((string) $request->input('access_password', ''));
                if ($password === '') {
                    return back()->withErrors(['access_password' => '密码访问模式必须设置访问密码。'])->withInput();
                }
                $updateData['access_mode'] = 'private';
                $updateData['access_password'] = $password;
            } else {
                $updateData['access_mode'] = 'public';
                $updateData['access_password'] = null;
            }
        }

        if (!empty($updateData)) {
            Post::whereIn('id', $request->ids)->each(fn($post) => $post->update($updateData));
        }

        return redirect()->route('admin.posts.index')
            ->with('success', '已更新选中的 ' . count($request->ids) . ' 篇文章。');
    }

    /**
     * 行内开关快速切换（置顶 / 热门 / 推荐 / 发布状态 / 访问模式）。
     */
    public function toggle(Request $request, Post $post): \Illuminate\Http\JsonResponse
    {
        $field = $request->input('field');
        $allowed = ['is_top', 'is_hot', 'is_recommend', 'status', 'access_mode'];
        if (!in_array($field, $allowed, true)) {
            return response()->json(['success' => false, 'message' => '不支持的字段'], 422);
        }

        if ($field === 'status') {
            $value = $request->input('value') === 'published' ? 'published' : 'draft';
            $post->status = $value;
            if ($value === 'published' && !$post->published_at) {
                $post->published_at = now();
            }
        } elseif ($field === 'access_mode') {
            $value = $request->input('value') === 'private' ? 'private' : 'public';
            $post->access_mode = $value;
        } else {
            $post->{$field} = $request->boolean('value');
        }

        $post->save();

        return response()->json(['success' => true, 'value' => $post->{$field}]);
    }

    /**
     * 批量导入文章（JSON 数组，每项：title/summary/content/category/tags/status/is_top/is_hot/is_recommend/access_mode/published_at）。
     * category/tags 支持名称或 slug，不存在时自动创建。
     */
    public function batchImport(Request $request): RedirectResponse
    {
        $request->validate([
            'file' => 'required|file|mimes:json,txt|max:2048',
        ]);

        $raw = $request->file('file')->get();
        $items = json_decode($raw, true);
        if (!is_array($items) || empty($items)) {
            return back()->with('error', '导入失败：JSON 内容为空或格式错误（需为对象数组）。');
        }

        $imported = 0;
        $errors = [];
        foreach ($items as $i => $item) {
            if (!is_array($item) || empty($item['title'] ?? null)) {
                $errors[] = '第 ' . ($i + 1) . ' 条缺少 title，已跳过';
                continue;
            }

            $categoryId = null;
            if (!empty($item['category'])) {
                $category = Category::where('name', $item['category'])
                    ->orWhere('slug', $item['category'])
                    ->first();
                if ($category) {
                    $categoryId = $category->id;
                } else {
                    $cat = Category::create([
                        'name' => $item['category'],
                        'slug' => Str::slug($item['category']) ?: 'cat-' . uniqid(),
                    ]);
                    $categoryId = $cat->id;
                }
            }

            $status = in_array($item['status'] ?? 'draft', ['published', 'draft'], true) ? $item['status'] : 'draft';
            $accessMode = ($item['access_mode'] ?? 'public') === 'private' ? 'private' : 'public';

            $post = Post::create([
                'user_id' => auth()->id(),
                'category_id' => $categoryId,
                'title' => $item['title'],
                'slug' => $this->generateUniqueSlug($item['title']),
                'summary' => $item['summary'] ?? null,
                'content' => $item['content'] ?? '',
                'cover' => null,
                'status' => $status,
                'is_top' => !empty($item['is_top']),
                'is_hot' => !empty($item['is_hot']),
                'is_recommend' => !empty($item['is_recommend']),
                'access_mode' => $accessMode,
                'published_at' => $status === 'published'
                    ? ($item['published_at'] ?? now())
                    : null,
            ]);

            if (!empty($item['tags'])) {
                $tagIds = [];
                $tagNames = is_array($item['tags']) ? $item['tags'] : explode(',', (string) $item['tags']);
                foreach ($tagNames as $tagName) {
                    $tagName = trim((string) $tagName);
                    if ($tagName === '') {
                        continue;
                    }
                    $tag = Tag::where('name', $tagName)->orWhere('slug', $tagName)->first();
                    if (!$tag) {
                        $tag = Tag::create([
                            'name' => $tagName,
                            'slug' => Str::slug($tagName) ?: 'tag-' . uniqid(),
                        ]);
                    }
                    $tagIds[] = $tag->id;
                }
                $post->tags()->sync($tagIds);
            }

            $imported++;
        }

        $message = "成功导入 {$imported} 篇文章。";
        if (!empty($errors)) {
            $message .= ' ' . count($errors) . ' 条被跳过。';
        }

        return redirect()->route('admin.posts.index')
            ->with('success', $message);
    }
}

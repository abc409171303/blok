<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\View\View;

class CategoryController extends Controller
{
    public function index(): View
    {
        $categories = Category::with(['children' => function ($query) {
                $query->orderBy('sort_order')->orderBy('id');
            }])
            ->whereNull('parent_id')
            ->orderBy('sort_order')
            ->orderBy('id')
            ->get();

        return view('admin.categories.index', compact('categories'));
    }

    public function create(): View
    {
        $categories = Category::whereNull('parent_id')
            ->orderBy('sort_order')
            ->get();

        return view('admin.categories.create', compact('categories'));
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'name' => 'required|string|max:50',
            'description' => 'nullable|string|max:255',
            'parent_id' => 'nullable|exists:categories,id',
            'sort_order' => 'nullable|integer|min:0',
        ]);

        $validated['slug'] = $this->generateUniqueSlug($validated['name']);
        $validated['sort_order'] = $validated['sort_order'] ?? 0;

        Category::create($validated);

        return redirect()->route('admin.categories.index')
            ->with('success', '分类创建成功');
    }

    public function edit(Category $category): View
    {
        $categories = Category::whereNull('parent_id')
            ->where('id', '!=', $category->id)
            ->orderBy('sort_order')
            ->get();

        return view('admin.categories.edit', compact('category', 'categories'));
    }

    public function update(Request $request, Category $category): RedirectResponse
    {
        $validated = $request->validate([
            'name' => 'required|string|max:50',
            'description' => 'nullable|string|max:255',
            'parent_id' => 'nullable|exists:categories,id',
            'sort_order' => 'nullable|integer|min:0',
        ]);

        $validated['slug'] = $this->generateUniqueSlug($validated['name'], $category->id);
        $validated['sort_order'] = $validated['sort_order'] ?? 0;

        $category->update($validated);

        return redirect()->route('admin.categories.index')
            ->with('success', '分类更新成功');
    }

    public function destroy(Category $category): RedirectResponse
    {
        $category->delete();

        return redirect()->route('admin.categories.index')
            ->with('success', '分类删除成功');
    }

    /**
     * 调整分类排序（置顶/上移/下移/置底），仅超级管理员可操作。
     * 只调整同一父级下的分类，重新编号 sort_order。
     */
    public function move(Request $request, Category $category): JsonResponse
    {
        if (!auth()->user()?->isAdmin()) {
            return response()->json(['success' => false, 'message' => '只有管理员可以调整分类排序。'], 403);
        }

        $action = $request->input('action');
        if (!in_array($action, ['top', 'up', 'down', 'bottom'], true)) {
            return response()->json(['success' => false, 'message' => '无效的排序操作。'], 422);
        }

        $query = Category::query();
        if ($category->parent_id === null) {
            $query->whereNull('parent_id');
        } else {
            $query->where('parent_id', $category->parent_id);
        }

        $orderedIds = $query->orderBy('sort_order')->orderBy('id')->pluck('id')->all();

        $index = array_search($category->id, $orderedIds, true);
        if ($index === false) {
            return response()->json(['success' => false, 'message' => '分类不存在。'], 404);
        }

        switch ($action) {
            case 'top':
                array_splice($orderedIds, $index, 1);
                array_unshift($orderedIds, $category->id);
                break;
            case 'up':
                if ($index > 0) {
                    [$orderedIds[$index - 1], $orderedIds[$index]] = [$orderedIds[$index], $orderedIds[$index - 1]];
                }
                break;
            case 'down':
                if ($index < count($orderedIds) - 1) {
                    [$orderedIds[$index], $orderedIds[$index + 1]] = [$orderedIds[$index + 1], $orderedIds[$index]];
                }
                break;
            case 'bottom':
                array_splice($orderedIds, $index, 1);
                $orderedIds[] = $category->id;
                break;
        }

        DB::transaction(function () use ($orderedIds) {
            foreach ($orderedIds as $position => $id) {
                Category::where('id', $id)->update(['sort_order' => ($position + 1) * 10]);
            }
        });

        return response()->json([
            'success' => true,
            'message' => '排序已更新。',
            'order' => $orderedIds,
        ]);
    }

    /**
     * 生成唯一 slug：中文名会生成空串，回退为随机串；如已存在则追加随机后缀。
     */
    private function generateUniqueSlug(string $name, ?int $ignoreId = null): string
    {
        $slug = Str::slug($name) ?: 'category-' . Str::lower(Str::random(8));

        $query = Category::where('slug', $slug);
        if ($ignoreId !== null) {
            $query->where('id', '!=', $ignoreId);
        }

        while ($query->exists()) {
            $slug = $slug . '-' . Str::lower(Str::random(4));
            $query = Category::where('slug', $slug);
            if ($ignoreId !== null) {
                $query->where('id', '!=', $ignoreId);
            }
        }

        return $slug;
    }
}

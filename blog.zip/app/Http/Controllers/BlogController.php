<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Message;
use App\Models\Post;
use App\Models\SiteConfig;
use App\Models\Tag;
use App\Rules\CaptchaRule;
use App\Services\Captcha;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class BlogController extends Controller
{
    public function index(Request $request): View
    {
        $perPage = (int) (SiteConfig::getInstance()->page_size ?: 10);

        $posts = Post::with(['category', 'tags', 'user'])
            ->published()
            ->orderBy('is_top', 'desc')
            ->orderBy('published_at', 'desc')
            ->paginate($perPage);

        $categories = Category::withCount(['posts' => function ($query) {
            $query->published();
        }])->orderBy('sort_order')->get();

        $recentPosts = Post::published()
            ->orderBy('published_at', 'desc')
            ->limit(5)
            ->get();

        $tags = Tag::withCount('posts')->get();

        return view('blog.index', compact('posts', 'categories', 'recentPosts', 'tags'));
    }

    public function about(): View
    {
        $config = SiteConfig::getInstance();

        return view('blog.about', compact('config'));
    }

    public function guestbook(): View
    {
        $messages = Message::approved()->latest()->paginate(20);

        return view('blog.guestbook', compact('messages'));
    }

    public function guestbookStore(Request $request): RedirectResponse
    {
        $rules = [
            'author' => 'required|string|max:100',
            'email' => 'required|email|max:100',
            'content' => 'required|string|max:1000',
        ];

        if (Captcha::enabled('message')) {
            $rules['captcha'] = ['required', new CaptchaRule('message')];
        }

        $validated = $request->validate($rules);

        $validated['status'] = 'pending';

        Message::create($validated);

        return back()->with('success', '留言提交成功，等待审核后展示。');
    }

    public function show(Request $request, string $slug): View
    {
        $query = Post::with(['category', 'tags', 'user'])
            ->where('slug', $slug);

        // 后台已登录的管理员可通过 ?preview=1 预览草稿文章
        $isPreview = $request->has('preview') && auth()->check();
        $post = ($isPreview ? $query : $query->published())->firstOrFail();

        if (!$isPreview) {
            try {
                $ip = $request->header('X-Forwarded-For')
                    ? explode(',', $request->header('X-Forwarded-For'))[0]
                    : ($request->ip() ?: 'unknown');
                $ip = trim($ip);

                $geo = $this->getGeoLocation($ip);

                \DB::table('post_views')->insert([
                    'post_id' => $post->id,
                    'ip_address' => $ip,
                    'country' => $geo['country'] ?? null,
                    'province' => $geo['province'] ?? null,
                    'city' => $geo['city'] ?? null,
                    'user_agent' => $request->userAgent(),
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);

                $post->increment('views');
            } catch (\Exception $e) {
                // 记录失败不影响用户访问
                $post->increment('views');
            }
        } else {
            $post->increment('views');
        }

        $categories = Category::withCount(['posts' => function ($query) {
            $query->published();
        }])->orderBy('sort_order')->get();

        $recentPosts = Post::published()
            ->orderBy('published_at', 'desc')
            ->limit(5)
            ->get();

        $tags = Tag::withCount('posts')->get();

        // 密码访问拦截（管理员预览不受限；验证成功后本次会话免密）
        $needAccess = !$isPreview
            && $post->access_mode === 'private'
            && $post->access_password
            && !session()->get("post_access_{$post->id}", false);

        if ($needAccess) {
            return view('blog.access', compact('post', 'categories', 'recentPosts', 'tags'));
        }

        $comments = $post->comments()
            ->approved()
            ->with('replies')
            ->whereNull('parent_id')
            ->latest()
            ->get();

        $config = SiteConfig::getInstance();

        return view('blog.show', compact('post', 'comments', 'categories', 'recentPosts', 'tags', 'config'));
    }

    /**
     * 校验文章访问密码：正确则本次会话解锁，错误返回错误提示。
     */
    public function verifyAccess(Request $request, string $slug): RedirectResponse
    {
        $post = Post::where('slug', $slug)->published()->firstOrFail();

        $request->validate([
            'access_password' => 'required|string',
        ]);

        if ($post->access_mode === 'private'
            && $post->access_password
            && $request->access_password === $post->access_password) {
            session()->put("post_access_{$post->id}", true);

            return redirect()->route('blog.show', $post->slug);
        }

        return redirect()->route('blog.show', $post->slug)
            ->withErrors(['access_password' => '访问密码不正确，请重试。']);
    }

    public function category(string $slug): View
    {
        $category = Category::where('slug', $slug)->firstOrFail();

        $perPage = (int) (SiteConfig::getInstance()->page_size ?: 10);

        $posts = Post::with(['category', 'tags', 'user'])
            ->published()
            ->byCategory($slug)
            ->orderBy('is_top', 'desc')
            ->orderBy('published_at', 'desc')
            ->paginate($perPage);

        $categories = Category::withCount(['posts' => function ($query) {
            $query->published();
        }])->orderBy('sort_order')->get();

        $recentPosts = Post::published()
            ->orderBy('published_at', 'desc')
            ->limit(5)
            ->get();

        $tags = Tag::withCount('posts')->get();

        return view('blog.category', compact('category', 'posts', 'categories', 'recentPosts', 'tags'));
    }

    public function search(Request $request): View|RedirectResponse
    {
        $keyword = trim((string) $request->get('q', ''));

        // 未输入关键词时不执行搜索，直接返回首页，避免空正则破坏标题
        if ($keyword === '') {
            return redirect()->route('blog.index');
        }

        $perPage = (int) (SiteConfig::getInstance()->page_size ?: 10);

        $posts = Post::with(['category', 'tags', 'user'])
            ->published()
            ->search($keyword)
            ->orderBy('is_top', 'desc')
            ->orderBy('published_at', 'desc')
            ->paginate($perPage);

        $categories = Category::withCount(['posts' => function ($query) {
            $query->published();
        }])->orderBy('sort_order')->get();

        $recentPosts = Post::published()
            ->orderBy('published_at', 'desc')
            ->limit(5)
            ->get();

        $tags = Tag::withCount('posts')->get();

        return view('blog.search', compact('posts', 'keyword', 'categories', 'recentPosts', 'tags'));
    }

    public function comment(Request $request, string $slug): RedirectResponse
    {
        $config = SiteConfig::getInstance();

        if (!($config->enable_comments ?? true)) {
            return redirect()->route('blog.show', $slug)
                ->withErrors(['content' => '评论功能已关闭。']);
        }

        $post = Post::where('slug', $slug)->published()->firstOrFail();

        $rules = [
            'author' => 'required|string|max:100',
            'email' => 'required|email|max:100',
            'content' => 'required|string',
            'parent_id' => 'nullable|exists:comments,id',
        ];

        if (Captcha::enabled('comment')) {
            $rules['captcha'] = ['required', new CaptchaRule('comment')];
        }

        $request->validate($rules);

        $post->comments()->create([
            'author' => $request->author,
            'email' => $request->email,
            'content' => $request->content,
            'parent_id' => $request->parent_id,
            'status' => ($config->auto_approve_comments ?? false) ? 'approved' : 'pending',
        ]);

        return redirect()->route('blog.show', $post->slug)
            ->with('success', ($config->auto_approve_comments ?? false)
                ? '评论已发布成功。'
                : 'Your comment has been submitted and is pending review.');
    }

    protected function getGeoLocation(string $ip): array
    {
        $cacheKey = 'geo_' . md5($ip);
        $cached = cache()->get($cacheKey);
        if ($cached) {
            return $cached;
        }

        $result = [
            'country' => null,
            'province' => null,
            'city' => null,
        ];

        try {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, "https://opendata.baidu.com/api.php?query={$ip}&co=&resource_id=6006&oe=utf8");
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 3);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            if ($httpCode === 200 && $response) {
                $data = json_decode($response, true);
                if ($data && isset($data['data'][0])) {
                    $loc = $data['data'][0]['location'] ?? '';
                    if ($loc) {
                        $parts = explode(' ', $loc);
                        $result['country'] = $parts[0] ?? null;
                        $result['province'] = $parts[1] ?? null;
                        $result['city'] = $parts[2] ?? null;
                    }
                }
            }
        } catch (\Exception $e) {
            // 获取地理位置失败
        }

        cache()->put($cacheKey, $result, 60 * 60 * 24);
        return $result;
    }
}

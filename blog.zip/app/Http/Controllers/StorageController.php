<?php

namespace App\Http\Controllers;

use Symfony\Component\HttpFoundation\BinaryFileResponse;

class StorageController extends Controller
{
    /**
     * 兜底提供 public 磁盘（storage/app/public）下的文件。
     *
     * Windows（宝塔/IIS）环境常通过 disable_functions 禁用 symlink 与 exec，
     * 导致 public/storage 软链接或 junction 无法创建，退化为“一次性复制”的实体目录。
     * 此后新上传的图片写入 storage/app/public，却不会同步到 public/storage，
     * 通过 /storage/... 访问即 404（表现为“上传后图片丢失”）。
     *
     * 本路由只在 Web 服务器未命中物理文件时才会被匹配（IIS/Apache/Nginx 的
     * “文件或目录不存在则转发到 index.php”规则），因此软链接正常时不会生效，
     * 仅作为软链接不可用时的兜底，保证上传图片始终可访问。
     */
    public function show(string $path): BinaryFileResponse
    {
        $root = realpath(storage_path('app/public'));

        if ($root === false) {
            abort(404);
        }

        $fullPath = realpath($root.DIRECTORY_SEPARATOR.$path);

        // 防路径穿越：解析后的绝对路径必须仍位于 public 存储目录内部，且为真实文件
        if (
            $fullPath === false
            || !str_starts_with($fullPath, $root.DIRECTORY_SEPARATOR)
            || !is_file($fullPath)
        ) {
            abort(404);
        }

        return response()->file($fullPath, [
            // 文件名由上传时随机生成，内容不会被覆盖，可安全长缓存
            'Cache-Control' => 'public, max-age=2592000',
        ]);
    }
}

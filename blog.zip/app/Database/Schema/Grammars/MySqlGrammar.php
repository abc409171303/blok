<?php

namespace App\Database\Schema\Grammars;

use Illuminate\Database\Schema\Grammars\MySqlGrammar as BaseMySqlGrammar;

/**
 * 版本感知的 MySQL Schema 语法。
 *
 * Laravel 内置的 compileColumns() 固定查询 information_schema.columns 的
 * generation_expression 列，而该列自 MySQL 5.7.6 才引入，MySQL 5.6 及更早版本
 * 不存在，会导致安装导入数据表时（Schema::hasColumn / getColumns 等）报
 * Unknown column 'generation_expression'。
 *
 * 这里在拼接列查询 SQL 前先执行 SELECT VERSION() 判断服务器版本：
 *  - MySQL >= 8.0：保留 generation_expression（别名保持框架原样的 `expression`）
 *  - MySQL 5.6 / 5.7：用 NULL 占位，避免查询不存在的列
 * 其余字段与框架原生实现保持一致。
 *
 * 注意：列处理器 MySqlProcessor::processColumns() 会读取 expression 键，
 * 因此 5.6/5.7 下必须保留该列名（值为 NULL），不能直接把整列去掉。
 */
class MySqlGrammar extends BaseMySqlGrammar
{
    /**
     * 当前连接是否支持 information_schema.columns.generation_expression。
     *
     * @var bool|null
     */
    protected $supportsGenerationExpression;

    /**
     * 编译查询表字段列表的 SQL。
     *
     * @param  string|null  $schema
     * @param  string  $table
     * @return string
     */
    public function compileColumns($schema, $table)
    {
        $generationExpression = $this->supportsGenerationExpression()
            ? 'generation_expression as `expression`, '
            : 'null as `expression`, ';

        return sprintf(
            'select column_name as `name`, data_type as `type_name`, column_type as `type`, '
            .'collation_name as `collation`, is_nullable as `nullable`, '
            .'column_default as `default`, column_comment as `comment`, '
            .$generationExpression.'extra as `extra` '
            .'from information_schema.columns where table_schema = %s and table_name = %s '
            .'order by ordinal_position asc',
            $schema ? $this->quoteString($schema) : 'schema()',
            $this->quoteString($table)
        );
    }

    /**
     * 判断服务器版本是否 >= 8.0（结果按连接缓存）。
     */
    protected function supportsGenerationExpression(): bool
    {
        if ($this->supportsGenerationExpression !== null) {
            return $this->supportsGenerationExpression;
        }

        $version = '0';

        try {
            $result = $this->connection->selectOne('select version() as version');
            $version = (string) ($result->version ?? '0');
        } catch (\Throwable $e) {
            // 读取版本失败时按旧版本处理，兼容优先。
            $version = '0';
        }

        return $this->supportsGenerationExpression = version_compare($version, '8.0.0', '>=');
    }
}

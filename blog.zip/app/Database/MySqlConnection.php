<?php

namespace App\Database;

use App\Database\Schema\Grammars\MySqlGrammar;
use Illuminate\Database\MySqlConnection as BaseMySqlConnection;

/**
 * 使用版本感知 Schema 语法的 MySQL 连接。
 *
 * 通过 Connection::resolverFor('mysql', ...) 注册，用于修复 MySQL 5.6 / 5.7
 * 上查询 information_schema.columns.generation_expression 失败的问题
 * （详见 App\Database\Schema\Grammars\MySqlGrammar）。
 */
class MySqlConnection extends BaseMySqlConnection
{
    /**
     * 获取默认的 Schema 语法实例。
     *
     * @return \Illuminate\Database\Schema\Grammars\MySqlGrammar
     */
    protected function getDefaultSchemaGrammar()
    {
        return new MySqlGrammar($this);
    }
}

/**
 * 标签弹窗树形选择组件（文章创建/编辑页共用）
 * 用法：<div x-data="tagPicker(initialIds, initialNames, groups)">...</div>
 * - initialIds: 已选标签 id 数组
 * - initialNames: 已选标签名称数组（与 ids 一一对应）
 * - groups: 一级标签分组 [{ id, name, children: [{ id, name }] }]
 */
document.addEventListener('alpine:init', () => {
    Alpine.data('tagPicker', (initialIds, initialNames, groups) => ({
        selectedTags: (initialIds || []).map((id, i) => ({ id: parseInt(id), name: (initialNames || [])[i] || '' })),
        groups: groups || [],
        pickerOpen: false,
        searchKeyword: '',
        expandedGroups: [],
        pickerStyle: {},

        get filteredGroups() {
            const kw = this.searchKeyword.trim().toLowerCase();
            if (!kw) return this.groups;
            return this.groups
                .map(g => {
                    const matchSelf = g.name.toLowerCase().includes(kw);
                    const children = (g.children || []).filter(c => c.name.toLowerCase().includes(kw));
                    return { ...g, children, matchSelf };
                })
                .filter(g => g.matchSelf || (g.children && g.children.length > 0));
        },

        isSelected(id) {
            return this.selectedTags.some(t => t.id === id);
        },

        toggleGroup(id) {
            const idx = this.expandedGroups.indexOf(id);
            if (idx >= 0) {
                this.expandedGroups.splice(idx, 1);
            } else {
                this.expandedGroups.push(id);
            }
        },

        toggleChild(id, name) {
            if (this.isSelected(id)) {
                this.selectedTags = this.selectedTags.filter(t => t.id !== id);
            } else {
                this.selectedTags.push({ id, name });
            }
        },

        removeTag(id) {
            this.selectedTags = this.selectedTags.filter(t => t.id !== id);
        },

        clearAll() {
            this.selectedTags = [];
        },

        openTagPicker(event) {
            // 自动判断弹出位置：下方空间不足则向上弹出（避免遮挡 SEO 等下方输入框）
            const rect = event.currentTarget.getBoundingClientRect();
            const vh = window.innerHeight;
            const vw = window.innerWidth;
            const estHeight = Math.min(vh * 0.6, 360) + 120; // 弹窗预估总高（含头部/底部）
            const spaceBelow = vh - rect.bottom - 8;
            const left = Math.max(12, Math.min(rect.left, vw - 12 - 420));
            if (spaceBelow < estHeight) {
                this.pickerStyle = { bottom: (vh - rect.top + 8) + 'px', left: left + 'px' };
            } else {
                this.pickerStyle = { top: (rect.bottom + 8) + 'px', left: left + 'px' };
            }
            this.searchKeyword = '';
            this.expandedGroups = [];
            this.pickerOpen = true;
        },

        closeTagPicker() {
            this.pickerOpen = false;
        },
    }));
});

/**
 * Vditor 编辑器统一初始化模块
 * - 统一工具栏配置（文章创建 / 编辑 / 博主简介共用）
 * - 统一描边风格图标（引用 layouts/admin.blade.php 中预注入的 #vditorIconScript sprite）
 * - 内置弹窗组件：TEX 公式 / Mermaid 图表 / 视频插入 / 表格自定义行列
 */
window.BlogVditor = (function () {
    'use strict';

    var ICON = function (name) {
        return '<svg class="vditor-toolbar__item-icon"><use xlink:href="#vditor-icon-' + name + '"></use></svg>';
    };

    /* ==================== 上传状态 ==================== */
    var _uploadUrl = '';
    var _uploadFieldName = 'file';
    var _uploadCsrf = '';
    var _uploadAccept = 'image/*,.mp4,.webm,.ogg,.mp3,.wav';

    /* ==================== 上传下拉菜单（平铺4个选项） ==================== */
    var uploadMenuStyleId = 'bvd-upload-menu-style';
    function ensureUploadMenuStyle() {
        if (document.getElementById(uploadMenuStyleId)) { return; }
        var style = document.createElement('style');
        style.id = uploadMenuStyleId;
        style.textContent = [
            '.bvd-upload-menu{position:fixed;z-index:10000;background:#fff;border:1px solid #e5e7eb;border-radius:12px;box-shadow:0 8px 24px rgba(0,0,0,.14);padding:6px;font-size:14px;color:#1f2937;transform-origin:top left;min-width:180px}',
            '.bvd-upload-menu__item{display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:8px;cursor:pointer;transition:background .12s}',
            '.bvd-upload-menu__item:hover{background:#f3f4f6}',
            '.bvd-upload-menu__item:active{background:#e5e7eb}',
            '.bvd-upload-menu__item svg{flex-shrink:0;width:20px;height:20px;color:#2563eb}',
            '.bvd-upload-menu__item span{color:#374151;flex:1}',
            '.bvd-upload-menu--dark{background:#1f2937;border-color:#374151;box-shadow:0 8px 24px rgba(0,0,0,.5)}',
            '.bvd-upload-menu--dark .bvd-upload-menu__item:hover{background:#374151}',
            '.bvd-upload-menu--dark .bvd-upload-menu__item:active{background:#4b5563}',
            '.bvd-upload-menu--dark .bvd-upload-menu__item span{color:#e5e7eb}',
            '.bvd-upload-menu--dark .bvd-upload-menu__item svg{color:#60a5fa}'
        ].join('');
        document.head.appendChild(style);
    }

    var UPLOAD_ICONS = {
        camera: '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z"/></svg>',
        photo: '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>',
        file: '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"/></svg>',
        library: '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M5 19a2 2 0 01-2-2V7a2 2 0 012-2h4l2 2h4a2 2 0 012 2v1M5 19h14a2 2 0 002-2v-5a2 2 0 00-2-2H9a2 2 0 00-2 2v5a2 2 0 01-2 2z"/></svg>'
    };

    /**
     * 弹出平铺4选项菜单，点击直接触发对应功能
     */
    function toggleUploadMenu(anchor) {
        var existing = document.getElementById('bvd-upload-menu');
        if (existing) { closeUploadMenu(); return; }
        ensureUploadMenuStyle();

        var dark = !!document.querySelector('.vditor--dark');
        var menu = document.createElement('div');
        menu.id = 'bvd-upload-menu';
        menu.className = 'bvd-upload-menu' + (dark ? ' bvd-upload-menu--dark' : '');
        menu.setAttribute('role', 'menu');
        var items = [
            { act: 'camera', label: '拍照' },
            { act: 'photo', label: '照片图库' },
            { act: 'file', label: '选取文件' },
            { act: 'library', label: '从文件库选择' }
        ].map(function (it) {
            return '<div class="bvd-upload-menu__item" role="menuitem" data-act="' + it.act + '">' +
                (UPLOAD_ICONS[it.act] || '') + '<span>' + it.label + '</span></div>';
        }).join('');
        menu.innerHTML = items;
        document.body.appendChild(menu);

        positionUploadMenu(menu, anchor);

        menu.addEventListener('click', function (e) {
            var item = e.target.closest('[data-act]');
            if (!item) { return; }
            var act = item.getAttribute('data-act');
            closeUploadMenu();
            if (act === 'camera') {
                triggerFileUpload('image/*,video/*', true);
            } else if (act === 'photo') {
                triggerFileUpload('image/jpeg,image/jpg,image/png,image/webp', false);
            } else if (act === 'file') {
                triggerFileUpload(_uploadAccept, false);
            } else if (act === 'library') {
                if (typeof window.openMediaSelector === 'function') {
                    window.openMediaSelector('vditor');
                } else {
                    showToast('文件库组件未加载');
                }
            }
        });

        setTimeout(function () {
            document.addEventListener('mousedown', onDocDown, true);
        }, 0);
        document.addEventListener('keydown', onDocKey, true);
        document.addEventListener('scroll', closeUploadMenu, true);

        // 防止Vditor内置upload按钮的默认行为
        var uploadBtn = document.querySelector('button[data-type="upload"]');
        if (uploadBtn) {
            uploadBtn.style.display = 'none';
            uploadBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                return false;
            });
        }
    }

    function onDocDown(e) {
        var menu = document.getElementById('bvd-upload-menu');
        if (!menu) { return; }
        if (menu.contains(e.target)) { return; }
        if (e.target.closest && e.target.closest('[data-type="custom-upload"]')) { return; }
        closeUploadMenu();
    }

    function onDocKey(e) {
        if (e.key === 'Escape') { closeUploadMenu(); }
    }

    function closeUploadMenu() {
        var menu = document.getElementById('bvd-upload-menu');
        if (menu && menu.parentNode) { menu.parentNode.removeChild(menu); }
        document.removeEventListener('mousedown', onDocDown, true);
        document.removeEventListener('keydown', onDocKey, true);
        document.removeEventListener('scroll', closeUploadMenu, true);
    }

    /**
     * 下拉菜单定位：默认显示在按钮下方，空间不足时自动翻转，并避免超出视口
     */
    function positionUploadMenu(menu, anchor) {
        var menuW = menu.offsetWidth || 180;
        var menuH = menu.offsetHeight || 200;
        var rect = anchor.getBoundingClientRect();
        var gap = 6;
        var pad = 8;

        var left = rect.left;
        var top = rect.bottom + gap;
        // 右边界检测
        if (left + menuW > window.innerWidth - pad) {
            left = Math.max(pad, window.innerWidth - menuW - pad);
        }
        if (left < pad) { left = pad; }
        // 底部空间不足时显示在按钮上方
        if (top + menuH > window.innerHeight - pad) {
            top = rect.top - menuH - gap;
            if (top < pad) { top = pad; }
        }
        menu.style.left = Math.round(left) + 'px';
        menu.style.top = Math.round(top) + 'px';
    }

    /**
     * 创建临时文件选择框并上传
     * @param {string} accept 允许的文件类型
     * @param {boolean} capture 是否唤起相机
     */
    function triggerFileUpload(accept, capture) {
        // 清理上一次未移除的临时文件框（用户取消选择时 change 不触发）
        document.querySelectorAll('input[data-bvd-upload]').forEach(function (el) {
            if (el.parentNode) { el.parentNode.removeChild(el); }
        });
        var input = document.createElement('input');
        input.type = 'file';
        input.setAttribute('data-bvd-upload', '1');
        input.accept = accept;
        input.multiple = false;
        if (capture) { input.setAttribute('capture', 'environment'); }
        input.style.display = 'none';
        document.body.appendChild(input);
        input.addEventListener('change', function () {
            if (input.files && input.files.length > 0) {
                doUpload(input.files[0]);
            }
            if (input.parentNode) { document.body.removeChild(input); }
        });
        input.click();
    }

    /**
     * 轻量 toast 提示（避免 alert 在部分环境阻塞主线程）
     */
    function showToast(msg) {
        var el = document.getElementById('bvd-upload-toast');
        if (!el) {
            el = document.createElement('div');
            el.id = 'bvd-upload-toast';
            el.style.cssText = 'position:fixed;top:20px;left:50%;transform:translateX(-50%);z-index:10001;background:#111827;color:#fff;padding:10px 18px;border-radius:8px;font-size:14px;box-shadow:0 4px 16px rgba(0,0,0,.2);opacity:0;transition:opacity .2s;pointer-events:none;max-width:80vw;';
            document.body.appendChild(el);
        }
        el.textContent = msg;
        el.style.opacity = '1';
        clearTimeout(el.__bvdTimer);
        el.__bvdTimer = setTimeout(function () { el.style.opacity = '0'; }, 2500);
    }

    /**
     * 上传文件到 _uploadUrl 并插入编辑器
     */
    function doUpload(file) {
        if (!_uploadUrl) { showToast('未配置上传接口'); return; }
        var vditor = window.__vditorInternal;
        if (!vditor) { showToast('编辑器未初始化'); return; }

        var formData = new FormData();
        formData.append(_uploadFieldName, file);

        var xhr = new XMLHttpRequest();
        xhr.open('POST', _uploadUrl);
        if (_uploadCsrf) { xhr.setRequestHeader('X-CSRF-TOKEN', _uploadCsrf); }
        xhr.onload = function () {
            var res;
            try { res = JSON.parse(xhr.responseText); } catch (e) { res = {}; }
            if (res.success && res.url) {
                insertUploadResult(vditor, res.url, file.name);
            } else {
                showToast(res.message || '上传失败');
            }
        };
        xhr.onerror = function () { showToast('网络错误，上传失败'); };
        xhr.send(formData);
    }

    /**
     * 按文件扩展名插入对应的内容（图片 / 音频 / 视频）
     * 注意：必须使用对外实例的 insertValue 官方 API。
     * insertMarkdown 的 execCommand 路径插入 <img> 会触发 vditor 内部重建死循环，卡死主线程。
     */
    function insertUploadResult(vditor, url, filename) {
        var lower = url.toLowerCase();
        var content;
        if (/\.(wav|mp3|ogg)(\?|#|$)/.test(lower)) {
            content = '<audio controls src="' + url + '"></audio>';
        } else if (/\.(mp4|webm|mov|m4v)(\?|#|$)/.test(lower)) {
            content = '<video controls src="' + url + '"></video>';
        } else {
            var alt = filename ? filename.replace(/"/g, '&quot;') : 'image';
            content = '![' + alt + '](' + url + ')';
        }
        var pub = window.vditor;
        if (pub && typeof pub.insertValue === 'function') {
            pub.insertValue(content);
        } else if (vditor && vditor.lute) {
            // 降级：对外实例不可用时走内部对象（图片插入有卡死风险，仅在无对外实例时使用）
            insertMarkdown(vditor, content + '\n');
        }
    }

    /* ==================== 通用弹窗 ==================== */
    var modalStyleId = 'vditor-modal-style';
    function ensureModalStyle() {
        if (document.getElementById(modalStyleId)) { return; }
        var style = document.createElement('style');
        style.id = modalStyleId;
        style.textContent = [
            '.vditor-modal-mask{position:fixed;inset:0;z-index:9999;background:rgba(17,24,39,.45);display:flex;align-items:center;justify-content:center;padding:16px}',
            '.vditor-modal{width:100%;max-width:440px;background:#fff;border-radius:12px;box-shadow:0 20px 50px rgba(0,0,0,.25);overflow:hidden;font-size:14px;color:#1f2937}',
            '.vditor-modal__head{display:flex;align-items:center;justify-content:space-between;padding:14px 18px;border-bottom:1px solid #f3f4f6;font-weight:600}',
            '.vditor-modal__close{cursor:pointer;color:#9ca3af;font-size:18px;line-height:1;border:0;background:transparent;padding:2px 6px}',
            '.vditor-modal__close:hover{color:#374151}',
            '.vditor-modal__body{padding:18px;max-height:60vh;overflow-y:auto}',
            '.vditor-modal__label{display:block;margin-bottom:6px;font-size:13px;color:#6b7280}',
            '.vditor-modal__input,.vditor-modal__select,.vditor-modal__textarea{width:100%;box-sizing:border-box;border:1px solid #d1d5db;border-radius:8px;padding:8px 10px;font-size:14px;outline:none;margin-bottom:12px;background:#fff;color:#1f2937}',
            '.vditor-modal__input:focus,.vditor-modal__select:focus,.vditor-modal__textarea:focus{border-color:#2563eb;box-shadow:0 0 0 3px rgba(37,99,235,.1)}',
            '.vditor-modal__textarea{resize:vertical;min-height:70px;font-family:ui-monospace,Menlo,monospace}',
            '.vditor-modal__row{display:flex;gap:12px}',
            '.vditor-modal__row > div{flex:1}',
            '.vditor-modal__foot{display:flex;justify-content:flex-end;gap:10px;padding:12px 18px;border-top:1px solid #f3f4f6}',
            '.vditor-modal__btn{border:1px solid #d1d5db;background:#fff;color:#374151;border-radius:8px;padding:7px 18px;font-size:14px;cursor:pointer;transition:all .15s}',
            '.vditor-modal__btn:hover{background:#f9fafb}',
            '.vditor-modal__btn--primary{background:#2563eb;border-color:#2563eb;color:#fff}',
            '.vditor-modal__btn--primary:hover{background:#1d4ed8}'
        ].join('');
        document.head.appendChild(style);
    }

    /**
     * 打开模态框
     * @param {Object} opts {title, body(html 字符串), onOk(返回 true 则关闭)}
     */
    function openModal(opts) {
        ensureModalStyle();
        var mask = document.createElement('div');
        mask.className = 'vditor-modal-mask';
        mask.innerHTML =
            '<div class="vditor-modal" role="dialog">' +
            '<div class="vditor-modal__head"><span>' + (opts.title || '') + '</span>' +
            '<button type="button" class="vditor-modal__close" data-close>&times;</button></div>' +
            '<div class="vditor-modal__body">' + (opts.body || '') + '</div>' +
            '<div class="vditor-modal__foot">' +
            '<button type="button" class="vditor-modal__btn" data-cancel>取消</button>' +
            '<button type="button" class="vditor-modal__btn vditor-modal__btn--primary" data-ok>' + (opts.okText || '确定') + '</button>' +
            '</div></div>';
        document.body.appendChild(mask);

        var firstInput = mask.querySelector('input,select,textarea');
        if (firstInput) { firstInput.focus(); }

        function close() {
            if (mask.parentNode) { mask.parentNode.removeChild(mask); }
            document.removeEventListener('keydown', onKey);
        }
        function onKey(e) {
            if (e.key === 'Escape') { close(); }
            if (e.key === 'Enter' && e.target.tagName !== 'TEXTAREA') { confirm(); }
        }
        function confirm() {
            var result = opts.onOk ? opts.onOk(mask) : true;
            if (result === true) { close(); }
        }
        mask.addEventListener('click', function (e) {
            if (e.target === mask || e.target.getAttribute('data-close') !== null || e.target.getAttribute('data-cancel') !== null) { close(); }
            if (e.target.getAttribute('data-ok') !== null) { confirm(); }
        });
        document.addEventListener('keydown', onKey);
    }

    /* ==================== Mermaid 模板 ==================== */
    var MERMAID_TEMPLATES = {
        'graph': '```mermaid\ngraph LR\n    A["起点"] --> B["终点"]\n    B --> C["结果"]\n```\n',
        'sequence': '```mermaid\nsequenceDiagram\n    participant A as 前端\n    participant B as 后端\n    A->>B: 发起请求\n    B-->>A: 返回结果\n```\n',
        'gantt': '```mermaid\ngantt\n    title 项目进度\n    dateFormat YYYY-MM-DD\n    section 阶段一\n    任务A :a1, 2026-01-01, 7d\n    任务B :after a1, 5d\n```\n',
        'class': '```mermaid\nclassDiagram\n    class Animal {\n        +String name\n        +int age\n        +eat()\n    }\n    class Dog {\n        +bark()\n    }\n    Dog --|> Animal\n```\n',
        'state': '```mermaid\nstateDiagram-v2\n    [*] --> 待处理\n    待处理 --> 处理中: 开始\n    处理中 --> 已完成: 完成\n    已完成 --> [*]\n```\n',
        'pie': '```mermaid\npie title 数据分布\n    "A" : 40\n    "B" : 30\n    "C" : 30\n```\n',
        'er': '```mermaid\nerDiagram\n    USER ||--o{ ORDER : "下单"\n    USER {\n        int id PK\n        string name\n    }\n    ORDER {\n        int id PK\n        int user_id FK\n    }\n```\n',
        'journey': '```mermaid\njourney\n    title 用户旅程\n    section 使用\n      打开页面: 5: 用户\n      完成操作: 3: 用户\n```\n'
    };

    /* ==================== 自定义按钮 ==================== */
    /**
     * 统一插入函数。
     * Vditor 自定义按钮 click 回调收到的 vditor 参数是内部对象（含 currentMode/lute/wysiwyg/ir/sv，
     * 但没有对外实例的 insertValue 等方法），因此统一经 lute 将 markdown 渲染为对应模式的 DOM 再插入。
     * @param {Object} internal Vditor 内部对象（click 回调第二参数）
     * @param {string} md markdown 内容
     */
    function insertMarkdown(internal, md) {
        if (!internal || !internal.lute) { return; }
        var mode = internal.currentMode;
        var html;
        if (mode === 'wysiwyg') {
            html = internal.lute.Md2VditorDOM(md);
        } else if (mode === 'ir') {
            html = internal.lute.Md2VditorIRDOM(md);
        } else {
            // sv 源码模式：直接在 textarea 中插入文本
            var svEl = internal.sv.element;
            if (!svEl) { return; }
            svEl.focus();
            var val = svEl.value;
            var start = svEl.selectionStart != null ? svEl.selectionStart : val.length;
            var end = svEl.selectionEnd != null ? svEl.selectionEnd : start;
            svEl.value = val.slice(0, start) + md + val.slice(end);
            svEl.selectionStart = svEl.selectionEnd = start + md.length;
            svEl.dispatchEvent(new Event('input', { bubbles: true }));
            return;
        }
        var el = internal[mode] ? internal[mode].element : null;
        if (!el) { return; }
        el.focus();
        var ok = false;
        try { ok = document.execCommand('insertHTML', false, html); } catch (err) { ok = false; }
        if (!ok) {
            var sel = window.getSelection();
            var range = sel.rangeCount > 0 ? sel.getRangeAt(0) : null;
            if (!range || !el.contains(range.commonAncestorContainer)) {
                range = document.createRange();
                range.selectNodeContents(el);
                range.collapse(false);
                sel.removeAllRanges();
                sel.addRange(range);
            }
            var temp = document.createElement('template');
            temp.innerHTML = html;
            range.deleteContents();
            range.insertNode(temp.content.cloneNode(true));
            range.collapse(false);
            sel.removeAllRanges();
            sel.addRange(range);
            el.dispatchEvent(new Event('input', { bubbles: true }));
        }
    }

    function mathButton() {
        return {
            name: 'math',
            icon: ICON('math'),
            tip: 'TEX 公式',
            tipPosition: 'n',
            // Vditor 自定义按钮回调签名固定为 (event, vditor)
            click: function (e, vditor) {
                openModal({
                    title: '插入 TEX 公式',
                    body:
                        '<label class="vditor-modal__label">公式类型</label>' +
                        '<select class="vditor-modal__select" id="bvd-math-type">' +
                        '<option value="inline">行内公式（$...$）</option>' +
                        '<option value="block">块级公式（$$...$$）</option></select>' +
                        '<label class="vditor-modal__label">公式内容</label>' +
                        '<textarea class="vditor-modal__textarea" id="bvd-math-content" placeholder="例如：\\frac{a}{b} 或 x^2 + y^2 = z^2"></textarea>',
                    onOk: function (mask) {
                        var type = mask.querySelector('#bvd-math-type').value;
                        var content = mask.querySelector('#bvd-math-content').value.trim();
                        if (!content) { return false; }
                        if (type === 'inline') {
                            insertMarkdown(vditor, '$' + content + '$');
                        } else {
                            insertMarkdown(vditor, '\n$$\n' + content + '\n$$\n');
                        }
                        return true;
                    }
                });
            }
        };
    }

    function mermaidButton() {
        return {
            name: 'mermaid',
            icon: ICON('mermaid'),
            tip: 'Mermaid 图表',
            tipPosition: 'n',
            // Vditor 自定义按钮回调签名固定为 (event, vditor)
            click: function (e, vditor) {
                var options = Object.keys(MERMAID_TEMPLATES).map(function (k) {
                    var label = { graph: '流程图', sequence: '时序图', gantt: '甘特图', 'class': '类图', state: '状态图', pie: '饼图', er: 'ER 图', journey: '用户旅程图' }[k] || k;
                    return '<option value="' + k + '">' + label + '</option>';
                }).join('');
                openModal({
                    title: '插入 Mermaid 图表',
                    body:
                        '<label class="vditor-modal__label">图表类型</label>' +
                        '<select class="vditor-modal__select" id="bvd-mermaid-type">' + options + '</select>' +
                        '<p style="font-size:12px;color:#9ca3af;margin:0">选择类型后将插入对应的图表模板，可继续编辑内容。</p>',
                    onOk: function (mask) {
                        var type = mask.querySelector('#bvd-mermaid-type').value;
                        insertMarkdown(vditor, MERMAID_TEMPLATES[type] || MERMAID_TEMPLATES.graph);
                        return true;
                    }
                });
            }
        };
    }

    function videoButton() {
        return {
            name: 'video',
            icon: ICON('video'),
            tip: '插入视频',
            tipPosition: 'n',
            // Vditor 自定义按钮回调签名固定为 (event, vditor)
            click: function (e, vditor) {
                openModal({
                    title: '插入视频',
                    body:
                        '<label class="vditor-modal__label">视频链接</label>' +
                        '<input class="vditor-modal__input" id="bvd-video-url" type="url" placeholder="https:// 或 B站/YouTube 链接" />' +
                        '<label class="vditor-modal__label">备选标题</label>' +
                        '<input class="vditor-modal__input" id="bvd-video-title" type="text" placeholder="（可选）视频说明文字" />',
                    onOk: function (mask) {
                        var url = mask.querySelector('#bvd-video-url').value.trim();
                        var title = mask.querySelector('#bvd-video-title').value.trim();
                        if (!url) { return false; }
                        var html = videoHtml(url, title);
                        if (html) { insertMarkdown(vditor, html + '\n'); return true; }
                        return false;
                    }
                });
            }
        };
    }

    function videoHtml(url, title) {
        var titleAttr = title ? ' title="' + title.replace(/"/g, '&quot;') + '"' : '';
        // Bilibili
        var bv = url.match(/(?:bilibili\.com\/video\/|BV)[\/]?(BV[0-9A-Za-z]+)/);
        if (bv) {
            return '<iframe src="https://player.bilibili.com/player.html?bvid=' + bv[1] + '&page=1" scrolling="no" border="0" frameborder="no" framespacing="0" allowfullscreen="true" width="100%" style="aspect-ratio:16/9;border:none;border-radius:8px"' + titleAttr + '></iframe>';
        }
        // YouTube
        var yt = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([0-9A-Za-z_-]{11})/);
        if (yt) {
            return '<iframe src="https://www.youtube.com/embed/' + yt[1] + '" frameborder="0" allowfullscreen="true" width="100%" style="aspect-ratio:16/9;border:none;border-radius:8px"' + titleAttr + '></iframe>';
        }
        // 通用视频文件
        if (/\.(mp4|webm|ogg|mov)(\?|#|$)/i.test(url)) {
            return '<video controls width="100%" style="border-radius:8px"' + titleAttr + '><source src="' + url + '"></video>';
        }
        // 其他视为通用 HTML5 视频
        return '<video controls width="100%"' + titleAttr + '><source src="' + url + '"></video>';
    }

    function tableButton() {
        return {
            // 注意：name 不能为内置名 'table'（genItem 会走内置分支，自定义 click 不生效）
            name: 'custom-table',
            icon: ICON('table'),
            tip: '插入表格（自定义行列）',
            tipPosition: 'n',
            // Vditor 自定义按钮回调签名固定为 (event, vditor)
            click: function (e, vditor) {
                openModal({
                    title: '插入表格',
                    body:
                        '<div class="vditor-modal__row">' +
                        '<div><label class="vditor-modal__label">列数</label>' +
                        '<input class="vditor-modal__input" id="bvd-table-col" type="number" min="1" max="12" value="3" /></div>' +
                        '<div><label class="vditor-modal__label">行数</label>' +
                        '<input class="vditor-modal__input" id="bvd-table-row" type="number" min="1" max="30" value="3" /></div>' +
                        '</div>' +
                        '<p style="font-size:12px;color:#9ca3af;margin:0">首行将自动作为表头。</p>',
                    onOk: function (mask) {
                        var cols = parseInt(mask.querySelector('#bvd-table-col').value, 10) || 3;
                        var rows = parseInt(mask.querySelector('#bvd-table-row').value, 10) || 3;
                        cols = Math.min(12, Math.max(1, cols));
                        rows = Math.min(30, Math.max(1, rows));
                        insertMarkdown(vditor, buildMarkdownTable(cols, rows) + '\n');
                        return true;
                    }
                });
            }
        };
    }

    function buildMarkdownTable(cols, rows) {
        var head = '| ' + new Array(cols).fill('列标题').join(' | ') + ' |\n';
        var sep = '| ' + new Array(cols).fill('---').join(' | ') + ' |\n';
        var body = '';
        for (var r = 0; r < rows - 1; r++) {
            body += '| ' + new Array(cols).fill(' ').join(' | ') + ' |\n';
        }
        return head + sep + body;
    }

    /**
     * 自定义“分割线”按钮。
     * Vditor 内置 line 按钮只处理 ir/sv 模式；默认 wysiwyg 模式下点击无效果，
     * 因此用自定义按钮统一处理所有编辑模式。
     */
    function lineButton() {
        return {
            name: 'custom-line',
            icon: ICON('line'),
            tip: '分割线',
            tipPosition: 'n',
            click: function (e, vditor) {
                // vditor 为内部对象：currentMode 是属性而非方法
                insertMarkdown(vditor, '\n---\n');
            }
        };
    }

    function aiWriteButton() {
        return {
            name: 'ai-write',
            icon: ICON('ai-write'),
            tip: 'AI 写作',
            tipPosition: 'n',
            // 打开 AI 写作弹窗（流式输出、图生文、停止生成等能力在弹窗内实现）
            // 注意：click 回调收到的 vditor 是内部对象（无 insertValue/getValue），
            // 不能覆盖 window.vditor（对外实例由 after 回调设置），内部对象另存备用。
            click: function (e, vditor) {
                window.__vditorInternal = vditor;
                if (typeof window.openAiWriter === 'function') {
                    window.openAiWriter();
                }
            }
        };
    }

    function aiImageButton() {
        return {
            name: 'ai-image',
            icon: ICON('ai-image'),
            tip: 'AI 生成配图',
            tipPosition: 'n',
            // 打开 AI 生成配图弹窗（自动提取正文提示词、预览、插入）
            click: function (e, vditor) {
                window.__vditorInternal = vditor;
                if (typeof window.openAiImage === 'function') {
                    window.openAiImage();
                }
            }
        };
    }

    /**
     * 自定义"上传"按钮。
     * Vditor 内置 upload 按钮是内嵌 <input type="file">，移动端会弹出浏览器原生选择菜单
     * （照片图库 / 拍照或录像 / 选取文件），无法新增自定义项。这里改为自定义菜单，
     * 在保留原有三项能力的基础上增加"从文件库选择"入口。
     */
    function uploadButton() {
        return {
            name: 'custom-upload',
            icon: ICON('upload'),
            tip: '上传图片/视频',
            tipPosition: 'n',
            click: function (e, vditor) {
                window.__vditorInternal = vditor;
                // 以按钮自身为锚点弹出下拉菜单
                var anchor = e && e.currentTarget ? e.currentTarget : null;
                if (!anchor) { anchor = document.querySelector('button[data-type="custom-upload"]'); }
                toggleUploadMenu(anchor);
            }
        };
    }

    /* ==================== 统一工具栏 ==================== */
    function buildToolbar(includeAi) {
        var toolbar = [
            'emoji', 'headings', 'bold', 'italic', 'strike', lineButton(), 'quote', '|',
            'link', uploadButton(), tableButton(), 'code', 'inline-code', '|',
            'list', 'ordered-list', 'check', 'outdent', 'indent', '|',
            'undo', 'redo', '|',
            'edit-mode', 'both', 'preview', 'fullscreen', 'outline', '|',
            mathButton(), mermaidButton(), videoButton(), '|'
        ];
        // 原“更多”菜单内的按钮按序展开到工具栏末尾
        if (includeAi) {
            toolbar = toolbar.concat([aiWriteButton(), aiImageButton()]);
        }
        toolbar = toolbar.concat(['export', 'info', 'help']);
        return toolbar;
    }

    /* ==================== 初始化 ==================== */
    /**
     * @param {Object} opts
     *   id         编辑器挂载元素 id（默认 'vditor'）
     *   value      初始内容
     *   height     编辑器高度
     *   placeholder 占位文案
     *   uploadUrl  上传接口
     *   uploadFieldName 上传字段名（默认 file）
     *   accept     上传类型
     *   formId     表单 id（提交时同步内容）
     *   outputEl   隐藏 textarea id
     *   outputType 'markdown' | 'html'（提交内容格式）
     *   includeAi  是否包含 AI 按钮（默认 true）
     *   onReady    after 回调
     */
    function init(opts) {
        opts = opts || {};
        var id = opts.id || 'vditor';
        var form = opts.formId ? document.getElementById(opts.formId) : null;
        var outputEl = opts.outputEl ? document.getElementById(opts.outputEl) : null;

        // 保存上传配置，供自定义上传按钮使用
        _uploadUrl = opts.uploadUrl || '';
        _uploadFieldName = opts.uploadFieldName || 'file';
        _uploadAccept = opts.accept || 'image/*,.mp4,.webm,.ogg,.mp3,.wav';
        var csrfMeta = document.querySelector('meta[name="csrf-token"]');
        _uploadCsrf = csrfMeta ? csrfMeta.content : '';

        // 降级：主库或 lute 加载失败时，显示可编辑的 textarea，避免编辑器空白
        if (typeof Vditor === 'undefined' || window.__vditorLuteFail || window.__vditorMainFail) {
            fallbackToTextarea(id, opts);
            return null;
        }

        var vditor = new Vditor(id, {
            icon: null, // 使用预注入的 #vditorIconScript sprite
            cdn: '/static/vditor', // 动态加载 katex/mermaid/lute 等走本地资源，禁用外网 CDN
            height: opts.height || 600,
            mode: 'wysiwyg',
            placeholder: opts.placeholder || '开始写作...',
            // HTML 内容（about 页面）直接放入挂载元素 #vditor，value 留空时 Vditor 自动 HTML2Md 渲染
            value: opts.value || '',
            toolbar: buildToolbar(opts.includeAi !== false),
            toolbarConfig: {
                pin: true
            },
            counter: { enable: false },
            cache: { enable: false },
            upload: false,
            preview: { delay: 500, markdown: { toc: true, math: true }, hljs: { style: 'github' }, math: { engine: 'KaTeX' } },
            after: function () {
                window.vditor = vditor;
                if (opts.onReady) { opts.onReady(vditor); }
                // 强制隐藏所有内置upload相关元素
                hideBuiltInUpload(vditor);
            }
        });

        if (form && outputEl) {
            form.addEventListener('submit', function () {
                outputEl.value = (opts.outputType === 'html') ? vditor.getHTML() : vditor.getValue();
            });
        }

        // 页面离开时销毁编辑器实例，释放事件监听与 DOM
        window.addEventListener('pagehide', function () {
            try {
                if (vditor && typeof vditor.destroy === 'function') { vditor.destroy(); }
            } catch (e) { /* 忽略销毁异常 */ }
        });
        return vditor;
    }

    /**
     * 强制隐藏Vditor内置的upload相关元素，防止原生菜单触发
     */
    function hideBuiltInUpload(vditor) {
        if (!vditor || !vditor.toolbar || !vditor.toolbar.elements) { return; }
        // 隐藏内置upload按钮
        var uploadEl = vditor.toolbar.elements.upload;
        if (uploadEl) {
            uploadEl.style.display = 'none';
            uploadEl.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                return false;
            }, true);
        }
        // 隐藏所有input[type=file]元素
        document.querySelectorAll('.vditor-toolbar input[type="file"]').forEach(function(el) {
            el.style.display = 'none';
            el.disabled = true;
        });
    }

    /**
     * 编辑器资源加载失败降级：显示挂载元素内的原始内容（textarea），保证表单仍可编辑提交。
     */
    function fallbackToTextarea(id, opts) {
        var mount = document.getElementById(id);
        if (!mount) { return; }
        mount.style.display = 'none';
        var wrap = mount.parentNode;
        if (!wrap) { return; }
        var ta = document.getElementById(opts.outputEl || '');
        var notice = document.createElement('div');
        notice.className = 'vditor-fallback';
        notice.style.cssText = 'padding:14px 16px;margin-bottom:10px;border:1px solid #fbbf24;border-radius:8px;background:#fffbeb;color:#92400e;font-size:13px;';
        notice.textContent = '编辑器组件加载失败，已切换为纯文本编辑，请直接填写内容或刷新页面重试。';
        if (ta) {
            var clone = ta.cloneNode(true);
            clone.removeAttribute('id');
            clone.name = ta.name;
            clone.className = (ta.className || '').replace('hidden', '') + ' w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm';
            clone.style.minHeight = '300px';
            clone.style.display = 'block';
            ta.style.display = 'none';
            ta.id = ta.id + '-backup';
            ta.removeAttribute('name'); // 避免与原 name 重复提交
            wrap.insertBefore(notice, wrap.firstChild);
            wrap.appendChild(clone);
        } else {
            wrap.insertBefore(notice, wrap.firstChild);
        }
    }

    return {
        init: init,
        openModal: openModal,
        ICON: ICON
    };
})();

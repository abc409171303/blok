<template>
  <div class="navigation-manager">
    <!-- 页面头部 -->
    <div class="page-header">
      <h2 class="page-title">导航管理</h2>
      <el-button type="primary" @click="openAddDialog">
        <el-icon><Plus /></el-icon>
        增加导航
      </el-button>
    </div>

    <!-- Tab 切换 -->
    <el-tabs v-model="activePosition" @tab-change="loadData">
      <el-tab-pane label="头部导航" name="head"></el-tab-pane>
      <el-tab-pane label="底部导航" name="foot"></el-tab-pane>
    </el-tabs>

    <!-- 工具栏 -->
    <div class="toolbar">
      <div class="toolbar-left">
        <el-checkbox
          v-model="selectAll"
          @change="handleSelectAllChange"
          :indeterminate="isIndeterminate"
          :disabled="!tableData || tableData.length === 0"
        >
          批量删除
        </el-checkbox>
        <el-button
          v-if="selectedIds.length > 0"
          type="danger"
          size="small"
          @click="handleBatchDelete"
        >
          删除选中 ({{ selectedIds.length }})
        </el-button>
      </div>
      <div class="toolbar-right">
        <el-input
          v-model="search"
          placeholder="搜索名称或链接..."
          style="width: 260px"
          clearable
          @input="handleSearch"
        >
          <template #prefix>
            <el-icon><Search /></el-icon>
          </template>
        </el-input>
      </div>
    </div>

    <!-- 数据表格 -->
    <el-table
      v-loading="loading"
      :data="tableData"
      stripe
      border
      style="width: 100%"
    >
      <el-table-column type="selection" width="50" />
      <el-table-column prop="id" label="ID" width="80" sortable />
      <el-table-column label="位置" width="100">
        <template #default="{ row }">
          <el-tag :type="row.position === 'head' ? 'primary' : 'success'">
            {{ row.position === 'head' ? '头部' : '底部' }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="name" label="名称" min-width="150" />
      <el-table-column label="图标" width="100">
        <template #default="{ row }">
          <i v-if="row.icon" :class="row.icon" style="font-size: 18px"></i>
          <span v-else style="color: #999">-</span>
        </template>
      </el-table-column>
      <el-table-column prop="url" label="链接" min-width="200" show-overflow-tooltip />
      <el-table-column prop="sort" label="排序" width="100" sortable />
      <el-table-column label="启用" width="100">
        <template #default="{ row }">
          <el-switch
            v-model="row.is_enable"
            :active-value="1"
            :inactive-value="0"
            @change="handleToggleEnable(row)"
          />
        </template>
      </el-table-column>
      <el-table-column label="打开方式" width="100">
        <template #default="{ row }">
          <el-tag :type="row.target === '_self' ? 'info' : 'warning'">
            {{ row.target === '_self' ? '当前窗口' : '新窗口' }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column label="操作" width="220" fixed="right">
        <template #default="{ row }">
          <el-button-group>
            <el-button
              size="small"
              @click="handleMoveUp(row)"
              :disabled="isFirstRow(row)"
              title="上移"
            >
              <el-icon><ArrowUp /></el-icon>
            </el-button>
            <el-button
              size="small"
              @click="handleMoveDown(row)"
              :disabled="isLastRow(row)"
              title="下移"
            >
              <el-icon><ArrowDown /></el-icon>
            </el-button>
            <el-button
              size="small"
              @click="handleView(row)"
              title="查看"
            >
              <el-icon><View /></el-icon>
            </el-button>
            <el-button
              size="small"
              type="primary"
              @click="handleEdit(row)"
              title="编辑"
            >
              <el-icon><Edit /></el-icon>
            </el-button>
            <el-button
              size="small"
              type="danger"
              @click="handleDelete(row)"
              title="删除"
            >
              <el-icon><Delete /></el-icon>
            </el-button>
          </el-button-group>
        </template>
      </el-table-column>
    </el-table>

    <!-- 新增/编辑对话框 -->
    <el-dialog
      v-model="dialogVisible"
      :title="isEdit ? '编辑导航' : '新增导航'"
      width="500px"
      @close="resetForm"
    >
      <el-form
        ref="formRef"
        :model="formData"
        :rules="formRules"
        label-width="100px"
      >
        <el-form-item label="导航名称" prop="name">
          <el-input v-model="formData.name" placeholder="请输入导航名称" />
        </el-form-item>
        <el-form-item label="图标" prop="icon">
          <el-input v-model="formData.icon" placeholder="fas fa-home">
            <template #prefix>
              <i v-if="formData.icon" :class="formData.icon"></i>
            </template>
          </el-input>
          <div class="form-tip">Font Awesome 图标类名，如：fas fa-home</div>
        </el-form-item>
        <el-form-item label="链接地址" prop="url">
          <el-input v-model="formData.url" placeholder="/about 或 https://example.com" />
        </el-form-item>
        <el-form-item label="位置" prop="position">
          <el-radio-group v-model="formData.position">
            <el-radio label="head">头部导航</el-radio>
            <el-radio label="foot">底部导航</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="启用" prop="is_enable">
          <el-switch v-model="formData.is_enable" :active-value="1" :inactive-value="0" />
        </el-form-item>
        <el-form-item label="打开方式" prop="target">
          <el-select v-model="formData.target" style="width: 100%">
            <el-option label="当前窗口" value="_self" />
            <el-option label="新窗口" value="_blank" />
          </el-select>
        </el-form-item>
        <el-form-item label="排序" prop="sort">
          <el-input-number v-model="formData.sort" :min="0" :step="1" style="width: 100%" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="submitForm" :loading="submitting">
          确定
        </el-button>
      </template>
    </el-dialog>

    <!-- 查看对话框 -->
    <el-dialog v-model="viewDialogVisible" title="查看导航" width="500px">
      <el-descriptions :column="1" border>
        <el-descriptions-item label="ID">{{ currentItem?.id }}</el-descriptions-item>
        <el-descriptions-item label="名称">{{ currentItem?.name }}</el-descriptions-item>
        <el-descriptions-item label="图标">
          <i v-if="currentItem?.icon" :class="currentItem.icon" style="font-size: 18px"></i>
          <span v-else>-</span>
        </el-descriptions-item>
        <el-descriptions-item label="位置">
          <el-tag :type="currentItem?.position === 'head' ? 'primary' : 'success'">
            {{ currentItem?.position === 'head' ? '头部' : '底部' }}
          </el-tag>
        </el-descriptions-item>
        <el-descriptions-item label="链接">{{ currentItem?.url }}</el-descriptions-item>
        <el-descriptions-item label="启用">
          <el-tag :type="currentItem?.is_enable ? 'success' : 'danger'">
            {{ currentItem?.is_enable ? '启用' : '禁用' }}
          </el-tag>
        </el-descriptions-item>
        <el-descriptions-item label="打开方式">
          <el-tag :type="currentItem?.target === '_self' ? 'info' : 'warning'">
            {{ currentItem?.target === '_self' ? '当前窗口' : '新窗口' }}
          </el-tag>
        </el-descriptions-item>
        <el-descriptions-item label="排序">{{ currentItem?.sort }}</el-descriptions-item>
      </el-descriptions>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted, watch } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import {
  Plus,
  Search,
  ArrowUp,
  ArrowDown,
  View,
  Edit,
  Delete,
} from '@element-plus/icons-vue'

// 数据
const loading = ref(false)
const submitting = ref(false)
const activePosition = ref('head')
const search = ref('')
const tableData = ref([])
const selectedIds = ref([])
const selectAll = ref(false)
const isIndeterminate = ref(false)
const dialogVisible = ref(false)
const viewDialogVisible = ref(false)
const isEdit = ref(false)
const currentItem = ref(null)
const formRef = ref(null)

// 表单数据
const formData = reactive({
  id: null,
  position: 'head',
  name: '',
  icon: '',
  url: '',
  is_enable: 1,
  target: '_self',
  sort: 0,
})

// 表单验证规则
const formRules = {
  name: [{ required: true, message: '请输入导航名称', trigger: 'blur' }],
  url: [{ required: true, message: '请输入链接地址', trigger: 'blur' }],
  position: [{ required: true, message: '请选择位置', trigger: 'change' }],
  target: [{ required: true, message: '请选择打开方式', trigger: 'change' }],
}

// 获取 CSRF Token
function getCsrfToken() {
  const meta = document.querySelector('meta[name="csrf-token"]')
  return meta ? meta.getAttribute('content') : ''
}

// 加载数据
async function loadData() {
  loading.value = true
  try {
    const response = await fetch(`/admin/api/navigations?position=${activePosition.value}&search=${search.value}`, {
      headers: {
        'X-CSRF-TOKEN': getCsrfToken(),
        'Accept': 'application/json',
      },
    })
    const result = await response.json()
    if (result.success) {
      tableData.value = result.data
    }
  } catch (error) {
    ElMessage.error('加载数据失败')
  } finally {
    loading.value = false
  }
}

// 搜索
function handleSearch() {
  loadData()
}

// 打开新增对话框
function openAddDialog() {
  isEdit.value = false
  formData.position = activePosition.value
  dialogVisible.value = true
}

// 重置表单
function resetForm() {
  if (formRef.value) {
    formRef.value.resetFields()
  }
  formData.id = null
  formData.name = ''
  formData.icon = ''
  formData.url = ''
  formData.is_enable = 1
  formData.target = '_self'
  formData.sort = 0
}

// 打开编辑对话框
function handleEdit(row) {
  isEdit.value = true
  currentItem.value = row
  formData.id = row.id
  formData.position = row.position
  formData.name = row.name
  formData.icon = row.icon || ''
  formData.url = row.url
  formData.is_enable = row.is_enable
  formData.target = row.target
  formData.sort = row.sort
  dialogVisible.value = true
}

// 查看
function handleView(row) {
  currentItem.value = row
  viewDialogVisible.value = true
}

// 提交表单
async function submitForm() {
  if (!formRef.value) return
  
  await formRef.value.validate(async (valid) => {
    if (!valid) return
    
    submitting.value = true
    try {
      const url = isEdit.value
        ? `/admin/api/navigations/${formData.id}`
        : '/admin/api/navigations'
      const method = isEdit.value ? 'PUT' : 'POST'
      
      const response = await fetch(url, {
        method: method,
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-TOKEN': getCsrfToken(),
          'Accept': 'application/json',
        },
        body: JSON.stringify(formData),
      })
      
      const result = await response.json()
      
      if (result.success) {
        ElMessage.success(result.message)
        dialogVisible.value = false
        loadData()
      } else {
        ElMessage.error(result.message || '操作失败')
      }
    } catch (error) {
      ElMessage.error('操作失败')
    } finally {
      submitting.value = false
    }
  })
}

// 删除
function handleDelete(row) {
  ElMessageBox.confirm('确定要删除这个导航项吗？', '提示', {
    type: 'warning',
  }).then(async () => {
    try {
      const response = await fetch(`/admin/api/navigations/${row.id}`, {
        method: 'DELETE',
        headers: {
          'X-CSRF-TOKEN': getCsrfToken(),
          'Accept': 'application/json',
        },
      })
      
      const result = await response.json()
      if (result.success) {
        ElMessage.success('删除成功')
        loadData()
      }
    } catch (error) {
      ElMessage.error('删除失败')
    }
  }).catch(() => {})
}

// 批量删除
function handleBatchDelete() {
  if (selectedIds.value.length === 0) return
  
  ElMessageBox.confirm(`确定要删除选中的 ${selectedIds.value.length} 个导航项吗？`, '提示', {
    type: 'warning',
  }).then(async () => {
    try {
      const response = await fetch('/admin/api/navigations/batch-destroy', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-TOKEN': getCsrfToken(),
          'Accept': 'application/json',
        },
        body: JSON.stringify({ ids: selectedIds.value }),
      })
      
      const result = await response.json()
      if (result.success) {
        ElMessage.success(result.message)
        selectedIds.value = []
        selectAll.value = false
        loadData()
      }
    } catch (error) {
      ElMessage.error('批量删除失败')
    }
  }).catch(() => {})
}

// 全选
function handleSelectAllChange(checked) {
  if (!tableData.value || tableData.value.length === 0) {
    selectAll.value = false
    isIndeterminate.value = false
    return
  }
  
  if (checked) {
    selectedIds.value = tableData.value.map(item => item.id)
    isIndeterminate.value = false
    selectAll.value = true
  } else {
    selectedIds.value = []
    isIndeterminate.value = false
    selectAll.value = false
  }
}

// 上移
async function handleMoveUp(row) {
  try {
    const response = await fetch(`/admin/api/navigations/${row.id}/move-up`, {
      method: 'POST',
      headers: {
        'X-CSRF-TOKEN': getCsrfToken(),
        'Accept': 'application/json',
      },
    })
    
    const result = await response.json()
    if (result.success) {
      ElMessage.success(result.message)
      loadData()
    } else {
      ElMessage.info(result.message)
    }
  } catch (error) {
    ElMessage.error('操作失败')
  }
}

// 下移
async function handleMoveDown(row) {
  try {
    const response = await fetch(`/admin/api/navigations/${row.id}/move-down`, {
      method: 'POST',
      headers: {
        'X-CSRF-TOKEN': getCsrfToken(),
        'Accept': 'application/json',
      },
    })
    
    const result = await response.json()
    if (result.success) {
      ElMessage.success(result.message)
      loadData()
    } else {
      ElMessage.info(result.message)
    }
  } catch (error) {
    ElMessage.error('操作失败')
  }
}

// 切换启用状态
async function handleToggleEnable(row) {
  try {
    const response = await fetch(`/admin/api/navigations/${row.id}/toggle`, {
      method: 'POST',
      headers: {
        'X-CSRF-TOKEN': getCsrfToken(),
        'Accept': 'application/json',
      },
    })
    
    const result = await response.json()
    if (result.success) {
      ElMessage.success(result.message)
      // 行内更新状态，不重新加载
    } else {
      row.is_enable = row.is_enable ? 0 : 1
      ElMessage.error('状态更新失败')
    }
  } catch (error) {
    row.is_enable = row.is_enable ? 0 : 1
    ElMessage.error('状态更新失败')
  }
}

// 判断是否是第一行
function isFirstRow(row) {
  const index = tableData.value.findIndex(item => item.id === row.id)
  return index === 0
}

// 判断是否是最后一行
function isLastRow(row) {
  if (!tableData.value) return true
  const index = tableData.value.findIndex(item => item.id === row.id)
  return index === tableData.value.length - 1
}

// 初始化
onMounted(() => {
  loadData()
})

// 监听表格数据变化，重置全选状态
watch(() => tableData.value, () => {
  selectedIds.value = []
  selectAll.value = false
  isIndeterminate.value = false
}, { deep: true })
</script>

<style scoped>
.navigation-manager {
  padding: 20px;
  background: #fff;
  border-radius: 8px;
}

.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.page-title {
  font-size: 20px;
  font-weight: 600;
  color: #303133;
  margin: 0;
}

.toolbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
  padding: 12px 0;
}

.toolbar-left {
  display: flex;
  align-items: center;
  gap: 12px;
}

.toolbar-right {
  display: flex;
  align-items: center;
}

.form-tip {
  font-size: 12px;
  color: #909399;
  margin-top: 4px;
}

:deep(.el-tabs__header) {
  margin-bottom: 16px;
}

:deep(.el-table) {
  font-size: 14px;
}

:deep(.el-button-group .el-button) {
  padding: 5px 8px;
}

:deep(.el-descriptions__label) {
  font-weight: 500;
  width: 100px;
}
</style>

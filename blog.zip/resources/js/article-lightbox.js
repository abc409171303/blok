import PhotoSwipe from 'photoswipe';
import 'photoswipe/style.css';

/**
 * 手机端文章正文图片全屏预览
 * - 点击正文图片打开全屏灯箱
 * - PhotoSwipe 内置：双指/双击缩放、拖动平移、左右滑动切换文章内多张图片
 * - 仅在手机视口（<= 768px）生效，桌面端点击不拦截、保持原行为
 */
const content = document.querySelector('.article-content');
const mobileQuery = window.matchMedia('(max-width: 768px)');

if (content) {
    content.addEventListener('click', (evt) => {
        // 仅手机端启用，桌面端不拦截、保持原行为
        if (!mobileQuery.matches) {
            return;
        }

        const img = evt.target.closest('img');
        if (!img || !content.contains(img)) {
            return;
        }

        // 图片被 <a> 包裹时阻止桌面式跳转（移动端改为预览）
        const link = img.closest('a');
        if (link) {
            evt.preventDefault();
        }

        const images = Array.from(content.querySelectorAll('img'));
        const startIndex = images.indexOf(img);
        if (startIndex === -1) {
            return;
        }

        openViewer(images, startIndex);
    });
}

async function openViewer(images, startIndex) {
    const resolved = await Promise.all(images.map((img) => resolveItem(img)));

    const dataSource = [];
    const indexMap = [];
    resolved.forEach((item, i) => {
        if (item) {
            dataSource.push(item);
            indexMap.push(i);
        }
    });

    const index = indexMap.indexOf(startIndex);
    if (index < 0 || dataSource.length === 0) {
        return;
    }

    const pswp = new PhotoSwipe({
        dataSource,
        index,
        // 桌面断点之外的移动端可接受窗口变化
        showHideAnimationType: 'zoom',
        bgOpacity: 1,
    });

    pswp.init();
}

function resolveItem(img) {
    const src = img.currentSrc || img.getAttribute('src') || '';
    if (!src) {
        return Promise.resolve(null);
    }

    if (img.naturalWidth > 0) {
        return Promise.resolve({
            src,
            width: img.naturalWidth,
            height: img.naturalHeight,
            alt: img.getAttribute('alt') || '',
        });
    }

    // 懒加载图片尚未解码，预取一次以拿到真实尺寸
    return new Promise((resolve) => {
        const probe = new Image();
        probe.onload = () => {
            resolve({
                src: probe.currentSrc || src,
                width: probe.naturalWidth,
                height: probe.naturalHeight,
                alt: img.getAttribute('alt') || '',
            });
        };
        probe.onerror = () => resolve(null);
        probe.src = src;
    });
}

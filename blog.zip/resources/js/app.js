import { createApp } from 'vue'
import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'
import * as ElementPlusIconsVue from '@element-plus/icons-vue'
import NavigationManager from './views/admin/NavigationManager.vue'

// 创建 Vue 应用
const app = createApp({})

// 使用 Element Plus
app.use(ElementPlus)

// 注册所有 Element Plus 图标
for (const [key, component] of Object.entries(ElementPlusIconsVue)) {
  app.component(key, component)
}

// 挂载导航管理组件
const container = document.getElementById('app-navigation-manager')
if (container) {
  app.mount('#app-navigation-manager')
  console.log('Navigation Manager mounted successfully')
}

export { app }

@extends('install.layout')

@section('title', '步骤一：环境检查')

@section('content')
    <h2 class="text-lg font-semibold text-gray-900 mb-1">环境检查</h2>
    <p class="text-sm text-gray-500 mb-6">检查服务器环境是否满足博客系统的运行要求</p>

    <div class="mb-6">
        <h3 class="text-sm font-semibold text-gray-700 mb-3 flex items-center">
            <i class="fa-solid fa-server text-blue-500 mr-2"></i>系统要求
        </h3>
        <div class="space-y-2">
            @foreach($requirements ?? [] as $name => $passed)
                <div class="flex items-center justify-between px-4 py-3 rounded-lg {{ $passed ? 'bg-green-50' : 'bg-red-50' }} border {{ $passed ? 'border-green-200' : 'border-red-200' }}">
                    <span class="text-sm {{ $passed ? 'text-gray-700' : 'text-red-700' }}">{{ $name }}</span>
                    @if($passed)
                        <span class="w-6 h-6 rounded-full bg-green-100 flex items-center justify-center">
                            <i class="fa-solid fa-check text-green-600 text-xs"></i>
                        </span>
                    @else
                        <span class="w-6 h-6 rounded-full bg-red-100 flex items-center justify-center">
                            <i class="fa-solid fa-xmark text-red-600 text-xs"></i>
                        </span>
                    @endif
                </div>
            @endforeach
        </div>
    </div>

    <div class="mb-8">
        <h3 class="text-sm font-semibold text-gray-700 mb-3 flex items-center">
            <i class="fa-solid fa-folder-open text-blue-500 mr-2"></i>目录权限
        </h3>
        <div class="space-y-2">
            @foreach($writable ?? [] as $path => $passed)
                <div class="flex items-center justify-between px-4 py-3 rounded-lg {{ $passed ? 'bg-green-50' : 'bg-red-50' }} border {{ $passed ? 'border-green-200' : 'border-red-200' }}">
                    <span class="text-sm {{ $passed ? 'text-gray-700' : 'text-red-700' }}">{{ $path }}</span>
                    @if($passed)
                        <span class="text-xs {{ $passed ? 'text-green-600' : 'text-red-600' }} font-medium">
                            <i class="fa-solid fa-check mr-1"></i>可写
                        </span>
                    @else
                        <span class="text-xs text-red-600 font-medium">
                            <i class="fa-solid fa-xmark mr-1"></i>不可写
                        </span>
                    @endif
                </div>
            @endforeach
        </div>

        @if(in_array(false, $writable ?? [], true))
            <div class="mt-3 px-4 py-3 rounded-lg bg-amber-50 border border-amber-200 text-xs text-amber-800 leading-relaxed">
                <p class="font-semibold mb-1">如何修复目录权限</p>
                <p>Windows / IIS：右键站点目录 → 属性 → 安全 → 编辑，为 <code class="px-1 bg-amber-100 rounded">IIS_IUSRS</code> 和 <code class="px-1 bg-amber-100 rounded">IUSR</code> 勾选「修改」「写入」，确定后重启站点。</p>
                <p class="mt-1">Linux / 宝塔：执行 <code class="px-1 bg-amber-100 rounded">chmod -R 775 storage bootstrap/cache database</code>，并将所有者改为运行 PHP 的账户。</p>
                <p class="mt-1">站点根目录：<code class="px-1 bg-amber-100 rounded">{{ base_path() }}</code></p>
            </div>
        @endif
    </div>

    @php
        $allPassed = true;
        foreach (($requirements ?? []) as $passed) { if (!$passed) { $allPassed = false; break; } }
        if ($allPassed) {
            foreach (($writable ?? []) as $passed) { if (!$passed) { $allPassed = false; break; } }
        }
        $dbDriverRequirement = $requirements['数据库驱动（SQLite / MySQL 至少一种）'] ?? false;
        $dbDriverLabel = $requirements['数据库驱动（SQLite / MySQL 至少一种）'] ?? false;
    @endphp

    <div class="flex items-center justify-between pt-4 border-t border-gray-100">
        @if($allPassed)
            <div class="flex items-center text-green-600 text-sm">
                <i class="fa-solid fa-circle-check mr-2"></i>所有检查项已通过
            </div>
        @else
            <div class="flex items-center text-red-600 text-sm">
                <i class="fa-solid fa-circle-exclamation mr-2"></i>部分检查项未通过，请修复后再继续
            </div>
        @endif
        <a href="{{ $allPassed ? route('install.step2') : '#' }}"
           class="inline-flex items-center px-6 py-2.5 rounded-lg text-sm font-medium text-white transition-colors {{ $allPassed ? 'bg-blue-600 hover:bg-blue-700' : 'bg-gray-300 cursor-not-allowed' }}"
           @if(!$allPassed) onclick="return false;" @endif>
            下一步 <i class="fa-solid fa-arrow-right ml-2"></i>
        </a>
    </div>
@endsection

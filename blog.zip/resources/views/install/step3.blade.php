@extends('install.layout')

@section('title', '步骤三：导入数据表结构')

@section('content')
    <h2 class="text-lg font-semibold text-gray-900 mb-1">导入数据表结构</h2>
    <p class="text-sm text-gray-500 mb-6">系统将自动导入文章、用户、评论等数据表结构</p>

    <div class="bg-blue-50 border border-blue-200 rounded-xl p-4 text-sm text-blue-700 mb-6">
        <div class="flex items-start">
            <i class="fa-solid fa-circle-info text-blue-500 mr-2 mt-0.5"></i>
            <div>
                <p class="font-medium mb-1">数据库配置预览</p>
                <p class="text-blue-600 text-xs">
                    类型：{{ $config['db_label'] ?? $config['db_connection'] ?? '-' }}
                    @if(($config['db_connection'] ?? '') === 'sqlite')
                        / 文件：{{ $config['db_database'] ?? 'database/database.sqlite' }}
                    @else
                        / 主机：{{ $config['db_host'] ?? '-' }}:{{ $config['db_port'] ?? '-' }} / 数据库：{{ $config['db_database'] ?? '-' }}
                    @endif
                    / 前缀：{{ ($config['db_prefix'] ?? '') !== '' ? $config['db_prefix'] : '无' }}
                </p>
            </div>
        </div>
    </div>

    <div class="mb-8">
        <h3 class="text-sm font-semibold text-gray-700 mb-3 flex items-center">
            <i class="fa-solid fa-database text-blue-500 mr-2"></i>将执行的操作
        </h3>
        <ul class="space-y-2 text-sm text-gray-600">
            <li class="flex items-center"><i class="fa-solid fa-check text-green-500 mr-2"></i>创建文章、分类、标签数据表</li>
            <li class="flex items-center"><i class="fa-solid fa-check text-green-500 mr-2"></i>创建用户、评论、留言数据表</li>
            <li class="flex items-center"><i class="fa-solid fa-check text-green-500 mr-2"></i>创建站点配置、访问统计等辅助数据表</li>
        </ul>
    </div>

    <form action="{{ route('install.step3.run') }}" method="POST">
        @csrf
        <div class="flex items-center justify-between pt-4 border-t border-gray-100">
            <a href="{{ route('install.step2') }}" class="inline-flex items-center px-4 py-2.5 text-sm font-medium text-gray-700 hover:text-gray-900 transition-colors">
                <i class="fa-solid fa-arrow-left mr-2"></i>上一步
            </a>
            <button type="submit" class="inline-flex items-center px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium rounded-lg transition-colors">
                <i class="fa-solid fa-play mr-2"></i>开始导入
            </button>
        </div>
    </form>
@endsection

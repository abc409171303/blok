@extends('install.layout')

@section('title', '步骤二：数据库配置')

@section('content')
    <h2 class="text-lg font-semibold text-gray-900 mb-1">数据库配置</h2>
    <p class="text-sm text-gray-500 mb-6">请填写数据库连接信息</p>

    <form action="{{ route('install.step2.save') }}" method="POST" id="db-form">
        @csrf

        <div class="mb-4">
            <label for="db_connection" class="block text-sm font-medium text-gray-700 mb-2">数据库类型</label>
            <select name="db_connection" id="db_connection" class="w-full px-4 py-2.5 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white">
                <option value="mysql" {{ old('db_connection', $config['db_connection'] ?? '') === 'mysql' ? 'selected' : '' }}>MySQL</option>
                <option value="mssql" {{ old('db_connection', $config['db_connection'] ?? '') === 'mssql' ? 'selected' : '' }}>MSSQL / SQL Server</option>
                <option value="sqlite" {{ old('db_connection', $config['db_connection'] ?? '') === 'sqlite' ? 'selected' : '' }}>SQLite</option>
            </select>
        </div>

        <div id="server-fields">
            <div class="mb-4">
                <label for="db_host" class="block text-sm font-medium text-gray-700 mb-2">主机地址</label>
                <input type="text" name="db_host" id="db_host" value="{{ old('db_host', $config['db_host'] ?? '127.0.0.1') }}" placeholder="127.0.0.1" class="w-full px-4 py-2.5 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
            </div>

            <div class="mb-4">
                <label for="db_port" class="block text-sm font-medium text-gray-700 mb-2">端口号</label>
                <input type="text" name="db_port" id="db_port" value="{{ old('db_port', $config['db_port'] ?? '3306') }}" placeholder="3306" class="w-full px-4 py-2.5 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
            </div>

            <div class="mb-4">
                <label for="db_database" class="block text-sm font-medium text-gray-700 mb-2">数据库名</label>
                <input type="text" name="db_database" id="db_database" value="{{ old('db_database', ($config['db_connection'] ?? '') === 'sqlite' ? '' : ($config['db_database'] ?? '')) }}" placeholder="blog" class="w-full px-4 py-2.5 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
            </div>

            <div class="mb-4">
                <label for="db_username" class="block text-sm font-medium text-gray-700 mb-2">用户名</label>
                <input type="text" name="db_username" id="db_username" value="{{ old('db_username', $config['db_username'] ?? 'root') }}" placeholder="root" class="w-full px-4 py-2.5 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
            </div>

            <div class="mb-6">
                <label for="db_password" class="block text-sm font-medium text-gray-700 mb-2">密码</label>
                <input type="password" name="db_password" id="db_password" value="{{ old('db_password', $config['db_password'] ?? '') }}" placeholder="请输入数据库密码" class="w-full px-4 py-2.5 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
            </div>
        </div>

        <div id="sqlite-fields" class="hidden">
            <div class="mb-6">
                <label for="db_database_sqlite" class="block text-sm font-medium text-gray-700 mb-2">数据库文件路径</label>
                <input type="text" name="db_database" id="db_database_sqlite" value="{{ old('db_database', ($config['db_connection'] ?? '') === 'sqlite' ? ($config['db_database'] ?? '') : '') }}" placeholder="database/database.sqlite" class="w-full px-4 py-2.5 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                <p class="mt-1.5 text-xs text-gray-400">留空则自动使用 database/database.sqlite；可为相对项目根目录的路径或绝对路径，文件不存在会自动创建。</p>
            </div>
        </div>

        <div class="mb-6">
            <label for="db_prefix" class="block text-sm font-medium text-gray-700 mb-2">数据表前缀（可选）</label>
            <input type="text" name="db_prefix" id="db_prefix" value="{{ old('db_prefix', $config['db_prefix'] ?? '') }}" placeholder="留空表示不使用前缀" class="w-full px-4 py-2.5 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
            <p class="mt-1.5 text-xs text-gray-400">只能包含字母、数字和下划线，例如 blog_。</p>
            @error('db_prefix')
                <p class="mt-1 text-xs text-red-500">{{ $message }}</p>
            @enderror
        </div>

        <div class="flex items-center justify-between pt-4 border-t border-gray-100">
            <a href="{{ route('install.step1') }}" class="inline-flex items-center px-4 py-2.5 text-sm font-medium text-gray-700 hover:text-gray-900 transition-colors">
                <i class="fa-solid fa-arrow-left mr-2"></i>上一步
            </a>
            <button type="submit" class="inline-flex items-center px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium rounded-lg transition-colors">
                下一步 <i class="fa-solid fa-arrow-right ml-2"></i>
            </button>
        </div>
    </form>
@endsection

@push('scripts')
<script>
    (function () {
        var select = document.getElementById('db_connection');
        var serverFields = document.getElementById('server-fields');
        var sqliteFields = document.getElementById('sqlite-fields');
        var portInput = document.getElementById('db_port');

        function toggle(initial) {
            var type = select.value;
            var isSqlite = type === 'sqlite';

            serverFields.classList.toggle('hidden', isSqlite);
            sqliteFields.classList.toggle('hidden', !isSqlite);

            serverFields.querySelectorAll('input, select, textarea').forEach(function (el) {
                el.disabled = isSqlite;
            });
            sqliteFields.querySelectorAll('input, select, textarea').forEach(function (el) {
                el.disabled = !isSqlite;
            });

            if (!isSqlite && !initial) {
                if (type === 'mssql') {
                    if (portInput.value === '3306' || portInput.value === '') {
                        portInput.value = '1433';
                    }
                    portInput.placeholder = '1433';
                } else {
                    if (portInput.value === '1433' || portInput.value === '') {
                        portInput.value = '3306';
                    }
                    portInput.placeholder = '3306';
                }
            }
        }

        select.addEventListener('change', function () {
            toggle(false);
        });

        toggle(true);
    })();
</script>
@endpush

@extends('layouts.admin')

@section('page-title', '动态验证码')

@section('content')
<div class="max-w-2xl">
    <div class="flex items-center justify-between mb-6">
        <h1 class="text-2xl font-bold text-gray-800">动态验证码</h1>
    </div>

    @if(session('success'))
    <div class="mb-6 px-4 py-3 bg-green-50 border border-green-200 text-green-700 text-sm rounded-lg">
        {{ session('success') }}
    </div>
    @endif

    <form action="{{ route('admin.captcha.update') }}" method="POST">
        @csrf

        <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <div class="px-6 py-4 border-b border-gray-200 flex items-center gap-2.5">
                <svg class="w-5 h-5 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 7v10c0 1.657 3.582 3 8 3s8-1.343 8-3V7M4 7c0 1.657 3.582 3 8 3s8-1.343 8-3M4 7c0-1.657 3.582-3 8-3s8 1.343 8 3"/></svg>
                <h2 class="text-lg font-semibold text-gray-800">验证码设置</h2>
            </div>

            <div class="px-6 py-5 space-y-1">
                <p class="text-xs text-gray-400 mb-4">开启后，对应场景提交时需输入图形验证码，防止恶意刷评论与垃圾留言。</p>

                {{-- 总开关 --}}
                <div class="flex items-center justify-between py-4 border-b border-gray-100">
                    <div>
                        <p class="text-sm font-medium text-gray-700">启用动态验证码</p>
                        <p class="text-xs text-gray-400 mt-0.5">关闭后以下所有场景均不需要验证码</p>
                    </div>
                    <label class="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" name="captcha_enabled" value="1"
                            class="sr-only peer" id="captchaMaster"
                            {{ old('captcha_enabled', $config->captcha_enabled ?? false) ? 'checked' : '' }}>
                        <div class="w-11 h-6 bg-gray-300 dark:bg-gray-600 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-blue-300 rounded-full peer peer-checked:bg-blue-600 after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border after:border-gray-300 after:rounded-full after:h-5 after:w-5 after:transition-all after:duration-200 peer-checked:after:translate-x-full peer-checked:after:border-white"></div>
                    </label>
                </div>

                <div id="sceneFields">
                    {{-- 评论 --}}
                    <div class="flex items-center justify-between py-4 border-b border-gray-100">
                        <div>
                            <p class="text-sm font-medium text-gray-700">文章评论</p>
                            <p class="text-xs text-gray-400 mt-0.5">访客发表评论时需输入验证码</p>
                        </div>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input type="checkbox" name="captcha_comment" value="1"
                                class="sr-only peer"
                                {{ old('captcha_comment', $config->captcha_comment ?? true) ? 'checked' : '' }}>
                            <div class="w-11 h-6 bg-gray-300 dark:bg-gray-600 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-blue-300 rounded-full peer peer-checked:bg-blue-600 after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border after:border-gray-300 after:rounded-full after:h-5 after:w-5 after:transition-all after:duration-200 peer-checked:after:translate-x-full peer-checked:after:border-white"></div>
                        </label>
                    </div>

                    {{-- 留言 --}}
                    <div class="flex items-center justify-between py-4 border-b border-gray-100">
                        <div>
                            <p class="text-sm font-medium text-gray-700">留言板留言</p>
                            <p class="text-xs text-gray-400 mt-0.5">访客在留言板提交留言时需输入验证码</p>
                        </div>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input type="checkbox" name="captcha_message" value="1"
                                class="sr-only peer"
                                {{ old('captcha_message', $config->captcha_message ?? true) ? 'checked' : '' }}>
                            <div class="w-11 h-6 bg-gray-300 dark:bg-gray-600 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-blue-300 rounded-full peer peer-checked:bg-blue-600 after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border after:border-gray-300 after:rounded-full after:h-5 after:w-5 after:transition-all after:duration-200 peer-checked:after:translate-x-full peer-checked:after:border-white"></div>
                        </label>
                    </div>

                    {{-- 后台登录 --}}
                    <div class="flex items-center justify-between py-4">
                        <div>
                            <p class="text-sm font-medium text-gray-700">后台登录</p>
                            <p class="text-xs text-gray-400 mt-0.5">管理员登录后台时需输入验证码</p>
                        </div>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input type="checkbox" name="captcha_admin_login" value="1"
                                class="sr-only peer"
                                {{ old('captcha_admin_login', $config->captcha_admin_login ?? true) ? 'checked' : '' }}>
                            <div class="w-11 h-6 bg-gray-300 dark:bg-gray-600 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-blue-300 rounded-full peer peer-checked:bg-blue-600 after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border after:border-gray-300 after:rounded-full after:h-5 after:w-5 after:transition-all after:duration-200 peer-checked:after:translate-x-full peer-checked:after:border-white"></div>
                        </label>
                    </div>
                </div>
            </div>
        </div>

        <div class="flex items-center gap-3 mt-6 pt-6 border-t border-gray-200">
            <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2.5 rounded-lg text-sm font-medium transition-colors">
                保存设置
            </button>
        </div>
    </form>
</div>

<script>
(function () {
    const master = document.getElementById('captchaMaster');
    const sceneFields = document.getElementById('sceneFields');

    function sync() {
        sceneFields.style.opacity = master.checked ? '1' : '0.4';
        sceneFields.style.pointerEvents = master.checked ? 'auto' : 'none';
    }

    if (master) {
        master.addEventListener('change', sync);
        sync();
    }
})();
</script>
@endsection

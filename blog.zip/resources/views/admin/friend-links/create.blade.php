@extends('layouts.admin')
@section('page-title', '新增友情链接')

@section('content')
<h2 class="text-xl font-bold text-gray-800 mb-6">新增友情链接</h2>

<div class="bg-white rounded-lg shadow-sm p-6 max-w-2xl">
    <form action="{{ route('admin.friend-links.store') }}" method="POST" enctype="multipart/form-data">
        @csrf

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-5">
            <div>
                <label for="site_name" class="block text-sm font-medium text-gray-700 mb-1.5">网站名称 <span class="text-red-500">*</span></label>
                <input type="text" name="site_name" id="site_name" value="{{ old('site_name') }}" required
                    class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                    placeholder="如：Laravel 中文网">
                @error('site_name')<p class="text-red-500 text-xs mt-1">{{ $message }}</p>@enderror
            </div>
            <div>
                <label for="site_url" class="block text-sm font-medium text-gray-700 mb-1.5">链接地址 <span class="text-red-500">*</span></label>
                <input type="text" name="site_url" id="site_url" value="{{ old('site_url') }}" required
                    class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                    placeholder="https://example.com">
                @error('site_url')<p class="text-red-500 text-xs mt-1">{{ $message }}</p>@enderror
            </div>
        </div>

        <div class="mb-5">
            <label class="block text-sm font-medium text-gray-700 mb-1.5">网站 Logo</label>
            <div class="mb-2">
                <button type="button" onclick="window.openMediaSelector('friend_link_logo')"
                    class="px-3 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs rounded-lg transition-colors">
                    从文件库选择
                </button>
                <input type="hidden" name="logo_path" id="logo_path" value="{{ old('logo_path', '') }}">
            </div>
            <div class="flex items-center gap-4">
                <div class="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center hover:border-blue-400 transition-colors cursor-pointer w-40" id="logo-dropzone">
                    <input type="file" name="logo" id="logo" accept="image/*" class="hidden" onchange="previewLogo(this)">
                    <div id="logo-placeholder" class="flex flex-col items-center gap-1.5">
                        <svg class="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                        <span class="text-xs text-gray-500">点击上传 Logo</span>
                    </div>
                    <img id="logo-preview-img" class="hidden max-h-16 mx-auto object-contain" src="" alt="">
                </div>
                <div class="text-xs text-gray-400">
                    <p>支持 JPG、PNG、SVG 等格式</p>
                    <p>建议使用透明背景图片</p>
                </div>
            </div>
            @error('logo')<p class="text-red-500 text-xs mt-1">{{ $message }}</p>@enderror
        </div>

        <div class="mb-5">
            <label for="description" class="block text-sm font-medium text-gray-700 mb-1.5">描述</label>
            <input type="text" name="description" id="description" value="{{ old('description') }}"
                class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                placeholder="一句话描述该网站">
            @error('description')<p class="text-red-500 text-xs mt-1">{{ $message }}</p>@enderror
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-5">
            <div>
                <label for="sort_order" class="block text-sm font-medium text-gray-700 mb-1.5">排序</label>
                <input type="number" name="sort_order" id="sort_order" value="{{ old('sort_order', 0) }}" min="0"
                    class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none">
                <p class="text-xs text-gray-400 mt-1">数字越小越靠前</p>
            </div>
            <div class="flex items-center pt-6">
                <label class="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" name="status" value="1" {{ old('status', true) ? 'checked' : '' }}
                        class="rounded border-gray-300 text-blue-600 focus:ring-blue-500">
                    <span class="text-sm text-gray-700">显示</span>
                </label>
            </div>
        </div>

        <div class="flex items-center gap-3">
            <button type="submit" class="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded-lg transition-colors">保存</button>
            <a href="{{ route('admin.friend-links.index') }}" class="px-5 py-2 border border-gray-300 text-gray-600 text-sm rounded-lg hover:bg-gray-50 transition-colors">取消</a>
        </div>
    </form>
</div>

<x-media-selector editor-id="friend-link"/>

<script>
// 从文件库选择后填充 Logo
window.addEventListener('media-selected', function(event) {
    const field = event.detail.field;
    const file = event.detail.file;
    if (!file) return;

    if (field === 'friend_link_logo') {
        document.getElementById('logo_path').value = file.file_path || '';
        const previewImg = document.getElementById('logo-preview-img');
        if (previewImg) {
            previewImg.src = file.url;
            previewImg.classList.remove('hidden');
            document.getElementById('logo-placeholder').classList.add('hidden');
        }
    }
});

// 本地上传预览
function previewLogo(input) {
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            const previewImg = document.getElementById('logo-preview-img');
            if (previewImg) {
                previewImg.src = e.target.result;
                previewImg.classList.remove('hidden');
                document.getElementById('logo-placeholder').classList.add('hidden');
            }
            document.getElementById('logo_path').value = '';
        };
        reader.readAsDataURL(input.files[0]);
    }
}
</script>
@endsection

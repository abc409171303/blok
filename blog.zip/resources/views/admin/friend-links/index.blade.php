@extends('layouts.admin')
@section('page-title', '友情链接')

@section('content')
<div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-6">
    <h2 class="text-xl font-bold text-gray-800">友情链接</h2>
    <a href="{{ route('admin.friend-links.create') }}" class="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded-lg transition-colors">
        <i class="fa-solid fa-plus mr-2"></i>新增链接
    </a>
</div>

@if(session('success'))
<div class="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg mb-4 text-sm">{{ session('success') }}</div>
@endif

<div class="bg-white rounded-lg shadow-sm overflow-hidden">
    <div class="overflow-x-auto">
        <table class="w-full text-sm min-w-[640px]">
            <thead class="bg-gray-50 border-b">
                <tr>
                    <th class="px-4 py-3 text-left font-medium text-gray-500">网站名称</th>
                    <th class="px-4 py-3 text-left font-medium text-gray-500 hidden sm:table-cell">链接地址</th>
                    <th class="px-4 py-3 text-left font-medium text-gray-500 hidden md:table-cell">描述</th>
                    <th class="px-4 py-3 text-left font-medium text-gray-500 hidden sm:table-cell">状态</th>
                    <th class="px-4 py-3 text-right font-medium text-gray-500">操作</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                @forelse($friendLinks as $link)
                <tr class="hover:bg-gray-50">
                    <td class="px-4 py-3">
                        <div class="flex items-center gap-3">
                            @if($link->logo)
                            <img src="{{ Storage::url($link->logo) }}" class="w-8 h-8 object-contain rounded" alt="">
                            @else
                            <span class="w-8 h-8 flex items-center justify-center bg-gray-100 text-gray-400 text-xs rounded">友</span>
                            @endif
                            <div class="font-medium text-gray-800">{{ $link->site_name }}</div>
                        </div>
                    </td>
                    <td class="px-4 py-3 text-gray-500 hidden sm:table-cell max-w-[200px] truncate">
                        <a href="{{ $link->site_url }}" target="_blank" rel="noopener" class="text-blue-600 hover:underline">{{ $link->site_url }}</a>
                    </td>
                    <td class="px-4 py-3 text-gray-500 hidden md:table-cell max-w-[200px] truncate">{{ $link->description ?: '-' }}</td>
                    <td class="px-4 py-3 hidden sm:table-cell">
                        <span class="inline-block px-2 py-0.5 text-xs rounded-full {{ $link->status ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-500' }}">
                            {{ $link->status ? '显示' : '隐藏' }}
                        </span>
                    </td>
                    <td class="px-4 py-3 text-right whitespace-nowrap">
                        <a href="{{ route('admin.friend-links.edit', $link) }}" class="text-blue-600 hover:text-blue-800 mr-3">编辑</a>
                        <form action="{{ route('admin.friend-links.destroy', $link) }}" method="POST" class="inline" onsubmit="return confirm('确定要删除该友情链接吗？')">
                            @csrf @method('DELETE')
                            <button type="submit" class="text-red-500 hover:text-red-700">删除</button>
                        </form>
                    </td>
                </tr>
                @empty
                <tr><td colspan="5" class="px-4 py-12 text-center text-gray-400">暂无友情链接</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
<div class="mt-4">{{ $friendLinks->links() }}</div>
@endsection

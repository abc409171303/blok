<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>登录 - {{ \App\Models\SiteConfig::getInstance()->site_name ?? 'Blog' }}</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
    <style>
        .login-bg {
            position: fixed;
            inset: 0;
            background-size: cover;
            background-position: center;
            filter: blur(8px) brightness(0.85);
            transform: scale(1.1);
            z-index: 0;
        }
        .login-content {
            position: relative;
            z-index: 1;
        }
    </style>
</head>
<body class="bg-white min-h-screen flex items-center justify-center px-4">
    @if(\App\Models\SiteConfig::getInstance()->admin_login_bg)
    @php
        $opacity = \App\Models\SiteConfig::getInstance()->admin_login_bg_opacity ?? 85;
    @endphp
    <div class="login-bg" style="background-image: url('{{ Storage::url(\App\Models\SiteConfig::getInstance()->admin_login_bg) }}'); opacity: {{ $opacity / 100 }};"></div>
    @endif
    <div class="login-content w-full" style="max-width: 24rem;">
        <div class="text-center mb-8">
            <h1 class="text-3xl font-bold text-gray-800">{{ \App\Models\SiteConfig::getInstance()->site_name ?? 'Blog' }}</h1>
            <p class="text-gray-500 mt-2">管理后台登录</p>
        </div>

        <div class="bg-white rounded-xl shadow-lg p-8 border border-gray-100">
            @if($errors->any())
            <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6">
                <ul class="list-disc list-inside text-sm">
                    @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
            @endif

            @if(session('error'))
            <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6 text-sm">
                {{ session('error') }}
            </div>
            @endif

            @if(session('success'))
            <div class="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg mb-6 text-sm">
                {{ session('success') }}
            </div>
            @endif

            <form action="{{ route('admin.login') }}" method="POST">
                @csrf

                <div class="mb-5">
                    <label for="account" class="block text-sm font-medium text-gray-700 mb-1.5">账号</label>
                    <input type="text" name="account" id="account" value="{{ old('account') }}" required autofocus
                        class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-colors"
                        placeholder="请输入账号">
                </div>

                <div class="mb-5">
                    <label for="password" class="block text-sm font-medium text-gray-700 mb-1.5">密码</label>
                    <input type="password" name="password" id="password" required
                        class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-colors"
                        placeholder="请输入密码">
                </div>

                @if(\App\Services\Captcha::enabled('admin_login'))
                <div class="mb-5">
                    <label for="captcha" class="block text-sm font-medium text-gray-700 mb-1.5">验证码</label>
                    <div class="flex items-center gap-3">
                        <input type="text" name="captcha" id="captcha" value="{{ old('captcha') }}" placeholder="请输入验证码"
                            maxlength="6" autocomplete="off" required style="min-width:0;"
                            class="flex-1 px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-colors">
                        <img src="{{ route('captcha.image', ['scene' => 'admin_login']) }}?v={{ time() }}"
                            alt="验证码" title="点击刷新验证码" style="cursor:pointer;width:130px;height:40px;flex-shrink:0;border-radius:6px;"
                            onclick="this.src='{{ route('captcha.image', ['scene' => 'admin_login']) }}?v='+Date.now();">
                    </div>
                    @error('captcha')<p class="text-sm text-red-500 mt-1.5">{{ $message }}</p>@enderror
                </div>
                @endif

                <div class="flex items-center justify-between mb-6">
                    <label class="flex items-center gap-2 text-sm text-gray-600 cursor-pointer">
                        <input type="checkbox" name="remember" class="rounded border-gray-300 text-blue-600 focus:ring-blue-500">
                        记住我
                    </label>
                </div>

                <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-2.5 rounded-lg text-sm transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2">
                    登录
                </button>
            </form>
        </div>
    </div>
</body>
</html>

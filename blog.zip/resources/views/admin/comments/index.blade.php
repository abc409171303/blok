@extends('layouts.admin')

@section('page-title', '评论管理')

@section('content')
<div x-data="{ showModal: false, c: null, openModal(c) { this.c = c; this.showModal = true; } }">
<div>
    <div class="flex items-center justify-between mb-6">
        <h1 class="text-2xl font-bold text-gray-800">评论</h1>
    </div>

    <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div class="px-4 py-3 border-b border-gray-200 flex flex-col sm:flex-row sm:items-center gap-3">
            <form method="GET" class="flex flex-wrap items-center gap-2 flex-1">
                <input type="text" name="id" value="{{ request('id') }}" placeholder="评论ID"
                    class="px-3 py-1.5 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none dark:bg-gray-800 dark:border-gray-600 dark:text-gray-200 w-24">
                <input type="text" name="author" value="{{ request('author') }}" placeholder="作者名称"
                    class="px-3 py-1.5 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none dark:bg-gray-800 dark:border-gray-600 dark:text-gray-200">
                <select name="status" class="px-3 py-1.5 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none dark:bg-gray-800 dark:border-gray-600 dark:text-gray-200">
                    <option value="">全部状态</option>
                    <option value="approved" {{ request('status') === 'approved' ? 'selected' : '' }}>已通过</option>
                    <option value="pending" {{ request('status') === 'pending' ? 'selected' : '' }}>待审核</option>
                    <option value="rejected" {{ request('status') === 'rejected' ? 'selected' : '' }}>已拒绝</option>
                </select>
                <button type="submit" class="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded-lg transition-colors">查询</button>
                @if(request()->anyFilled(['id', 'author', 'status']))
                <a href="{{ route('admin.comments.index') }}" class="px-4 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-600 text-sm rounded-lg transition-colors">重置</a>
                @endif
            </form>
            <div class="flex items-center gap-2" id="batchBar" style="display:none;">
                <span class="text-sm text-gray-500">已选 <span id="selCount">0</span> 条</span>
                <button type="button" onclick="batchDelete()" class="px-4 py-1.5 bg-red-500 hover:bg-red-600 text-white text-sm rounded-lg transition-colors">批量删除</button>
                <button type="button" onclick="clearSelect()" class="px-3 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-600 text-sm rounded-lg transition-colors">取消</button>
            </div>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead>
                    <tr class="bg-gray-50 border-b border-gray-200">
                        <th class="text-left px-4 py-3 font-medium text-gray-600 w-12">
                            <input type="checkbox" class="master-check w-4 h-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500 cursor-pointer" onchange="toggleAll(this)">
                        </th>
                        <th class="text-left px-4 py-3 font-medium text-gray-600 w-12">ID</th>
                        <th class="text-left px-4 py-3 font-medium text-gray-600">作者</th>
                        <th class="text-left px-4 py-3 font-medium text-gray-600">邮箱</th>
                        <th class="text-left px-4 py-3 font-medium text-gray-600">文章</th>
                        <th class="text-left px-4 py-3 font-medium text-gray-600">内容</th>
                        <th class="text-left px-4 py-3 font-medium text-gray-600">状态</th>
                        <th class="text-left px-4 py-3 font-medium text-gray-600">日期</th>
                        <th class="text-left px-4 py-3 font-medium text-gray-600 w-40">操作</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    @forelse($comments as $comment)
                    <tr class="hover:bg-gray-50 transition-colors">
                        <td class="px-4 py-3 text-gray-500 w-12">
                            <input type="checkbox" class="row-check w-4 h-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500 cursor-pointer" value="{{ $comment->id }}" onchange="updateBatchBar()">
                        </td>
                        <td class="px-4 py-3 text-gray-500">{{ $comment->id }}</td>
                        <td class="px-4 py-3">
                            <span class="font-medium text-gray-800">{{ $comment->author }}</span>
                        </td>
                        <td class="px-4 py-3 text-gray-600">{{ $comment->email }}</td>
                        <td class="px-4 py-3">
                            @if($comment->post)
                            <a href="{{ route('admin.posts.edit', $comment->post) }}" class="text-blue-600 hover:text-blue-800">
                                {{ Str::limit($comment->post->title, 25) }}
                            </a>
                            @else
                            <span class="text-gray-400">已删除</span>
                            @endif
                        </td>
                        <td class="px-4 py-3">
                            <span class="text-gray-600" title="{{ $comment->content }}">{{ Str::limit($comment->content, 100) }}</span>
                        </td>
                        <td class="px-4 py-3">
                            @if($comment->status === 'approved')
                            <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-700">已通过</span>
                            @elseif($comment->status === 'pending')
                            <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-700">待审核</span>
                            @else
                            <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-700">已拒绝</span>
                            @endif
                        </td>
                        <td class="px-4 py-3 text-gray-500">{{ $comment->created_at->format('Y-m-d H:i') }}</td>
                        <td class="px-4 py-3">
                            <div class="flex items-center gap-2">
                                <button type="button" @click="openModal({ id: {{ $comment->id }}, author: @js($comment->author), email: @js($comment->email), content: @js($comment->content), status: '{{ $comment->status }}', created_at: @js($comment->created_at->format('Y-m-d H:i')), post_title: @js($comment->post?->title) })" class="text-blue-600 hover:text-blue-800 text-sm">查看</button>
                                @if($comment->status !== 'approved')
                                <form action="{{ route('admin.comments.approve', $comment) }}" method="POST" class="inline">
                                    @csrf
                                    <button type="submit" class="text-green-600 hover:text-green-800 text-sm">通过</button>
                                </form>
                                @endif
                                @if($comment->status !== 'rejected')
                                <form action="{{ route('admin.comments.reject', $comment) }}" method="POST" class="inline">
                                    @csrf
                                    <button type="submit" class="text-orange-600 hover:text-orange-800 text-sm">拒绝</button>
                                </form>
                                @endif
                                <form action="{{ route('admin.comments.destroy', $comment) }}" method="POST" onsubmit="return confirm('确定要删除这条评论吗？')" class="inline">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="text-red-600 hover:text-red-800 text-sm">删除</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="9" class="px-4 py-12 text-center text-gray-500">
                            <div class="flex flex-col items-center gap-2">
                                <svg class="w-12 h-12 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"/></svg>
                                <span>暂无评论</span>
                            </div>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if($comments->hasPages())
        <div class="px-4 py-3 border-t border-gray-200">
            {{ $comments->links() }}
        </div>
        @endif
    </div>
</div>

<form id="batchDeleteForm" action="{{ route('admin.comments.batchDestroy') }}" method="POST" style="display:none;">
    @csrf
    <input type="hidden" name="ids" id="batchIds">
</form>

{{-- 评论详情弹窗 --}}
<div x-show="showModal" x-cloak style="display: none;" class="fixed inset-0 z-50 overflow-y-auto" @keydown.escape.window="showModal = false">
    <div class="fixed inset-0 bg-gray-900/60" @click="showModal = false"></div>
    <div class="relative min-h-screen flex items-center justify-center p-4">
        <div class="relative w-full max-w-3xl bg-white dark:bg-gray-800 dark:text-gray-200 rounded-xl shadow-xl border border-gray-200 dark:border-gray-600 overflow-hidden">
            <div class="flex items-center justify-between px-6 py-5 border-b border-gray-100 dark:border-gray-700">
                <h3 class="text-xl font-semibold text-gray-800 dark:text-gray-100">评论详情</h3>
                <button type="button" @click="showModal = false" class="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
                </button>
            </div>
            <div class="px-6 py-5 space-y-5" style="max-height: calc(100vh - 220px); overflow-y: auto;">
                <template x-if="c">
                    <div class="space-y-5">
                        <div class="flex flex-wrap items-center gap-x-3 gap-y-1">
                            <span class="text-lg font-medium text-gray-800 dark:text-gray-100" x-text="c.author"></span>
                            <span class="text-sm text-gray-400" x-text="c.email"></span>
                            <span class="ml-auto text-sm text-gray-400" x-text="c.created_at"></span>
                        </div>
                        <div class="flex items-center gap-3 flex-wrap">
                            <span class="text-sm text-gray-500 dark:text-gray-400">文章：</span>
                            <span class="text-sm text-gray-800 dark:text-gray-200" x-text="c.post_title || '已删除'"></span>
                            <span class="text-sm text-gray-500 dark:text-gray-400 ml-4">ID：</span>
                            <span class="text-sm text-gray-800 dark:text-gray-200 font-mono" x-text="c.id"></span>
                            <span class="ml-auto" x-show="c.status === 'approved'"><span class="inline-flex px-2 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-700">已通过</span></span>
                            <span class="ml-auto" x-show="c.status === 'pending'"><span class="inline-flex px-2 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-700">待审核</span></span>
                            <span class="ml-auto" x-show="c.status === 'rejected'"><span class="inline-flex px-2 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-700">已拒绝</span></span>
                        </div>
                        <div class="bg-gray-50 dark:bg-gray-700/50 border border-gray-100 dark:border-gray-700 rounded-lg px-6 py-5 min-h-[160px] text-base text-gray-700 dark:text-gray-300 leading-loose whitespace-pre-wrap break-words" x-text="c.content"></div>
                    </div>
                </template>
            </div>
            <div class="flex items-center justify-end gap-2 px-6 py-4 border-t border-gray-100 dark:border-gray-700">
                <button type="button" @click="showModal = false" class="px-4 py-2 text-sm text-gray-600 dark:text-gray-300 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">关闭</button>
            </div>
        </div>
    </div>
</div>

<script>
function toggleAll(el) {
    document.querySelectorAll('.row-check').forEach(cb => cb.checked = el.checked);
    updateBatchBar();
}
function updateBatchBar() {
    const checked = document.querySelectorAll('.row-check:checked');
    const bar = document.getElementById('batchBar');
    document.getElementById('selCount').textContent = checked.length;
    bar.style.display = checked.length > 0 ? 'flex' : 'none';
    bar.style.gap = '8px';
}
function clearSelect() {
    document.querySelectorAll('.row-check').forEach(cb => cb.checked = false);
    document.querySelector('.master-check').checked = false;
    updateBatchBar();
}
function batchDelete() {
    const checked = document.querySelectorAll('.row-check:checked');
    if (!checked.length) return;
    if (!confirm('确定要删除选中的 ' + checked.length + ' 条评论吗？')) return;
    document.getElementById('batchIds').value = Array.from(checked).map(cb => cb.value).join(',');
    document.getElementById('batchDeleteForm').submit();
}
</script>
</div>
</div>
@endsection

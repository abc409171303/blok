@extends('layouts.admin')
@section('page-title', '导航管理')

@section('content')
<div id="app-navigation-manager"></div>
@endsection

@push('scripts')
@vite(['resources/js/app.js'])
@endpush

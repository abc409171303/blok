@extends('layouts.admin')

@section('page-title', '导航设置')

@section('content')
<div class="container mx-auto px-4 py-6" x-data="navManager()">
    {{-- 页面头部 --}}
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
        <div>
            <h1 class="text-xl font-bold text-gray-800">导航设置</h1>
            <p class="text-xs text-gray-500 mt-0.5">管理网站头部与底部导航菜单，保存后前台即时生效</p>
        </div>
        <button @click="openModal()"
                class="inline-flex items-center justify-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
            增加
        </button>
    </div>

    {{-- 位置 Tab --}}
    <div class="mb-4">
        <div class="flex border-b border-gray-200">
            <a href="{{ route('admin.navigations.index', ['position' => 'head']) }}"
               class="px-5 py-2.5 text-sm font-medium transition-colors {{ $position === 'head' ? 'border-b-2 border-blue-500 text-blue-600' : 'text-gray-500 hover:text-gray-700' }}">
                头部导航
            </a>
            <a href="{{ route('admin.navigations.index', ['position' => 'foot']) }}"
               class="px-5 py-2.5 text-sm font-medium transition-colors {{ $position === 'foot' ? 'border-b-2 border-blue-500 text-blue-600' : 'text-gray-500 hover:text-gray-700' }}">
                底部导航
            </a>
        </div>
    </div>

    {{-- 工具栏 --}}
    <div class="flex items-center justify-between mb-3">
        <div class="flex items-center gap-2">
            <label class="flex items-center gap-2 text-sm text-gray-600 cursor-pointer select-none">
                <input type="checkbox" class="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                       @change="toggleSelectAll($event.target.checked)"
                       :checked="selectedIds.length > 0 && selectedIds.length === items.length">
                <span>全选</span>
            </label>
            <button @click="batchDelete()"
                    :disabled="selectedIds.length === 0"
                    :class="selectedIds.length > 0 ? 'text-red-600 hover:bg-red-50' : 'text-gray-300 cursor-not-allowed'"
                    class="text-sm px-3 py-1.5 rounded-lg transition-colors">
                批量删除<span x-text="selectedIds.length > 0 ? ' (' + selectedIds.length + ')' : ''"></span>
            </button>
        </div>
        <button @click="refresh()" class="inline-flex items-center gap-1.5 text-sm text-gray-600 hover:text-blue-600 px-3 py-1.5 rounded-lg transition-colors">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg>
            刷新
        </button>
    </div>

    {{-- 桌面端表格 --}}
    <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden hidden md:block">
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead>
                    <tr class="bg-gray-50 border-b border-gray-200">
                        <th class="text-left px-4 py-3 font-medium text-gray-600 w-10">勾选</th>
                        <th class="text-left px-4 py-3 font-medium text-gray-600 w-14">ID</th>
                        <th class="text-left px-4 py-3 font-medium text-gray-600 w-16">位置</th>
                        <th class="text-left px-4 py-3 font-medium text-gray-600">名称</th>
                        <th class="text-left px-4 py-3 font-medium text-gray-600 w-20">图标</th>
                        <th class="text-left px-4 py-3 font-medium text-gray-600">链接</th>
                        <th class="text-left px-4 py-3 font-medium text-gray-600 w-20">启用</th>
                        <th class="text-left px-4 py-3 font-medium text-gray-600 w-24">打开方式</th>
                        <th class="text-left px-4 py-3 font-medium text-gray-600 w-16">排序</th>
                        <th class="text-left px-4 py-3 font-medium text-gray-600 w-44">操作</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    @forelse($navigations as $nav)
                    <tr draggable="true"
                        data-id="{{ $nav->id }}"
                        @dragstart="onDragStart($event, {{ $nav->id }})"
                        @dragover.prevent
                        @drop="onDrop($event, {{ $nav->id }})"
                        :class="draggingId === {{ $nav->id }} ? 'bg-blue-50 opacity-60' : ''"
                        class="hover:bg-gray-50 transition-colors cursor-grab">
                        <td class="px-4 py-3" @click.stop>
                            <input type="checkbox" value="{{ $nav->id }}"
                                   class="rounded border-gray-300 text-blue-600 focus:ring-blue-500 row-check"
                                   :checked="selectedIds.includes({{ $nav->id }})"
                                   @change="toggleSelect({{ $nav->id }}, $event.target.checked)">
                        </td>
                        <td class="px-4 py-3 text-gray-500">{{ $nav->id }}</td>
                        <td class="px-4 py-3">
                            <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs {{ $nav->position === 'head' ? 'bg-blue-50 text-blue-600' : 'bg-gray-100 text-gray-600' }}">
                                {{ $nav->position === 'head' ? '头部' : '底部' }}
                            </span>
                        </td>
                        <td class="px-4 py-3">
                            <div class="flex items-center gap-2">
                                @if($nav->icon)<i class="{{ $nav->icon }} text-gray-400 w-4"></i>@endif
                                <span class="font-medium text-gray-800">{{ $nav->name }}</span>
                            </div>
                        </td>
                        <td class="px-4 py-3 text-gray-500">
                            @if($nav->icon)<code class="text-xs text-gray-400">{{ $nav->icon }}</code>@else<span class="text-gray-300">-</span>@endif
                        </td>
                        <td class="px-4 py-3">
                            <a href="{{ $nav->url }}" target="_blank" rel="noopener" class="text-blue-600 hover:underline break-all">{{ $nav->url }}</a>
                        </td>
                        <td class="px-4 py-3">
                            <button type="button" @click="toggleEnable({{ $nav->id }})"
                                    :class="itemEnabled({{ $nav->id }}) ? 'bg-blue-500' : 'bg-gray-300'"
                                    class="relative inline-flex flex-shrink-0 h-6 w-11 border-2 border-transparent rounded-full cursor-pointer transition-colors ease-in-out duration-200"
                                    :title="itemEnabled({{ $nav->id }}) ? '点击禁用' : '点击启用'">
                                <span :class="itemEnabled({{ $nav->id }}) ? 'translate-x-5' : 'translate-x-0'"
                                      class="pointer-events-none inline-block h-5 w-5 rounded-full bg-white shadow transform ring-0 transition ease-in-out duration-200"></span>
                            </button>
                        </td>
                        <td class="px-4 py-3">
                            <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs {{ $nav->target === '_blank' ? 'bg-amber-50 text-amber-600' : 'bg-gray-100 text-gray-600' }}">
                                {{ $nav->target === '_blank' ? '新窗口' : '当前窗口' }}
                            </span>
                        </td>
                        <td class="px-4 py-3 text-gray-500">
                            <span class="inline-flex items-center gap-1 text-xs text-gray-400">
                                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 9l4-4 4 4m0 6l-4 4-4-4"/></svg>
                                {{ $nav->sort }}
                            </span>
                        </td>
                        <td class="px-4 py-3">
                            <div class="flex items-center gap-1">
                                <button type="button" title="上移" @click="moveUp({{ $nav->id }})"
                                        class="p-1.5 rounded-lg text-gray-400 hover:text-blue-600 hover:bg-blue-50 transition-colors {{ $loop->first ? 'opacity-30 cursor-not-allowed' : '' }}"
                                        {{ $loop->first ? 'disabled' : '' }}>
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 15l7-7 7 7"/></svg>
                                </button>
                                <button type="button" title="下移" @click="moveDown({{ $nav->id }})"
                                        class="p-1.5 rounded-lg text-gray-400 hover:text-blue-600 hover:bg-blue-50 transition-colors {{ $loop->last ? 'opacity-30 cursor-not-allowed' : '' }}"
                                        {{ $loop->last ? 'disabled' : '' }}>
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
                                </button>
                                <button type="button" title="编辑" @click="editNav({{ $nav->id }})"
                                        class="p-1.5 rounded-lg text-gray-400 hover:text-blue-600 hover:bg-blue-50 transition-colors">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
                                </button>
                                <button type="button" title="删除" @click="deleteNav({{ $nav->id }})"
                                        class="p-1.5 rounded-lg text-gray-400 hover:text-red-600 hover:bg-red-50 transition-colors">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                                </button>
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="10" class="px-6 py-12 text-center text-gray-400">暂无导航数据，点击右上角「增加」添加。</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        <div class="px-4 py-2.5 bg-gray-50 border-t border-gray-200 text-xs text-gray-500">
            提示：拖动表格行可调整排序，保存后前台导航顺序即时同步
        </div>
    </div>

    {{-- 移动端卡片视图 --}}
    <div class="md:hidden space-y-3">
        @forelse($navigations as $nav)
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
            <div class="flex items-start justify-between gap-2 mb-2">
                <div class="flex items-center gap-2 min-w-0">
                    <input type="checkbox" value="{{ $nav->id }}"
                           class="rounded border-gray-300 text-blue-600 focus:ring-blue-500 shrink-0"
                           :checked="selectedIds.includes({{ $nav->id }})"
                           @change="toggleSelect({{ $nav->id }}, $event.target.checked)">
                    @if($nav->icon)<i class="{{ $nav->icon }} text-gray-400"></i>@endif
                    <span class="font-semibold text-gray-800 truncate">{{ $nav->name }}</span>
                </div>
                <button type="button" @click="toggleEnable({{ $nav->id }})"
                        :class="itemEnabled({{ $nav->id }}) ? 'bg-blue-500' : 'bg-gray-300'"
                        class="relative inline-flex flex-shrink-0 h-6 w-11 border-2 border-transparent rounded-full cursor-pointer transition-colors ease-in-out duration-200">
                    <span :class="itemEnabled({{ $nav->id }}) ? 'translate-x-5' : 'translate-x-0'"
                          class="pointer-events-none inline-block h-5 w-5 rounded-full bg-white shadow transform ring-0 transition ease-in-out duration-200"></span>
                </button>
            </div>
            <div class="flex items-center gap-2 text-xs text-gray-500 mb-1">
                <span class="inline-flex items-center px-2 py-0.5 rounded-full {{ $nav->position === 'head' ? 'bg-blue-50 text-blue-600' : 'bg-gray-100 text-gray-600' }}">{{ $nav->position === 'head' ? '头部' : '底部' }}</span>
                <span class="inline-flex items-center px-2 py-0.5 rounded-full {{ $nav->target === '_blank' ? 'bg-amber-50 text-amber-600' : 'bg-gray-100 text-gray-600' }}">{{ $nav->target === '_blank' ? '新窗口' : '当前窗口' }}</span>
                <span class="text-gray-400">排序 {{ $nav->sort }}</span>
            </div>
            <div class="text-xs text-blue-600 truncate mb-3"><a href="{{ $nav->url }}" target="_blank" rel="noopener">{{ $nav->url }}</a></div>
            <div class="flex items-center justify-between pt-2 border-t border-gray-100">
                <div class="flex items-center gap-1">
                    <button type="button" @click="moveUp({{ $nav->id }})" class="p-1.5 text-gray-400 hover:text-blue-600 {{ $loop->first ? 'opacity-30' : '' }}" {{ $loop->first ? 'disabled' : '' }}>
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 15l7-7 7 7"/></svg>
                    </button>
                    <button type="button" @click="moveDown({{ $nav->id }})" class="p-1.5 text-gray-400 hover:text-blue-600 {{ $loop->last ? 'opacity-30' : '' }}" {{ $loop->last ? 'disabled' : '' }}>
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
                    </button>
                </div>
                <div class="flex items-center gap-3 text-sm">
                    <button type="button" @click="editNav({{ $nav->id }})" class="text-blue-600 hover:text-blue-800">编辑</button>
                    <button type="button" @click="deleteNav({{ $nav->id }})" class="text-red-600 hover:text-red-800">删除</button>
                </div>
            </div>
        </div>
        @empty
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-8 text-center text-gray-400">暂无导航数据，点击右上角「增加」添加。</div>
        @endforelse
    </div>

{{-- 新增/编辑弹窗 --}}
<div x-show="modalOpen" x-cloak class="fixed inset-0 z-50 overflow-y-auto" style="display: none;">
    <div class="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0">
        <div class="fixed inset-0 transition-opacity bg-gray-500 bg-opacity-75" @click="closeModal()"></div>
        <div class="relative z-10 inline-block w-full max-w-md p-4 sm:p-6 my-4 sm:my-8 overflow-hidden text-left align-middle transition-all transform bg-white shadow-xl rounded-xl">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-lg font-semibold text-gray-900" x-text="isEdit ? '编辑导航' : '新增导航'"></h3>
                <button type="button" @click="closeModal()" class="text-gray-400 hover:text-gray-600">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
                </button>
            </div>

            <form @submit.prevent="submitForm()" class="space-y-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">导航名称 <span class="text-red-500">*</span></label>
                    <input type="text" x-model="form.name" required maxlength="255" placeholder="如：首页、博客、关于"
                           class="w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm px-3 py-2 border">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">访问链接 <span class="text-red-500">*</span></label>
                    <input type="text" x-model="form.url" required maxlength="2048" placeholder="/about 或 https://example.com"
                           class="w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm px-3 py-2 border">
                    <p class="text-xs text-gray-400 mt-1">站内链接以 / 开头（如 /about、/blog），站外链接填完整网址</p>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">图标类名</label>
                    <input type="text" x-model="form.icon" placeholder="如：fas fa-home（Font Awesome）"
                           class="w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm px-3 py-2 border">
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">打开方式</label>
                        <select x-model="form.target" class="w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm px-3 py-2 border">
                            <option value="_self">当前窗口</option>
                            <option value="_blank">新窗口</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">启用状态</label>
                        <div class="flex items-center h-[38px]">
                            <button type="button" @click="form.is_enable = !form.is_enable"
                                    :class="form.is_enable ? 'bg-blue-500' : 'bg-gray-300'"
                                    class="relative inline-flex flex-shrink-0 h-6 w-11 border-2 border-transparent rounded-full cursor-pointer transition-colors ease-in-out duration-200">
                                <span :class="form.is_enable ? 'translate-x-5' : 'translate-x-0'"
                                      class="pointer-events-none inline-block h-5 w-5 rounded-full bg-white shadow transform ring-0 transition ease-in-out duration-200"></span>
                            </button>
                            <span class="ml-2 text-sm text-gray-600" x-text="form.is_enable ? '启用' : '禁用'"></span>
                        </div>
                    </div>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">排序值</label>
                    <input type="number" x-model.number="form.sort" min="0" step="1"
                           class="w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm px-3 py-2 border">
                    <p class="text-xs text-gray-400 mt-1">数值越小越靠前，也可以保存后用列表中的上下箭头或拖拽调整</p>
                </div>

                <input type="hidden" x-model="form.position">
                <input type="hidden" x-model="form.id">

                <div class="flex justify-end gap-3 pt-2">
                    <button type="button" @click="closeModal()"
                            class="px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors">
                        取消
                    </button>
                    <button type="submit" :disabled="submitting"
                            :class="submitting ? 'opacity-60 cursor-not-allowed' : 'hover:bg-blue-700'"
                            class="px-5 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium transition-colors">
                        <span x-text="submitting ? '保存中...' : '保存'"></span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

</div>

<script>
function navManager() {
    return {
        modalOpen: false,
        isEdit: false,
        submitting: false,
        selectedIds: [],
        draggingId: null,
        position: '{{ $position }}',

        // 行数据快照（用于开关状态即时反映，保存后页面刷新）
        items: @json($navigations->map(fn($n) => ['id' => $n->id, 'is_enable' => (bool) $n->is_enable])),

        itemEnabled(id) {
            const item = this.items.find(i => i.id === id);
            return item ? item.is_enable : false;
        },

        // 弹窗表单
        form: { id: null, position: '{{ $position }}', name: '', url: '', icon: '', target: '_self', is_enable: true, sort: 0 },

        openModal() {
            this.isEdit = false;
            this.form = { id: null, position: this.position, name: '', url: '', icon: '', target: '_self', is_enable: true, sort: this.nextSort() };
            this.modalOpen = true;
        },

        editNav(id) {
            const row = @json($navigations);
            const item = row.find(n => n.id === id);
            if (!item) return;
            this.isEdit = true;
            this.form = {
                id: item.id,
                position: item.position,
                name: item.name,
                url: item.url,
                icon: item.icon || '',
                target: item.target,
                is_enable: item.is_enable ? true : false,
                sort: item.sort,
            };
            this.modalOpen = true;
        },

        closeModal() {
            this.modalOpen = false;
        },

        nextSort() {
            return @json($navigations->max('sort') !== null ? $navigations->max('sort') + 1 : 0);
        },

        // 提交表单（新增/编辑）
        submitForm() {
            this.submitting = true;
            const isEdit = this.isEdit;
            const url = isEdit ? `/admin/navigations/${this.form.id}` : '/admin/navigations';
            fetch(url, {
                method: isEdit ? 'PUT' : 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': this.csrf(),
                    'Accept': 'application/json',
                },
                body: JSON.stringify(this.form),
            })
            .then(r => r.json())
            .then(res => {
                if (res.success) {
                    this.showToast(res.message, 'success');
                    this.closeModal();
                    this.refresh();
                } else {
                    this.showToast(res.message || '保存失败', 'error');
                }
            })
            .catch(() => this.showToast('网络错误，请重试', 'error'))
            .finally(() => { this.submitting = false; });
        },

        // 启用/禁用
        toggleEnable(id) {
            fetch(`/admin/navigations/${id}/toggle`, {
                method: 'POST',
                headers: { 'X-CSRF-TOKEN': this.csrf(), 'Accept': 'application/json' },
            })
            .then(r => r.json())
            .then(res => {
                if (res.success) {
                    const item = this.items.find(i => i.id === id);
                    if (item) item.is_enable = res.is_enable;
                    this.showToast(res.is_enable ? '已启用' : '已禁用', 'success');
                } else {
                    this.showToast('状态更新失败', 'error');
                }
            })
            .catch(() => this.showToast('网络错误，请重试', 'error'));
        },

        // 上移
        moveUp(id) {
            fetch(`/admin/navigations/${id}/move-up`, {
                method: 'POST',
                headers: { 'X-CSRF-TOKEN': this.csrf(), 'Accept': 'application/json' },
            })
            .then(r => r.json())
            .then(res => {
                if (res.success) { this.showToast('已上移', 'success'); this.refresh(); }
                else this.showToast(res.message || '操作失败', 'error');
            })
            .catch(() => this.showToast('网络错误，请重试', 'error'));
        },

        // 下移
        moveDown(id) {
            fetch(`/admin/navigations/${id}/move-down`, {
                method: 'POST',
                headers: { 'X-CSRF-TOKEN': this.csrf(), 'Accept': 'application/json' },
            })
            .then(r => r.json())
            .then(res => {
                if (res.success) { this.showToast('已下移', 'success'); this.refresh(); }
                else this.showToast(res.message || '操作失败', 'error');
            })
            .catch(() => this.showToast('网络错误，请重试', 'error'));
        },

        // 拖拽排序
        onDragStart(e, id) {
            this.draggingId = id;
            e.dataTransfer.effectAllowed = 'move';
            e.dataTransfer.setData('text/plain', String(id));
        },

        onDrop(e, targetId) {
            e.preventDefault();
            const fromId = this.draggingId;
            this.draggingId = null;
            if (!fromId || fromId === targetId) return;
            // 收集当前 DOM 顺序
            const rows = Array.from(document.querySelectorAll('tbody tr[data-id]'));
            const ids = rows.map(tr => parseInt(tr.getAttribute('data-id'), 10));
            // 从数组中移除拖拽项，插入到目标位置
            const fromIdx = ids.indexOf(fromId);
            const toIdx = ids.indexOf(targetId);
            if (fromIdx === -1 || toIdx === -1) return;
            ids.splice(fromIdx, 1);
            ids.splice(toIdx, 0, fromId);
            this.saveSort(ids);
        },

        saveSort(ids) {
            fetch('/admin/navigations/sort', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': this.csrf(),
                    'Accept': 'application/json',
                },
                body: JSON.stringify({ ids: ids, position: this.position }),
            })
            .then(r => r.json())
            .then(res => {
                if (res.success) { this.showToast('排序已更新', 'success'); this.refresh(); }
                else this.showToast(res.message || '排序失败', 'error');
            })
            .catch(() => this.showToast('网络错误，请重试', 'error'));
        },

        // 删除
        deleteNav(id) {
            if (!confirm('确定要删除这个导航项吗？')) return;
            fetch(`/admin/navigations/${id}`, {
                method: 'DELETE',
                headers: { 'X-CSRF-TOKEN': this.csrf(), 'Accept': 'application/json' },
            })
            .then(r => r.json())
            .then(res => {
                if (res.success) { this.showToast('已删除', 'success'); this.refresh(); }
                else this.showToast('删除失败', 'error');
            })
            .catch(() => this.showToast('网络错误，请重试', 'error'));
        },

        // 批量删除
        batchDelete() {
            if (this.selectedIds.length === 0) return;
            if (!confirm(`确定要删除选中的 ${this.selectedIds.length} 个导航项吗？`)) return;
            fetch('/admin/navigations/batch-destroy', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': this.csrf(),
                    'Accept': 'application/json',
                },
                body: JSON.stringify({ ids: this.selectedIds }),
            })
            .then(r => r.json())
            .then(res => {
                if (res.success) {
                    this.showToast(res.message, 'success');
                    this.selectedIds = [];
                    this.refresh();
                } else {
                    this.showToast(res.message || '批量删除失败', 'error');
                }
            })
            .catch(() => this.showToast('网络错误，请重试', 'error'));
        },

        toggleSelect(id, checked) {
            if (checked) {
                if (!this.selectedIds.includes(id)) this.selectedIds.push(id);
            } else {
                this.selectedIds = this.selectedIds.filter(i => i !== id);
            }
        },

        toggleSelectAll(checked) {
            const allIds = @json($navigations->pluck('id'));
            this.selectedIds = checked ? [...allIds] : [];
        },

        refresh() {
            window.location.href = `/admin/navigations?position=${this.position}`;
        },

        csrf() {
            const meta = document.querySelector('meta[name="csrf-token"]');
            return meta ? meta.getAttribute('content') : '';
        },

        // Toast 提示（统一使用全局弹窗）
        showToast(message, type = 'success') {
            window.notify(message, type);
        },
    }
}
</script>
@endsection

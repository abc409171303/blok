@extends('layouts.admin')
@section('page-title', '留言管理')

@section('content')
<div>
    <div class="flex items-center justify-between mb-6">
        <h1 class="text-2xl font-bold text-gray-800">留言管理</h1>
    </div>

    @if(session('success'))
    <div class="mb-4 px-4 py-3 bg-green-50 border border-green-200 text-green-700 text-sm rounded-lg">{{ session('success') }}</div>
    @endif

    <div x-data="{ showModal: false, m: null, reply: '', openModal(m) { this.m = m; this.reply = m.reply || ''; this.showModal = true; } }">
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead>
                        <tr class="bg-gray-50 border-b border-gray-200">
                            <th class="text-left px-4 py-3 font-medium text-gray-600 w-12">ID</th>
                            <th class="text-left px-4 py-3 font-medium text-gray-600">作者</th>
                            <th class="text-left px-4 py-3 font-medium text-gray-600">内容</th>
                            <th class="text-left px-4 py-3 font-medium text-gray-600">状态</th>
                            <th class="text-left px-4 py-3 font-medium text-gray-600">提交时间</th>
                            <th class="text-left px-4 py-3 font-medium text-gray-600 w-40">操作</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100">
                        @forelse($messages as $message)
                        <tr class="hover:bg-gray-50 transition-colors">
                            <td class="px-4 py-3 text-lg text-gray-500">{{ $message->id }}</td>
                            <td class="px-4 py-3">
                                <div class="text-lg font-medium text-gray-800">{{ $message->author }}</div>
                                <div class="text-sm text-gray-400">{{ $message->email }}</div>
                            </td>
                            <td class="px-4 py-3 text-lg text-gray-600 max-w-[300px]">
                                <div class="truncate">{{ $message->content }}</div>
                            </td>
                            <td class="px-4 py-3">
                                @if($message->status === 'approved')
                                <span class="inline-flex items-center px-2 py-0.5 rounded-full text-lg font-medium bg-green-100 text-green-700">已通过</span>
                                @elseif($message->status === 'rejected')
                                <span class="inline-flex items-center px-2 py-0.5 rounded-full text-lg font-medium bg-red-100 text-red-700">已拒绝</span>
                                @else
                                <span class="inline-flex items-center px-2 py-0.5 rounded-full text-lg font-medium bg-yellow-100 text-yellow-700">待审核</span>
                                @endif
                            </td>
                            <td class="px-4 py-3 text-lg text-gray-500">{{ $message->created_at->format('Y-m-d H:i') }}</td>
                            <td class="px-4 py-3">
                                <div class="flex items-center gap-2">
                                    <button type="button" @click="openModal({ id: {{ $message->id }}, author: @js($message->author), email: @js($message->email), content: @js($message->content), reply: @js($message->reply), created_at: @js($message->created_at->format('Y-m-d H:i')) })" class="text-blue-600 hover:text-blue-800 text-lg">查看</button>
                                    @if($message->status === 'pending')
                                    <form action="{{ route('admin.messages.approve', $message) }}" method="POST" class="inline">
                                        @csrf
                                        <button type="submit" class="text-green-600 hover:text-green-800 text-lg">通过</button>
                                    </form>
                                    @endif
                                    @if($message->status !== 'rejected')
                                    <form action="{{ route('admin.messages.reject', $message) }}" method="POST" class="inline">
                                        @csrf
                                        <button type="submit" class="text-yellow-600 hover:text-yellow-800 text-lg">拒绝</button>
                                    </form>
                                    @endif
                                    <form action="{{ route('admin.messages.destroy', $message) }}" method="POST" onsubmit="return confirm('确定要删除这条留言吗？')" class="inline">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="text-red-600 hover:text-red-800 text-lg">删除</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="6" class="px-4 py-12 text-center text-gray-500">
                                <div class="flex flex-col items-center gap-2">
                                    <svg class="w-12 h-12 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"/></svg>
                                    <span>暂无留言</span>
                                </div>
                            </td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
            @if($messages->hasPages())
            <div class="px-4 py-3 border-t border-gray-200">
                {{ $messages->links() }}
            </div>
            @endif
        </div>

        {{-- 留言详情弹窗 --}}
        <div x-show="showModal" x-cloak style="display: none;" class="fixed inset-0 z-50 overflow-y-auto" @keydown.escape.window="showModal = false">
            <div class="fixed inset-0 bg-gray-900/60" @click="showModal = false"></div>
            <div class="relative min-h-screen flex items-center justify-center p-4">
                <div class="relative w-full max-w-3xl bg-white dark:bg-gray-800 dark:text-gray-200 rounded-xl shadow-xl border border-gray-200 dark:border-gray-600 overflow-hidden">
                    {{-- 头部 --}}
                    <div class="flex items-center justify-between px-6 py-5 border-b border-gray-100 dark:border-gray-700">
                        <h3 class="text-xl font-semibold text-gray-800 dark:text-gray-100">留言详情</h3>
                        <button type="button" @click="showModal = false" class="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
                        </button>
                    </div>
                    {{-- 主体 --}}
                    <div class="px-6 py-5 space-y-5">
                        <template x-if="m">
                            <div class="space-y-5">
                                <div class="flex flex-wrap items-center gap-x-3 gap-y-1">
                                    <span class="text-lg font-medium text-gray-800 dark:text-gray-100" x-text="m.author"></span>
                                    <span class="text-sm text-gray-400" x-text="m.email"></span>
                                    <span class="ml-auto text-sm text-gray-400" x-text="m.created_at"></span>
                                </div>
                                <div class="bg-gray-50 dark:bg-gray-700/50 border border-gray-100 dark:border-gray-700 rounded-lg px-5 py-4 min-h-[110px] text-lg text-gray-600 dark:text-gray-300 leading-relaxed whitespace-pre-wrap break-words" x-text="m.content"></div>

                                {{-- 已有回复 --}}
                                <div x-show="m.reply">
                                    <div class="text-lg font-medium text-gray-500 dark:text-gray-400 mb-1.5">博主回复</div>
                                    <div class="bg-blue-50 dark:bg-blue-900/20 border border-blue-100 dark:border-blue-800 rounded-lg px-5 py-4 min-h-[80px] text-lg text-gray-600 dark:text-gray-300 leading-relaxed whitespace-pre-wrap break-words" x-text="m.reply"></div>
                                </div>

                                {{-- 回复输入 --}}
                                <div>
                                    <label class="block text-lg font-medium text-gray-500 dark:text-gray-400 mb-1.5">回复留言</label>
                                    <textarea x-model="reply" rows="5" maxlength="2000" placeholder="输入回复内容..." class="w-full px-3 py-2 text-lg bg-white dark:bg-gray-700 text-gray-800 dark:text-gray-100 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-400 focus:border-blue-400 resize-none"></textarea>
                                </div>
                            </div>
                        </template>
                    </div>
                    {{-- 底部操作 --}}
                    <div class="flex items-center justify-end gap-2 px-6 py-4 border-t border-gray-100 dark:border-gray-700">
                        <button type="button" @click="showModal = false" class="px-4 py-2 text-sm text-gray-600 dark:text-gray-300 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">关闭</button>
                        <form :action="'/admin/messages/' + (m ? m.id : 0) + '/reply'" method="POST" class="inline">
                            @csrf
                            <button type="submit" :disabled="!reply.trim()" class="px-4 py-2 text-sm bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed">保存回复</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

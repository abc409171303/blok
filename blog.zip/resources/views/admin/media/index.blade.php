@extends('layouts.admin')

@section('page-title', '文件库')

@section('content')
<div x-data="mediaManager()">
    <div class="flex items-center justify-between mb-6">
        <h1 class="text-2xl font-bold text-gray-800 dark:text-gray-100">文件库</h1>
        <button @click="openUploadModal()" class="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"/></svg>
            上传文件
        </button>
    </div>

    {{-- 统计卡片 --}}
    <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-5 flex items-center gap-4">
            <div class="w-12 h-12 rounded-lg bg-blue-50 dark:bg-blue-900/30 flex items-center justify-center">
                <svg class="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
            </div>
            <div>
                <p class="text-sm text-gray-500 dark:text-gray-400">全部文件</p>
                <p class="text-2xl font-bold text-gray-800 dark:text-gray-100">{{ $stats['total'] }}</p>
            </div>
        </div>
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-5 flex items-center gap-4">
            <div class="w-12 h-12 rounded-lg bg-green-50 dark:bg-green-900/30 flex items-center justify-center">
                <svg class="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
            </div>
            <div>
                <p class="text-sm text-gray-500 dark:text-gray-400">图片</p>
                <p class="text-2xl font-bold text-gray-800 dark:text-gray-100">{{ $stats['images'] }}</p>
            </div>
        </div>
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-5 flex items-center gap-4">
            <div class="w-12 h-12 rounded-lg bg-purple-50 dark:bg-purple-900/30 flex items-center justify-center">
                <svg class="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 10l4.553-2.276M10 15L5.447 12.724M19 21V7a2 2 0 00-2-2H7a2 2 0 00-2 2v14m0 0h12M7 21V9m12 12V9"/></svg>
            </div>
            <div>
                <p class="text-sm text-gray-500 dark:text-gray-400">视频</p>
                <p class="text-2xl font-bold text-gray-800 dark:text-gray-100">{{ $stats['videos'] }}</p>
            </div>
        </div>
    </div>

    {{-- 工具栏：分类筛选 --}}
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 mb-6">
        <div class="flex flex-wrap items-center gap-3 px-4 py-3 border-b border-gray-100 dark:border-gray-700">
            <form method="GET" action="{{ route('admin.media.index') }}" class="flex flex-wrap gap-3 items-center flex-1">
                <nav class="flex items-center gap-1">
                    <a href="{{ route('admin.media.index') }}"
                        class="px-3 py-1.5 rounded-lg text-sm font-medium transition-colors {{ !request('type') ? 'bg-blue-50 text-blue-600 dark:bg-blue-900/30 dark:text-blue-300' : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700' }}">
                        全部
                    </a>
                    <a href="{{ route('admin.media.index', ['type' => 'image']) }}"
                        class="px-3 py-1.5 rounded-lg text-sm font-medium transition-colors {{ request('type') === 'image' ? 'bg-blue-50 text-blue-600 dark:bg-blue-900/30 dark:text-blue-300' : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700' }}">
                        图片
                    </a>
                    <a href="{{ route('admin.media.index', ['type' => 'video']) }}"
                        class="px-3 py-1.5 rounded-lg text-sm font-medium transition-colors {{ request('type') === 'video' ? 'bg-blue-50 text-blue-600 dark:bg-blue-900/30 dark:text-blue-300' : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700' }}">
                        视频
                    </a>
                </nav>
                <div class="flex-1 min-w-[160px]">
                    <input type="text" name="search" value="{{ request('search') }}" placeholder="搜索文件名..."
                        class="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none">
                </div>
                <button type="submit" class="px-4 py-2 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-300 rounded-lg text-sm font-medium transition-colors">
                    筛选
                </button>
                @if(request()->anyFilled(['type', 'search']))
                <a href="{{ route('admin.media.index') }}" class="px-4 py-2 text-sm text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:text-gray-300 inline-flex items-center">
                    清除
                </a>
                @endif
            </form>
            {{-- 批量操作按钮组 --}}
            <div id="batch-actions" class="flex items-center gap-2">
                <button type="button" data-action="copy"
                    @click="bulkCopyLinks"
                    class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors cursor-not-allowed"
                    disabled>
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"/></svg>
                    复制链接
                    <span class="batch-count text-xs opacity-80">(0)</span>
                </button>
                <button type="button" data-action="edit"
                    @click="openBulkEdit"
                    class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors cursor-not-allowed"
                    disabled>
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
                    编辑
                    <span class="batch-count text-xs opacity-80">(0)</span>
                </button>
                <button type="button" data-action="delete"
                    @click="bulkDelete"
                    class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors cursor-not-allowed"
                    disabled>
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                    删除
                    <span class="batch-count text-xs opacity-80">(0)</span>
                </button>
            </div>
        </div>
    </div>

    {{-- 文件网格 --}}
    <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
        @forelse($files as $file)
        <div class="relative bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden hover:shadow-md transition-shadow media-card" data-id="{{ $file->id }}">
            <input type="checkbox" value="{{ $file->id }}" @change="toggleFile($event)"
                class="absolute top-2 left-2 z-10 w-4 h-4 rounded border-gray-300 dark:border-gray-600 text-blue-600 focus:ring-blue-500">

            {{-- 缩略图区域：点击选中，底部操作按钮选中后激活 --}}
            <div class="aspect-square bg-gray-100 dark:bg-gray-700 flex items-center justify-center relative cursor-pointer"
                @click="selectMedia($event, {{ $file->id }})">
                @if($file->file_type === 'image')
                <img src="{{ $file->url }}" alt="{{ $file->file_name }}" class="w-full h-full object-cover">
                @else
                <div class="w-full h-full flex flex-col items-center justify-center text-gray-400 dark:text-gray-500">
                    <svg class="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M15 10l4.553-2.276M10 15L5.447 12.724M19 21V7a2 2 0 00-2-2H7a2 2 0 00-2 2v14m0 0h12M7 21V9m12 12V9"/></svg>
                    <span class="text-xs mt-2">视频</span>
                </div>
                @endif

                {{-- 操作按钮：选中激活彩色，未选中灰色禁用可见 --}}
                <div class="absolute bottom-2 right-2 flex items-center gap-1.5">
                    <button type="button" @click.stop="openEdit(mediaMap[{{ $file->id }}])"
                        title="编辑" data-op="edit"
                        class="media-btn w-7 h-7 rounded-full inline-flex items-center justify-center transition-colors disabled:cursor-not-allowed">
                        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
                    </button>
                    <button type="button" @click.stop="copySelected()"
                        title="复制链接" data-op="copy"
                        class="media-btn w-7 h-7 rounded-full inline-flex items-center justify-center transition-colors disabled:cursor-not-allowed">
                        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"/></svg>
                    </button>
                    <button type="button" @click.stop="deleteFile(selectedFile)"
                        title="删除" data-op="delete"
                        class="media-btn w-7 h-7 rounded-full inline-flex items-center justify-center transition-colors disabled:cursor-not-allowed">
                        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                    </button>
                </div>
            </div>

            {{-- 文件信息 --}}
            <div class="p-3">
                <p class="text-sm text-gray-800 dark:text-gray-100 truncate" title="{{ $file->file_name }}">{{ $file->file_name }}</p>
                <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">
                    @if($file->file_size >= 1048576)
                    {{ round($file->file_size / 1048576, 1) }} MB
                    @elseif($file->file_size >= 1024)
                    {{ round($file->file_size / 1024, 1) }} KB
                    @else
                    {{ $file->file_size }} B
                    @endif
                    @if($file->width && $file->height)
                    · {{ $file->width }}×{{ $file->height }}
                    @endif
                </p>
            </div>
        </div>
        @empty
        <div class="col-span-full bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 py-16 text-center">
            <svg class="w-16 h-16 text-gray-300 dark:text-gray-600 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
            <p class="text-gray-500 dark:text-gray-400">暂无文件，点击右上角"上传文件"添加</p>
        </div>
        @endforelse
    </div>

    {{-- 分页 --}}
    @if($files->hasPages())
    <div class="mt-6">
        {{ $files->appends(request()->query())->links() }}
    </div>
    @endif

    {{-- 上传模态框 --}}
    <div x-show="uploadModalOpen" x-cloak class="fixed inset-0 z-50 overflow-y-auto" style="display: none;">
        <div class="fixed inset-0 bg-black/50" @click="uploadModalOpen = false"></div>
        <div class="flex min-h-full items-center justify-center p-4">
            <div class="relative bg-white dark:bg-gray-800 rounded-xl shadow-2xl w-full max-w-2xl p-6" @click.stop>
                <div class="flex items-center justify-between mb-6">
                    <h2 class="text-xl font-bold text-gray-800 dark:text-gray-100">上传文件</h2>
                    <button @click="uploadModalOpen = false" class="text-gray-400 hover:text-gray-600 dark:text-gray-400">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
                    </button>
                </div>

                <div class="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-12 text-center hover:border-blue-400 transition-colors cursor-pointer"
                    @dragover.prevent="dragover = true" @dragleave="dragover = false" @drop.prevent="dropFiles($event)"
                    :class="dragover ? 'border-blue-500 bg-blue-50' : ''">
                    <input type="file" ref="fileInput" @change="handleFiles($event.target.files)" multiple accept="image/*,video/*,audio/*" class="hidden" :disabled="uploading">
                    <div @click="$refs.fileInput.click()">
                        <svg class="w-16 h-16 text-blue-400 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"/></svg>
                        <p class="text-base text-gray-700 dark:text-gray-300 font-medium">点击选择或拖拽文件到此处</p>
                        <p class="text-sm text-gray-500 dark:text-gray-400 mt-2">支持图片、视频、音频，单个文件最大 10MB</p>
                    </div>
                </div>

                {{-- 上传进度 --}}
                <div x-show="uploading" class="mt-4">
                    <div class="flex items-center justify-between gap-2 mb-2">
                        <p class="text-sm text-gray-600 dark:text-gray-400 truncate" x-text="uploadLabel"></p>
                        <p class="text-sm text-gray-500 dark:text-gray-400 flex-shrink-0" x-text="uploadPercent + '%'"></p>
                    </div>
                    <div class="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2 overflow-hidden">
                        <div class="bg-blue-600 h-2 rounded-full transition-all duration-150" :style="'width: ' + uploadPercent + '%'"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- 编辑模态框 --}}
    <div x-show="editModalOpen" x-cloak class="fixed inset-0 z-50 overflow-y-auto" style="display: none;">
        <div class="fixed inset-0 bg-black/50" @click="editModalOpen = false"></div>
        <div class="flex min-h-full items-center justify-center p-4">
            <div class="relative bg-white dark:bg-gray-800 rounded-xl shadow-2xl w-full max-w-md p-6" @click.stop>
                <div class="flex items-center justify-between mb-6">
                    <h2 class="text-xl font-bold text-gray-800 dark:text-gray-100" x-text="editForm.ids ? '批量编辑 (' + editForm.ids.length + ' 个)' : '编辑文件'"></h2>
                    <button @click="editModalOpen = false" class="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
                    </button>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">新文件名</label>
                    <input type="text" x-model="editForm.file_name" maxlength="255"
                        :placeholder="editForm.ids ? '为选中的 ' + editForm.ids.length + ' 个文件设置统一文件名' : '输入新文件名'"
                        class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg text-sm bg-white dark:bg-gray-700 text-gray-800 dark:text-gray-100 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none">
                </div>

                <div class="flex justify-end gap-2 mt-6">
                    <button @click="editModalOpen = false"
                        class="px-4 py-2 text-sm text-gray-600 dark:text-gray-300 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">取消</button>
                    <button @click="editForm.ids ? saveBulkEdit() : saveEdit()"
                        class="px-4 py-2 text-sm bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors">保存</button>
                </div>
            </div>
        </div>
    </div>
</div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('alpine:init', () => {
    Alpine.data('mediaManager', () => ({
        selectedFiles: [],
        selectedFile: null,
        mediaMap: {},
        dragover: false,
        uploadModalOpen: false,
        uploading: false,
        uploadPercent: 0,
        uploadFileName: '',
        uploadIndex: 0,
        uploadTotal: 0,
        editModalOpen: false,
        editForm: { id: null, file_name: '', title: '', ids: null },

        init() {
            // 构建 ID → file 映射（从文件信息区读取真实文件名）
            var cards = document.querySelectorAll('.media-card');
            var self = this;
            cards.forEach(function(card) {
                var id = parseInt(card.getAttribute('data-id'));
                var nameEl = card.querySelector('.text-sm.text-gray-800');
                var fname = nameEl ? nameEl.textContent.trim() : '';
                var imgEl = card.querySelector('img');
                var url = imgEl ? imgEl.getAttribute('src') : '';
                self.mediaMap[id] = { id: id, title: '', file_name: fname, url: url };
            });

            // 初始化所有按钮状态（禁用 + 灰色）
            this.updateBtnStates();
            this.updateToolbarBtnStates();

            // 挂到 window 供外部调用
            window.mediaMgr = this;
        },

        openUploadModal() {
            this.uploadModalOpen = true;
        },

        selectMedia(event, fileId) {
            if (event.target.tagName === 'INPUT') return;
            this.selectedFile = fileId;
            this.updateBtnStates();
        },

        updateBtnStates() {
            var cards = document.querySelectorAll('.media-card');
            var selectedId = this.selectedFile;
            cards.forEach(function(card) {
                var id = parseInt(card.getAttribute('data-id'));
                var ring = card.classList.contains('ring-2');
                if (id === selectedId && !ring) {
                    card.classList.add('ring-2', 'ring-blue-500');
                } else if (id !== selectedId && ring) {
                    card.classList.remove('ring-2', 'ring-blue-500');
                }
                var btns = card.querySelectorAll('.media-btn');
                btns.forEach(function(btn) {
                    btn.disabled = (id !== selectedId);
                    if (id === selectedId) {
                        btn.classList.remove('bg-black/25', 'text-white/50');
                        if (btn.getAttribute('data-op') === 'delete') {
                            btn.classList.add('bg-red-500', 'text-white', 'hover:bg-red-600', 'shadow-md');
                        } else {
                            btn.classList.add('bg-blue-500', 'text-white', 'hover:bg-blue-600', 'shadow-md');
                        }
                    } else {
                        btn.classList.remove('bg-red-500', 'text-white', 'hover:bg-red-600', 'shadow-md', 'bg-blue-500', 'hover:bg-blue-600');
                        btn.classList.add('bg-black/25', 'text-white/50');
                    }
                });
            });
        },

        openEdit(file) {
            if (!file) return;
            this.editForm = { id: file.id, file_name: file.file_name, title: file.title };
            this.editModalOpen = true;
        },

        async saveEdit() {
            if (!this.editForm.file_name.trim()) {
                window.notify('文件名不能为空', 'error');
                return;
            }
            try {
                const resp = await fetch('/admin/media/' + this.editForm.id, {
                    method: 'PATCH',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                        'Accept': 'application/json',
                    },
                    body: JSON.stringify({ file_name: this.editForm.file_name.trim(), title: this.editForm.title }),
                });
                const data = await resp.json();
                if (data.success) {
                    window.notify('保存成功', 'success');
                    setTimeout(() => location.reload(), 800);
                } else {
                    window.notify('保存失败', 'error');
                }
            } catch (e) {
                window.notify('保存失败：' + e.message, 'error');
            }
        },

        copySelected() {
            if (!this.selectedFile) return;
            this.copyLink(this.selectedFile);
        },

        async bulkCopyLinks() {
            if (this.selectedFiles.length === 0) return;
            try {
                const resp = await fetch('/admin/media/bulk-copy', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                        'Accept': 'application/json',
                    },
                    body: JSON.stringify({ ids: this.selectedFiles }),
                });
                const data = await resp.json();
                if (data.success) {
                    const text = data.urls.join('\n');
                    await navigator.clipboard.writeText(text);
                    window.notify('已复制 ' + data.urls.length + ' 个链接', 'success');
                } else {
                    window.notify('复制失败', 'error');
                }
            } catch (e) {
                window.notify('复制失败：' + e.message, 'error');
            }
        },

        openBulkEdit() {
            if (this.selectedFiles.length === 0) return;
            this.editForm = { ids: [...this.selectedFiles], file_name: '' };
            this.editModalOpen = true;
        },

        async saveBulkEdit() {
            if (!this.editForm.file_name.trim()) {
                window.notify('文件名不能为空', 'error');
                return;
            }
            try {
                const resp = await fetch('/admin/media/bulk-update', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                        'Accept': 'application/json',
                    },
                    body: JSON.stringify({ ids: this.editForm.ids, file_name: this.editForm.file_name.trim() }),
                });
                const data = await resp.json();
                if (data.success) {
                    window.notify(data.message || '保存成功', 'success');
                    this.editModalOpen = false;
                    this.selectedFiles = [];
                    this.selectedFile = null;
                    this.updateBtnStates();
                    setTimeout(() => location.reload(), 800);
                } else {
                    window.notify('保存失败', 'error');
                }
            } catch (e) {
                window.notify('保存失败：' + e.message, 'error');
            }
        },

        toggleFile(event) {
            const id = parseInt(event.target.value);
            if (event.target.checked) {
                if (!this.selectedFiles.includes(id)) this.selectedFiles.push(id);
            } else {
                this.selectedFiles = this.selectedFiles.filter(fid => fid !== id);
            }
            // 手动更新工具栏按钮状态（Alpine 绑定在大作用域下可能失效）
            this.updateToolbarBtnStates();
        },

        updateToolbarBtnStates() {
            var count = this.selectedFiles.length;
            var btns = document.querySelectorAll('#batch-actions button');
            btns.forEach(function(btn) {
                btn.disabled = (count === 0);
                var text = btn.getAttribute('data-action');
                if (count > 0) {
                    btn.classList.remove('bg-gray-100', 'dark:bg-gray-700', 'text-gray-400', 'dark:text-gray-500');
                    if (text === 'delete') {
                        btn.classList.add('bg-red-500', 'text-white', 'hover:bg-red-600', 'shadow-sm');
                    } else {
                        btn.classList.add('bg-blue-500', 'text-white', 'hover:bg-blue-600', 'shadow-sm');
                    }
                } else {
                    btn.classList.remove('bg-red-500', 'bg-blue-500', 'text-white', 'hover:bg-red-600', 'hover:bg-blue-600', 'shadow-sm');
                    btn.classList.add('bg-gray-100', 'dark:bg-gray-700', 'text-gray-400', 'dark:text-gray-500');
                }
            });
            // 更新数量角标
            var badgeSpans = document.querySelectorAll('#batch-actions .batch-count');
            badgeSpans.forEach(function(span) { span.textContent = count; });
        },

        async copyLink(url) {
            if (typeof url === 'number' && this.mediaMap[url] && this.mediaMap[url].url) {
                url = this.mediaMap[url].url;
            }
            if (!url) {
                window.notify('复制链接失败：未找到文件URL', 'error');
                return;
            }
            try {
                await navigator.clipboard.writeText(url);
                window.notify('链接已复制到剪贴板', 'success');
            } catch (e) {
                const input = document.createElement('input');
                input.value = url;
                document.body.appendChild(input);
                input.select();
                document.execCommand('copy');
                document.body.removeChild(input);
                window.notify('链接已复制到剪贴板', 'success');
            }
        },

        async deleteFile(id) {
            if (!id) return;
            if (!confirm('确定要删除这个文件吗？')) return;

            try {
                const resp = await fetch('/admin/media/' + id, {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                        'Accept': 'application/json',
                    },
                });

                const data = await resp.json();
                if (data.success) {
                    window.notify('删除成功', 'success');
                    setTimeout(() => location.reload(), 800);
                } else {
                    window.notify('删除失败', 'error');
                }
            } catch (e) {
                window.notify('删除失败：' + e.message, 'error');
            }
        },

        async bulkDelete() {
            if (this.selectedFiles.length === 0) return;
            if (!confirm('确定要删除选中的 ' + this.selectedFiles.length + ' 个文件吗？')) return;

            try {
                const resp = await fetch('/admin/media/bulk-destroy', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                        'Accept': 'application/json',
                    },
                    body: JSON.stringify({ ids: this.selectedFiles }),
                });

                const data = await resp.json();
                if (data.success) {
                    window.notify('批量删除成功', 'success');
                    setTimeout(() => location.reload(), 800);
                } else {
                    window.notify('批量删除失败', 'error');
                }
            } catch (e) {
                window.notify('批量删除失败：' + e.message, 'error');
            }
        },

        handleFiles(files) {
            if (!files || files.length === 0 || this.uploading) return;
            this.uploadQueue(Array.from(files));
        },

        dropFiles(event) {
            this.dragover = false;
            if (this.uploading) return;
            const files = event.dataTransfer.files;
            this.handleFiles(files);
        },

        async uploadQueue(files) {
            this.uploading = true;
            this.uploadTotal = files.length;
            this.uploadIndex = 0;
            this.uploadPercent = 0;
            let successCount = 0;

            for (let i = 0; i < files.length; i++) {
                this.uploadIndex = i + 1;
                this.uploadFileName = files[i].name;
                this.uploadPercent = 0;
                try {
                    await this.uploadFile(files[i]);
                    successCount += 1;
                } catch (e) {
                    window.notify('上传失败：' + files[i].name + ' ' + (e.message || '未知错误'), 'error');
                }
            }

            this.uploading = false;
            this.uploadPercent = 0;
            this.uploadFileName = '';
            this.uploadIndex = 0;
            this.uploadTotal = 0;
            if (this.$refs.fileInput) this.$refs.fileInput.value = '';

            if (successCount > 0) {
                window.notify(successCount === files.length ? '上传成功' : ('已上传 ' + successCount + '/' + files.length + ' 个文件'), 'success');
                setTimeout(() => location.reload(), 800);
            }
        },

        uploadFile(file) {
            return new Promise((resolve, reject) => {
                const formData = new FormData();
                formData.append('file', file);

                const xhr = new XMLHttpRequest();
                xhr.open('POST', '/admin/media/upload');
                xhr.setRequestHeader('X-CSRF-TOKEN', document.querySelector('meta[name="csrf-token"]').getAttribute('content'));
                xhr.setRequestHeader('Accept', 'application/json');

                xhr.upload.onprogress = (e) => {
                    if (e.lengthComputable) {
                        this.uploadPercent = Math.round((e.loaded / e.total) * 100);
                    }
                };

                xhr.onload = () => {
                    let data = null;
                    try {
                        data = JSON.parse(xhr.responseText);
                    } catch (e) {
                        reject(new Error('响应解析错误'));
                        return;
                    }

                    if (xhr.status >= 200 && xhr.status < 300 && data.success) {
                        this.uploadPercent = 100;
                        resolve(data);
                    } else {
                        reject(new Error(data.message || '未知错误'));
                    }
                };

                xhr.onerror = () => reject(new Error('网络错误'));
                xhr.send(formData);
            });
        },

        get uploadLabel() {
            if (!this.uploading) return '';
            const prefix = this.uploadTotal > 1
                ? ('正在上传 (' + this.uploadIndex + '/' + this.uploadTotal + '): ')
                : '正在上传: ';
            return prefix + this.uploadFileName;
        },
    }));
});
</script>

@push('styles')
<style>
[x-cloak] { display: none !important; }
</style>
@endpush
@endsection

@extends('layouts.admin')
@section('title', '编辑用户')

@section('content')
<h2 class="text-xl font-bold text-gray-800 mb-6">编辑用户</h2>

<div class="bg-white rounded-lg shadow-sm p-6 max-w-lg">
    <form action="{{ route('admin.users.update', $user) }}" method="POST">
        @csrf @method('PUT')
        <div class="mb-4">
            <label for="name" class="block text-sm font-medium text-gray-700 mb-1.5">账号 <span class="text-red-500">*</span></label>
            <input type="text" name="name" id="name" value="{{ old('name', $user->name) }}" required
                class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                placeholder="请输入账号">
            @error('name')<p class="text-red-500 text-xs mt-1">{{ $message }}</p>@enderror
        </div>
        <div class="mb-4">
            <label for="email" class="block text-sm font-medium text-gray-700 mb-1.5">邮箱</label>
            <input type="email" name="email" id="email" value="{{ old('email', $user->email) }}"
                class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                placeholder="可选">
            @error('email')<p class="text-red-500 text-xs mt-1">{{ $message }}</p>@enderror
        </div>
        <div class="mb-4">
            <label for="password" class="block text-sm font-medium text-gray-700 mb-1.5">新密码 <span class="text-gray-400 text-xs">(留空不修改)</span></label>
            <input type="password" name="password" id="password"
                class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                placeholder="留空则不修改密码">
            @error('password')<p class="text-red-500 text-xs mt-1">{{ $message }}</p>@enderror
        </div>
        <div class="mb-5">
            <label for="role" class="block text-sm font-medium text-gray-700 mb-1.5">角色 <span class="text-red-500">*</span></label>
            <select name="role" id="role" required
                class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none">
                <option value="user" {{ old('role', $user->role) === 'user' ? 'selected' : '' }}>用户</option>
                <option value="admin" {{ old('role', $user->role) === 'admin' ? 'selected' : '' }}>管理员</option>
                @if(auth()->user()?->isSuperAdmin())
                <option value="super_admin" {{ old('role', $user->role) === 'super_admin' ? 'selected' : '' }}>超级管理员</option>
                @endif
            </select>
            @error('role')<p class="text-red-500 text-xs mt-1">{{ $message }}</p>@enderror
        </div>
        <div class="flex items-center gap-3">
            <button type="submit" class="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded-lg transition-colors">保存</button>
            <a href="{{ route('admin.users.index') }}" class="px-5 py-2 border border-gray-300 text-gray-600 text-sm rounded-lg hover:bg-gray-50 transition-colors">取消</a>
        </div>
    </form>
</div>
@endsection

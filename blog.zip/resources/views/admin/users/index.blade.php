@extends('layouts.admin')
@section('title', '用户管理')

@section('content')
<div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-6">
    <h2 class="text-xl font-bold text-gray-800">用户管理</h2>
    <a href="{{ route('admin.users.create') }}" class="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded-lg transition-colors">
        <i class="fa-solid fa-plus mr-2"></i>新增用户
    </a>
</div>

@if(session('success'))
<div class="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg mb-4 text-sm">{{ session('success') }}</div>
@endif
@if(session('error'))
<div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-4 text-sm">{{ session('error') }}</div>
@endif

<div class="bg-white rounded-lg shadow-sm overflow-hidden">
    <table class="w-full text-sm">
        <thead class="bg-gray-50 border-b">
            <tr>
                <th class="px-4 py-3 text-left font-medium text-gray-500">账号</th>
                <th class="px-4 py-3 text-left font-medium text-gray-500 hidden sm:table-cell">邮箱</th>
                <th class="px-4 py-3 text-left font-medium text-gray-500 hidden sm:table-cell">角色</th>
                <th class="px-4 py-3 text-left font-medium text-gray-500 hidden sm:table-cell">注册时间</th>
                <th class="px-4 py-3 text-right font-medium text-gray-500">操作</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-100">
            @forelse($users as $user)
            <tr class="hover:bg-gray-50">
                <td class="px-4 py-3">
                    <span class="font-medium text-gray-800">{{ $user->name }}</span>
                    @if($user->id === auth()->id())<span class="ml-2 text-[10px] bg-blue-100 text-blue-600 px-1.5 py-0.5 rounded">当前</span>@endif
                </td>
                <td class="px-4 py-3 text-gray-500 hidden sm:table-cell">{{ $user->email ?: '-' }}</td>
                <td class="px-4 py-3 hidden sm:table-cell">
                    @if($user->role === 'super_admin')
                        <span class="inline-block px-2 py-0.5 text-xs rounded-full bg-purple-100 text-purple-600">超级管理员</span>
                    @elseif($user->role === 'admin')
                        <span class="inline-block px-2 py-0.5 text-xs rounded-full bg-red-100 text-red-600">管理员</span>
                    @else
                        <span class="inline-block px-2 py-0.5 text-xs rounded-full bg-gray-100 text-gray-600">用户</span>
                    @endif
                </td>
                <td class="px-4 py-3 text-gray-500 hidden sm:table-cell">{{ $user->created_at->format('Y-m-d H:i') }}</td>
                <td class="px-4 py-3 text-right">
                    <a href="{{ route('admin.users.edit', $user) }}" class="text-blue-600 hover:text-blue-800 mr-3">编辑</a>
                    @if($user->id !== auth()->id())
                    <form action="{{ route('admin.users.destroy', $user) }}" method="POST" class="inline" onsubmit="return confirm('确定要删除该用户吗？')">
                        @csrf @method('DELETE')
                        <button type="submit" class="text-red-500 hover:text-red-700">删除</button>
                    </form>
                    @endif
                </td>
            </tr>
            @empty
            <tr><td colspan="5" class="px-4 py-12 text-center text-gray-400">暂无用户</td></tr>
            @endforelse
        </tbody>
    </table>
</div>

<div class="mt-4">{{ $users->links() }}</div>
@endsection

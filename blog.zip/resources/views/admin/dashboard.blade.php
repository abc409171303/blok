@extends('layouts.admin')

@section('page-title', '控制台')

@section('content')
<div>
    <h1 class="text-2xl font-bold text-gray-800 mb-6">控制台</h1>

    @if(($installWizardExists ?? false) && Auth::user()?->isSuperAdmin())
    <div class="mb-6 bg-amber-50 border border-amber-200 rounded-xl p-5">
        <div class="flex flex-col sm:flex-row sm:items-start gap-4">
            <div class="flex items-start gap-3 flex-1">
                <div class="w-10 h-10 shrink-0 bg-amber-100 rounded-lg flex items-center justify-center">
                    <svg class="w-5 h-5 text-amber-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v4m0 4h.01M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/></svg>
                </div>
                <div>
                    <div class="font-semibold text-amber-800">检测到安装向导文件仍存在，存在重复安装风险</div>
                    <div class="text-sm text-amber-700 mt-1">建议移除安装向导程序文件，移除后可有效防止他人重复安装。安装锁文件 install.lock 会被保留。</div>
                </div>
            </div>
            <form action="{{ route('admin.install-wizard.remove') }}" method="POST" onsubmit="return confirm('确定要移除安装向导吗？移除后安装程序将无法再次访问。');" class="shrink-0">
                @csrf
                <button type="submit" class="inline-flex items-center px-4 py-2.5 bg-amber-600 hover:bg-amber-700 text-white text-sm font-medium rounded-lg transition-colors">
                    <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                    一键移除安装向导
                </button>
            </form>
        </div>
    </div>
    @endif

    <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 mb-8">
        <a href="{{ route('admin.posts.index') }}" class="bg-white rounded-xl shadow-sm border border-gray-200 p-5 hover:shadow-md hover:border-blue-300 transition-all block group no-underline">
            <div class="flex items-center justify-between mb-3">
                <div class="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center group-hover:bg-blue-200 transition-colors">
                    <svg class="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z"/></svg>
                </div>
            </div>
            <div class="text-2xl font-bold text-gray-800">{{ $stats['posts'] }}</div>
            <div class="text-sm text-gray-500 mt-0.5">文章</div>
        </a>

        <a href="{{ route('admin.comments.index') }}" class="bg-white rounded-xl shadow-sm border border-gray-200 p-5 hover:shadow-md hover:border-green-300 transition-all block group no-underline">
            <div class="flex items-center justify-between mb-3">
                <div class="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center group-hover:bg-green-200 transition-colors">
                    <svg class="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"/></svg>
                </div>
            </div>
            <div class="text-2xl font-bold text-gray-800">{{ $stats['comments'] }}</div>
            <div class="text-sm text-gray-500 mt-0.5">评论</div>
        </a>

        <a href="{{ route('admin.categories.index') }}" class="bg-white rounded-xl shadow-sm border border-gray-200 p-5 hover:shadow-md hover:border-purple-300 transition-all block group no-underline">
            <div class="flex items-center justify-between mb-3">
                <div class="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center group-hover:bg-purple-200 transition-colors">
                    <svg class="w-5 h-5 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z"/></svg>
                </div>
            </div>
            <div class="text-2xl font-bold text-gray-800">{{ $stats['categories'] }}</div>
            <div class="text-sm text-gray-500 mt-0.5">分类</div>
        </a>

        <a href="{{ route('admin.tags.index') }}" class="bg-white rounded-xl shadow-sm border border-gray-200 p-5 hover:shadow-md hover:border-orange-300 transition-all block group no-underline">
            <div class="flex items-center justify-between mb-3">
                <div class="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center group-hover:bg-orange-200 transition-colors">
                    <svg class="w-5 h-5 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z"/></svg>
                </div>
            </div>
            <div class="text-2xl font-bold text-gray-800">{{ $stats['tags'] }}</div>
            <div class="text-sm text-gray-500 mt-0.5">标签</div>
        </a>

        <a href="{{ route('admin.visits.index') }}" class="bg-white rounded-xl shadow-sm border border-gray-200 p-5 hover:shadow-md hover:border-cyan-300 transition-all block group no-underline">
            <div class="flex items-center justify-between mb-3">
                <div class="w-10 h-10 bg-cyan-100 rounded-lg flex items-center justify-center group-hover:bg-cyan-200 transition-colors">
                    <svg class="w-5 h-5 text-cyan-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
                </div>
            </div>
            <div class="text-2xl font-bold text-gray-800">{{ number_format($stats['views']) }}</div>
            <div class="text-sm text-gray-500 mt-0.5">浏览量</div>
        </a>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <a href="{{ route('admin.posts.create') }}" class="bg-white rounded-xl shadow-sm border border-gray-200 p-5 hover:shadow-md hover:border-blue-300 transition-all group">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center group-hover:bg-blue-200 transition-colors">
                    <svg class="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                </div>
                <div>
                    <div class="font-medium text-gray-800">新建文章</div>
                    <div class="text-sm text-gray-500">创建一篇新的博客文章</div>
                </div>
            </div>
        </a>

        <a href="{{ route('admin.comments.index') }}" class="bg-white rounded-xl shadow-sm border border-gray-200 p-5 hover:shadow-md hover:border-green-300 transition-all group">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center group-hover:bg-green-200 transition-colors">
                    <svg class="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"/></svg>
                </div>
                <div>
                    <div class="font-medium text-gray-800">评论管理</div>
                    <div class="text-sm text-gray-500">审核和管理用户评论</div>
                </div>
            </div>
        </a>

        <a href="{{ route('admin.settings.index') }}" class="bg-white rounded-xl shadow-sm border border-gray-200 p-5 hover:shadow-md hover:border-purple-300 transition-all group">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center group-hover:bg-purple-200 transition-colors">
                    <svg class="w-5 h-5 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.066 2.573c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.573 1.066c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.066-2.573c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                </div>
                <div>
                    <div class="font-medium text-gray-800">站点设置</div>
                    <div class="text-sm text-gray-500">修改博客的基本配置</div>
                </div>
            </div>
        </a>
    </div>

    @isset($server)
    @php
        $serverLeft = [
            ['PHP 版本', $server['php_version'], 'font-mono'],
            ['Laravel 版本', $server['laravel_version'], 'font-mono'],
            ['操作系统', $server['os'], ''],
            ['Web 服务器', $server['server_software'], ''],
            ['上传限制', $server['upload_max'], ''],
        ];
        $serverRight = [
            ['内存限制', $server['memory_limit'] === '-1' ? '不限制' : $server['memory_limit'], 'font-mono'],
            ['最大执行时间', $server['max_execution_time'], 'font-mono'],
            ['服务器时间', $server['server_time'], 'font-mono'],
            ['数据库版本', $server['db_version'], 'font-mono'],
            ['时区', $server['timezone'], ''],
        ];
    @endphp
    <div class="mt-8">
        <h2 class="text-lg font-semibold text-gray-800 mb-4">服务器信息</h2>
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <div class="grid grid-cols-1 md:grid-cols-2">
                {{-- 左列（手机单列显示） --}}
                <div class="divide-y divide-gray-100">
                    @foreach($serverLeft as $row)
                    <div class="flex items-stretch">
                        <div class="w-32 shrink-0 bg-gray-50 px-4 sm:px-5 py-3 text-gray-500">{{ $row[0] }}</div>
                        <div class="flex-1 min-w-0 px-4 sm:px-5 py-3 text-gray-800 break-words {{ $row[2] }}">{{ $row[1] }}</div>
                    </div>
                    @endforeach
                </div>
                {{-- 右列（手机接在左列下方） --}}
                <div class="divide-y divide-gray-100 border-t border-gray-100 md:border-t-0 md:border-l">
                    @foreach($serverRight as $row)
                    <div class="flex items-stretch">
                        <div class="w-32 shrink-0 bg-gray-50 px-4 sm:px-5 py-3 text-gray-500">{{ $row[0] }}</div>
                        <div class="flex-1 min-w-0 px-4 sm:px-5 py-3 text-gray-800 break-words {{ $row[2] }}">{{ $row[1] }}</div>
                    </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
    @endisset
</div>
@endsection

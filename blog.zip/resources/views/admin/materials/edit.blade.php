@extends('layouts.admin')
@section('page-title', '编辑物料')

@section('content')
<h2 class="text-xl font-bold text-gray-800 mb-6">编辑物料</h2>

<div class="bg-white rounded-lg shadow-sm p-6 max-w-2xl">
    <form action="{{ route('admin.materials.update', $material) }}" method="POST">
        @csrf @method('PUT')

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-5">
            <div>
                <label for="name" class="block text-sm font-medium text-gray-700 mb-1.5">物料名称 <span class="text-red-500">*</span></label>
                <input type="text" name="name" id="name" value="{{ old('name', $material->name) }}" required
                    class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                    placeholder="如：A4 打印纸">
                @error('name')<p class="text-red-500 text-xs mt-1">{{ $message }}</p>@enderror
            </div>
            <div>
                <label for="code" class="block text-sm font-medium text-gray-700 mb-1.5">物料编码</label>
                <input type="text" name="code" id="code" value="{{ old('code', $material->code) }}"
                    class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                    placeholder="如：WL-001">
                @error('code')<p class="text-red-500 text-xs mt-1">{{ $message }}</p>@enderror
            </div>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-5">
            <div>
                <label for="specification" class="block text-sm font-medium text-gray-700 mb-1.5">规格型号</label>
                <input type="text" name="specification" id="specification" value="{{ old('specification', $material->specification) }}"
                    class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                    placeholder="如：A4 / 70g / 500张">
                @error('specification')<p class="text-red-500 text-xs mt-1">{{ $message }}</p>@enderror
            </div>
            <div>
                <label for="unit" class="block text-sm font-medium text-gray-700 mb-1.5">单位</label>
                <input type="text" name="unit" id="unit" value="{{ old('unit', $material->unit) }}"
                    class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                    placeholder="如：包、箱、个、千克">
                @error('unit')<p class="text-red-500 text-xs mt-1">{{ $message }}</p>@enderror
            </div>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-5">
            <div>
                <label for="price" class="block text-sm font-medium text-gray-700 mb-1.5">单价（元）</label>
                <input type="number" name="price" id="price" value="{{ old('price', $material->price) }}" min="0" step="0.01"
                    class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none">
                @error('price')<p class="text-red-500 text-xs mt-1">{{ $message }}</p>@enderror
            </div>
            <div>
                <label for="stock" class="block text-sm font-medium text-gray-700 mb-1.5">库存数量</label>
                <input type="number" name="stock" id="stock" value="{{ old('stock', $material->stock) }}" min="0" step="1"
                    class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none">
                @error('stock')<p class="text-red-500 text-xs mt-1">{{ $message }}</p>@enderror
            </div>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-5">
            <div>
                <label for="sort_order" class="block text-sm font-medium text-gray-700 mb-1.5">排序</label>
                <input type="number" name="sort_order" id="sort_order" value="{{ old('sort_order', $material->sort_order) }}" min="0"
                    class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none">
                <p class="text-xs text-gray-400 mt-1">数字越小越靠前</p>
            </div>
            <div class="flex items-center pt-6">
                <label class="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" name="status" value="1" {{ old('status', $material->status) ? 'checked' : '' }}
                        class="rounded border-gray-300 text-blue-600 focus:ring-blue-500">
                    <span class="text-sm text-gray-700">启用</span>
                </label>
            </div>
        </div>

        <div class="mb-5">
            <label for="remark" class="block text-sm font-medium text-gray-700 mb-1.5">备注</label>
            <textarea name="remark" id="remark" rows="3"
                class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                placeholder="补充说明（可选）">{{ old('remark', $material->remark) }}</textarea>
            @error('remark')<p class="text-red-500 text-xs mt-1">{{ $message }}</p>@enderror
        </div>

        <div class="flex items-center gap-3">
            <button type="submit" class="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded-lg transition-colors">保存</button>
            <a href="{{ route('admin.materials.index') }}" class="px-5 py-2 border border-gray-300 text-gray-600 text-sm rounded-lg hover:bg-gray-50 transition-colors">取消</a>
        </div>
    </form>
</div>
@endsection

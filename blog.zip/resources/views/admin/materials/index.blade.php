@extends('layouts.admin')
@section('page-title', '物料管理')

@section('content')
<div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-6">
    <h2 class="text-xl font-bold text-gray-800">物料管理</h2>
    <a href="{{ route('admin.materials.create') }}" class="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded-lg transition-colors">
        <i class="fa-solid fa-plus mr-2"></i>新增物料
    </a>
</div>

@if(session('success'))
<div class="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg mb-4 text-sm">{{ session('success') }}</div>
@endif

<div class="bg-white rounded-lg shadow-sm overflow-hidden">
    <div class="overflow-x-auto">
        <table class="w-full text-sm min-w-[640px]">
            <thead class="bg-gray-50 border-b">
                <tr>
                    <th class="px-4 py-3 text-left font-medium text-gray-500">物料名称</th>
                    <th class="px-4 py-3 text-left font-medium text-gray-500 hidden sm:table-cell">编码</th>
                    <th class="px-4 py-3 text-left font-medium text-gray-500 hidden md:table-cell">规格型号</th>
                    <th class="px-4 py-3 text-left font-medium text-gray-500 hidden sm:table-cell">单位</th>
                    <th class="px-4 py-3 text-left font-medium text-gray-500">单价</th>
                    <th class="px-4 py-3 text-left font-medium text-gray-500">库存</th>
                    <th class="px-4 py-3 text-left font-medium text-gray-500 hidden sm:table-cell">状态</th>
                    <th class="px-4 py-3 text-right font-medium text-gray-500">操作</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                @forelse($materials as $material)
                <tr class="hover:bg-gray-50">
                    <td class="px-4 py-3">
                        <div class="font-medium text-gray-800">{{ $material->name }}</div>
                        @if($material->remark)<div class="text-xs text-gray-400 mt-0.5 max-w-[200px] truncate">{{ $material->remark }}</div>@endif
                    </td>
                    <td class="px-4 py-3 text-gray-500 hidden sm:table-cell">{{ $material->code ?: '-' }}</td>
                    <td class="px-4 py-3 text-gray-500 hidden md:table-cell max-w-[150px] truncate">{{ $material->specification ?: '-' }}</td>
                    <td class="px-4 py-3 text-gray-500 hidden sm:table-cell">{{ $material->unit ?: '-' }}</td>
                    <td class="px-4 py-3 text-gray-700">{{ number_format($material->price, 2) }}</td>
                    <td class="px-4 py-3">
                        <span class="{{ $material->stock <= 0 ? 'text-red-500 font-medium' : 'text-gray-700' }}">{{ $material->stock }}</span>
                    </td>
                    <td class="px-4 py-3 hidden sm:table-cell">
                        <span class="inline-block px-2 py-0.5 text-xs rounded-full {{ $material->status ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-500' }}">
                            {{ $material->status ? '启用' : '停用' }}
                        </span>
                    </td>
                    <td class="px-4 py-3 text-right whitespace-nowrap">
                        <a href="{{ route('admin.materials.edit', $material) }}" class="text-blue-600 hover:text-blue-800 mr-3">编辑</a>
                        <form action="{{ route('admin.materials.destroy', $material) }}" method="POST" class="inline" onsubmit="return confirm('确定要删除该物料吗？')">
                            @csrf @method('DELETE')
                            <button type="submit" class="text-red-500 hover:text-red-700">删除</button>
                        </form>
                    </td>
                </tr>
                @empty
                <tr><td colspan="8" class="px-4 py-12 text-center text-gray-400">暂无物料</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
<div class="mt-4">{{ $materials->links() }}</div>
@endsection

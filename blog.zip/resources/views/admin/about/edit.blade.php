@extends('layouts.admin')
@section('page-title', '关于博主')

@push('styles')
<link rel="stylesheet" href="{{ asset('static/vditor/index.css') }}?v=3.11.2">
<style>
.vditor { border: none !important; }
.vditor-toolbar {
    background: #f9fafb !important;
    padding: 8px !important;
    border-radius: 8px 8px 0 0 !important;
    border-bottom: 1px solid #e5e7eb !important;
}
.vditor-content { border: none !important; min-height: 500px !important; }
.vditor-wysiwyg { border: none !important; padding: 16px !important; }
/* 编辑器内容区：段落紧贴左边缘，无缩进留白 */
#vditor .vditor-reset { padding-left: 0 !important; }
#vditor .vditor-reset p { text-indent: 0 !important; margin-left: 0 !important; padding-left: 0 !important; }
#vditor .vditor-reset blockquote { margin-left: 0 !important; padding-left: 1em !important; border-left: 3px solid #e5e7eb !important; }
</style>
@endpush

@section('content')
<div>
    <div class="flex items-center justify-between mb-6">
        <h1 class="text-2xl font-bold text-gray-800">关于博主</h1>
    </div>

    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <form action="{{ route('admin.about.update') }}" method="POST" id="about-form">
            @csrf
            @method('PUT')

            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-2">博主介绍内容</label>
                {{-- about_content 为 HTML：直接放入挂载元素，Vditor 在 value 为空时经 HTML2Md 渲染 --}}
                <div id="vditor">{!! $config->about_content !!}</div>
                <textarea name="about_content" id="about_content" class="hidden">{{ old('about_content', $config->about_content) }}</textarea>
                @error('about_content')<p class="mt-1 text-sm text-red-500">{{ $message }}</p>@enderror
            </div>

            <div class="flex items-center gap-3 pt-4 border-t border-gray-200">
                <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2.5 rounded-lg text-sm font-medium transition-colors">保存</button>
            </div>
        </form>
    </div>
</div>

{{-- 本地 Vditor 资源（已下载到 public/static/vditor，禁用外网 CDN）--}}
{{-- 提前加载并解析 lute（4MB WASM），带 vditorLuteScript ID 使 Vditor 跳过动态加载，工具栏秒出 --}}
<link rel="preload" as="script" href="{{ asset('static/vditor/dist/js/lute/lute.min.js') }}?v=3.11.2">
<script src="{{ asset('static/vditor/dist/js/lute/lute.min.js') }}?v=3.11.2" id="vditorLuteScript"
    onerror="window.__vditorLuteFail = true;"></script>
<script src="{{ asset('static/vditor/index.min.js') }}?v=3.11.2"
    onerror="window.__vditorMainFail = true;"></script>
<script src="{{ asset('js/vditor-common.js') }}?v={{ filemtime(public_path('js/vditor-common.js')) }}"></script>
<script>
window.BlogVditor.routes = {
    aiWrite: '{{ route("admin.ai.write") }}',
    aiImage: '{{ route("admin.ai.generateImage") }}',
};

// Vditor 统一初始化（工具栏配置与文章创建/编辑页一致）
// 注意：about_content 存储的是 HTML，已直接放入 #vditor 挂载元素，
// value 为空时 Vditor 自动将其经 HTML2Md 转换渲染（勿传 value，否则 HTML 会被当 markdown 转义）
window.BlogVditor.init({
    id: 'vditor',
    height: 500,
    placeholder: '写点什么介绍自己...',
    uploadUrl: '{{ route("admin.upload.image") }}',
    uploadFieldName: 'image',
    formId: 'about-form',
    outputEl: 'about_content',
    outputType: 'html'
});
</script>
@endsection

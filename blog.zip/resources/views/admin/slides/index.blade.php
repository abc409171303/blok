@extends('layouts.admin')
@section('page-title', '幻灯片管理')

@section('content')
<div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-6">
    <h2 class="text-xl font-bold text-gray-800">幻灯片管理</h2>
    <a href="{{ route('admin.slides.create') }}" class="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded-lg transition-colors">
        <i class="fa-solid fa-plus mr-2"></i>新增幻灯片
    </a>
</div>

@if(session('success'))
<div class="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg mb-4 text-sm">{{ session('success') }}</div>
@endif

<div class="bg-white rounded-lg shadow-sm overflow-hidden">
    <table class="w-full text-sm">
        <thead class="bg-gray-50 border-b">
            <tr>
                <th class="px-4 py-3 text-left font-medium text-gray-500">图片</th>
                <th class="px-4 py-3 text-left font-medium text-gray-500">标题</th>
                <th class="px-4 py-3 text-left font-medium text-gray-500 hidden sm:table-cell">位置</th>
                <th class="px-4 py-3 text-left font-medium text-gray-500 hidden sm:table-cell">链接</th>
                <th class="px-4 py-3 text-left font-medium text-gray-500 hidden sm:table-cell">状态</th>
                <th class="px-4 py-3 text-right font-medium text-gray-500">操作</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-100">
            @forelse($slides as $slide)
            <tr class="hover:bg-gray-50">
                <td class="px-4 py-3">
                    @if($slide->image)
                    <img src="{{ $slide->image_url }}" class="w-24 h-14 object-cover rounded" alt="">
                    @else
                    <span class="text-gray-400">-</span>
                    @endif
                </td>
                <td class="px-4 py-3">
                    <div class="font-medium text-gray-800">{{ $slide->title }}</div>
                    @if($slide->subtitle)<div class="text-xs text-gray-400 mt-0.5">{{ Str::limit($slide->subtitle, 30) }}</div>@endif
                </td>
                <td class="px-4 py-3 text-gray-500 hidden sm:table-cell">{{ $slide->position ?: '首页顶部轮播' }}</td>
                <td class="px-4 py-3 text-gray-500 hidden sm:table-cell max-w-[150px] truncate">{{ $slide->link_url ?: '-' }}</td>
                <td class="px-4 py-3 hidden sm:table-cell">
                    <span class="inline-block px-2 py-0.5 text-xs rounded-full {{ $slide->status ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-500' }}">
                        {{ $slide->status ? '显示' : '隐藏' }}
                    </span>
                </td>
                <td class="px-4 py-3 text-right">
                    <a href="{{ route('admin.slides.edit', $slide) }}" class="text-blue-600 hover:text-blue-800 mr-3">编辑</a>
                    <form action="{{ route('admin.slides.destroy', $slide) }}" method="POST" class="inline" onsubmit="return confirm('确定要删除该幻灯片吗？')">
                        @csrf @method('DELETE')
                        <button type="submit" class="text-red-500 hover:text-red-700">删除</button>
                    </form>
                </td>
            </tr>
            @empty
            <tr><td colspan="6" class="px-4 py-12 text-center text-gray-400">暂无幻灯片</td></tr>
            @endforelse
        </tbody>
    </table>
</div>
<div class="mt-4">{{ $slides->links() }}</div>
@endsection

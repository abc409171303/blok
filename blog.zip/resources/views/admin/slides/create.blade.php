@extends('layouts.admin')
@section('page-title', '新增幻灯片')

@section('content')
<div x-data="slideEditor()">
<h2 class="text-xl font-bold text-gray-800 mb-6">新增幻灯片</h2>

<div class="bg-white rounded-lg shadow-sm p-8 max-w-4xl">
    <form action="{{ route('admin.slides.store') }}" method="POST" enctype="multipart/form-data">
        @csrf

        <div class="grid grid-cols-1 md:grid-cols-2 gap-5 mb-4">
            <div class="md:col-span-1">
                <label for="title" class="block text-sm font-medium text-gray-700 mb-1.5">标题 <span class="text-red-500">*</span></label>
                <input type="text" name="title" id="title" value="{{ old('title') }}" required
                    class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                    placeholder="幻灯片标题">
                @error('title')<p class="text-red-500 text-xs mt-1">{{ $message }}</p>@enderror
            </div>
            <div class="md:col-span-1">
                <label for="subtitle" class="block text-sm font-medium text-gray-700 mb-1.5">副标题</label>
                <input type="text" name="subtitle" id="subtitle" value="{{ old('subtitle') }}"
                    class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                    placeholder="幻灯片副标题或描述">
                @error('subtitle')<p class="text-red-500 text-xs mt-1">{{ $message }}</p>@enderror
            </div>
        </div>

        <div class="mb-4">
            <label for="link_url" class="block text-sm font-medium text-gray-700 mb-1.5">链接地址</label>
            <input type="text" name="link_url" id="link_url" value="{{ old('link_url') }}"
                class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                placeholder="点击跳转链接，留空则不跳转">
            @error('link_url')<p class="text-red-500 text-xs mt-1">{{ $message }}</p>@enderror
        </div>

        <div class="mb-5">
            <label class="block text-sm font-medium text-gray-700 mb-2">内容类型</label>
            <div class="grid grid-cols-2 gap-3 max-w-xs">
                <button type="button" @click="contentType = 'image'" :class="contentType === 'image' ? 'border-blue-500 ring-2 ring-blue-200' : 'border-gray-300'"
                    class="px-4 py-3 rounded-lg border-2 text-sm font-medium transition-all">图片</button>
                <button type="button" @click="contentType = 'video'" :class="contentType === 'video' ? 'border-blue-500 ring-2 ring-blue-200' : 'border-gray-300'"
                    class="px-4 py-3 rounded-lg border-2 text-sm font-medium transition-all">视频</button>
            </div>
        </div>

        <div x-show="contentType === 'image'" class="mb-4">
            <label class="block text-sm font-medium text-gray-700 mb-1.5">背景图片</label>
            <div class="mb-2">
                <button type="button" onclick="window.openMediaSelector('slide_image')"
                    class="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 text-sm rounded-lg transition-colors">
                    从文件库选择
                </button>
                <input type="hidden" name="image_path" id="image_path" value="{{ old('image_path', '') }}">
            </div>
            <div class="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-blue-400 transition-colors cursor-pointer" id="image-dropzone">
                <input type="file" name="image" id="image" accept="image/*"
                    class="hidden" onchange="previewFile(this)">
                <div id="image-placeholder" class="flex flex-col items-center gap-2">
                    <svg class="w-12 h-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                    <span class="text-sm text-gray-500">点击上传图片</span>
                    <span class="text-xs text-gray-400">建议尺寸 1200x480</span>
                </div>
                <img id="image-preview-img" class="hidden max-h-48 mx-auto rounded" src="" alt="">
            </div>
            @error('image')<p class="text-red-500 text-xs mt-1">{{ $message }}</p>@enderror
        </div>

        <div x-show="contentType === 'video'" class="mb-4" style="display: none;">
            <label for="video_url" class="block text-sm font-medium text-gray-700 mb-1.5">视频 URL <span class="text-red-500">*</span></label>
            <input type="text" name="video_url" id="video_url"
                class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                placeholder="https://example.com/video.mp4 或 B 站视频地址">
            <p class="text-xs text-gray-400 mt-1">支持 MP4 文件或 B 站视频嵌入地址</p>
            @error('video_url')<p class="text-red-500 text-xs mt-1">{{ $message }}</p>@enderror

            <div class="mt-4">
                <label class="block text-sm font-medium text-gray-700 mb-1.5">视频封面图</label>
                <div class="mb-2">
                    <button type="button" onclick="window.openMediaSelector('slide_video_cover')"
                        class="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 text-sm rounded-lg transition-colors">
                        从文件库选择
                    </button>
                    <input type="hidden" name="video_cover_path" id="video_cover_path" value="{{ old('video_cover_path', '') }}">
                </div>
                <div class="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-blue-400 transition-colors cursor-pointer" id="video-cover-dropzone">
                    <input type="file" name="video_cover" id="video_cover" accept="image/*"
                        class="hidden" onchange="previewVideoCover(this)">
                    <div id="video-cover-placeholder" class="flex flex-col items-center gap-2">
                        <svg class="w-12 h-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                        <span class="text-sm text-gray-500">点击上传封面图</span>
                    </div>
                    <img id="video-cover-preview" class="hidden max-h-48 mx-auto rounded" src="" alt="">
                </div>
                @error('video_cover')<p class="text-red-500 text-xs mt-1">{{ $message }}</p>@enderror
            </div>
        </div>

        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-5">
            <div>
                <label for="position" class="block text-sm font-medium text-gray-700 mb-1.5">位置</label>
                <input type="text" name="position" id="position" value="{{ old('position', '首页顶部轮播') }}"
                    class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                    placeholder="如：首页顶部轮播">
            </div>
            <div>
                <label for="bg_color" class="block text-sm font-medium text-gray-700 mb-1.5">背景色</label>
                <div class="flex items-center gap-2">
                    <input type="color" name="bg_color" id="bg_color" value="{{ old('bg_color', '#1f2937') }}"
                        class="w-10 h-10 rounded border border-gray-300 cursor-pointer p-0.5"
                        oninput="document.getElementById('bg-color-text').textContent=this.value">
                    <span class="text-xs text-gray-500" id="bg-color-text">{{ old('bg_color', '#1f2937') }}</span>
                    <button type="button" onclick="clearBgColor()"
                        class="px-2 py-1 text-xs text-gray-400 hover:text-red-500 border border-gray-200 hover:border-red-200 rounded transition-colors" title="清空背景色">
                        清空
                    </button>
                </div>
            </div>
            <div>
                <label for="sort_order" class="block text-sm font-medium text-gray-700 mb-1.5">排序</label>
                <input type="number" name="sort_order" id="sort_order" value="{{ old('sort_order', 0) }}" min="0"
                    class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none">
                <p class="text-xs text-gray-400 mt-1">数字越小越靠前</p>
            </div>
            <div class="flex items-end pb-1">
                <label class="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" name="status" value="1" {{ old('status', true) ? 'checked' : '' }}
                        class="rounded border-gray-300 text-blue-600 focus:ring-blue-500 w-4 h-4">
                    <span class="text-sm text-gray-700">启用显示</span>
                </label>
            </div>
        </div>

        <div class="flex items-center gap-3 pt-2 border-t border-gray-100">
            <button type="submit" class="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded-lg transition-colors font-medium">保存</button>
            <a href="{{ route('admin.slides.index') }}" class="px-6 py-2.5 border border-gray-300 text-gray-600 text-sm rounded-lg hover:bg-gray-50 transition-colors">取消</a>
        </div>
    </form>
</div>
</div>

<input type="hidden" name="has_image" id="has_image" value="0">
<input type="hidden" name="image_data_url" id="image_data_url" value="">

<x-media-selector editor-id="slide"/>

<script>
document.addEventListener('alpine:init', () => {
    Alpine.data('slideEditor', () => ({
        contentType: 'image',
    }));
});

function previewFile(input) {
    const placeholder = document.getElementById('image-placeholder');
    const previewImg = document.getElementById('image-preview-img');
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            previewImg.src = e.target.result;
            previewImg.classList.remove('hidden');
            placeholder.classList.add('hidden');
        };
        reader.readAsDataURL(input.files[0]);
    }
}
document.getElementById('image-dropzone')?.addEventListener('click', function(e) {
    if (e.target.tagName !== 'IMG') document.getElementById('image').click();
});

function previewVideoCover(input) {
    const placeholder = document.getElementById('video-cover-placeholder');
    const previewImg = document.getElementById('video-cover-preview');
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            previewImg.src = e.target.result;
            previewImg.classList.remove('hidden');
            placeholder.classList.add('hidden');
        };
        reader.readAsDataURL(input.files[0]);
    }
}
document.getElementById('video-cover-dropzone')?.addEventListener('click', function(e) {
    if (e.target.tagName !== 'IMG') document.getElementById('video_cover').click();
});

// 从文件库选择后填充对应字段
window.addEventListener('media-selected', function(event) {
    const field = event.detail.field;
    const file = event.detail.file;
    if (!file) return;

    if (field === 'slide_image') {
        document.getElementById('image_path').value = file.file_path || '';
        const previewImg = document.getElementById('image-preview-img');
        if (previewImg) {
            previewImg.src = file.url;
            previewImg.classList.remove('hidden');
            document.getElementById('image-placeholder').classList.add('hidden');
            document.getElementById('has_image').value = '1';
        }
    } else if (field === 'slide_video_cover') {
        document.getElementById('video_cover_path').value = file.file_path || '';
        const previewImg = document.getElementById('video-cover-preview');
        if (previewImg) {
            previewImg.src = file.url;
            previewImg.classList.remove('hidden');
            document.getElementById('video-cover-placeholder').classList.add('hidden');
        }
    }
});

function clearBgColor() {
    const input = document.getElementById('bg_color');
    const text = document.getElementById('bg-color-text');
    input.value = '';
    text.textContent = '已清空';
    text.className = 'text-xs text-gray-400';
}
</script>
@endsection

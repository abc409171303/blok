@extends('layouts.admin')
@section('page-title', '导航管理')

@section('content')
<div id="app-navigation-manager"></div>
@endsection

@push('scripts')
@vite(['resources/js/app.js'])
<script>
// 等待 Vue 应用挂载后，再挂载导航管理组件
window.addEventListener('DOMContentLoaded', function() {
    if (window.app && window.app.config && window.app.config.globalProperties) {
        // Vue 应用已经初始化，现在挂载我们的组件
        import('/resources/js/views/admin/NavigationManager.vue').then(module => {
            // 这里需要根据实际的 Vue 应用配置来挂载
            console.log('Navigation Manager loaded');
        });
    }
});
</script>
@endpush

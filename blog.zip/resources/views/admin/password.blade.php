@extends('layouts.admin')
@section('title', '修改密码')

@section('content')
<h2 class="text-xl font-bold text-gray-800 mb-6">修改密码</h2>

<div class="bg-white rounded-lg shadow-sm p-6 max-w-lg">
    <form action="{{ route('admin.password.update') }}" method="POST">
        @csrf
        <div class="mb-4">
            <label for="current_password" class="block text-sm font-medium text-gray-700 mb-1.5">当前密码 <span class="text-red-500">*</span></label>
            <input type="password" name="current_password" id="current_password" required autocomplete="current-password"
                class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                placeholder="请输入当前密码">
            @error('current_password')<p class="text-red-500 text-xs mt-1">{{ $message }}</p>@enderror
        </div>
        <div class="mb-4">
            <label for="password" class="block text-sm font-medium text-gray-700 mb-1.5">新密码 <span class="text-red-500">*</span></label>
            <input type="password" name="password" id="password" required autocomplete="new-password" minlength="6"
                class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                placeholder="至少 6 位">
            @error('password')<p class="text-red-500 text-xs mt-1">{{ $message }}</p>@enderror
        </div>
        <div class="mb-5">
            <label for="password_confirmation" class="block text-sm font-medium text-gray-700 mb-1.5">确认新密码 <span class="text-red-500">*</span></label>
            <input type="password" name="password_confirmation" id="password_confirmation" required autocomplete="new-password" minlength="6"
                class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                placeholder="再次输入新密码">
        </div>
        <div class="flex items-center gap-3">
            <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-lg text-sm font-medium transition-colors">确认修改</button>
            <a href="{{ route('admin.dashboard') }}" class="px-5 py-2 border border-gray-300 text-gray-700 rounded-lg text-sm font-medium hover:bg-gray-50 transition-colors">取消</a>
        </div>
    </form>
</div>
@endsection

@extends('layouts.admin')
@section('title', '管理日志')

@section('content')
<div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-6">
    <h2 class="text-xl font-bold text-gray-800">管理日志</h2>
    @if($logs->total() > 0)
    <form action="{{ route('admin.logs.clear') }}" method="POST" onsubmit="return confirm('确定要清空所有日志吗？此操作不可恢复。')">
        @csrf
        <button type="submit" class="inline-flex items-center px-4 py-2 bg-red-500 hover:bg-red-600 text-white text-sm rounded-lg transition-colors">
            <i class="fa-solid fa-trash-can mr-2"></i>清空日志
        </button>
    </form>
    @endif
</div>

@if(session('success'))
<div class="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg mb-4 text-sm">{{ session('success') }}</div>
@endif

<form method="GET" class="mb-4 flex flex-wrap gap-3">
    <select name="user_id" class="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none">
        <option value="">全部用户</option>
        @foreach($logs->whereNotNull('user')->unique('user_id') as $u)
        <option value="{{ $u->user_id }}" {{ request('user_id') == $u->user_id ? 'selected' : '' }}>{{ $u->user?->name ?? '未知' }}</option>
        @endforeach
    </select>
    <select name="action" class="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none">
        <option value="">全部操作</option>
        @foreach($actions as $a)
        <option value="{{ $a }}" {{ request('action') == $a ? 'selected' : '' }}>{{ $a }}</option>
        @endforeach
    </select>
    <button type="submit" class="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded-lg transition-colors">筛选</button>
    <a href="{{ route('admin.logs.index') }}" class="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-600 text-sm rounded-lg transition-colors">重置</a>
</form>

<div class="bg-white rounded-lg shadow-sm overflow-hidden">
    <table class="w-full text-sm">
        <thead class="bg-gray-50 border-b">
            <tr>
                <th class="px-4 py-3 text-left font-medium text-gray-500 w-16">操作</th>
                <th class="px-4 py-3 text-left font-medium text-gray-500">描述</th>
                <th class="px-4 py-3 text-left font-medium text-gray-500 w-24 hidden sm:table-cell">操作人</th>
                <th class="px-4 py-3 text-left font-medium text-gray-500 w-32 hidden md:table-cell">IP 地址</th>
                <th class="px-4 py-3 text-left font-medium text-gray-500 w-40 hidden lg:table-cell">时间</th>
                <th class="px-4 py-3 text-right font-medium text-gray-500 w-20">操作</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-100">
            @forelse($logs as $log)
            <tr class="hover:bg-gray-50">
                <td class="px-4 py-3">
                    @php
                        $actionColors = [
                            '创建' => 'bg-green-100 text-green-700',
                            '更新' => 'bg-blue-100 text-blue-700',
                            '删除' => 'bg-red-100 text-red-700',
                            '登录' => 'bg-yellow-100 text-yellow-700',
                            '退出' => 'bg-gray-100 text-gray-700',
                            '设置' => 'bg-purple-100 text-purple-700',
                        ];
                        $colorClass = $actionColors[$log->action] ?? 'bg-gray-100 text-gray-700';
                    @endphp
                    <span class="inline-block px-2 py-0.5 text-xs rounded-full {{ $colorClass }}">{{ $log->action }}</span>
                </td>
                <td class="px-4 py-3 text-gray-700">{{ $log->description ?? '-' }}</td>
                <td class="px-4 py-3 text-gray-500 hidden sm:table-cell">{{ $log->user?->name ?? '系统' }}</td>
                <td class="px-4 py-3 text-gray-400 hidden md:table-cell">{{ $log->ip_address ?? '-' }}</td>
                <td class="px-4 py-3 text-gray-400 hidden lg:table-cell">{{ $log->created_at->format('Y-m-d H:i:s') }}</td>
                <td class="px-4 py-3 text-right">
                    <form action="{{ route('admin.logs.destroy', $log) }}" method="POST" onsubmit="return confirm('确定要删除这条日志吗？')">
                        @csrf @method('DELETE')
                        <button type="submit" class="text-red-400 hover:text-red-600 text-xs">删除</button>
                    </form>
                </td>
            </tr>
            @empty
            <tr><td colspan="6" class="px-4 py-12 text-center text-gray-400">暂无日志记录</td></tr>
            @endforelse
        </tbody>
    </table>
</div>

<div class="mt-4">{{ $logs->appends(request()->except('page'))->links() }}</div>
@endsection

@extends('layouts.admin')

@section('page-title', '图片压缩')

@section('content')
<div>
    <h1 class="text-2xl font-bold text-gray-800 dark:text-white mb-6">图片压缩</h1>

    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <form action="{{ route('admin.settings.image-compress.update') }}" method="POST">
            @csrf

            <div class="space-y-8">
                <div>
                    <h2 class="text-lg font-semibold text-gray-800 dark:text-white mb-4 pb-2 border-b border-gray-200 dark:border-gray-700">压缩规则</h2>
                    <p class="text-sm text-gray-500 dark:text-gray-400 mb-6">发布文章时上传的图片会按以下规则自动压缩，GIF 动图和 SVG 不会处理。</p>

                    <div class="space-y-6">
                        <div class="flex items-center justify-between max-w-xl py-2">
                            <div>
                                <p class="text-sm font-medium text-gray-700 dark:text-gray-300">启用图片压缩</p>
                                <p class="text-xs text-gray-400 mt-0.5">关闭后上传图片将保持原图</p>
                            </div>
                            <label class="relative inline-flex items-center cursor-pointer">
                                <input type="checkbox" name="image_compress_enabled" value="1" class="sr-only peer"
                                    {{ old('image_compress_enabled', $config->image_compress_enabled ?? true) ? 'checked' : '' }}>
                                <div class="w-11 h-6 bg-gray-200 dark:bg-gray-600 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border after:border-gray-300 after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                            </label>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-3xl">
                            <div>
                                <label for="image_compress_quality" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">压缩质量（1-100）</label>
                                <input type="number" name="image_compress_quality" id="image_compress_quality" min="1" max="100"
                                    value="{{ old('image_compress_quality', $config->image_compress_quality ?? 80) }}"
                                    class="w-full px-4 py-2.5 border border-gray-300 dark:border-gray-600 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none bg-white dark:bg-gray-700 text-gray-900 dark:text-white">
                                <p class="text-xs text-gray-400 mt-1">数值越低体积越小，画质也会下降，建议 70-85</p>
                                @error('image_compress_quality')
                                    <p class="text-xs text-red-500 mt-1">{{ $message }}</p>
                                @enderror
                            </div>
                            <div>
                                <label for="image_compress_max_kb" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">目标大小（KB）</label>
                                <input type="number" name="image_compress_max_kb" id="image_compress_max_kb" min="0" max="10240"
                                    value="{{ old('image_compress_max_kb', $config->image_compress_max_kb ?? 0) }}"
                                    class="w-full px-4 py-2.5 border border-gray-300 dark:border-gray-600 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none bg-white dark:bg-gray-700 text-gray-900 dark:text-white">
                                <p class="text-xs text-gray-400 mt-1">超过该体积时继续降低质量；填 0 表示不限制</p>
                                @error('image_compress_max_kb')
                                    <p class="text-xs text-red-500 mt-1">{{ $message }}</p>
                                @enderror
                            </div>
                            <div>
                                <label for="image_compress_max_width" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">最大宽度（px）</label>
                                <input type="number" name="image_compress_max_width" id="image_compress_max_width" min="0" max="10000"
                                    value="{{ old('image_compress_max_width', $config->image_compress_max_width ?? 1920) }}"
                                    class="w-full px-4 py-2.5 border border-gray-300 dark:border-gray-600 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none bg-white dark:bg-gray-700 text-gray-900 dark:text-white">
                                <p class="text-xs text-gray-400 mt-1">超出后按比例缩小；填 0 表示不限制宽度</p>
                                @error('image_compress_max_width')
                                    <p class="text-xs text-red-500 mt-1">{{ $message }}</p>
                                @enderror
                            </div>
                            <div>
                                <label for="image_compress_max_height" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">最大高度（px）</label>
                                <input type="number" name="image_compress_max_height" id="image_compress_max_height" min="0" max="10000"
                                    value="{{ old('image_compress_max_height', $config->image_compress_max_height ?? 1920) }}"
                                    class="w-full px-4 py-2.5 border border-gray-300 dark:border-gray-600 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none bg-white dark:bg-gray-700 text-gray-900 dark:text-white">
                                <p class="text-xs text-gray-400 mt-1">超出后按比例缩小；填 0 表示不限制高度</p>
                                @error('image_compress_max_height')
                                    <p class="text-xs text-red-500 mt-1">{{ $message }}</p>
                                @enderror
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="flex items-center gap-3 mt-8 pt-6 border-t border-gray-200 dark:border-gray-700">
                <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2.5 rounded-lg text-sm font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 dark:focus:ring-offset-gray-900">
                    保存设置
                </button>
            </div>
        </form>
    </div>
</div>
@endsection

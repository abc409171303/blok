@extends('layouts.admin')

@section('page-title', '站点外观')

@section('content')
<div>
    <h1 class="text-2xl font-bold text-gray-800 dark:text-white mb-6">站点外观</h1>

    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <form action="{{ route('admin.settings.appearance.update') }}" method="POST" enctype="multipart/form-data">
            @csrf

            <div class="space-y-8">
                <!-- 视觉资源 -->
                <div>
                    <h2 class="text-lg font-semibold text-gray-800 dark:text-white mb-4 pb-2 border-b border-gray-200 dark:border-gray-700">视觉资源</h2>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 items-stretch">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">站点 Logo</label>
                            <div class="mb-2">
                                <button type="button" onclick="window.openMediaSelector('site_logo')"
                                    class="px-3 py-1.5 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-300 text-xs rounded-lg transition-colors">
                                    从文件库选择
                                </button>
                                <input type="hidden" name="site_logo_path" id="site_logo_path" value="{{ old('site_logo_path', $config->site_logo ?? '') }}">
                            </div>
                            <div class="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-4 h-36 flex items-center justify-center text-center hover:border-blue-400 dark:hover:border-blue-500 transition-colors cursor-pointer overflow-hidden" id="logo-dropzone">
                                <input type="file" name="site_logo" id="site_logo" accept="image/jpeg,image/png,image/jpg,image/gif,image/webp"
                                    class="hidden" onchange="previewFile(this, 'logo-preview-img', 'logo-placeholder')">
                                @php $logoExists = !empty($config->site_logo); @endphp
                                <div id="logo-placeholder" class="flex flex-col items-center gap-2 {{ $logoExists ? 'hidden' : '' }}">
                                    <svg class="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                                    <span class="text-sm text-gray-500 dark:text-gray-400">点击上传 Logo</span>
                                </div>
                                <img id="logo-preview-img"
                                    src="{{ $config->site_logo ? Storage::url($config->site_logo) : '' }}"
                                    class="max-h-28 max-w-full object-contain rounded {{ $logoExists ? '' : 'hidden' }}" alt="Logo">
                            </div>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">站点 Favicon</label>
                            <div class="mb-2">
                                <button type="button" onclick="window.openMediaSelector('site_favicon')"
                                    class="px-3 py-1.5 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-300 text-xs rounded-lg transition-colors">
                                    从文件库选择
                                </button>
                                <input type="hidden" name="site_favicon_path" id="site_favicon_path" value="{{ old('site_favicon_path', $config->site_favicon ?? '') }}">
                            </div>
                            <div class="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-4 h-36 flex items-center justify-center text-center hover:border-blue-400 dark:hover:border-blue-500 transition-colors cursor-pointer overflow-hidden" id="favicon-dropzone">
                                <input type="file" name="site_favicon" id="site_favicon" accept="image/x-icon,image/png"
                                    class="hidden" onchange="previewFile(this, 'favicon-preview-img', 'favicon-placeholder')">
                                @php $faviconExists = !empty($config->site_favicon); @endphp
                                <div id="favicon-placeholder" class="flex flex-col items-center gap-2 {{ $faviconExists ? 'hidden' : '' }}">
                                    <svg class="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                                    <span class="text-sm text-gray-500 dark:text-gray-400">点击上传 Favicon</span>
                                </div>
                                <img id="favicon-preview-img"
                                    src="{{ $config->site_favicon ? Storage::url($config->site_favicon) : '' }}"
                                    class="max-h-28 max-w-full object-contain rounded {{ $faviconExists ? '' : 'hidden' }}" alt="Favicon">
                            </div>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">联系二维码</label>
                            <div class="mb-2">
                                <button type="button" onclick="window.openMediaSelector('contact_qrcode')"
                                    class="px-3 py-1.5 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-300 text-xs rounded-lg transition-colors">
                                    从文件库选择
                                </button>
                                <input type="hidden" name="contact_qrcode_path" id="contact_qrcode_path" value="{{ old('contact_qrcode_path', $config->contact_qrcode ?? '') }}">
                            </div>
                            <div class="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-4 h-36 flex items-center justify-center text-center hover:border-blue-400 dark:hover:border-blue-500 transition-colors cursor-pointer overflow-hidden" id="qrcode-dropzone">
                                <input type="file" name="contact_qrcode" id="contact_qrcode" accept="image/jpeg,image/png,image/jpg,image/gif"
                                    class="hidden" onchange="previewFile(this, 'qrcode-preview-img', 'qrcode-placeholder')">
                                @php $qrcodeExists = !empty($config->contact_qrcode); @endphp
                                <div id="qrcode-placeholder" class="flex flex-col items-center gap-2 {{ $qrcodeExists ? 'hidden' : '' }}">
                                    <svg class="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 4v1m6 11h2m-6 0h-2.48a2.5 2.5 0 00-4.76 0H4m16 0h2"/></svg>
                                    <span class="text-sm text-gray-500 dark:text-gray-400">点击上传二维码</span>
                                </div>
                                <img id="qrcode-preview-img"
                                    src="{{ $config->contact_qrcode ? Storage::url($config->contact_qrcode) : '' }}"
                                    class="max-h-28 max-w-full object-contain rounded {{ $qrcodeExists ? '' : 'hidden' }}" alt="二维码">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- 后台登录页背景图 -->
                <div>
                    <h2 class="text-lg font-semibold text-gray-800 dark:text-white mb-4 pb-2 border-b border-gray-200 dark:border-gray-700">后台登录页背景</h2>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">登录页背景图</label>
                            @if($config->admin_login_bg)
                            <div class="mb-3">
                                <img src="{{ Storage::url($config->admin_login_bg) }}" alt="背景图" class="h-32 w-full object-cover rounded-lg">
                                <p class="text-xs text-gray-400 mt-1">当前背景图</p>
                            </div>
                            @endif
                            <div class="flex gap-2 mb-2">
                                <button type="button" onclick="window.openMediaSelector('admin_login_bg')"
                                    class="px-3 py-1.5 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-300 text-xs rounded-lg transition-colors">
                                    从文件库选择
                                </button>
                                <input type="hidden" name="admin_login_bg_path" id="admin_login_bg_path" value="{{ old('admin_login_bg_path', $config->admin_login_bg ?? '') }}">
                            </div>
                            <div class="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-4 h-36 flex items-center justify-center text-center hover:border-blue-400 dark:hover:border-blue-500 transition-colors cursor-pointer relative" id="login-bg-dropzone">
                                <input type="file" name="admin_login_bg" id="admin_login_bg" accept="image/jpeg,image/png,image/jpg,image/webp"
                                    class="hidden" onchange="previewFile(this, 'login-bg-preview-img', 'login-bg-placeholder')">
                                <div id="login-bg-placeholder" class="flex flex-col items-center gap-2">
                                    <svg class="w-10 h-10 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                                    <span class="text-sm text-gray-500 dark:text-gray-400">点击上传背景图</span>
                                </div>
                                <img id="login-bg-preview-img" class="hidden max-h-32 mx-auto rounded-lg" src="" alt="">
                                <button type="button" id="login-bg-clear-btn" onclick="clearLoginBg()" class="hidden absolute top-2 right-2 w-6 h-6 flex items-center justify-center bg-red-500 hover:bg-red-600 text-white rounded-full text-xs font-bold transition-colors" title="清除已选图片">
                                    ×
                                </button>
                            </div>
                            @if($config->admin_login_bg)
                            <div class="mt-3">
                                <button type="submit" name="reset_admin_login_bg" value="1"
                                    class="px-3 py-1.5 bg-red-100 dark:bg-red-900/30 hover:bg-red-200 dark:hover:bg-red-900/50 text-red-700 dark:text-red-400 text-xs rounded-lg transition-colors">
                                    恢复默认背景
                                </button>
                            </div>
                            @endif
                            <div class="mt-4">
                                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">背景图透明度</label>
                                <div class="flex items-center gap-3">
                                    <input type="range" name="admin_login_bg_opacity" id="admin_login_bg_opacity" min="0" max="100" value="{{ old('admin_login_bg_opacity', $config->admin_login_bg_opacity ?? 85) }}"
                                        class="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-lg appearance-none cursor-pointer">
                                    <span id="opacity-value" class="text-sm text-gray-600 dark:text-gray-400 min-w-[3rem] text-center">{{ $config->admin_login_bg_opacity ?? 85 }}%</span>
                                </div>
                                <p class="text-xs text-gray-400 mt-1">范围 0-100，值越小背景越透明</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- 文章阅读布局 -->
                <div>
                    <h2 class="text-lg font-semibold text-gray-800 dark:text-white mb-4 pb-2 border-b border-gray-200 dark:border-gray-700">文章阅读布局</h2>
                    <div class="flex items-center justify-between max-w-2xl py-2">
                        <div class="pr-6">
                            <p class="text-sm font-medium text-gray-700 dark:text-gray-300">文章详情页显示侧边博主卡片</p>
                            <p class="text-xs text-gray-400 mt-0.5 leading-relaxed">
                                开启：文章详情右侧完整保留博主头像、简介与联系方式（完整模式）。<br>
                                关闭：隐藏整套博主卡片，进入纯净阅读模式，文章详情侧边仅保留分类等阅读模块，正文下方提供微信 / QQ空间 / 微博分享按钮。
                            </p>
                        </div>
                        <label class="relative inline-flex items-center cursor-pointer shrink-0">
                            <input type="checkbox" name="post_detail_sidebar_author" value="1" class="sr-only peer"
                                {{ old('post_detail_sidebar_author', $config->post_detail_sidebar_author ?? true) ? 'checked' : '' }}>
                            <div class="w-11 h-6 bg-gray-200 dark:bg-gray-600 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border after:border-gray-300 after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                        </label>
                    </div>
                </div>
            </div>

            <div class="flex items-center gap-3 mt-8 pt-6 border-t border-gray-200 dark:border-gray-700">
                <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2.5 rounded-lg text-sm font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 dark:focus:ring-offset-gray-900">
                    保存设置
                </button>
            </div>
        </form>
    </div>
</div>

<x-media-selector editor-id="settings"/>

<script>
function previewFile(input, previewImgId, placeholderId) {
    const placeholder = document.getElementById(placeholderId);
    const previewImg = document.getElementById(previewImgId);
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            previewImg.src = e.target.result;
            previewImg.classList.remove('hidden');
            placeholder.classList.add('hidden');
        };
        reader.readAsDataURL(input.files[0]);
    }
}
function clearLoginBg() {
    const input = document.getElementById('admin_login_bg');
    const previewImg = document.getElementById('login-bg-preview-img');
    const placeholder = document.getElementById('login-bg-placeholder');
    const clearBtn = document.getElementById('login-bg-clear-btn');
    const pathField = document.getElementById('admin_login_bg_path');
    input.value = '';
    input.files = null;
    previewImg.src = '';
    previewImg.classList.add('hidden');
    placeholder.classList.remove('hidden');
    clearBtn.classList.add('hidden');
    pathField.value = '';
}
function bindDropzone(zoneId, inputId) {
    document.getElementById(zoneId)?.addEventListener('click', function() {
        document.getElementById(inputId).click();
    });
}
bindDropzone('logo-dropzone', 'site_logo');
bindDropzone('favicon-dropzone', 'site_favicon');
bindDropzone('qrcode-dropzone', 'contact_qrcode');
bindDropzone('login-bg-dropzone', 'admin_login_bg');

// 文件上传后显示/隐藏叉号按钮
document.getElementById('admin_login_bg')?.addEventListener('change', function() {
    const clearBtn = document.getElementById('login-bg-clear-btn');
    if (this.files && this.files[0]) {
        clearBtn?.classList.remove('hidden');
    } else {
        clearBtn?.classList.add('hidden');
    }
});

// 从文件库选择后填充对应字段
window.addEventListener('media-selected', function(event) {
    const field = event.detail.field;
    const file = event.detail.file;
    if (!file) return;

    const map = {
        site_logo: { pathId: 'site_logo_path', previewId: 'logo-preview-img', placeholderId: 'logo-placeholder' },
        site_favicon: { pathId: 'site_favicon_path', previewId: 'favicon-preview-img', placeholderId: 'favicon-placeholder' },
        contact_qrcode: { pathId: 'contact_qrcode_path', previewId: 'qrcode-preview-img', placeholderId: 'qrcode-placeholder' },
        admin_login_bg: { pathId: 'admin_login_bg_path', previewId: 'login-bg-preview-img', placeholderId: 'login-bg-placeholder', clearBtnId: 'login-bg-clear-btn' },
    };

    const item = map[field];
    if (!item) return;

    document.getElementById(item.pathId).value = file.file_path || '';
    const previewImg = document.getElementById(item.previewId);
    if (previewImg) {
        previewImg.src = file.url;
        previewImg.classList.remove('hidden');
        document.getElementById(item.placeholderId).classList.add('hidden');
        if (item.clearBtnId) {
            document.getElementById(item.clearBtnId).classList.remove('hidden');
        }
    }
});

// 透明度滑块实时更新显示值
const opacitySlider = document.getElementById('admin_login_bg_opacity');
const opacityValue = document.getElementById('opacity-value');
if (opacitySlider && opacityValue) {
    opacitySlider.addEventListener('input', function() {
        opacityValue.textContent = this.value + '%';
    });
}
</script>
@endsection

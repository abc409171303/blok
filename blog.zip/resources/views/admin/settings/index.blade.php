@extends('layouts.admin')

@section('page-title', '基本设置')

@section('content')
<div>
    <h1 class="text-2xl font-bold text-gray-800 mb-6">基本设置</h1>

    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <form action="{{ route('admin.settings.update') }}" method="POST" enctype="multipart/form-data">
            @csrf

            <div class="space-y-8">
                <!-- 站点信息 -->
                <div>
                    <h2 class="text-lg font-semibold text-gray-800 mb-4 pb-2 border-b border-gray-200">网站信息</h2>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label for="site_name" class="block text-sm font-medium text-gray-700 mb-1.5">网站名称 <span class="text-red-500">*</span></label>
                            <input type="text" name="site_name" id="site_name" value="{{ old('site_name', $config->site_name) }}" required
                                class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none">
                        </div>
                        <div>
                            <label for="site_domain" class="block text-sm font-medium text-gray-700 mb-1.5">网站域名</label>
                            <input type="text" name="site_domain" id="site_domain" value="{{ old('site_domain', $config->site_domain) }}"
                                class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                                placeholder="albb.xx.kg">
                        </div>
                        <div>
                            <label for="site_keywords" class="block text-sm font-medium text-gray-700 mb-1.5">网站关键词</label>
                            <input type="text" name="site_keywords" id="site_keywords" value="{{ old('site_keywords', $config->site_keywords) }}"
                                class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                                placeholder="以逗号分隔的关键词">
                        </div>
                        <div>
                            <label for="site_copyright" class="block text-sm font-medium text-gray-700 mb-1.5">版权信息</label>
                            <input type="text" name="site_copyright" id="site_copyright" value="{{ old('site_copyright', $config->site_copyright) }}"
                                class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                                placeholder="Copyright &copy; 2024">
                        </div>
                        <div class="md:col-span-2">
                            <label for="site_description" class="block text-sm font-medium text-gray-700 mb-1.5">网站描述</label>
                            <textarea name="site_description" id="site_description" rows="3"
                                class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none resize-none"
                                placeholder="简要描述您的站点">{{ old('site_description', $config->site_description) }}</textarea>
                        </div>
                    </div>
                </div>

                <!-- 主题设置 -->
                <div>
                    <h2 class="text-lg font-semibold text-gray-800 mb-4 pb-2 border-b border-gray-200">主题设置</h2>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label for="site_color" class="block text-sm font-medium text-gray-700 mb-1.5">网站主色调</label>
                            <div class="flex items-center gap-3">
                                <input type="color" name="site_color" id="site_color" value="{{ old('site_color', $config->site_color ?? '#2563eb') }}"
                                    class="w-10 h-10 rounded border border-gray-300 cursor-pointer p-0.5">
                                <span class="text-sm text-gray-500">{{ old('site_color', $config->site_color ?? '#2563eb') }}</span>
                            </div>
                        </div>
                        <div>
                            <label for="page_size" class="block text-sm font-medium text-gray-700 mb-1.5">每页显示数量</label>
                            <input type="number" name="page_size" id="page_size" value="{{ old('page_size', $config->page_size) }}" min="1" max="100"
                                class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none">
                        </div>
                    </div>
                </div>

                <!-- 备案信息 -->
                <div>
                    <h2 class="text-lg font-semibold text-gray-800 mb-4 pb-2 border-b border-gray-200">备案信息</h2>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label for="icp_number" class="block text-sm font-medium text-gray-700 mb-1.5">ICP备案编号</label>
                            <input type="text" name="icp_number" id="icp_number" value="{{ old('icp_number', $config->icp_number) }}"
                                class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                                placeholder="如：苏ICP备2020068439号">
                        </div>
                        <div>
                            <label for="police_record_text" class="block text-sm font-medium text-gray-700 mb-1.5">公安备案文字</label>
                            <input type="text" name="police_record_text" id="police_record_text" value="{{ old('police_record_text', $config->police_record_text) }}"
                                class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                                placeholder="如：苏公网安备 32021402001978号">
                        </div>
                        <div class="md:col-span-2">
                            <label for="police_record_link" class="block text-sm font-medium text-gray-700 mb-1.5">公安备案链接</label>
                            <input type="text" name="police_record_link" id="police_record_link" value="{{ old('police_record_link', $config->police_record_link) }}"
                                class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                                placeholder="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=...">
                        </div>
                    </div>
                </div>

                <!-- 联系信息 -->
                <div>
                    <h2 class="text-lg font-semibold text-gray-800 mb-4 pb-2 border-b border-gray-200">联系信息</h2>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label for="contact_email" class="block text-sm font-medium text-gray-700 mb-1.5">邮箱</label>
                            <input type="email" name="contact_email" id="contact_email" value="{{ old('contact_email', $config->contact_email) }}"
                                class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                                placeholder="admin@example.com">
                        </div>
                        <div>
                            <label for="contact_phone" class="block text-sm font-medium text-gray-700 mb-1.5">电话</label>
                            <input type="text" name="contact_phone" id="contact_phone" value="{{ old('contact_phone', $config->contact_phone) }}"
                                class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                                placeholder="400-xxx-xxxx">
                        </div>
                        <div class="md:col-span-2">
                            <label for="contact_address" class="block text-sm font-medium text-gray-700 mb-1.5">地址</label>
                            <input type="text" name="contact_address" id="contact_address" value="{{ old('contact_address', $config->contact_address) }}"
                                class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                                placeholder="江苏省无锡市xx区xx路xx号">
                        </div>
                    </div>
                </div>

                <!-- 媒体资源 -->
                <div>
                    <h2 class="text-lg font-semibold text-gray-800 mb-4 pb-2 border-b border-gray-200">媒体资源</h2>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1.5">博主头像</label>
                            @if($config->site_avatar)
                            <div class="mb-3">
                                <img src="{{ Storage::url($config->site_avatar) }}" alt="头像" class="w-16 h-16 rounded-full object-cover">
                                <p class="text-xs text-gray-400 mt-1">当前头像</p>
                            </div>
                            @endif
                            <div class="mb-2">
                                <button type="button" onclick="window.openMediaSelector('site_avatar')"
                                    class="px-3 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs rounded-lg transition-colors">
                                    从文件库选择
                                </button>
                                <input type="hidden" name="site_avatar_path" id="site_avatar_path" value="{{ old('site_avatar_path', '') }}">
                            </div>
                            <div class="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center hover:border-blue-400 transition-colors cursor-pointer" id="avatar-dropzone">
                                <input type="file" name="site_avatar" id="site_avatar" accept="image/jpeg,image/png,image/jpg,image/gif,image/webp"
                                    class="hidden" onchange="previewFile(this, 'avatar-preview-img', 'avatar-placeholder')">
                                <div id="avatar-placeholder" class="flex flex-col items-center gap-2">
                                    <svg class="w-10 h-10 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                                    <span class="text-sm text-gray-500">点击上传头像</span>
                                </div>
                                <img id="avatar-preview-img" class="hidden w-16 h-16 mx-auto rounded-full object-cover" src="" alt="">
                            </div>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1.5">站点 Logo</label>
                            @if($config->site_logo)
                            <div class="mb-3">
                                <img src="{{ Storage::url($config->site_logo) }}" alt="Logo" class="h-12 rounded">
                                <p class="text-xs text-gray-400 mt-1">当前 Logo</p>
                            </div>
                            @endif
                            <div class="mb-2">
                                <button type="button" onclick="window.openMediaSelector('site_logo')"
                                    class="px-3 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs rounded-lg transition-colors">
                                    从文件库选择
                                </button>
                                <input type="hidden" name="site_logo_path" id="site_logo_path" value="{{ old('site_logo_path', '') }}">
                            </div>
                            <div class="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center hover:border-blue-400 transition-colors cursor-pointer" id="logo-dropzone">
                                <input type="file" name="site_logo" id="site_logo" accept="image/jpeg,image/png,image/jpg,image/gif,image/webp"
                                    class="hidden" onchange="previewFile(this, 'logo-preview-img', 'logo-placeholder')">
                                <div id="logo-placeholder" class="flex flex-col items-center gap-2">
                                    <svg class="w-10 h-10 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                                    <span class="text-sm text-gray-500">点击上传 Logo</span>
                                </div>
                                <img id="logo-preview-img" class="hidden max-h-16 mx-auto rounded" src="" alt="">
                            </div>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1.5">站点 Favicon</label>
                            @if($config->site_favicon)
                            <div class="mb-3">
                                <img src="{{ Storage::url($config->site_favicon) }}" alt="Favicon" class="h-8 rounded">
                                <p class="text-xs text-gray-400 mt-1">当前 Favicon</p>
                            </div>
                            @endif
                            <div class="mb-2">
                                <button type="button" onclick="window.openMediaSelector('site_favicon')"
                                    class="px-3 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs rounded-lg transition-colors">
                                    从文件库选择
                                </button>
                                <input type="hidden" name="site_favicon_path" id="site_favicon_path" value="{{ old('site_favicon_path', '') }}">
                            </div>
                            <div class="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center hover:border-blue-400 transition-colors cursor-pointer" id="favicon-dropzone">
                                <input type="file" name="site_favicon" id="site_favicon" accept="image/x-icon,image/png"
                                    class="hidden" onchange="previewFile(this, 'favicon-preview-img', 'favicon-placeholder')">
                                <div id="favicon-placeholder" class="flex flex-col items-center gap-2">
                                    <svg class="w-10 h-10 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                                    <span class="text-sm text-gray-500">点击上传 Favicon</span>
                                </div>
                                <img id="favicon-preview-img" class="hidden max-h-16 mx-auto rounded" src="" alt="">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1.5">联系二维码</label>
                            @if($config->contact_qrcode)
                            <div class="mb-3">
                                <img src="{{ Storage::url($config->contact_qrcode) }}" alt="二维码" class="h-24 rounded">
                                <p class="text-xs text-gray-400 mt-1">当前二维码</p>
                            </div>
                            @endif
                            <div class="mb-2">
                                <button type="button" onclick="window.openMediaSelector('contact_qrcode')"
                                    class="px-3 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs rounded-lg transition-colors">
                                    从文件库选择
                                </button>
                                <input type="hidden" name="contact_qrcode_path" id="contact_qrcode_path" value="{{ old('contact_qrcode_path', '') }}">
                            </div>
                            <div class="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center hover:border-blue-400 transition-colors cursor-pointer" id="qrcode-dropzone">
                                <input type="file" name="contact_qrcode" id="contact_qrcode" accept="image/jpeg,image/png,image/jpg,image/gif"
                                    class="hidden" onchange="previewFile(this, 'qrcode-preview-img', 'qrcode-placeholder')">
                                <div id="qrcode-placeholder" class="flex flex-col items-center gap-2">
                                    <svg class="w-10 h-10 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 4v1m6 11h2m-6 0h-2.48a2.5 2.5 0 00-4.76 0H4m16 0h2"/></svg>
                                    <span class="text-sm text-gray-500">点击上传二维码</span>
                                </div>
                                <img id="qrcode-preview-img" class="hidden max-h-24 mx-auto rounded" src="" alt="">
                            </div>
                        </div>
                    </div>
                </div>
                </div>
                </div>

                <!-- AI 配置 -->
                <div>
                    <h2 class="text-lg font-semibold text-gray-800 mb-4 pb-2 border-b border-gray-200">AI 对接配置</h2>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label for="ai_api_base_url" class="block text-sm font-medium text-gray-700 mb-1.5">API 地址</label>
                            <input type="text" name="ai_api_base_url" id="ai_api_base_url" value="{{ old('ai_api_base_url', $config->ai_api_base_url) }}"
                                class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                                placeholder="https://dashscope.aliyuncs.com/compatible-mode/v1">
                            <p class="text-xs text-gray-400 mt-1">OpenAI 兼容格式的 API 地址</p>
                        </div>
                        <div>
                            <label for="ai_model" class="block text-sm font-medium text-gray-700 mb-1.5">模型名称</label>
                            <input type="text" name="ai_model" id="ai_model" value="{{ old('ai_model', $config->ai_model) }}"
                                class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                                placeholder="qwen-plus">
                        </div>
                        <div>
                            <label for="ai_image_model" class="block text-sm font-medium text-gray-700 mb-1.5">配图模型名称</label>
                            <input type="text" name="ai_image_model" id="ai_image_model" value="{{ old('ai_image_model', $config->ai_image_model) }}"
                                class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                                placeholder="wanx2.1-t2i-turbo">
                            <p class="text-xs text-gray-400 mt-1">通义万相文生图模型（DashScope）</p>
                        </div>
                        <div class="md:col-span-2">
                            <label for="ai_api_key" class="block text-sm font-medium text-gray-700 mb-1.5">API Key</label>
                            <input type="password" name="ai_api_key" id="ai_api_key" value="{{ old('ai_api_key', $config->ai_api_key) }}"
                                class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                                placeholder="sk-xxxxxxxx">
                        </div>
                    </div>
                </div>

                <!-- 自定义代码 -->
                <div>
                    <h2 class="text-lg font-semibold text-gray-800 mb-4 pb-2 border-b border-gray-200">自定义代码</h2>
                    <div class="space-y-4">
                        <div>
                            <label for="custom_header_html" class="block text-sm font-medium text-gray-700 mb-1.5">自定义 HTML（&lt;head&gt; 内）</label>
                            <textarea name="custom_header_html" id="custom_header_html" rows="5"
                                class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm font-mono focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none resize-y"
                                placeholder="统计代码、meta 标签等...">{{ old('custom_header_html', $config->custom_header_html) }}</textarea>
                            <p class="text-xs text-gray-400 mt-1">将插入到页面 &lt;head&gt; 标签内</p>
                        </div>
                        <div>
                            <label for="custom_footer_js" class="block text-sm font-medium text-gray-700 mb-1.5">自定义 JS（页脚）</label>
                            <textarea name="custom_footer_js" id="custom_footer_js" rows="5"
                                class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm font-mono focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none resize-y"
                                placeholder="&lt;script&gt;...&lt;/script&gt;">{{ old('custom_footer_js', $config->custom_footer_js) }}</textarea>
                            <p class="text-xs text-gray-400 mt-1">将插入到页面底部，&lt;/body&gt; 之前</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="flex items-center gap-3 mt-8 pt-6 border-t border-gray-200">
                <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2.5 rounded-lg text-sm font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2">
                    保存设置
                </button>
            </div>
        </form>
    </div>
</div>

<x-media-selector editor-id="settings"/>

<script>
function previewFile(input, previewImgId, placeholderId) {
    const placeholder = document.getElementById(placeholderId);
    const previewImg = document.getElementById(previewImgId);
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            previewImg.src = e.target.result;
            previewImg.classList.remove('hidden');
            placeholder.classList.add('hidden');
        };
        reader.readAsDataURL(input.files[0]);
    }
}
function bindDropzone(zoneId, inputId) {
    document.getElementById(zoneId)?.addEventListener('click', function(e) {
        if (e.target.tagName !== 'IMG') {
            document.getElementById(inputId).click();
        }
    });
}
bindDropzone('avatar-dropzone', 'site_avatar');
bindDropzone('logo-dropzone', 'site_logo');
bindDropzone('favicon-dropzone', 'site_favicon');
bindDropzone('qrcode-dropzone', 'contact_qrcode');

// 从文件库选择后填充对应字段
window.addEventListener('media-selected', function(event) {
    const field = event.detail.field;
    const file = event.detail.file;
    if (!file) return;

    const map = {
        site_avatar: { pathId: 'site_avatar_path', previewId: 'avatar-preview-img', placeholderId: 'avatar-placeholder' },
        site_logo: { pathId: 'site_logo_path', previewId: 'logo-preview-img', placeholderId: 'logo-placeholder' },
        site_favicon: { pathId: 'site_favicon_path', previewId: 'favicon-preview-img', placeholderId: 'favicon-placeholder' },
        contact_qrcode: { pathId: 'contact_qrcode_path', previewId: 'qrcode-preview-img', placeholderId: 'qrcode-placeholder' },
    };

    const item = map[field];
    if (!item) return;

    document.getElementById(item.pathId).value = file.file_path || '';
    const previewImg = document.getElementById(item.previewId);
    if (previewImg) {
        previewImg.src = file.url;
        previewImg.classList.remove('hidden');
        document.getElementById(item.placeholderId).classList.add('hidden');
    }
});
</script>
@endsection

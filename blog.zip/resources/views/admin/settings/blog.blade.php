@extends('layouts.admin')

@section('page-title', '博客设置')

@section('content')
<div>
    <h1 class="text-2xl font-bold text-gray-800 mb-6">博客设置</h1>

    @if(session('success'))
    <div class="mb-6 px-4 py-3 bg-green-50 border border-green-200 text-green-700 text-sm rounded-lg">
        {{ session('success') }}
    </div>
    @endif

    <form action="{{ route('admin.settings.blog.update') }}" method="POST" enctype="multipart/form-data">
        @csrf

        <div class="space-y-6">
            <!-- SEO设置 -->
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 flex items-center gap-2.5">
                    <svg class="w-5 h-5 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
                    <h2 class="text-lg font-semibold text-gray-800">SEO设置</h2>
                </div>
                <div class="px-6 py-5 space-y-5">
                    <div>
                        <label for="site_seo_title" class="block text-sm font-medium text-gray-700 mb-1.5">首页SEO标题</label>
                        <input type="text" name="site_seo_title" id="site_seo_title" value="{{ old('site_seo_title', $config->site_seo_title) }}"
                            class="w-full max-w-xl px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                            placeholder="首页标题，留空则使用网站名称">
                        <p class="text-xs text-gray-400 mt-1">显示在浏览器标签和搜索引擎结果中的首页标题</p>
                    </div>
                    <div>
                        <label for="site_keywords" class="block text-sm font-medium text-gray-700 mb-1.5">首页SEO关键词</label>
                        <input type="text" name="site_keywords" id="site_keywords" value="{{ old('site_keywords', $config->site_keywords) }}"
                            class="w-full max-w-xl px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                            placeholder="以逗号分隔的关键词">
                    </div>
                    <div>
                        <label for="site_description" class="block text-sm font-medium text-gray-700 mb-1.5">首页SEO描述</label>
                        <textarea name="site_description" id="site_description" rows="3"
                            class="w-full max-w-xl px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none resize-none"
                            placeholder="网站描述，会显示在搜索引擎结果中">{{ old('site_description', $config->site_description) }}</textarea>
                    </div>
                </div>
            </div>

            <!-- 内容设置 -->
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 flex items-center gap-2.5">
                    <svg class="w-5 h-5 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                    <h2 class="text-lg font-semibold text-gray-800">内容设置</h2>
                </div>
                <div class="px-6 py-5 space-y-5">
                    <div>
                        <label for="site_name" class="block text-sm font-medium text-gray-700 mb-1.5">博客名称 <span class="text-red-500">*</span></label>
                        <input type="text" name="site_name" id="site_name" value="{{ old('site_name', $config->site_name) }}" required
                            class="w-full max-w-xl px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                            placeholder="博客名称">
                    </div>
                    <div>
                        <label for="site_tagline" class="block text-sm font-medium text-gray-700 mb-1.5">博客标语</label>
                        <input type="text" name="site_tagline" id="site_tagline" value="{{ old('site_tagline', $config->site_tagline) }}"
                            class="w-full max-w-xl px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                            placeholder="一句话介绍你的博客">
                    </div>

                    <!-- 博客头像 -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1.5">博客头像</label>
                        <div class="flex items-center gap-6">
                            <div class="shrink-0">
                                @if($config->site_avatar)
                                <img id="avatar-current" src="{{ Storage::url($config->site_avatar) }}" alt="头像"
                                    class="w-16 h-16 rounded-full object-cover border border-gray-200">
                                @else
                                <div id="avatar-current" class="w-16 h-16 rounded-full bg-gray-100 border border-gray-200 flex items-center justify-center text-gray-300">
                                    <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
                                </div>
                                @endif
                            </div>
                            <div class="flex flex-wrap items-center gap-3">
                                <button type="button" id="avatar-upload-btn"
                                    class="px-3 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs rounded-lg transition-colors">
                                    本地上传
                                </button>
                                <input type="file" name="site_avatar" id="site_avatar" accept="image/jpeg,image/png,image/jpg,image/gif,image/webp"
                                    class="hidden" onchange="previewAvatar(this)">
                                <button type="button" onclick="window.openMediaSelector('site_avatar')"
                                    class="px-3 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs rounded-lg transition-colors">
                                    从文件库选择
                                </button>
                                @if($config->site_avatar)
                                <button type="button" id="avatar-remove-btn"
                                    class="px-3 py-1.5 text-red-500 hover:bg-red-50 border border-red-200 text-xs rounded-lg transition-colors">
                                    删除头像
                                </button>
                                @endif
                            </div>
                            <input type="hidden" name="site_avatar_path" id="site_avatar_path" value="{{ old('site_avatar_path', '') }}">
                            <input type="hidden" name="remove_site_avatar" id="remove_site_avatar" value="0">
                        </div>
                        <p id="avatar-uploaded" class="text-xs text-blue-600 mt-2 hidden">已选择新头像，保存后生效。</p>
                    </div>

                    <div>
                        <label for="contact_qq" class="block text-sm font-medium text-gray-700 mb-1.5">联系方式-QQ</label>
                        <input type="text" name="contact_qq" id="contact_qq" value="{{ old('contact_qq', $config->contact_qq) }}"
                            class="w-full max-w-xl px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                            placeholder="QQ号码">
                    </div>
                    <div>
                        <label for="contact_weibo" class="block text-sm font-medium text-gray-700 mb-1.5">联系方式-微博</label>
                        <input type="text" name="contact_weibo" id="contact_weibo" value="{{ old('contact_weibo', $config->contact_weibo) }}"
                            class="w-full max-w-xl px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                            placeholder="微博主页链接">
                    </div>
                    <div>
                        <label for="contact_wechat" class="block text-sm font-medium text-gray-700 mb-1.5">联系方式-微信</label>
                        <input type="text" name="contact_wechat" id="contact_wechat" value="{{ old('contact_wechat', $config->contact_wechat) }}"
                            class="w-full max-w-xl px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                            placeholder="微信号">
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1.5">联系方式-二维码</label>
                        <div class="flex items-center gap-6">
                            <div class="shrink-0">
                                @if($config->contact_qrcode)
                                <img id="qrcode-current" src="{{ Storage::url($config->contact_qrcode) }}" alt="二维码"
                                    class="w-16 h-16 rounded-lg object-cover border border-gray-200">
                                @else
                                <div id="qrcode-current" class="w-16 h-16 rounded-lg bg-gray-100 border border-gray-200 flex items-center justify-center text-gray-300">
                                    <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 4v1m6 11h2m-6 0h-2.48a2.5 2.5 0 00-4.76 0H4m16 0h2"/></svg>
                                </div>
                                @endif
                            </div>
                            <div class="flex flex-wrap items-center gap-3">
                                <button type="button" id="qrcode-upload-btn"
                                    class="px-3 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs rounded-lg transition-colors">
                                    本地上传
                                </button>
                                <input type="file" name="contact_qrcode" id="contact_qrcode" accept="image/jpeg,image/png,image/jpg,image/gif"
                                    class="hidden" onchange="previewQrcode(this)">
                                <button type="button" onclick="window.openMediaSelector('contact_qrcode')"
                                    class="px-3 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs rounded-lg transition-colors">
                                    从文件库选择
                                </button>
                                @if($config->contact_qrcode)
                                <button type="button" id="qrcode-remove-btn"
                                    class="px-3 py-1.5 text-red-500 hover:bg-red-50 border border-red-200 text-xs rounded-lg transition-colors">
                                    删除二维码
                                </button>
                                @endif
                            </div>
                            <input type="hidden" name="contact_qrcode_path" id="contact_qrcode_path" value="{{ old('contact_qrcode_path', '') }}">
                            <input type="hidden" name="remove_contact_qrcode" id="remove_contact_qrcode" value="0">
                        </div>
                        <p id="qrcode-uploaded" class="text-xs text-blue-600 mt-2 hidden">已选择新二维码，保存后生效。</p>
                        <p class="text-xs text-gray-400 mt-1">上传后，前台侧边栏将以图片形式展示联系方式</p>
                    </div>
                </div>
            </div>

            <!-- 功能设置 -->
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 flex items-center gap-2.5">
                    <svg class="w-5 h-5 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                    <h2 class="text-lg font-semibold text-gray-800">功能设置</h2>
                </div>
                <div class="px-6 py-5 space-y-5">
                    <div>
                        <label for="sidebar_tag_count" class="block text-sm font-medium text-gray-700 mb-1.5">侧边栏标签数量</label>
                        <input type="number" name="sidebar_tag_count" id="sidebar_tag_count" value="{{ old('sidebar_tag_count', $config->sidebar_tag_count ?? 0) }}" min="0" max="100"
                            class="w-40 px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none">
                        <p class="text-xs text-gray-400 mt-1">0为不限制，侧边栏最多显示的标签个数</p>
                    </div>

                    <div>
                        <label for="dark_mode_mode" class="block text-sm font-medium text-gray-700 mb-1.5">暗黑模式</label>
                        <div class="flex flex-wrap items-center gap-4">
                            <select name="dark_mode_mode" id="dark_mode_mode"
                                class="w-48 px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none bg-white">
                                <option value="always" {{ old('dark_mode_mode', $config->dark_mode_mode ?? ($config->enable_dark_mode ? 'always' : 'never')) === 'always' ? 'selected' : '' }}>始终开启</option>
                                <option value="never" {{ old('dark_mode_mode', $config->dark_mode_mode ?? ($config->enable_dark_mode ? 'always' : 'never')) === 'never' ? 'selected' : '' }}>始终关闭</option>
                                <option value="schedule" {{ old('dark_mode_mode', $config->dark_mode_mode ?? ($config->enable_dark_mode ? 'always' : 'never')) === 'schedule' ? 'selected' : '' }}>定时开启</option>
                            </select>
                            <div id="dark-schedule-fields" class="flex flex-wrap items-center gap-3 {{ old('dark_mode_mode', $config->dark_mode_mode ?? 'always') === 'schedule' ? '' : 'hidden' }}">
                                <div class="flex items-center gap-2">
                                    <span class="text-sm text-gray-500">开始</span>
                                    <input type="time" name="dark_mode_start" id="dark_mode_start" value="{{ old('dark_mode_start', $config->dark_mode_start ?? '19:00') }}"
                                        class="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none">
                                </div>
                                <div class="flex items-center gap-2">
                                    <span class="text-sm text-gray-500">结束</span>
                                    <input type="time" name="dark_mode_end" id="dark_mode_end" value="{{ old('dark_mode_end', $config->dark_mode_end ?? '07:00') }}"
                                        class="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none">
                                </div>
                            </div>
                        </div>
                        <p class="text-xs text-gray-400 mt-1">定时开启时，前台将仅在该时间段内使用暗色主题；支持跨午夜（如 19:00 - 07:00）</p>
                        <input type="hidden" name="enable_dark_mode" id="enable_dark_mode" value="1">
                    </div>

                    <div>
                        <label for="search_driver" class="block text-sm font-medium text-gray-700 mb-1.5">博客超级搜索驱动</label>
                        <select name="search_driver" id="search_driver"
                            class="w-full max-w-xl px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none bg-white">
                            <option value="builtin" {{ old('search_driver', $config->search_driver ?? 'builtin') === 'builtin' ? 'selected' : '' }}>内置搜索</option>
                            <option value="baidu" {{ old('search_driver', $config->search_driver ?? 'builtin') === 'baidu' ? 'selected' : '' }}>百度搜索</option>
                            <option value="google" {{ old('search_driver', $config->search_driver ?? 'builtin') === 'google' ? 'selected' : '' }}>谷歌搜索</option>
                            <option value="bing" {{ old('search_driver', $config->search_driver ?? 'builtin') === 'bing' ? 'selected' : '' }}>必应搜索</option>
                        </select>
                        <p class="text-xs text-gray-400 mt-1">选择前台搜索使用的搜索引擎</p>
                    </div>

                    <div class="flex items-center justify-between max-w-xl py-2">
                        <div>
                            <p class="text-sm font-medium text-gray-700">启用评论</p>
                            <p class="text-xs text-gray-400 mt-0.5">允许访客在文章下方发表评论</p>
                        </div>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input type="checkbox" name="enable_comments" value="1" class="sr-only peer"
                                {{ old('enable_comments', $config->enable_comments ?? true) ? 'checked' : '' }}>
                            <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border after:border-gray-300 after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                        </label>
                    </div>

                    <div class="flex items-center justify-between max-w-xl py-2">
                        <div>
                            <p class="text-sm font-medium text-gray-700">自动审核评论</p>
                            <p class="text-xs text-gray-400 mt-0.5">开启后新评论自动通过，无需手动审核</p>
                        </div>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input type="checkbox" name="auto_approve_comments" value="1" class="sr-only peer"
                                {{ old('auto_approve_comments', $config->auto_approve_comments ?? false) ? 'checked' : '' }}>
                            <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border after:border-gray-300 after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                        </label>
                    </div>
                </div>
            </div>
        </div>

        <div class="flex items-center gap-3 mt-8 pt-6 border-t border-gray-200">
            <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2.5 rounded-lg text-sm font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2">
                保存设置
            </button>
        </div>
    </form>
</div>

<x-media-selector editor-id="settings"/>

<script>
// 暗黑模式：定时模式时显示时间段输入
(function() {
    const modeSelect = document.getElementById('dark_mode_mode');
    const scheduleFields = document.getElementById('dark-schedule-fields');
    if (modeSelect && scheduleFields) {
        function syncScheduleFields() {
            scheduleFields.classList.toggle('hidden', modeSelect.value !== 'schedule');
        }
        modeSelect.addEventListener('change', syncScheduleFields);
        syncScheduleFields();
    }
})();

function previewAvatar(input) {
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            const img = document.getElementById('avatar-current');
            if (img.tagName === 'IMG') {
                img.src = e.target.result;
            } else {
                const newImg = document.createElement('img');
                newImg.id = 'avatar-current';
                newImg.src = e.target.result;
                newImg.className = 'w-16 h-16 rounded-full object-cover border border-gray-200';
                img.replaceWith(newImg);
            }
            document.getElementById('avatar-uploaded').classList.remove('hidden');
            document.getElementById('site_avatar_path').value = '';
            document.getElementById('remove_site_avatar').value = '0';
            const rmBtn = document.getElementById('avatar-remove-btn');
            if (rmBtn) rmBtn.classList.add('hidden');
        };
        reader.readAsDataURL(input.files[0]);
    }
}
document.getElementById('avatar-upload-btn')?.addEventListener('click', function() {
    document.getElementById('site_avatar').click();
});
document.getElementById('avatar-remove-btn')?.addEventListener('click', function() {
    document.getElementById('remove_site_avatar').value = '1';
    document.getElementById('site_avatar_path').value = '';
    this.classList.add('hidden');
    const img = document.getElementById('avatar-current');
    img.replaceWith(buildEmptyAvatar());
    document.getElementById('avatar-uploaded').classList.add('hidden');
});
function buildEmptyAvatar() {
    const div = document.createElement('div');
    div.id = 'avatar-current';
    div.className = 'w-16 h-16 rounded-full bg-gray-100 border border-gray-200 flex items-center justify-center text-gray-300';
    div.innerHTML = '<svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>';
    return div;
}

// 从文件库选择后填充对应字段
window.addEventListener('media-selected', function(event) {
    const field = event.detail.field;
    const file = event.detail.file;
    if (!file) return;

    if (field === 'site_avatar') {
        document.getElementById('site_avatar_path').value = file.file_path || '';
        document.getElementById('remove_site_avatar').value = '0';
        const img = document.getElementById('avatar-current');
        if (img.tagName === 'IMG') {
            img.src = file.url;
        } else {
            const newImg = document.createElement('img');
            newImg.id = 'avatar-current';
            newImg.src = file.url;
            newImg.className = 'w-16 h-16 rounded-full object-cover border border-gray-200';
            img.replaceWith(newImg);
        }
        document.getElementById('avatar-uploaded').classList.remove('hidden');
        const rmBtn = document.getElementById('avatar-remove-btn');
        if (rmBtn) rmBtn.classList.add('hidden');
    } else if (field === 'contact_qrcode') {
        document.getElementById('contact_qrcode_path').value = file.file_path || '';
        document.getElementById('remove_contact_qrcode').value = '0';
        const img = document.getElementById('qrcode-current');
        if (img.tagName === 'IMG') {
            img.src = file.url;
        } else {
            const newImg = document.createElement('img');
            newImg.id = 'qrcode-current';
            newImg.src = file.url;
            newImg.className = 'w-16 h-16 rounded-lg object-cover border border-gray-200';
            img.replaceWith(newImg);
        }
        document.getElementById('qrcode-uploaded').classList.remove('hidden');
        const rmBtn = document.getElementById('qrcode-remove-btn');
        if (rmBtn) rmBtn.classList.add('hidden');
    }
});

// 二维码本地上传预览
function previewQrcode(input) {
    if (!input.files || !input.files[0]) return;
    const reader = new FileReader();
    reader.onload = function(e) {
        const img = document.getElementById('qrcode-current');
        if (img.tagName === 'IMG') {
            img.src = e.target.result;
        } else {
            const newImg = document.createElement('img');
            newImg.id = 'qrcode-current';
            newImg.src = e.target.result;
            newImg.className = 'w-16 h-16 rounded-lg object-cover border border-gray-200';
            img.replaceWith(newImg);
        }
        document.getElementById('qrcode-uploaded').classList.remove('hidden');
        document.getElementById('contact_qrcode_path').value = '';
        document.getElementById('remove_contact_qrcode').value = '0';
        const rmBtn = document.getElementById('qrcode-remove-btn');
        if (rmBtn) rmBtn.classList.add('hidden');
    };
    reader.readAsDataURL(input.files[0]);
}
document.getElementById('qrcode-upload-btn')?.addEventListener('click', function() {
    document.getElementById('contact_qrcode').click();
});
document.getElementById('qrcode-remove-btn')?.addEventListener('click', function() {
    document.getElementById('remove_contact_qrcode').value = '1';
    document.getElementById('contact_qrcode_path').value = '';
    this.classList.add('hidden');
    const img = document.getElementById('qrcode-current');
    img.replaceWith(buildEmptyQrcode());
    document.getElementById('qrcode-uploaded').classList.add('hidden');
});
function buildEmptyQrcode() {
    const div = document.createElement('div');
    div.id = 'qrcode-current';
    div.className = 'w-16 h-16 rounded-lg bg-gray-100 border border-gray-200 flex items-center justify-center text-gray-300';
    div.innerHTML = '<svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 4v1m6 11h2m-6 0h-2.48a2.5 2.5 0 00-4.76 0H4m16 0h2"/></svg>';
    return div;
}
</script>
@endsection

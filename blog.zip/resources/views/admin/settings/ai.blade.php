@extends('layouts.admin')

@section('page-title', 'AI配置')

@section('content')
<div>
    <h1 class="text-2xl font-bold text-gray-800 dark:text-white mb-6">AI配置</h1>

    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <form action="{{ route('admin.settings.ai.update') }}" method="POST" enctype="multipart/form-data">
            @csrf

            <div class="space-y-8">
                <!-- AI 配置 -->
                <div>
                    <h2 class="text-lg font-semibold text-gray-800 dark:text-white mb-4 pb-2 border-b border-gray-200 dark:border-gray-700">AI 对接配置</h2>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label for="ai_api_base_url" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">API 地址</label>
                            <input type="text" name="ai_api_base_url" id="ai_api_base_url" value="{{ old('ai_api_base_url', $config->ai_api_base_url) }}"
                                class="w-full px-4 py-2.5 border border-gray-300 dark:border-gray-600 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                                placeholder="https://dashscope.aliyuncs.com/compatible-mode/v1">
                            <p class="text-xs text-gray-400 mt-1">OpenAI 兼容格式的 API 地址</p>
                        </div>
                        <div>
                            <label for="ai_model" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">模型名称</label>
                            <input type="text" name="ai_model" id="ai_model" value="{{ old('ai_model', $config->ai_model) }}"
                                class="w-full px-4 py-2.5 border border-gray-300 dark:border-gray-600 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                                placeholder="qwen-plus">
                        </div>
                        <div>
                            <label for="ai_image_model" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">配图模型名称</label>
                            <input type="text" name="ai_image_model" id="ai_image_model" value="{{ old('ai_image_model', $config->ai_image_model) }}"
                                class="w-full px-4 py-2.5 border border-gray-300 dark:border-gray-600 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                                placeholder="wanx2.1-t2i-turbo">
                            <p class="text-xs text-gray-400 mt-1">通义万相文生图模型（DashScope）</p>
                        </div>
                        <div class="md:col-span-2">
                            <label for="ai_api_key" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">API Key</label>
                            <input type="password" name="ai_api_key" id="ai_api_key" value="{{ old('ai_api_key', $config->ai_api_key) }}"
                                class="w-full px-4 py-2.5 border border-gray-300 dark:border-gray-600 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                                placeholder="sk-xxxxxxxx">
                        </div>
                    </div>
                </div>
            </div>

            <div class="flex items-center gap-3 mt-8 pt-6 border-t border-gray-200 dark:border-gray-700">
                <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2.5 rounded-lg text-sm font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 dark:focus:ring-offset-gray-900">
                    保存设置
                </button>
            </div>
        </form>
    </div>
</div>
@endsection

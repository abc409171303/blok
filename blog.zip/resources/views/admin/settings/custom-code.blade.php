@extends('layouts.admin')

@section('page-title', '自定义代码')

@section('content')
<div>
    <h1 class="text-2xl font-bold text-gray-800 dark:text-white mb-6">自定义代码</h1>

    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <form action="{{ route('admin.settings.custom-code.update') }}" method="POST" enctype="multipart/form-data">
            @csrf

            <div class="space-y-8">
                <!-- 建站起始时间 -->
                <div>
                    <h2 class="text-lg font-semibold text-gray-800 dark:text-white mb-4 pb-2 border-b border-gray-200 dark:border-gray-700">建站起始时间</h2>
                    <div class="max-w-md">
                        <label for="site_start_date" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">建站起始时间</label>
                        <input type="text" name="site_start_date" id="site_start_date"
                            value="{{ old('site_start_date', $config->site_start_date ?? '') }}"
                            placeholder="2026-07-26"
                            class="w-full px-4 py-2.5 border border-gray-300 dark:border-gray-600 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none bg-white dark:bg-gray-700 text-gray-900 dark:text-white placeholder-gray-400">
                        <p class="text-xs text-gray-400 mt-1">留空则不显示运行天数；填写后在自定义JS中读取此配置计算并渲染</p>
                    </div>
                </div>

                <!-- 自定义代码 -->
                <div>
                    <h2 class="text-lg font-semibold text-gray-800 dark:text-white mb-4 pb-2 border-b border-gray-200 dark:border-gray-700">自定义代码</h2>
                    <div class="space-y-4">
                        <div>
                            <label for="custom_header_html" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">自定义 HTML（&lt;head&gt; 内）</label>
                            <textarea name="custom_header_html" id="custom_header_html" rows="5"
                                class="w-full px-4 py-2.5 border border-gray-300 dark:border-gray-600 rounded-lg text-sm font-mono focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none resize-y bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                                placeholder="统计代码、meta 标签等...">{{ old('custom_header_html', $config->custom_header_html) }}</textarea>
                            <p class="text-xs text-gray-400 mt-1">将插入到页面 &lt;head&gt; 标签内</p>
                        </div>
                        <div>
                            <label for="custom_footer_js" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">自定义 JS（页脚）</label>
                            <textarea name="custom_footer_js" id="custom_footer_js" rows="5"
                                class="w-full px-4 py-2.5 border border-gray-300 dark:border-gray-600 rounded-lg text-sm font-mono focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none resize-y bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                                placeholder="&lt;script&gt;...&lt;/script&gt;">{{ old('custom_footer_js', $config->custom_footer_js) }}</textarea>
                            <p class="text-xs text-gray-400 mt-1">将插入到页面底部，&lt;/body&gt; 之前</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="flex items-center gap-3 mt-8 pt-6 border-t border-gray-200 dark:border-gray-700">
                <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2.5 rounded-lg text-sm font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 dark:focus:ring-offset-gray-900">
                    保存设置
                </button>
            </div>
        </form>
    </div>
</div>
@endsection

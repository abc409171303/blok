@extends('layouts.admin')

@section('content')
<div class="mb-6 flex items-center justify-between">
    <h1 class="text-2xl font-bold text-gray-900">编辑分类</h1>
    <a href="{{ route('admin.categories.index') }}" class="text-sm text-blue-600 hover:text-blue-800">返回列表</a>
</div>

<div class="rounded-lg bg-white p-6 shadow">
    <form action="{{ route('admin.categories.update', $category) }}" method="POST">
        @csrf
        @method('PUT')
        <div class="mb-4">
            <label class="mb-1 block text-sm font-medium text-gray-700">分类名称</label>
            <input type="text" name="name" value="{{ old('name', $category->name) }}" class="w-full rounded-lg border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500" required>
            @error('name')<p class="mt-1 text-sm text-red-600">{{ $message }}</p>@enderror
        </div>
        <div class="mb-4">
            <label class="mb-1 block text-sm font-medium text-gray-700">描述</label>
            <input type="text" name="description" value="{{ old('description', $category->description) }}" class="w-full rounded-lg border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500">
        </div>
        <div class="mb-4">
            <label class="mb-1 block text-sm font-medium text-gray-700">上级分类</label>
            <select name="parent_id" class="w-full rounded-lg border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500">
                <option value="">顶级分类</option>
                @foreach($categories as $cat)
                    <option value="{{ $cat->id }}" {{ old('parent_id', $category->parent_id) == $cat->id ? 'selected' : '' }}>{{ $cat->name }}</option>
                @endforeach
            </select>
        </div>
        <div class="mb-6">
            <label class="mb-1 block text-sm font-medium text-gray-700">排序</label>
            <input type="number" name="sort_order" value="{{ old('sort_order', $category->sort_order) }}" min="0" class="w-24 rounded-lg border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500">
        </div>
        <button type="submit" class="rounded-lg bg-blue-600 px-4 py-2 text-white hover:bg-blue-700">更新</button>
    </form>
</div>
@endsection

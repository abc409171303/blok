@extends('layouts.admin')

@section('page-title', '分类管理')

@section('content')
<div>
    <div class="flex items-center justify-between mb-6">
        <h1 class="text-2xl font-bold text-gray-800">分类</h1>
        <a href="{{ route('admin.categories.create') }}" class="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
            新建分类
        </a>
    </div>

    <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden" id="category-table-container">
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead>
                    <tr class="bg-gray-50 border-b border-gray-200">
                        <th class="text-left px-4 py-3 font-medium text-gray-600 w-12">ID</th>
                        <th class="text-left px-4 py-3 font-medium text-gray-600">名称</th>
                        <th class="text-left px-4 py-3 font-medium text-gray-600">描述</th>
                        <th class="text-left px-4 py-3 font-medium text-gray-600">上级分类</th>
                        <th class="text-left px-4 py-3 font-medium text-gray-600">排序</th>
                        <th class="text-left px-4 py-3 font-medium text-gray-600">文章数</th>
                        <th class="text-left px-4 py-3 font-medium text-gray-600 w-64">操作</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    @forelse($categories as $category)
                    <tr class="hover:bg-gray-50 transition-colors">
                        <td class="px-4 py-3 text-gray-500">{{ $category->id }}</td>
                        <td class="px-4 py-3">
                            <span class="font-medium text-gray-800">{{ $category->name }}</span>
                        </td>
                        <td class="px-4 py-3 text-gray-600">
                            {{ Str::limit($category->description, 30) ?: '-' }}
                        </td>
                        <td class="px-4 py-3 text-gray-600">
                            {{ $category->parent ? $category->parent->name : '顶级分类' }}
                        </td>
                        <td class="px-4 py-3 text-gray-600">{{ $category->sort_order }}</td>
                        <td class="px-4 py-3 text-gray-600">{{ $category->posts->count() }}</td>
                        <td class="px-4 py-3">
                            <div class="flex items-center gap-2 flex-wrap">
                                @if(auth()->user()?->isSuperAdmin())
                                    @include('admin.categories._sort-buttons', ['category' => $category, 'isFirst' => $loop->first, 'isLast' => $loop->last])
                                @endif
                                <a href="{{ route('admin.categories.edit', $category) }}" class="text-blue-600 hover:text-blue-800 text-sm">编辑</a>
                                <form action="{{ route('admin.categories.destroy', $category) }}" method="POST" onsubmit="return confirm('确定要删除这个分类吗？')" class="inline">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="text-red-600 hover:text-red-800 text-sm">删除</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    @if($category->children->isNotEmpty())
                        @foreach($category->children as $child)
                        <tr class="hover:bg-gray-50 transition-colors bg-gray-50/50">
                            <td class="px-4 py-3 text-gray-500">{{ $child->id }}</td>
                            <td class="px-4 py-3">
                                <span class="pl-6 text-gray-700">
                                    <span class="text-gray-300 mr-1">&#9492;</span>
                                    {{ $child->name }}
                                </span>
                            </td>
                            <td class="px-4 py-3 text-gray-600">
                                {{ Str::limit($child->description, 30) ?: '-' }}
                            </td>
                            <td class="px-4 py-3 text-gray-600">
                                {{ $child->parent ? $child->parent->name : '顶级分类' }}
                            </td>
                            <td class="px-4 py-3 text-gray-600">{{ $child->sort_order }}</td>
                            <td class="px-4 py-3 text-gray-600">{{ $child->posts->count() }}</td>
                            <td class="px-4 py-3">
                                <div class="flex items-center gap-2 flex-wrap">
                                    @if(auth()->user()?->isSuperAdmin())
                                    @include('admin.categories._sort-buttons', ['category' => $child, 'isFirst' => $loop->first, 'isLast' => $loop->last])
                                @endif
                                    <a href="{{ route('admin.categories.edit', $child) }}" class="text-blue-600 hover:text-blue-800 text-sm">编辑</a>
                                    <form action="{{ route('admin.categories.destroy', $child) }}" method="POST" onsubmit="return confirm('确定要删除这个分类吗？')" class="inline">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="text-red-600 hover:text-red-800 text-sm">删除</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        @endforeach
                    @endif
                    @empty
                    <tr>
                        <td colspan="7" class="px-4 py-12 text-center text-gray-500">
                            <div class="flex flex-col items-center gap-2">
                                <svg class="w-12 h-12 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z"/></svg>
                                <span>暂无分类</span>
                            </div>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
(function () {
    var MOVE_URL = @json(route('admin.categories.move', ['category' => '__KEY__'], false));
    var CSRF = document.querySelector('meta[name="csrf-token"]');
    var busy = false;

    function lockButtons(lock) {
        document.querySelectorAll('[data-move-btn]').forEach(function (b) {
            if (lock) {
                if (b.dataset.origDisabled === undefined) {
                    b.dataset.origDisabled = b.disabled ? '1' : '0';
                }
                b.disabled = true;
            } else {
                b.disabled = b.dataset.origDisabled === '1';
            }
        });
    }

    function refreshTable() {
        fetch(window.location.href, { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
            .then(function (r) { return r.text(); })
            .then(function (html) {
                var doc = new DOMParser().parseFromString(html, 'text/html');
                var fresh = doc.getElementById('category-table-container');
                var target = document.getElementById('category-table-container');
                if (fresh && target) {
                    target.innerHTML = fresh.innerHTML;
                }
                busy = false;
            })
            .catch(function () {
                busy = false;
                lockButtons(false);
            });
    }

    document.addEventListener('click', function (e) {
        var btn = e.target.closest('[data-move-btn]');
        if (!btn || btn.disabled || busy) {
            return;
        }

        busy = true;
        lockButtons(true);

        var slug = btn.dataset.slug;
        var action = btn.dataset.action;
        var url = MOVE_URL.replace('__KEY__', slug);

        fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'X-CSRF-TOKEN': CSRF ? CSRF.content : '',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify({ action: action })
        })
        .then(function (r) {
            return r.json().then(function (d) { return { ok: r.ok, d: d }; });
        })
        .then(function (res) {
            if (!res.ok || !res.d || !res.d.success) {
                alert((res.d && res.d.message) || '排序失败，请重试。');
                busy = false;
                lockButtons(false);
                return;
            }
            refreshTable();
        })
        .catch(function () {
            alert('网络错误，排序失败，请重试。');
            busy = false;
            lockButtons(false);
        });
    });
})();
</script>
@endsection

@if(auth()->user()?->isSuperAdmin())
@php
    $btnBase = 'inline-flex items-center justify-center w-6 h-6 rounded border border-gray-300 text-xs font-medium text-gray-600 hover:bg-gray-100 disabled:opacity-40 disabled:cursor-not-allowed transition-colors';
    $isFirst = $isFirst ?? false;
    $isLast = $isLast ?? false;
@endphp
<div class="inline-flex items-center gap-0.5" role="group" aria-label="调整排序">
    <button type="button" data-move-btn data-slug="{{ $category->slug }}" data-action="top" title="置顶" aria-label="置顶"
        class="{{ $btnBase }}" {{ $isFirst ? 'disabled' : '' }}>T</button>
    <button type="button" data-move-btn data-slug="{{ $category->slug }}" data-action="up" title="上移" aria-label="上移"
        class="{{ $btnBase }}" {{ $isFirst ? 'disabled' : '' }}>↑</button>
    <button type="button" data-move-btn data-slug="{{ $category->slug }}" data-action="down" title="下移" aria-label="下移"
        class="{{ $btnBase }}" {{ $isLast ? 'disabled' : '' }}>↓</button>
    <button type="button" data-move-btn data-slug="{{ $category->slug }}" data-action="bottom" title="置底" aria-label="置底"
        class="{{ $btnBase }}" {{ $isLast ? 'disabled' : '' }}>⊥</button>
</div>
@endif

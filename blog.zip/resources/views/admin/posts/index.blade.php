@extends('layouts.admin')

@section('page-title', '系统概况 / 博客文章')

@section('content')
<div x-data="postsManager()">
    {{-- ========== 筛选 + 操作区 ========== --}}
    <div class="bg-white rounded-xl shadow-sm border border-gray-200 mb-5">
        <div class="p-4">
            <div class="flex flex-wrap items-center gap-3">
                <form method="GET" action="{{ route('admin.posts.index') }}" class="flex flex-wrap items-center gap-3 flex-1" id="postFilterForm">
                    <div class="flex-1 min-w-[220px] relative">
                        <svg class="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                        </svg>
                        <input type="text" name="search" value="{{ request('search') }}" placeholder="搜索文章标题..."
                            class="w-full pl-9 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none">
                    </div>
                    <button type="submit" class="inline-flex items-center gap-1.5 px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-medium transition-colors">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                        </svg>
                        搜索
                    </button>
                    <button type="button" @click="resetFilter()" class="px-4 py-2 border border-gray-300 hover:bg-gray-50 text-gray-600 rounded-lg text-sm font-medium transition-colors">
                        重置
                    </button>
                    <button type="button" @click="moreOpen = !moreOpen"
                        class="inline-flex items-center gap-1 px-3 py-2 text-gray-500 hover:text-gray-700 rounded-lg text-sm font-medium transition-colors">
                        更多
                        <svg class="w-3.5 h-3.5 transition-transform" :class="moreOpen ? 'rotate-180' : ''" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
                        </svg>
                    </button>
                </form>

                <div class="flex items-center gap-2 md:ml-auto">
                    <button @click="openImportModal()" class="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-medium transition-colors">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"/>
                        </svg>
                        批量导入
                    </button>
                    <a href="{{ route('admin.posts.create') }}" class="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-medium transition-colors">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
                        </svg>
                        增加
                    </a>
                </div>
            </div>

            {{-- 更多筛选条件 --}}
            <div x-show="moreOpen" x-cloak x-transition:enter="transition ease-out duration-150" x-transition:enter-start="opacity-0" x-transition:enter-end="opacity-100" class="mt-4 pt-4 border-t border-gray-100 flex flex-wrap items-center gap-3">
                <select name="status" form="postFilterForm" class="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none bg-white">
                    <option value="">所有状态</option>
                    <option value="draft" {{ request('status') === 'draft' ? 'selected' : '' }}>草稿</option>
                    <option value="published" {{ request('status') === 'published' ? 'selected' : '' }}>已发布</option>
                </select>
                <select name="category_id" form="postFilterForm" class="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none bg-white">
                    <option value="">所有分类</option>
                    @foreach($categories as $cat)
                    <option value="{{ $cat->id }}" {{ request('category_id') == $cat->id ? 'selected' : '' }}>{{ $cat->name }}</option>
                    @endforeach
                </select>
                <select name="tag_id" form="postFilterForm" class="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none bg-white">
                    <option value="">所有标签</option>
                    @foreach($tags as $tag)
                    <option value="{{ $tag->id }}" {{ request('tag_id') == $tag->id ? 'selected' : '' }}>{{ $tag->name }}</option>
                    @endforeach
                </select>
                <select name="access_mode" form="postFilterForm" class="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none bg-white">
                    <option value="">访问模式</option>
                    <option value="public" {{ request('access_mode') === 'public' ? 'selected' : '' }}>公开</option>
                    <option value="private" {{ request('access_mode') === 'private' ? 'selected' : '' }}>密码访问</option>
                </select>
            </div>
        </div>
    </div>

    {{-- ========== 表格 ========== --}}
    <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead>
                    <tr class="bg-gray-50 border-b border-gray-200 text-gray-600">
                        <th class="text-left px-4 py-3 w-10">
                            <input type="checkbox" @change="toggleAll($event)" :checked="selectedIds.length === totalCount && totalCount > 0" class="rounded border-gray-300">
                        </th>
                        <th class="text-left px-4 py-3 font-medium w-14">ID</th>
                        <th class="text-left px-4 py-3 font-medium">标题</th>
                        <th class="text-left px-4 py-3 font-medium">分类</th>
                        <th class="text-left px-4 py-3 font-medium">标签</th>
                        <th class="text-left px-4 py-3 font-medium">置顶</th>
                        <th class="text-left px-4 py-3 font-medium">热门</th>
                        <th class="text-left px-4 py-3 font-medium">推荐</th>
                        <th class="text-left px-4 py-3 font-medium">立即发布</th>
                        <th class="text-left px-4 py-3 font-medium">访问模式</th>
                        <th class="text-left px-4 py-3 font-medium w-36">操作</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    @forelse($posts as $post)
                    <tr class="hover:bg-gray-50 transition-colors" :class="selectedIds.includes({{ $post->id }}) ? 'bg-blue-50/50' : ''">
                        <td class="px-4 py-3">
                            <input type="checkbox" value="{{ $post->id }}" @change="toggleItem($event)" :checked="selectedIds.includes({{ $post->id }})" class="rounded border-gray-300">
                        </td>
                        <td class="px-4 py-3 text-gray-400">{{ $post->id }}</td>
                        <td class="px-4 py-3 max-w-[280px]">
                            <div class="flex items-center gap-1.5 flex-wrap">
                                <a href="{{ route('admin.posts.edit', $post) }}" class="text-blue-600 hover:text-blue-800 font-medium truncate">{{ Str::limit($post->title, 40) }}</a>
                                <span x-show="getFlag({{ $post->id }}, 'is_top')" x-cloak class="inline-flex items-center px-1.5 py-0.5 rounded text-xs font-medium bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300">置顶</span>
                                <span x-show="getFlag({{ $post->id }}, 'is_hot')" x-cloak class="inline-flex items-center px-1.5 py-0.5 rounded text-xs font-medium bg-orange-100 text-orange-700 dark:bg-orange-900/40 dark:text-orange-300">热门</span>
                                <span x-show="getFlag({{ $post->id }}, 'is_recommend')" x-cloak class="inline-flex items-center px-1.5 py-0.5 rounded text-xs font-medium bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300">推荐</span>
                            </div>
                        </td>
                        <td class="px-4 py-3 text-gray-600">{{ $post->category->name ?? '-' }}</td>
                        <td class="px-4 py-3">
                            <div class="flex items-center gap-1 flex-wrap">
                                @forelse($post->tags as $tag)
                                <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs bg-gray-100 text-gray-600">{{ $tag->name }}</span>
                                @empty
                                <span class="text-gray-300">-</span>
                                @endforelse
                            </div>
                        </td>
                        <td class="px-4 py-3 text-center">
                            <button type="button" @click="toggleFlag({{ $post->id }}, 'is_top')"
                                :disabled="switching['{{ $post->id }}_is_top']"
                                title="置顶"
                                class="inline-block w-4 h-4 rounded-full transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-blue-300 focus:ring-offset-2 dark:focus:ring-offset-gray-900 disabled:opacity-40 disabled:cursor-not-allowed"
                                :class="getFlag({{ $post->id }}, 'is_top') ? 'bg-blue-500 hover:bg-blue-600' : 'bg-gray-300 hover:bg-gray-400 dark:bg-gray-600 dark:hover:bg-gray-500'"></button>
                        </td>
                        <td class="px-4 py-3 text-center">
                            <button type="button" @click="toggleFlag({{ $post->id }}, 'is_hot')"
                                :disabled="switching['{{ $post->id }}_is_hot']"
                                title="热门"
                                class="inline-block w-4 h-4 rounded-full transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-blue-300 focus:ring-offset-2 dark:focus:ring-offset-gray-900 disabled:opacity-40 disabled:cursor-not-allowed"
                                :class="getFlag({{ $post->id }}, 'is_hot') ? 'bg-blue-500 hover:bg-blue-600' : 'bg-gray-300 hover:bg-gray-400 dark:bg-gray-600 dark:hover:bg-gray-500'"></button>
                        </td>
                        <td class="px-4 py-3 text-center">
                            <button type="button" @click="toggleFlag({{ $post->id }}, 'is_recommend')"
                                :disabled="switching['{{ $post->id }}_is_recommend']"
                                title="推荐"
                                class="inline-block w-4 h-4 rounded-full transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-blue-300 focus:ring-offset-2 dark:focus:ring-offset-gray-900 disabled:opacity-40 disabled:cursor-not-allowed"
                                :class="getFlag({{ $post->id }}, 'is_recommend') ? 'bg-blue-500 hover:bg-blue-600' : 'bg-gray-300 hover:bg-gray-400 dark:bg-gray-600 dark:hover:bg-gray-500'"></button>
                        </td>
                        <td class="px-4 py-3">
                            <button type="button" @click="toggleStatus({{ $post->id }})"
                                :disabled="switching['{{ $post->id }}_status']"
                                class="inline-flex items-center gap-1.5 text-sm disabled:opacity-40">
                                <span class="w-2 h-2 rounded-full" :class="getMeta({{ $post->id }}, 'status') === 'published' ? 'bg-green-500' : 'bg-gray-400 dark:bg-gray-500'"></span>
                                <span :class="getMeta({{ $post->id }}, 'status') === 'published' ? 'text-green-600' : 'text-gray-500 dark:text-gray-400'">
                                    <span x-text="getMeta({{ $post->id }}, 'status') === 'published' ? '是' : '否'"></span>
                                </span>
                            </button>
                        </td>
                        <td class="px-4 py-3">
                            <button type="button" @click="toggleAccess({{ $post->id }})"
                                :disabled="switching['{{ $post->id }}_access_mode']"
                                class="inline-flex items-center gap-1 px-2 py-1 rounded-lg text-sm border transition-colors disabled:opacity-40"
                                :class="getMeta({{ $post->id }}, 'access_mode') === 'private' ? 'border-amber-200 bg-amber-50 text-amber-700 dark:border-amber-700/40 dark:bg-amber-900/30 dark:text-amber-300' : 'border-gray-200 text-gray-600 hover:border-blue-300 dark:border-gray-700 dark:text-gray-300'">
                                <span x-text="getMeta({{ $post->id }}, 'access_mode') === 'public' ? '公开' : '密码访问'"></span>
                            </button>
                        </td>
                        <td class="px-4 py-3">
                            <div class="flex items-center gap-2">
                                <a href="{{ route('blog.show', $post->slug) }}{{ $post->status === 'draft' ? '?preview=1' : '' }}" target="_blank" class="text-gray-600 hover:text-blue-600 text-sm">查看</a>
                                <a href="{{ route('admin.posts.edit', $post) }}" class="text-blue-600 hover:text-blue-800 text-sm">编辑</a>
                                <form action="{{ route('admin.posts.destroy', $post) }}" method="POST" onsubmit="return confirm('确定要删除这篇文章吗？')" class="inline">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="text-red-600 hover:text-red-800 text-sm">删除</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="11" class="px-4 py-12 text-center text-gray-500">
                            <div class="flex flex-col items-center gap-2">
                                <svg class="w-12 h-12 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z"/></svg>
                                <span>暂无文章</span>
                            </div>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        @if($posts->hasPages() || $posts->total() > 0)
        <div class="px-4 py-3 border-t border-gray-200">
            {{ $posts->appends(request()->except('page'))->links('vendor.pagination.posts') }}
        </div>
        @endif
    </div>

    {{-- ========== 批量操作浮动条 ========== --}}
    <div x-show="selectedIds.length > 0" x-cloak x-transition class="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 flex items-center gap-3 bg-gray-900 text-white rounded-xl shadow-xl px-4 py-3">
        <span class="text-sm text-gray-300">已选 <span class="text-white font-semibold" x-text="selectedIds.length"></span> 项</span>
        <button @click="openBatchEditModal()" class="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 rounded-lg text-sm transition-colors">批量编辑</button>
        <form method="POST" action="{{ route('admin.posts.batch-destroy') }}" x-ref="batchDeleteForm" @submit.prevent="batchDelete()">
            @csrf
            <template x-for="id in selectedIds" :key="id">
                <input type="hidden" name="ids[]" :value="id">
            </template>
            <button type="submit" class="px-3 py-1.5 bg-red-500 hover:bg-red-600 rounded-lg text-sm transition-colors">批量删除</button>
        </form>
    </div>

    {{-- ========== 批量导入弹窗 ========== --}}
    <div x-show="importModalOpen" x-cloak class="fixed inset-0 z-50 flex items-center justify-center" @keydown.escape.window="importModalOpen = false">
        <div class="fixed inset-0 bg-black/50" @click="importModalOpen = false"></div>
        <div class="relative bg-white rounded-xl shadow-lg w-full max-w-md mx-4 p-6 z-10">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-lg font-semibold text-gray-800">批量导入文章</h3>
                <button @click="importModalOpen = false" class="text-gray-400 hover:text-gray-600">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
                </button>
            </div>
            <form action="{{ route('admin.posts.import') }}" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="border-2 border-dashed border-gray-300 rounded-xl p-6 text-center hover:border-blue-400 transition-colors cursor-pointer"
                    @click="$refs.importFile.click()">
                    <svg class="w-10 h-10 mx-auto text-gray-400 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"/>
                    </svg>
                    <p class="text-sm text-gray-600">点击选择 JSON 文件</p>
                    <p class="text-xs text-gray-400 mt-1">支持 .json 格式，最大 2MB</p>
                    <input type="file" name="file" x-ref="importFile" accept=".json,application/json" class="hidden" @change="importFileChanged($event)">
                </div>
                <p class="text-xs text-gray-400 mt-3 leading-relaxed">
                    JSON 格式：对象数组，每项含 title（必填）、summary、content、category、tags（数组）、status（draft/published）、is_top、is_hot、is_recommend、access_mode（public/private）。
                </p>
                <div class="flex items-center justify-end gap-3 pt-4 mt-4 border-t border-gray-200">
                    <button type="button" @click="importModalOpen = false" class="px-4 py-2 text-sm text-gray-600 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors">取消</button>
                    <button type="submit" class="px-4 py-2 text-sm text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors">开始导入</button>
                </div>
            </form>
        </div>
    </div>

    {{-- ========== 批量编辑弹窗 ========== --}}
    <div x-show="batchEditModalOpen" x-cloak class="fixed inset-0 z-50 flex items-center justify-center" @keydown.escape.window="closeBatchEditModal()">
        <div class="fixed inset-0 bg-black/50" @click="closeBatchEditModal()"></div>
        <div class="relative bg-white rounded-xl shadow-lg w-full max-w-lg mx-4 p-6 z-10">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-lg font-semibold text-gray-800">批量编辑文章</h3>
                <button @click="closeBatchEditModal()" class="text-gray-400 hover:text-gray-600">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
                </button>
            </div>
            <form action="{{ route('admin.posts.batch-update') }}" method="POST" x-ref="batchEditForm" @submit.prevent="batchEditSubmit()">
                @csrf
                <template x-for="id in selectedIds" :key="'be' + id">
                    <input type="hidden" name="ids[]" :value="id">
                </template>
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">分类</label>
                        <select name="category_id"
                            class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white">
                            <option value="">不修改</option>
                            @foreach($categories as $cat)
                            <option value="{{ $cat->id }}">{{ $cat->name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">状态</label>
                        <select name="status"
                            class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white">
                            <option value="">不修改</option>
                            <option value="draft">草稿</option>
                            <option value="published">已发布</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">访问模式</label>
                        <select name="access_mode" x-model="batchEditData.access_mode"
                            class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white">
                            <option value="">不修改</option>
                            <option value="public">公开</option>
                            <option value="private">密码访问</option>
                        </select>
                    </div>
                    <div x-show="batchEditData.access_mode === 'private'" x-cloak>
                        <label class="block text-sm font-medium text-gray-700 mb-1">访问密码</label>
                        <input type="password" name="access_password" x-ref="batchEditPwd" autocomplete="new-password"
                            placeholder="设置访客查看正文所需密码"
                            class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none">
                        <p class="text-xs text-gray-400 mt-1">保存后，访客需输入此密码才能查看文章正文。</p>
                    </div>
                    <div class="grid grid-cols-3 gap-3">
                        <div class="flex flex-col items-center gap-2">
                            <label class="text-sm font-medium text-gray-700">置顶</label>
                            <input type="hidden" name="is_top" :value="batchEditData.is_top ? '1' : '0'">
                            <button type="button" @click="batchEditData.is_top = !batchEditData.is_top"
                                class="relative inline-flex items-center h-6 w-11 rounded-full transition-colors duration-200"
                                :class="batchEditData.is_top ? 'bg-blue-500' : 'bg-gray-300'">
                                <span class="inline-block w-4 h-4 rounded-full bg-white shadow transform transition-transform duration-200"
                                    :class="batchEditData.is_top ? 'translate-x-6' : 'translate-x-1'"></span>
                            </button>
                        </div>
                        <div class="flex flex-col items-center gap-2">
                            <label class="text-sm font-medium text-gray-700">热门</label>
                            <input type="hidden" name="is_hot" :value="batchEditData.is_hot ? '1' : '0'">
                            <button type="button" @click="batchEditData.is_hot = !batchEditData.is_hot"
                                class="relative inline-flex items-center h-6 w-11 rounded-full transition-colors duration-200"
                                :class="batchEditData.is_hot ? 'bg-blue-500' : 'bg-gray-300'">
                                <span class="inline-block w-4 h-4 rounded-full bg-white shadow transform transition-transform duration-200"
                                    :class="batchEditData.is_hot ? 'translate-x-6' : 'translate-x-1'"></span>
                            </button>
                        </div>
                        <div class="flex flex-col items-center gap-2">
                            <label class="text-sm font-medium text-gray-700">推荐</label>
                            <input type="hidden" name="is_recommend" :value="batchEditData.is_recommend ? '1' : '0'">
                            <button type="button" @click="batchEditData.is_recommend = !batchEditData.is_recommend"
                                class="relative inline-flex items-center h-6 w-11 rounded-full transition-colors duration-200"
                                :class="batchEditData.is_recommend ? 'bg-blue-500' : 'bg-gray-300'">
                                <span class="inline-block w-4 h-4 rounded-full bg-white shadow transform transition-transform duration-200"
                                    :class="batchEditData.is_recommend ? 'translate-x-6' : 'translate-x-1'"></span>
                            </button>
                        </div>
                    </div>
                </div>
                <div class="flex items-center justify-end gap-3 pt-4 mt-4 border-t border-gray-200">
                    <button type="button" @click="closeBatchEditModal()" class="px-4 py-2 text-sm text-gray-600 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors">取消</button>
                    <button type="submit" class="px-4 py-2 text-sm text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors">保存修改</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('alpine:init', () => {
    Alpine.data('postsManager', () => ({
        selectedIds: [],
        batchEditModalOpen: false,
        batchEditData: { category_id: '', status: '', access_mode: '', is_top: false, is_hot: false, is_recommend: false },
        importModalOpen: false,
        importFileName: '',
        moreOpen: false,
        totalCount: {{ $posts->total() }},

        // 行内开关状态（置顶/热门/推荐）与元数据（发布状态/访问模式），以文章 ID 为键
        flagStates: {!! $posts->mapWithKeys(fn($p) => [$p->id => ['is_top' => (bool)$p->is_top, 'is_hot' => (bool)$p->is_hot, 'is_recommend' => (bool)$p->is_recommend]])->toJson() !!},
        postMeta: {!! $posts->mapWithKeys(fn($p) => [$p->id => ['status' => $p->status, 'access_mode' => $p->access_mode]])->toJson() !!},
        // 提交中标记（key = id_field）与防抖定时器
        switching: {},
        _saveTimers: {},

        toggleAll(event) {
            if (event.target.checked) {
                this.selectedIds = [];
                @foreach($posts as $post)
                this.selectedIds.push({{ $post->id }});
                @endforeach
            } else {
                this.selectedIds = [];
            }
        },

        toggleItem(event) {
            const id = parseInt(event.target.value);
            if (event.target.checked) {
                if (!this.selectedIds.includes(id)) this.selectedIds.push(id);
            } else {
                this.selectedIds = this.selectedIds.filter(i => i !== id);
            }
        },

        resetFilter() {
            window.location.href = '{{ route('admin.posts.index') }}';
        },

        // ===== 行内开关（置顶/热门/推荐） =====
        getFlag(id, field) {
            return !!(this.flagStates[id] && this.flagStates[id][field]);
        },

        getMeta(id, key) {
            return (this.postMeta[id] || {})[key] || '';
        },

        // 点击后立即切换 UI，防抖 300ms 后提交后端；提交期间锁定该开关
        toggleFlag(id, field) {
            const key = id + '_' + field;
            if (this.switching[key]) return;
            this.flagStates[id] = this.flagStates[id] || {};
            this.flagStates[id][field] = !this.getFlag(id, field);
            if (this._saveTimers[key]) clearTimeout(this._saveTimers[key]);
            this._saveTimers[key] = setTimeout(() => this.saveFlag(id, field, this.flagStates[id][field]), 300);
        },

        saveFlag(id, field, value) {
            const key = id + '_' + field;
            this.switching[key] = true;
            const csrf = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
            fetch('{{ route('admin.posts.toggle', ['post' => '__ID__']) }}'.replace('__ID__', id), {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': csrf,
                    'Accept': 'application/json',
                },
                body: JSON.stringify({ field: field, value: value }),
            })
            .then(r => r.json())
            .then(res => {
                this.switching[key] = false;
                if (res.success) {
                    this.flagStates[id][field] = !!res.value;
                    window.notify('已更新', 'success');
                } else {
                    this.flagStates[id][field] = !value;
                    window.notify(res.message || '切换失败', 'error');
                }
            })
            .catch(() => {
                this.switching[key] = false;
                this.flagStates[id][field] = !value;
                window.notify('请求失败，请重试', 'error');
            });
        },

        // ===== 发布状态 / 访问模式 =====
        toggleStatus(id) {
            this.toggleMeta(id, 'status', this.getMeta(id, 'status') === 'published' ? 'draft' : 'published');
        },

        toggleAccess(id) {
            this.toggleMeta(id, 'access_mode', this.getMeta(id, 'access_mode') === 'public' ? 'private' : 'public');
        },

        toggleMeta(id, field, nextValue) {
            const key = id + '_' + field;
            if (this.switching[key]) return;
            this.switching[key] = true;
            const csrf = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
            fetch('{{ route('admin.posts.toggle', ['post' => '__ID__']) }}'.replace('__ID__', id), {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': csrf,
                    'Accept': 'application/json',
                },
                body: JSON.stringify({ field: field, value: nextValue }),
            })
            .then(r => r.json())
            .then(res => {
                this.switching[key] = false;
                if (res.success) {
                    this.postMeta[id][field] = res.value;
                    if (field === 'access_mode' && res.value === 'private') {
                        window.notify('已切换为密码访问，请点击编辑设置访问密码', 'success');
                    } else {
                        window.notify('已更新', 'success');
                    }
                } else {
                    window.notify(res.message || '切换失败', 'error');
                }
            })
            .catch(() => {
                this.switching[key] = false;
                window.notify('请求失败，请重试', 'error');
            });
        },

        batchDelete() {
            if (this.selectedIds.length === 0) return;
            if (!confirm('确定要删除选中的 ' + this.selectedIds.length + ' 篇文章吗？')) return;
            this.$refs.batchDeleteForm.submit();
        },

        openBatchEditModal() {
            this.batchEditData = { category_id: '', status: '', access_mode: '', is_top: false, is_hot: false, is_recommend: false };
            this.batchEditModalOpen = true;
        },

        closeBatchEditModal() {
            this.batchEditModalOpen = false;
        },

        // 批量编辑提交：前端校验密码后提交
        batchEditSubmit() {
            if (this.batchEditData.access_mode === 'private') {
                const pw = this.$refs.batchEditPwd ? this.$refs.batchEditPwd.value.trim() : '';
                if (!pw) {
                    window.notify('密码访问模式必须设置访问密码', 'error');
                    return;
                }
            }
            this.$refs.batchEditForm.submit();
        },

        openImportModal() {
            this.importFileName = '';
            this.importModalOpen = true;
        },

        importFileChanged(event) {
            this.importFileName = event.target.files[0] ? event.target.files[0].name : '';
        },
    }));
});
</script>

{{-- 手机端底部安全间距：避免分页被系统导航栏遮挡 --}}
<div class="sm:hidden" style="height:80px" aria-hidden="true"></div>
@endsection

@push('styles')
<style>
[x-cloak] { display: none !important; }
</style>
@endpush

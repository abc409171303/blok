<div x-data="{ prompt: '', loading: false, result: '' }" class="bg-blue-50 rounded-lg p-4 border border-blue-100">
    <h3 class="text-sm font-semibold text-blue-800 mb-3 flex items-center gap-2">
        <i class="fa-solid fa-robot"></i>AI 写作助手
    </h3>
    <textarea x-model="prompt" rows="3" placeholder="描述你想写的内容，如：写一篇关于 PHP 8.2 新特性的博客文章"
        class="w-full px-3 py-2 border border-blue-200 rounded-lg text-xs focus:ring-2 focus:ring-blue-400 focus:border-blue-400 outline-none resize-none mb-3"></textarea>
    <button @click="loading = true; fetch('{{ route('admin.ai.write') }}', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': document.querySelector('meta[name=csrf-token]').content }, body: JSON.stringify({ prompt: prompt }) }).then(r => r.json()).then(data => { if (data.error) { window.notify(data.error, 'error'); } else { result = data.content; } }).finally(() => loading = false)"
        :disabled="!prompt || loading"
        class="w-full px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-300 text-white text-xs rounded-lg transition-colors">
        <span x-show="!loading">生成内容</span>
        <span x-show="loading"><i class="fa-solid fa-spinner fa-spin mr-1"></i>生成中...</span>
    </button>
    <div x-show="result" class="mt-3">
        <div class="text-xs text-gray-500 mb-2 flex items-center justify-between">
            <span>AI 生成结果：</span>
            <button @click="navigator.clipboard.writeText(result)" class="text-blue-600 hover:text-blue-800 text-xs">复制</button>
        </div>
        <div x-html="result" class="text-xs text-gray-700 bg-white rounded-lg p-3 max-h-60 overflow-y-auto border border-blue-100 prose prose-sm max-w-none"></div>
        <button @click="if(typeof vditorInsert !== 'undefined') vditorInsert(result); else document.querySelector('#content').value += result; result=''" class="mt-2 w-full px-3 py-1.5 bg-green-600 hover:bg-green-700 text-white text-xs rounded-lg transition-colors">
            <i class="fa-solid fa-circle-down mr-1"></i>插入编辑器
        </button>
    </div>
</div>

{{-- AI 写作助手 / AI 生成配图 弹窗（挂载于 Vditor 工具栏按钮） --}}
<style>
.ai-modal {
    position: fixed;
    inset: 0;
    z-index: 100;
    display: none;
}
.ai-modal.open {
    display: block;
}
.ai-modal .ai-backdrop {
    position: absolute;
    inset: 0;
    background: rgba(0, 0, 0, 0.5);
}
.ai-modal .ai-panel {
    position: relative;
    width: 100%;
    max-width: 760px;
    margin: 6vh auto 0;
    background: #fff;
    border-radius: 12px;
    padding: 24px;
    box-shadow: 0 12px 40px rgba(0, 0, 0, 0.25);
    max-height: 84vh;
    overflow-y: auto;
}
.ai-modal .ai-panel h3 {
    font-size: 16px;
    font-weight: 600;
    color: #1f2937;
    margin-bottom: 16px;
    display: flex;
    align-items: center;
    gap: 8px;
}
.ai-modal .ai-panel textarea {
    width: 100%;
    border: 1px solid #d1d5db;
    border-radius: 8px;
    padding: 10px 12px;
    font-size: 14px;
    line-height: 1.6;
    outline: none;
    resize: vertical;
}
.ai-modal .ai-panel textarea:focus {
    border-color: #3b82f6;
    box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.2);
}
.ai-modal .ai-btn-primary {
    background: #3b82f6;
    color: #fff;
    padding: 8px 20px;
    border-radius: 8px;
    font-size: 14px;
    transition: background 0.2s;
}
.ai-modal .ai-btn-primary:hover {
    background: #2563eb;
}
.ai-modal .ai-btn-primary:disabled {
    background: #9ca3af;
    cursor: not-allowed;
}
.ai-modal .ai-btn-ghost {
    background: #f3f4f6;
    color: #374151;
    padding: 8px 16px;
    border-radius: 8px;
    font-size: 13px;
    transition: background 0.2s;
}
.ai-modal .ai-btn-ghost:hover {
    background: #e5e7eb;
}
.ai-modal .ai-btn-stop {
    background: #ef4444;
    color: #fff;
    padding: 8px 20px;
    border-radius: 8px;
    font-size: 14px;
    transition: background 0.2s;
}
.ai-modal .ai-btn-stop:hover {
    background: #dc2626;
}
.ai-modal .ai-result {
    margin-top: 16px;
    background: #f9fafb;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    padding: 12px 14px;
    max-height: 320px;
    overflow-y: auto;
    font-size: 14px;
    line-height: 1.7;
    color: #374151;
    white-space: pre-wrap;
    word-break: break-word;
}
.ai-modal .ai-loading {
    color: #6b7280;
    text-align: center;
    padding: 24px 0;
    font-size: 14px;
}
.ai-modal .ai-hint {
    font-size: 12px;
    color: #9ca3af;
    margin-top: 4px;
}
/* iPad / 小屏 / 触屏适配 */
@media (max-width: 820px) {
    .ai-modal .ai-panel {
        width: calc(100% - 24px);
        max-width: 100%;
        margin: 2vh auto 0;
        padding: 16px;
        max-height: 92vh;
    }
    .ai-modal .ai-panel h3 {
        font-size: 15px;
        margin-bottom: 12px;
    }
    .ai-modal .ai-panel .ai-btn-primary,
    .ai-modal .ai-panel .ai-btn-ghost,
    .ai-modal .ai-panel .ai-btn-stop {
        min-height: 42px;
        padding: 8px 18px;
    }
    .ai-modal .ai-panel textarea {
        font-size: 16px; /* 防止 iOS 聚焦时自动放大 */
    }
    .ai-modal .ai-result {
        max-height: 40vh;
        -webkit-overflow-scrolling: touch;
    }
}
@media (max-width: 480px) {
    .ai-modal .ai-panel {
        width: calc(100% - 16px);
        margin: 1vh auto 0;
        padding: 14px;
    }
    .ai-modal .ai-panel .ai-btn-primary,
    .ai-modal .ai-panel .ai-btn-ghost,
    .ai-modal .ai-panel .ai-btn-stop {
        min-height: 44px;
        flex: 1;
    }
    .ai-modal .ai-panel .flex.flex-wrap.gap-2.mt-3,
    .ai-modal .ai-panel .flex.flex-wrap.items-center.gap-2.mt-3 {
        gap: 8px;
    }
}
.ai-modal .ai-tag {
    display: inline-flex;
    align-items: center;
    font-size: 12px;
    color: #1d4ed8;
    background: #eff6ff;
    border: 1px solid #bfdbfe;
    border-radius: 6px;
    padding: 2px 8px;
    margin-bottom: 8px;
}
.ai-modal .ai-tag-err {
    color: #b91c1c;
    background: #fef2f2;
    border-color: #fecaca;
}
</style>

{{-- ============ AI 写作弹窗 ============ --}}
<div id="ai-writer-modal" class="ai-modal">
    <div class="ai-backdrop" onclick="closeAiModal('ai-writer-modal')"></div>
    <div class="ai-panel">
        <h3>
            <svg class="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 2a7 7 0 0 0-7 7v6a7 7 0 0 0 14 0V9a7 7 0 0 0-7-7zm-3 9a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm6 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2zM8.9 17h6.2a.5.5 0 0 1 .4.8l-.8 1.2a2 2 0 0 1-1.7 1H9.6a2 2 0 0 1-1.7-1l-.8-1.2a.5.5 0 0 1 .4-.8z"/></svg>
            AI 写作助手
        </h3>

        {{-- 参考标题（自动读取文章标题） --}}
        <div class="ai-tag" id="ai-writer-title-tag">参考标题：暂无</div>

        {{-- 自定义提示词 --}}
        <textarea id="ai-writer-prompt" rows="4" placeholder="补充写作要求，例如：写一篇川西自驾游的游记，从成都出发，途经康定、新都桥，介绍沿途风景与路况建议，包含 Mermaid 自驾线路流程图；留空则使用文章标题一键生成"></textarea>
        <div class="ai-hint">输入框有内容时以输入内容为生成指令、标题作参考；输入框留空时使用文章标题生成。不会读取编辑器正文。</div>

        {{-- 可选上传图片（图生文） --}}
        <div class="flex flex-wrap items-center gap-2 mt-3">
            <button type="button" class="ai-btn-ghost" id="ai-writer-img-btn">上传图片（图生文，可选）</button>
            <input type="file" id="ai-writer-img-input" accept="image/*" class="hidden">
            <span id="ai-writer-img-name" class="text-xs text-gray-500 max-w-[200px] truncate"></span>
            <button type="button" class="ai-btn-ghost" id="ai-writer-img-remove" style="display:none;">移除图片</button>
        </div>
        <div id="ai-writer-img-preview" class="mt-2" style="display:none;">
            <img id="ai-writer-img-preview-img" class="max-h-32 rounded-lg border border-gray-200" alt="图生文参考图">
        </div>

        {{-- 操作按钮 --}}
        <div class="flex flex-wrap items-center gap-2 mt-3">
            <button type="button" class="ai-btn-primary" id="ai-writer-btn">生成内容</button>
            <button type="button" class="ai-btn-stop" id="ai-writer-stop" style="display:none;">停止生成</button>
            <button type="button" class="ai-btn-ghost" onclick="closeAiModal('ai-writer-modal')">关闭</button>
        </div>

        {{-- 输出预览（流式） --}}
        <div id="ai-writer-result" class="ai-result" style="display:none;"></div>
        <div class="flex justify-end gap-2 mt-3" id="ai-writer-actions" style="display:none;">
            <button type="button" class="ai-btn-primary" id="ai-writer-insert">填入编辑器</button>
            <button type="button" class="ai-btn-ghost" onclick="closeAiModal('ai-writer-modal')">放弃结果</button>
        </div>
    </div>
</div>

{{-- ============ AI 生成配图弹窗 ============ --}}
<div id="ai-image-modal" class="ai-modal">
    <div class="ai-backdrop" onclick="closeAiModal('ai-image-modal')"></div>
    <div class="ai-panel">
        <h3>
            <svg class="w-5 h-5 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8.5 13.5l2.5 3 3.5-4.5 4.5 6H5m18-12v12a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2zM6 9a2 2 0 1 0 4 0 2 2 0 0 0-4 0z"/></svg>
            AI 生成配图
        </h3>

        {{-- 提示词（自动从正文提取，可手动修改） --}}
        <textarea id="ai-image-prompt" rows="3" placeholder="描述想要的图片内容，例如：川西高原自驾公路，雪山、草甸、蓝天白云，公路蜿蜒延伸，摄影写实风格"></textarea>
        <div class="ai-hint">已自动提取编辑器正文内容作为绘图描述，可直接修改。</div>

        <div class="flex items-center gap-2 mt-3">
            <button type="button" class="ai-btn-primary" id="ai-image-btn">生成图片</button>
            <button type="button" class="ai-btn-ghost" onclick="closeAiModal('ai-image-modal')">关闭</button>
        </div>

        <div id="ai-image-result" class="mt-4" style="display:none;">
            <div id="ai-image-loading" class="ai-loading">图片生成中，通常需要 10~60 秒，请耐心等待...</div>
            <img id="ai-image-preview" class="hidden max-w-full rounded-lg border border-gray-200 mx-auto" alt="AI 生成的配图">
            <div class="flex justify-end gap-2 mt-3">
                <button type="button" class="ai-btn-primary" id="ai-image-insert" style="display:none;">插入编辑器</button>
                <button type="button" class="ai-btn-ghost" onclick="closeAiModal('ai-image-modal')">关闭</button>
            </div>
        </div>
    </div>
</div>

<script>
function openAiModal(id) {
    document.getElementById(id).classList.add('open');
}
function closeAiModal(id) {
    document.getElementById(id).classList.remove('open');
    if (id === 'ai-writer-modal') {
        stopAiWrite(); // 关闭即放弃，中断进行中的生成
    }
}

window.openAiWriter = function () {
    // 自动读取当前文章标题作为参考上下文
    const titleEl = document.getElementById('title');
    const title = (titleEl && titleEl.value.trim()) || '';
    const tag = document.getElementById('ai-writer-title-tag');
    tag.textContent = title ? '参考标题：' + title : '参考标题：暂无';
    tag.classList.remove('ai-tag-err');
    resetWriterModal();
    openAiModal('ai-writer-modal');
};

window.openAiImage = function () {
    // 自动从编辑器正文提取绘图提示词
    const vd = window.vditor;
    let plain = '';
    if (vd && typeof vd.getValue === 'function') {
        plain = vd.getValue()
            .replace(/```[\s\S]*?```/g, ' ')   // 去代码块
            .replace(/[#*>`_\[\]()!~\-]/g, ' ') // 去 Markdown 符号
            .replace(/\s+/g, ' ')
            .trim();
    }
    const promptEl = document.getElementById('ai-image-prompt');
    promptEl.value = plain ? plain.slice(0, 200) : '';
    resetImageModal();
    openAiModal('ai-image-modal');
};

/* ==================== AI 写作：图生文图片上传 ==================== */
(function () {
    const input = document.getElementById('ai-writer-img-input');
    const btn = document.getElementById('ai-writer-img-btn');
    const removeBtn = document.getElementById('ai-writer-img-remove');
    const nameEl = document.getElementById('ai-writer-img-name');
    const previewWrap = document.getElementById('ai-writer-img-preview');
    const previewImg = document.getElementById('ai-writer-img-preview-img');

    window.__aiWriterImage = ''; // 存相对路径（content/xxx.jpg）

    btn.addEventListener('click', function () { input.click(); });

    input.addEventListener('change', function () {
        const file = input.files && input.files[0];
        if (!file) return;
        if (!/^image\//.test(file.type)) { window.notify('请选择图片文件', 'error'); input.value = ''; return; }
        if (file.size > 5 * 1024 * 1024) { window.notify('图片不能超过 5MB', 'error'); input.value = ''; return; }

        const fd = new FormData();
        fd.append('image', file);
        fetch(window.COVER_UPLOAD_URL || '/admin/upload/image', {
            method: 'POST',
            headers: { 'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content') },
            body: fd,
        })
        .then(function (r) { return r.json(); })
        .then(function (res) {
            if (res.success && res.url) {
                window.__aiWriterImage = res.path || res.url;
                nameEl.textContent = file.name;
                nameEl.style.display = '';
                previewImg.src = res.url;
                previewWrap.style.display = 'block';
                removeBtn.style.display = '';
            } else {
                window.notify('图片上传失败：' + (res.message || '未知错误'), 'error');
            }
        })
        .catch(function (e) { window.notify('图片上传失败：' + e.message, 'error'); })
        .finally(function () { input.value = ''; });
    });

    removeBtn.addEventListener('click', function () {
        window.__aiWriterImage = '';
        nameEl.style.display = 'none';
        nameEl.textContent = '';
        previewWrap.style.display = 'none';
        previewImg.src = '';
        removeBtn.style.display = 'none';
    });
})();

/* ==================== AI 写作：流式生成 ==================== */
var __aiWriteController = null;
var __aiWriteAborted = false;

function resetWriterModal() {
    window.__aiResult = '';
    __aiWriteAborted = false;
    const resultEl = document.getElementById('ai-writer-result');
    resultEl.style.display = 'none';
    resultEl.textContent = '';
    resultEl.style.color = '#374151';
    document.getElementById('ai-writer-actions').style.display = 'none';
    const btn = document.getElementById('ai-writer-btn');
    btn.disabled = false;
    btn.style.display = '';
    document.getElementById('ai-writer-stop').style.display = 'none';
}

function stopAiWrite() {
    if (__aiWriteController) {
        __aiWriteAborted = true;
        __aiWriteController.abort();
    }
}

document.getElementById('ai-writer-btn').addEventListener('click', aiWrite);
document.getElementById('ai-writer-stop').addEventListener('click', stopAiWrite);
document.getElementById('ai-writer-insert').addEventListener('click', aiInsertWriter);

async function aiWrite() {
    const promptEl = document.getElementById('ai-writer-prompt');
    const btn = document.getElementById('ai-writer-btn');
    const stopBtn = document.getElementById('ai-writer-stop');
    const resultEl = document.getElementById('ai-writer-result');
    const actionsEl = document.getElementById('ai-writer-actions');

    const titleEl = document.getElementById('title');
    const title = (titleEl && titleEl.value.trim()) || '';
    const inputText = promptEl.value.trim();

    // 数据源优先级：弹窗输入框内容 > 页面表单文章标题；不读取编辑器正文
    const instruction = inputText || title;
    if (!instruction) { window.notify('请填写写作要求或文章标题', 'error'); return; }

    // 组装请求体：输入框有文字时标题作为参考上下文；输入框为空时标题本身就是生成指令
    const body = { prompt: instruction, stream: true };
    if (inputText && title) { body.title = title; }
    if (window.__aiWriterImage) { body.image = window.__aiWriterImage; }

    btn.disabled = true;
    btn.style.display = 'none';
    stopBtn.style.display = '';
    resultEl.style.display = 'block';
    resultEl.textContent = '';
    resultEl.style.color = '#374151';
    actionsEl.style.display = 'none';
    window.__aiResult = '';
    __aiWriteAborted = false;

    const controller = new AbortController();
    __aiWriteController = controller;

    try {
        const resp = await fetch('{{ route('admin.ai.write') }}', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                'Accept': 'text/event-stream',
            },
            body: JSON.stringify(body),
            signal: controller.signal,
        });

        if (!resp.ok || !resp.body) {
            let msg = '请求失败（HTTP ' + resp.status + '）';
            try {
                const err = await resp.json();
                if (err.error) msg = err.error;
            } catch (e) {}
            throw new Error(msg);
        }

        // 流式读取（打字机效果）
        const reader = resp.body.getReader();
        const decoder = new TextDecoder();
        let buf = '';
        let done = false;

        while (true) {
            const { value, done: rd } = await reader.read();
            if (rd) break;
            buf += decoder.decode(value, { stream: true });

            // 按 SSE 事件边界拆分
            let idx;
            while ((idx = buf.indexOf('\n\n')) !== -1) {
                const evt = buf.slice(0, idx);
                buf = buf.slice(idx + 2);
                const lines = evt.split('\n');
                for (const line of lines) {
                    if (!line.startsWith('data:')) continue;
                    const payload = line.slice(5).trim();
                    if (payload === '[DONE]') { done = true; continue; }
                    try {
                        const j = JSON.parse(payload);
                        if (j.error) { throw new Error(j.error); }
                        if (j.content) {
                            window.__aiResult += j.content;
                            resultEl.textContent = window.__aiResult;
                            resultEl.scrollTop = resultEl.scrollHeight;
                        }
                    } catch (e) { /* 忽略单个坏事件 */ }
                }
            }
            if (done) break;
        }
        // 处理残余 buffer
        if (!done && buf.trim()) {
            const j = JSON.parse(buf.replace(/^data:\s*/, '').trim());
            if (j.content) { window.__aiResult += j.content; resultEl.textContent = window.__aiResult; }
        }
    } catch (e) {
        if (e.name === 'AbortError' || __aiWriteAborted) {
            // 用户停止生成：保留已生成内容
        } else {
            resultEl.textContent = '生成失败：' + e.message;
            resultEl.style.color = '#dc2626';
        }
    } finally {
        __aiWriteController = null;
        btn.disabled = false;
        btn.style.display = '';
        stopBtn.style.display = 'none';
        if (window.__aiResult) {
            actionsEl.style.display = 'flex';
        }
    }
}

function aiInsertWriter() {
    const vd = window.vditor;
    if (window.__aiResult && vd) {
        vd.insertValue(window.__aiResult + '\n');
        window.__aiResult = '';
        closeAiModal('ai-writer-modal');
    }
}

/* ==================== AI 生成配图 ==================== */
function resetImageModal() {
    window.__aiImageUrl = '';
    document.getElementById('ai-image-result').style.display = 'none';
    document.getElementById('ai-image-loading').style.display = 'none';
    document.getElementById('ai-image-loading').style.color = '#6b7280';
    const previewEl = document.getElementById('ai-image-preview');
    previewEl.classList.add('hidden');
    previewEl.src = '';
    document.getElementById('ai-image-insert').style.display = 'none';
    const btn = document.getElementById('ai-image-btn');
    btn.disabled = false;
    btn.textContent = '生成图片';
}

document.getElementById('ai-image-btn').addEventListener('click', aiGenerateImage);
document.getElementById('ai-image-insert').addEventListener('click', aiInsertImage);

async function aiGenerateImage() {
    const promptEl = document.getElementById('ai-image-prompt');
    const btn = document.getElementById('ai-image-btn');
    const resultWrap = document.getElementById('ai-image-result');
    const loadingEl = document.getElementById('ai-image-loading');
    const previewEl = document.getElementById('ai-image-preview');
    const insertEl = document.getElementById('ai-image-insert');
    const prompt = promptEl.value.trim();
    if (!prompt) { window.notify('请输入绘图描述', 'error'); return; }

    btn.disabled = true;
    btn.textContent = '生成中...';
    resultWrap.style.display = 'block';
    loadingEl.style.display = 'block';
    loadingEl.style.color = '#6b7280';
    loadingEl.textContent = '图片生成中，通常需要 10~60 秒，请耐心等待...';
    previewEl.classList.add('hidden');
    insertEl.style.display = 'none';
    window.__aiImageUrl = '';

    try {
        const resp = await fetch('{{ route('admin.ai.generateImage') }}', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
            },
            body: JSON.stringify({ prompt: prompt }),
        });
        const data = await resp.json();
        loadingEl.style.display = 'none';
        if (data.error) {
            loadingEl.style.color = '#dc2626';
            loadingEl.textContent = data.error;
            loadingEl.style.display = 'block';
        } else {
            previewEl.src = data.url;
            previewEl.classList.remove('hidden');
            window.__aiImageUrl = data.url;
            insertEl.style.display = 'inline-block';
        }
    } catch (e) {
        loadingEl.style.display = 'none';
        loadingEl.style.color = '#dc2626';
        loadingEl.textContent = '请求异常：' + e.message;
        loadingEl.style.display = 'block';
    } finally {
        btn.disabled = false;
        btn.textContent = '生成图片';
    }
}

function aiInsertImage() {
    const vd = window.vditor;
    if (window.__aiImageUrl && vd) {
        vd.insertValue('![](' + window.__aiImageUrl + ')');
        window.__aiImageUrl = '';
        closeAiModal('ai-image-modal');
    }
}
</script>

{{--
    标签弹窗树形选择组件（文章创建/编辑页共用）
    用法：@include('admin.posts._tag-picker', ['tagGroups' => $tagGroups, 'selectedTagIds' => [...], 'selectedTagNames' => [...]])
    - tagGroups: 一级标签集合（含 children 关系）
    - selectedTagIds / selectedTagNames: 已选标签 id 与名称数组
    提交时自动生成 <input type="hidden" name="tags[]">，保持原有保存逻辑兼容。
--}}
@php
    $selectedTagIds = $selectedTagIds ?? [];
    $selectedTagNames = $selectedTagNames ?? [];
@endphp
<div x-data="tagPicker({{ json_encode($selectedTagIds) }}, {{ json_encode($selectedTagNames) }}, {{ json_encode($tagGroups->map(fn($g) => ['id' => $g->id, 'name' => $g->name, 'children' => $g->children->map(fn($c) => ['id' => $c->id, 'name' => $c->name])->values()])) }})" class="w-full">

    {{-- 标签输入框（点击弹出选择弹窗） --}}
    <div @click="openTagPicker($event)"
         class="flex items-center flex-wrap gap-1.5 min-h-[42px] px-3 py-2 border border-gray-300 rounded-lg cursor-pointer hover:border-blue-400 focus-within:ring-2 focus-within:ring-blue-500 focus-within:border-blue-500 transition-colors">
        <template x-for="t in selectedTags" :key="t.id">
            <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs bg-gray-100 text-gray-600">
                <span x-text="t.name"></span>
                <button type="button" class="hover:text-red-500 transition-colors" @click.stop="removeTag(t.id)">×</button>
            </span>
        </template>
        <span x-show="selectedTags.length === 0" class="text-sm text-gray-400 pointer-events-none">点击选择标签（可多选不同分类下的子标签）</span>
        <span class="text-xs text-gray-400 ml-auto shrink-0" x-text="selectedTags.length ? '已选 ' + selectedTags.length + ' 个' : ''"></span>
    </div>

    {{-- 已选标签隐藏输入（保持 name="tags[]" 兼容原有保存逻辑） --}}
    <template x-for="t in selectedTags" :key="'h' + t.id">
        <input type="hidden" name="tags[]" :value="t.id">
    </template>

    {{-- 弹窗遮罩：点击外部空白关闭 --}}
    <div x-show="pickerOpen" x-cloak
         class="fixed inset-0 z-50"
         @click="closeTagPicker()"></div>

    {{-- 选择弹窗 --}}
    <div x-show="pickerOpen" x-cloak
         x-transition:enter="transition ease-out duration-150"
         x-transition:enter-start="opacity-0 scale-95"
         x-transition:enter-end="opacity-100 scale-100"
         :style="pickerStyle"
         class="fixed z-50 w-[420px] max-w-[calc(100vw-1.5rem)] bg-white rounded-xl shadow-xl border border-gray-200 overflow-hidden">

        {{-- 弹窗头部：搜索框 --}}
        <div class="px-3 pt-3 pb-2 border-b border-gray-100">
            <div class="relative">
                <svg class="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
                <input type="text" x-model="searchKeyword"
                       class="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                       placeholder="输入关键词快速筛选标签">
            </div>
        </div>

        {{-- 弹窗主体：树形列表（最大高度 + 内部滚动） --}}
        <div class="max-h-[min(60vh,360px)] overflow-y-auto py-2" @click.stop>
            {{-- 无匹配 --}}
            <div x-show="filteredGroups.length === 0" class="px-4 py-8 text-center text-sm text-gray-400">未找到匹配的标签</div>

            {{-- 一级分组（默认折叠，点击展开） --}}
            <template x-for="group in filteredGroups" :key="group.id">
                <div>
                    {{-- 一级标签行 --}}
                    <button type="button"
                            class="flex items-center gap-2 w-full px-3 py-2 text-sm hover:bg-gray-50 transition-colors"
                            :class="group.children.length ? 'font-medium text-gray-800' : ''"
                            @click.stop="group.children.length ? toggleGroup(group.id) : toggleChild(group.id, group.name)">
                        <svg class="w-3.5 h-3.5 shrink-0 transition-transform text-gray-400"
                             :class="expandedGroups.includes(group.id) ? 'rotate-90' : ''"
                             :style="group.children.length ? '' : 'visibility:hidden'"
                             fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
                        <span class="flex-1 text-left" x-text="group.children.length ? group.name : group.name"></span>
                        <span x-show="group.children.length" class="text-xs text-gray-400" x-text="'(' + group.children.length + ')'"></span>
                        {{-- 无子标签的一级标签直接作为可勾选项 --}}
                        <span x-show="!group.children.length" class="shrink-0">
                            <input type="checkbox" :checked="isSelected(group.id)" @change="toggleChild(group.id, group.name)"
                                   class="rounded border-gray-300 text-blue-600 focus:ring-blue-500">
                        </span>
                    </button>

                    {{-- 二级子标签 --}}
                    <div x-show="expandedGroups.includes(group.id)" x-cloak class="pl-8 pr-3 pb-1">
                        <template x-for="child in group.children" :key="child.id">
                            <label class="flex items-center gap-2 py-1.5 cursor-pointer hover:bg-gray-50 rounded-lg px-2">
                                <input type="checkbox" :checked="isSelected(child.id)" @change="toggleChild(child.id, child.name)"
                                       class="rounded border-gray-300 text-blue-600 focus:ring-blue-500">
                                <span class="text-sm text-gray-700" x-text="child.name"></span>
                            </label>
                        </template>
                    </div>
                </div>
            </template>
        </div>

        {{-- 弹窗底部：确认关闭 --}}
        <div class="px-3 py-2.5 border-t border-gray-100 bg-gray-50 flex items-center justify-between">
            <button type="button" class="text-xs text-gray-500 hover:text-red-500 transition-colors" @click="clearAll()">清空已选</button>
            <div class="flex items-center gap-2">
                <span class="text-xs text-gray-400" x-text="'已选 ' + selectedTags.length + ' 个标签'"></span>
                <button type="button"
                        class="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded-lg transition-colors"
                        @click="closeTagPicker()">确认</button>
            </div>
        </div>
    </div>
</div>

{{-- 组件 Alpine 定义 --}}
<script src="{{ asset('js/tag-picker.js') }}"></script>

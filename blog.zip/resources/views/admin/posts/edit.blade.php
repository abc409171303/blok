@extends('layouts.admin')

@push('styles')
<link rel="stylesheet" href="{{ asset('static/vditor/index.css') }}?v=3.11.2">
<style>
.cover-preview-wrap { position: relative; display: inline-block; }
.cover-delete-btn {
    position: absolute; top: -8px; right: -8px;
    width: 28px; height: 28px; line-height: 28px; text-align: center;
    background: rgba(0,0,0,0.55); color: #fff; border: none; border-radius: 50%;
    cursor: pointer; font-size: 14px; font-weight: 600;
    transition: background 0.15s; display: flex; align-items: center; justify-content: center;
}
.cover-delete-btn:hover { background: rgba(220,38,38,0.85); }
.cover-delete-btn svg { width: 14px; height: 14px; }
.vditor { border: none !important; }
.vditor-toolbar {
    background: #f9fafb !important;
    padding: 8px !important;
    border-radius: 8px 8px 0 0 !important;
    border-bottom: 1px solid #e5e7eb !important;
}
.vditor-content { border: none !important; }
.vditor-wysiwyg { border: none !important; padding: 16px !important; }
/* 编辑器内容区：段落紧贴左边缘，无缩进留白 */
#vditor .vditor-reset { padding-left: 0 !important; }
#vditor .vditor-reset p { text-indent: 0 !important; margin-left: 0 !important; padding-left: 0 !important; }
#vditor .vditor-reset blockquote { margin-left: 0 !important; padding-left: 1em !important; border-left: 3px solid #e5e7eb !important; }
/* 文章创建/编辑页：自适应一屏布局
   - 桌面端与 iPad（≥768px 宽）双栏显示，整体适配视口高度，无需滚动即可看到完整表单
   - height 链 + flex 分配，不依赖 100vh，兼容 iPad/iframe/缩放
   - main 内部滚动仅作兜底；保存/取消按钮跟随页面滚动，位于表单末尾 */
html, body {
    height: 100%;
}
body > .flex.min-h-screen {
    height: 100%;
    min-height: 0;
}
main.flex-1 {
    min-height: 0;
    overflow-y: auto;
    flex-basis: auto;
    padding: 1rem;
    display: flex;
    flex-direction: column;
}
/* Vditor 编辑器填充左栏剩余空间（覆盖 JS 固定高度 600） */
#vditor, #vditor .vditor {
    height: 100% !important;
}
/* 桌面/iPad（md+）：vditor 容器固定 flex-basis 0px，避免长内容经百分比 basis 退化撑开左栏 */
@media (min-width: 768px) {
    .post-vditor-wrap {
        flex: 1 1 0px !important;
    }
}
/* 长文在编辑区内部滚动，避免内容溢出撑开页面 */
#vditor .vditor-wysiwyg {
    overflow-y: auto;
}
</style>
@endpush

@section('content')
<div x-data="postEditor()" class="flex flex-col md:min-h-0 md:flex-1">
    <div class="flex items-center justify-between mb-3">
        <h1 class="text-2xl font-bold text-gray-800">编辑文章</h1>
        <a href="{{ route('admin.posts.index') }}" class="inline-flex items-center gap-2 text-gray-500 hover:text-gray-700 text-sm">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
            返回列表
        </a>
    </div>

    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-4 flex flex-col md:min-h-0 md:flex-1" style="padding-bottom: 5.5rem">
        <form action="{{ route('admin.posts.update', $post) }}" method="POST" enctype="multipart/form-data" id="post-form" class="flex-1 md:min-h-0 flex flex-col">
            @csrf
            @method('PUT')

            <div class="flex flex-col md:flex-row gap-4 md:min-h-0 md:flex-1">
                <div class="flex-1 min-w-0 min-h-0 flex flex-col gap-3">
                    <div>
                        <label for="title" class="block text-sm font-medium text-gray-700 mb-1.5">标题 <span class="text-red-500">*</span></label>
                        <input type="text" name="title" id="title" value="{{ old('title', $post->title) }}" required
                            class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none">
                        @error('title')<p class="mt-1 text-sm text-red-500">{{ $message }}</p>@enderror
                    </div>

                    <div>
                        <label for="summary" class="block text-sm font-medium text-gray-700 mb-1.5">摘要</label>
                        <textarea name="summary" id="summary" rows="2"
                            class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none resize-none"
                            placeholder="文章摘要...">{{ old('summary', $post->summary) }}</textarea>
                        @error('summary')<p class="mt-1 text-sm text-red-500">{{ $message }}</p>@enderror
                    </div>

                    <div class="flex-1 min-h-0 flex flex-col post-vditor-wrap">
                        <label class="block text-sm font-medium text-gray-700 mb-1.5">内容 <span class="text-red-500">*</span></label>
                        <div class="border border-gray-300 rounded-lg bg-white flex-1 min-h-0 post-vditor-wrap">
                            <div id="vditor" class="h-full"></div>
                        </div>
                        <div class="flex items-center justify-between mt-1.5">
                            <span class="text-xs text-gray-500" id="word-count"></span>
                            <textarea name="content" id="content" class="hidden">{{ old('content', $post->content) }}</textarea>
                        </div>
                        @error('content')<p class="mt-1 text-sm text-red-500">{{ $message }}</p>@enderror
                    </div>
                </div>

                <div class="md:w-80 shrink-0 space-y-3 relative">
                    <div class="bg-gray-50 rounded-lg p-3 space-y-3">
                        <div>
                            <label for="category_id" class="block text-sm font-medium text-gray-700 mb-1.5">分类</label>
                            <select name="category_id" id="category_id"
                                class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none bg-white">
                                <option value="">无分类</option>
                                @foreach($categories as $cat)
                                <option value="{{ $cat->id }}" {{ old('category_id', $post->category_id) == $cat->id ? 'selected' : '' }}>{{ $cat->name }}</option>
                                @endforeach
                            </select>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">状态</label>
                            <div class="flex gap-4">
                                <label class="flex items-center gap-2 cursor-pointer">
                                    <input type="radio" name="status" value="draft" {{ old('status', $post->status) === 'draft' ? 'checked' : '' }} class="text-blue-600 focus:ring-blue-500">
                                    <span class="text-sm text-gray-700">草稿</span>
                                </label>
                                <label class="flex items-center gap-2 cursor-pointer">
                                    <input type="radio" name="status" value="published" {{ old('status', $post->status) === 'published' ? 'checked' : '' }} class="text-blue-600 focus:ring-blue-500">
                                    <span class="text-sm text-gray-700">发布</span>
                                </label>
                            </div>
                            @error('status')<p class="mt-1 text-sm text-red-500">{{ $message }}</p>@enderror
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">访问模式</label>
                            <div class="flex gap-4">
                                <label class="flex items-center gap-2 cursor-pointer">
                                    <input type="radio" name="access_mode" value="public" id="access_public"
                                        {{ old('access_mode', $post->access_mode) === 'public' ? 'checked' : '' }}
                                        class="text-blue-600 focus:ring-blue-500" onchange="toggleAccessPassword()">
                                    <span class="text-sm text-gray-700">公开</span>
                                </label>
                                <label class="flex items-center gap-2 cursor-pointer">
                                    <input type="radio" name="access_mode" value="private" id="access_private"
                                        {{ old('access_mode', $post->access_mode) === 'private' ? 'checked' : '' }}
                                        class="text-blue-600 focus:ring-blue-500" onchange="toggleAccessPassword()">
                                    <span class="text-sm text-gray-700">密码访问</span>
                                </label>
                            </div>
                            <div id="access-password-wrap" class="hidden mt-3">
                                <input type="password" name="access_password" id="access_password"
                                    value="{{ old('access_password', $post->access_password) }}" placeholder="设置访问密码" autocomplete="new-password"
                                    class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none">
                            </div>
                            <p class="text-xs text-gray-500 mt-1.5">密码访问的文章，访客需输入密码才能查看正文</p>
                            @error('access_password')<p class="mt-1 text-sm text-red-500">{{ $message }}</p>@enderror
                        </div>

                        <div>
                            <label for="published_at" class="block text-sm font-medium text-gray-700 mb-1.5">发布时间</label>
                            <input type="datetime-local" name="published_at" id="published_at" value="{{ old('published_at', $post->published_at ? \Carbon\Carbon::parse($post->published_at)->format('Y-m-d\TH:i') : '') }}"
                                class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none">
                        </div>
                    </div>

                    <div class="bg-gray-50 rounded-lg p-3">
                        <div class="flex items-center gap-6">
                            <div class="flex items-center gap-2">
                                <input type="checkbox" name="is_top" id="is_top" value="1" {{ old('is_top', $post->is_top) ? 'checked' : '' }} class="rounded border-gray-300 text-blue-600 focus:ring-blue-500">
                                <label for="is_top" class="text-sm text-gray-700 cursor-pointer">置顶</label>
                            </div>
                            <div class="flex items-center gap-2">
                                <input type="checkbox" name="is_recommend" id="is_recommend" value="1" {{ old('is_recommend', $post->is_recommend) ? 'checked' : '' }} class="rounded border-gray-300 text-blue-600 focus:ring-blue-500">
                                <label for="is_recommend" class="text-sm text-gray-700 cursor-pointer">推荐</label>
                            </div>
                        </div>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1.5">封面图片</label>
                            <!-- 封面图片上传区域 -->
                            <div class="border-2 border-dashed border-gray-300 rounded-lg p-3 text-center hover:border-blue-400 transition-colors">
                                <div class="flex items-center justify-center gap-3 flex-wrap">
                                    <button type="button" @click="window.openMediaSelector('cover')" class="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded-lg transition-colors">
                                        <svg class="w-4 h-4 inline mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                                        从文件库选择
                                    </button>
                                    <span class="text-gray-400">或</span>
                                    <label class="px-3 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 text-sm rounded-lg transition-colors cursor-pointer">
                                        <svg class="w-4 h-4 inline mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m4-7L13.5 5.5 13 6m0 0l-1-.5a4 4 0 00-5 0L7 6l-.5.5a4 4 0 000 5L7 12l.5.5a4 4 0 005 0l1-.5.5-.5a4 4 0 000-5z"/></svg>
                                        本地上传
                                        <input type="file" id="cover" accept="image/*" class="hidden" @change="uploadCover($event.target)">
                                    </label>
                                </div>
                            <!-- 本地封面上传进度条 -->
                            <div id="cover-upload-progress" class="hidden mt-3">
                                <div class="flex items-center justify-between text-xs text-gray-500 mb-1">
                                    <span id="cover-upload-status">上传中...</span>
                                    <span id="cover-upload-percent">0%</span>
                                </div>
                                <div class="w-full bg-gray-200 rounded-full h-1.5">
                                    <div id="cover-upload-bar" class="bg-blue-600 h-1.5 rounded-full transition-all duration-200" style="width:0%"></div>
                                </div>
                            </div>
                            <div id="cover-upload-error" class="hidden mt-2 text-sm text-red-600"></div>
                            <div id="cover-preview" class="mt-3">
                                <div class="cover-preview-wrap" id="cover-preview-wrap" style="{{ empty($post->cover) ? 'display:none' : '' }}">
                                    <img id="cover-preview-img" class="max-h-40 rounded shadow-sm block" src="{{ $post->cover_url }}" alt="">
                                    <button type="button" class="cover-delete-btn" title="删除封面图" onclick="removeCover()">
                                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M6 18L18 6M6 6l12 12"/></svg>
                                    </button>
                                </div>
                                <div id="cover-placeholder" class="{{ empty($post->cover) ? '' : 'hidden' }} text-gray-400 text-sm py-2">暂无封面图</div>
                            </div>
                        </div>
                        <input type="hidden" name="cover_url" id="cover_url" value="{{ $post->cover ?? '' }}">
                        <input type="hidden" name="remove_cover" id="remove_cover" value="0">
                        @error('cover')<p class="mt-1 text-sm text-red-500">{{ $message }}</p>@enderror
                    </div>

                    @if($tagGroups->isNotEmpty())
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1.5">标签</label>
                        @include('admin.posts._tag-picker', [
                            'tagGroups' => $tagGroups,
                            'selectedTagIds' => old('tags', $post->tags->pluck('id')->toArray()),
                            'selectedTagNames' => $post->tags->pluck('name')->toArray(),
                        ])
                    </div>
                    @endif
                </div>
            </div>

            <div class="flex items-center gap-3 mt-8 pt-6 border-t border-gray-200 dark:border-gray-700">
                <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2.5 rounded-lg text-sm font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 dark:focus:ring-offset-gray-900">保存</button>
                <a href="{{ route('admin.posts.index') }}" class="px-6 py-2.5 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg text-sm font-medium hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">取消</a>
            </div>
        </form>
    </div>

    <x-media-selector editor-id="editor"/>

    {{-- AI 写作 / AI 生成配图 弹窗 --}}
    @include("admin.posts._ai-toolbar")
</div>

{{-- 本地 Vditor 资源（已下载到 public/static/vditor，禁用外网 CDN）--}}
{{-- 提前加载并解析 lute（4MB WASM），带 vditorLuteScript ID 使 Vditor 跳过动态加载，工具栏秒出 --}}
<link rel="preload" as="script" href="{{ asset('static/vditor/dist/js/lute/lute.min.js') }}?v=3.11.2">
<script src="{{ asset('static/vditor/dist/js/lute/lute.min.js') }}?v=3.11.2" id="vditorLuteScript"
    onerror="window.__vditorLuteFail = true;"></script>
<script src="{{ asset('static/vditor/index.min.js') }}?v=3.11.2"
    onerror="window.__vditorMainFail = true;"></script>
<script src="{{ asset('js/vditor-common.js') }}?v={{ filemtime(public_path('js/vditor-common.js')) }}"></script>
<script>
// 访问模式：选中"密码访问"时显示密码输入框
function toggleAccessPassword() {
    const wrap = document.getElementById('access-password-wrap');
    if (!wrap) return;
    const privateRadio = document.getElementById('access_private');
    wrap.classList.toggle('hidden', !(privateRadio && privateRadio.checked));
}
document.addEventListener('DOMContentLoaded', toggleAccessPassword);
</script>
<script>
document.addEventListener('alpine:init', () => {
    Alpine.data('postEditor', () => ({
        // 上传封面图。移动端相册照片常见 HEIC / 超 5MB，先在本地压缩转码再上传，
        // 保证「手机端封面上传」稳定成功；桌面端行为保持不变。
        uploadCover(input) {
            const file = input.files && input.files[0];
            const self = this;
            input.value = '';
            if (!file) { return; }
            const errEl = document.getElementById('cover-upload-error');
            if (errEl) { errEl.classList.add('hidden'); }
            // 部分移动端浏览器拿不到 file.type，此时交给服务端校验，避免误判
            if (file.type && !/^image\//.test(file.type)) { self.showCoverError('请选择图片文件'); return; }
            const isMobile = self.isMobileCoverUpload();
            if (!isMobile && file.size > 5 * 1024 * 1024) { self.showCoverError('图片不能超过 5MB'); return; }

            const els = {
                bar: document.getElementById('cover-upload-bar'),
                wrap: document.getElementById('cover-upload-progress'),
                pct: document.getElementById('cover-upload-percent'),
                status: document.getElementById('cover-upload-status'),
            };
            els.wrap.classList.remove('hidden');
            els.bar.style.width = '0%';
            els.pct.textContent = '0%';
            els.status.textContent = '上传中...';

            self.prepareCoverFile(file).then(function (ready) {
                self.sendCoverUpload(ready, els, true);
            }).catch(function () {
                self.sendCoverUpload(file, els, true);
            });
        },
        // 移动端判定：仅在移动端做前端压缩/转码与弱网重试
        isMobileCoverUpload() {
            return /Android|iPhone|iPad|iPod|Mobile|HarmonyOS|MicroMessenger/i.test(navigator.userAgent || '')
                || (navigator.maxTouchPoints > 1 && /Mac/.test(navigator.platform || ''));
        },
        // 移动端：非通用图片格式（如 HEIC）或过大时，用 canvas 转成 JPEG 并限制边长
        prepareCoverFile(file) {
            const self = this;
            return new Promise(function (resolve) {
                if (!self.isMobileCoverUpload()) { resolve(file); return; }
                const okTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp', 'image/bmp'];
                const type = (file.type || '').toLowerCase();
                const needsConvert = !okTypes.includes(type);
                const needsResize = file.size > 5 * 1024 * 1024;
                if (!needsConvert && !needsResize) { resolve(file); return; }
                // 保留 GIF 动画，不做转码
                if (type === 'image/gif') { resolve(file); return; }

                const objectUrl = URL.createObjectURL(file);
                const img = new Image();
                const done = function (out) { URL.revokeObjectURL(objectUrl); resolve(out); };
                img.onload = function () {
                    try {
                        const maxSide = 2560;
                        const scale = Math.min(1, maxSide / Math.max(img.width, img.height));
                        const w = Math.max(1, Math.round(img.width * scale));
                        const h = Math.max(1, Math.round(img.height * scale));
                        const canvas = document.createElement('canvas');
                        canvas.width = w;
                        canvas.height = h;
                        const ctx = canvas.getContext('2d');
                        ctx.fillStyle = '#ffffff';
                        ctx.fillRect(0, 0, w, h);
                        ctx.drawImage(img, 0, 0, w, h);
                        canvas.toBlob(function (blob) {
                            if (!blob) { done(file); return; }
                            const name = (file.name || 'cover').replace(/\.[^.]+$/, '') + '.jpg';
                            done(new File([blob], name, { type: 'image/jpeg' }));
                        }, 'image/jpeg', 0.85);
                    } catch (e) { done(file); }
                };
                img.onerror = function () { done(file); };
                img.src = objectUrl;
            });
        },
        // 发送上传请求；retry 为 true 表示移动端弱网失败后允许自动重试一次
        sendCoverUpload(file, els, retry) {
            const self = this;
            const fd = new FormData();
            fd.append('image', file, file.name || 'cover.jpg');
            const xhr = new XMLHttpRequest();
            xhr.open('POST', window.COVER_UPLOAD_URL || '/admin/upload/image');
            xhr.setRequestHeader('X-CSRF-TOKEN', document.querySelector('meta[name="csrf-token"]').content);
            // 声明 JSON：鉴权/校验失败时返回 401/422 JSON，而非 302 跳转后拿到登录页 HTML
            xhr.setRequestHeader('Accept', 'application/json');
            xhr.upload.onprogress = function (e) {
                if (e.lengthComputable) {
                    const p = Math.round(e.loaded / e.total * 100);
                    els.bar.style.width = p + '%';
                    els.pct.textContent = p + '%';
                }
            };
            xhr.onload = function () {
                const res = self.parseCoverResponse(xhr.responseText);
                if (xhr.status >= 200 && xhr.status < 300 && res && res.success && res.url) {
                    document.getElementById('cover_url').value = normalizeCoverPath(res.path || res.url);
                    showCoverPreview(res.url);
                    els.status.textContent = '上传成功';
                    els.bar.style.width = '100%';
                    els.pct.textContent = '100%';
                    setTimeout(function () { els.wrap.classList.add('hidden'); }, 1500);
                    return;
                }
                els.wrap.classList.add('hidden');

                if (xhr.status === 401 || xhr.status === 419 || (res === null && self.looksLikeLoginPage(xhr.responseText))) {
                    self.showCoverError('登录已过期，请重新登录');
                    setTimeout(function () { window.location.href = '/admin/login'; }, 1200);
                    return;
                }
                if (xhr.status === 422) {
                    const msg = (res && (res.message || (res.errors ? Object.values(res.errors)[0][0] : ''))) || '';
                    self.showCoverError(msg || '文件不符合要求（仅支持 jpeg/png/jpg/gif/webp，最大 5MB）');
                    return;
                }
                if (self.isMobileCoverUpload() && retry) {
                    els.wrap.classList.remove('hidden');
                    els.status.textContent = '网络不稳定，正在重试...';
                    setTimeout(function () { self.sendCoverUpload(file, els, false); }, 800);
                    return;
                }
                self.showCoverError((res && res.message) || '上传响应异常，请重试');
            };
            xhr.onerror = function () {
                if (self.isMobileCoverUpload() && retry) {
                    els.wrap.classList.remove('hidden');
                    els.status.textContent = '网络不稳定，正在重试...';
                    setTimeout(function () { self.sendCoverUpload(file, els, false); }, 800);
                    return;
                }
                els.wrap.classList.add('hidden');
                self.showCoverError('网络错误，上传失败');
            };
            xhr.send(fd);
        },
        // 容错解析响应：去掉 BOM/空白，解析失败返回 null
        parseCoverResponse(text) {
            const raw = (text || '').replace(/^\uFEFF/, '').trim();
            if (!raw) { return null; }
            try { return JSON.parse(raw); } catch (e) { return null; }
        },
        // 响应体疑似后台登录页（会话过期被重定向）
        looksLikeLoginPage(text) {
            if (!text) { return false; }
            return /<form[\s\S]{0,400}(name=["']password["']|admin\/login)|(管理员登录|后台登录)/i.test(text);
        },
        showCoverError(msg) {
            const errEl = document.getElementById('cover-upload-error');
            if (errEl) {
                errEl.textContent = msg;
                errEl.classList.remove('hidden');
            } else { window.notify(msg, 'error'); }
        },
    }));
});

window.COVER_UPLOAD_URL = '{{ route("admin.upload.image") }}';

// 封面路径标准化：完整 URL 或 /storage/ 前缀 → content/xxx.jpg 相对路径
function normalizeCoverPath(p) {
    if (!p) return '';
    let v = String(p);
    if (/^https?:\/\//i.test(v)) {
        try { v = new URL(v).pathname; } catch (e) {}
    }
    v = v.replace(/^\/?(storage\/)?/, '');
    return v;
}

// 文件库选图确认后：回显封面预览并赋值表单字段（存相对路径）
window.addEventListener('media-selected', function(event) {
    if (event.detail.field !== 'cover') return;
    const file = event.detail.file;
    const url = event.detail.url;
    const path = (file && file.file_path) || url;
    if (!path) return;
    document.getElementById('cover_url').value = normalizeCoverPath(path);
    showCoverPreview(url || path);
    const errEl = document.getElementById('cover-upload-error');
    if (errEl) errEl.classList.add('hidden');
});

// 删除封面图：清空隐藏字段、标记删除、隐藏预览、恢复上传区域
function removeCover() {
    document.getElementById('cover_url').value = '';
    const removeFlag = document.getElementById('remove_cover');
    if (removeFlag) removeFlag.value = '1';
    const previewWrap = document.getElementById('cover-preview-wrap');
    const placeholder = document.getElementById('cover-placeholder');
    if (previewWrap) previewWrap.style.display = 'none';
    if (placeholder) placeholder.classList.remove('hidden');
}

// 显示封面预览（上传/文件库选择后共用）
function showCoverPreview(url) {
    const previewImg = document.getElementById('cover-preview-img');
    const previewWrap = document.getElementById('cover-preview-wrap');
    const placeholder = document.getElementById('cover-placeholder');
    const removeFlag = document.getElementById('remove_cover');
    if (removeFlag) removeFlag.value = '0';
    if (previewImg && url) { previewImg.src = url; }
    if (previewWrap) previewWrap.style.display = 'inline-block';
    if (placeholder) placeholder.classList.add('hidden');
}

window.BlogVditor.routes = {
    aiWrite: '{{ route("admin.ai.write") }}',
    aiImage: '{{ route("admin.ai.generateImage") }}',
};

// Vditor 统一初始化（工具栏配置见 vditor-common.js）
window.BlogVditor.init({
    id: 'vditor',
    value: {!! json_encode($post->content) !!},
    height: 600,
    placeholder: '开始写作...',
    uploadUrl: '{{ route("admin.upload.file") }}',
    uploadFieldName: 'file',
    formId: 'post-form',
    outputEl: 'content',
    outputType: 'markdown',
    onReady: function(vditor) {
        const updateCount = () => {
            const count = vditor.getValue().length;
            const el = document.getElementById('word-count');
            if (el) el.textContent = count + ' 字';
        };
        updateCount();
        console.log('Vditor 完整编辑器已初始化完成');
    }
});
</script>
@endsection

@push('styles')
<style>[x-cloak] { display: none !important; }</style>
@endpush

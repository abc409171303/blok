@extends('layouts.admin')

@section('page-title', '系统升级')

@section('content')
<div>
    <h1 class="text-2xl font-bold text-gray-800 dark:text-gray-100 mb-6">系统升级</h1>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- 左侧：升级状态与操作 -->
        <div class="lg:col-span-2 space-y-6">
            <!-- 版本信息卡片 -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
                <div class="flex items-center justify-between mb-4">
                    <h2 class="text-lg font-semibold text-gray-800 dark:text-gray-100">版本检测</h2>
                    <button id="checkBtn" onclick="checkUpdate()"
                        class="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium rounded-lg transition-colors flex items-center gap-2">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg>
                        检查更新
                    </button>
                </div>
                <div id="versionInfo" class="space-y-3">
                    <div class="flex items-center gap-4 p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                        <div class="flex-1">
                            <span class="text-sm text-gray-500 dark:text-gray-400">当前版本</span>
                            <p class="text-2xl font-bold text-gray-800 dark:text-gray-100 mt-1">{{ config('app.version', '1.0.0') }}</p>
                        </div>
                        <div class="flex items-center gap-2">
                            <svg class="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>
                        </div>
                        <div class="flex-1 text-right">
                            <span class="text-sm text-gray-500 dark:text-gray-400">最新版本</span>
                            <p id="remoteVersion" class="text-2xl font-bold text-gray-400 dark:text-gray-500 mt-1">--</p>
                        </div>
                    </div>
                    <div id="updateStatus" class="p-4 rounded-lg hidden"></div>
                </div>
            </div>

            <!-- 配置说明卡片 -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
                <h2 class="text-lg font-semibold text-gray-800 dark:text-gray-100 mb-4">升级说明</h2>
                <div class="space-y-4 text-sm text-gray-600 dark:text-gray-400">
                    <div class="flex items-start gap-3">
                        <div class="w-6 h-6 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center flex-shrink-0 mt-0.5">
                            <span class="text-blue-600 dark:text-blue-400 font-medium text-xs">1</span>
                        </div>
                        <p>在右侧配置远程更新服务器地址和更新密钥。</p>
                    </div>
                    <div class="flex items-start gap-3">
                        <div class="w-6 h-6 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center flex-shrink-0 mt-0.5">
                            <span class="text-blue-600 dark:text-blue-400 font-medium text-xs">2</span>
                        </div>
                        <p>点击"检查更新"验证远程服务器是否可达，并获取最新版本信息。</p>
                    </div>
                    <div class="flex items-start gap-3">
                        <div class="w-6 h-6 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center flex-shrink-0 mt-0.5">
                            <span class="text-blue-600 dark:text-blue-400 font-medium text-xs">3</span>
                        </div>
                        <p>确认有新版本后，点击"立即升级"。系统会自动备份源码和数据库。</p>
                    </div>
                    <div class="flex items-start gap-3">
                        <div class="w-6 h-6 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center flex-shrink-0 mt-0.5">
                            <span class="text-blue-600 dark:text-blue-400 font-medium text-xs">4</span>
                        </div>
                        <p>升级包下载后会自动校验 MD5 值，确保完整性。</p>
                    </div>
                    <div class="flex items-start gap-3">
                        <div class="w-6 h-6 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center flex-shrink-0 mt-0.5">
                            <span class="text-blue-600 dark:text-blue-400 font-medium text-xs">5</span>
                        </div>
                        <p>升级完成后自动清理临时文件。如遇到异常，可使用备份一键回滚。</p>
                    </div>
                </div>
            </div>

            <!-- 升级进度（隐藏） -->
            <div id="upgradeProgress" class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6 hidden">
                <h2 class="text-lg font-semibold text-gray-800 dark:text-gray-100 mb-4">升级进度</h2>
                <div class="space-y-4">
                    <div class="flex items-center gap-3">
                        <div id="stepBackup" class="w-8 h-8 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
                            <span class="text-sm font-medium text-gray-600 dark:text-gray-400">1</span>
                        </div>
                        <span class="text-sm text-gray-600 dark:text-gray-400">备份源码和数据库...</span>
                    </div>
                    <div class="flex items-center gap-3">
                        <div id="stepDownload" class="w-8 h-8 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
                            <span class="text-sm font-medium text-gray-600 dark:text-gray-400">2</span>
                        </div>
                        <span class="text-sm text-gray-600 dark:text-gray-400">下载升级包...</span>
                    </div>
                    <div class="flex items-center gap-3">
                        <div id="stepVerify" class="w-8 h-8 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
                            <span class="text-sm font-medium text-gray-600 dark:text-gray-400">3</span>
                        </div>
                        <span class="text-sm text-gray-600 dark:text-gray-400">校验升级包...</span>
                    </div>
                    <div class="flex items-center gap-3">
                        <div id="stepApply" class="w-8 h-8 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
                            <span class="text-sm font-medium text-gray-600 dark:text-gray-400">4</span>
                        </div>
                        <span class="text-sm text-gray-600 dark:text-gray-400">应用升级...</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- 右侧：升级配置 -->
        <div class="space-y-6">
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
                <h2 class="text-lg font-semibold text-gray-800 dark:text-gray-100 mb-4">升级配置</h2>
                <form id="updateConfigForm" action="{{ route('admin.settings.update-config') }}" method="POST">
                    @csrf
                    <div class="space-y-4">
                        <div>
                            <label for="system_update_server" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">
                                远程更新服务器地址
                            </label>
                            <input type="url" name="system_update_server" id="system_update_server"
                                value="{{ old('system_update_server', $config->system_update_server) }}"
                                placeholder="https://update.example.com"
                                class="w-full px-4 py-2.5 border border-gray-300 dark:border-gray-600 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none bg-white dark:bg-gray-700 text-gray-800 dark:text-gray-100">
                            <p class="mt-1 text-xs text-gray-500 dark:text-gray-400">服务器需提供 version.json 接口。</p>
                        </div>
                        <div>
                            <label for="system_update_key" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">
                                更新密钥
                            </label>
                            <input type="password" name="system_update_key" id="system_update_key"
                                value="{{ old('system_update_key') }}"
                                placeholder="输入访问密钥"
                                class="w-full px-4 py-2.5 border border-gray-300 dark:border-gray-600 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none bg-white dark:bg-gray-700 text-gray-800 dark:text-gray-100">
                            <p class="mt-1 text-xs text-gray-500 dark:text-gray-400">用于请求升级包的认证密钥。</p>
                        </div>
                    </div>
                    <button type="submit"
                        class="mt-6 w-full px-4 py-2.5 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-200 text-sm font-medium rounded-lg transition-colors">
                        保存配置
                    </button>
                </form>
            </div>

            <!-- 升级操作卡片 -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
                <h2 class="text-lg font-semibold text-gray-800 dark:text-gray-100 mb-4">升级操作</h2>
                <div class="space-y-3">
                    <button id="upgradeBtn" onclick="startUpgrade()" disabled
                        class="w-full px-4 py-3 bg-green-600 hover:bg-green-700 disabled:bg-gray-300 disabled:cursor-not-allowed text-white text-sm font-medium rounded-lg transition-colors flex items-center justify-center gap-2">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
                        立即升级
                    </button>
                    <button onclick="showBackups()"
                        class="w-full px-4 py-3 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-200 text-sm font-medium rounded-lg transition-colors flex items-center justify-center gap-2">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4"/></svg>
                        查看备份
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- 备份列表弹窗 -->
<div id="backupModal" class="fixed inset-0 bg-black/50 z-50 hidden items-center justify-center p-4">
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-md w-full max-h-[80vh] overflow-y-auto">
        <div class="p-6">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-lg font-semibold text-gray-800 dark:text-gray-100">备份列表</h3>
                <button onclick="closeBackupModal()" class="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
                </button>
            </div>
            <div id="backupList" class="space-y-2">
                <p class="text-sm text-gray-500 dark:text-gray-400 text-center py-4">加载中...</p>
            </div>
        </div>
    </div>
</div>

<!-- 成功提示弹窗 -->
<div id="successModal" class="fixed inset-0 bg-black/50 z-50 hidden items-center justify-center p-4">
    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-md w-full">
        <div class="p-6">
            <div class="text-center">
                <div class="w-16 h-16 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center mx-auto mb-4">
                    <svg class="w-8 h-8 text-green-600 dark:text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                </div>
                <h3 class="text-xl font-bold text-gray-800 dark:text-gray-100 mb-2">升级成功</h3>
                <p id="successMessage" class="text-sm text-gray-600 dark:text-gray-400 mb-4"></p>
                <div id="changelogBox" class="hidden bg-gray-50 dark:bg-gray-700 rounded-lg p-4 mb-4 text-left">
                    <p class="text-sm font-medium text-gray-700 dark:text-gray-200 mb-2">更新日志</p>
                    <p id="changelogContent" class="text-sm text-gray-600 dark:text-gray-400 whitespace-pre-wrap"></p>
                </div>
                <button onclick="window.location.href='{{ route('admin.dashboard') }}'"
                    class="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium rounded-lg transition-colors">
                    返回控制台
                </button>
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script>
const API_BASE = '{{ route("admin.update.check") }}';

async function checkUpdate() {
    const btn = document.getElementById('checkBtn');
    btn.disabled = true;
    btn.innerHTML = `<svg class="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> 检查中...`;

    try {
        const response = await fetch(API_BASE, {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            }
        });
        const data = await response.json();

        if (data.success) {
            displayUpdateInfo(data.data);
        } else {
            showStatus('error', data.message || '检查失败');
        }
    } catch (e) {
        showStatus('error', '网络错误：' + e.message);
    } finally {
        btn.disabled = false;
        btn.innerHTML = `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg> 检查更新`;
    }
}

function displayUpdateInfo(data) {
    document.getElementById('remoteVersion').textContent = data.remote_version || '--';

    if (data.need_upgrade) {
        showStatus('success', `发现新版本 ${data.remote_version}，请保存配置后立即升级。`);
        document.getElementById('upgradeBtn').disabled = false;
        if (data.changelog) {
            document.getElementById('changelogContent').textContent = data.changelog;
            document.getElementById('changelogBox').classList.remove('hidden');
        }
    } else {
        showStatus('info', data.message || '当前已是最新版本。');
        document.getElementById('upgradeBtn').disabled = true;
    }
}

function showStatus(type, message) {
    const el = document.getElementById('updateStatus');
    el.classList.remove('hidden', 'bg-blue-50', 'dark:bg-blue-900/20', 'bg-green-50', 'dark:bg-green-900/20', 'bg-red-50', 'dark:bg-red-900/20');

    if (type === 'success') {
        el.classList.add('bg-green-50', 'dark:bg-green-900/20');
        el.innerHTML = `<div class="flex items-start gap-3"><svg class="w-5 h-5 text-green-600 dark:text-green-400 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg><p class="text-sm text-green-700 dark:text-green-300">${message}</p></div>`;
    } else if (type === 'error') {
        el.classList.add('bg-red-50', 'dark:bg-red-900/20');
        el.innerHTML = `<div class="flex items-start gap-3"><svg class="w-5 h-5 text-red-600 dark:text-red-400 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg><p class="text-sm text-red-700 dark:text-red-300">${message}</p></div>`;
    } else {
        el.classList.add('bg-blue-50', 'dark:bg-blue-900/20');
        el.innerHTML = `<div class="flex items-start gap-3"><svg class="w-5 h-5 text-blue-600 dark:text-blue-400 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg><p class="text-sm text-blue-700 dark:text-blue-300">${message}</p></div>`;
    }
    el.classList.remove('hidden');
}

async function startUpgrade() {
    const btn = document.getElementById('upgradeBtn');
    const progress = document.getElementById('upgradeProgress');

    btn.disabled = true;
    btn.innerHTML = `<svg class="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> 升级中...`;
    progress.classList.remove('hidden');

    try {
        const response = await fetch('{{ route("admin.update.upgrade") }}', {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            }
        });
        const data = await response.json();

        if (data.success) {
            document.getElementById('successMessage').textContent = data.data.message;
            if (data.data.changelog) {
                document.getElementById('changelogContent').textContent = data.data.changelog;
                document.getElementById('changelogBox').classList.remove('hidden');
            }
            document.getElementById('successModal').classList.remove('hidden');
            document.getElementById('successModal').classList.add('flex');
        } else {
            showStatus('error', data.message);
            resetUpgradeBtn();
        }
    } catch (e) {
        showStatus('error', '升级失败：' + e.message);
        resetUpgradeBtn();
    }
}

function resetUpgradeBtn() {
    const btn = document.getElementById('upgradeBtn');
    btn.disabled = false;
    btn.innerHTML = `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg> 立即升级`;
}

async function showBackups() {
    const modal = document.getElementById('backupModal');
    const list = document.getElementById('backupList');
    modal.classList.remove('hidden');
    modal.classList.add('flex');
    list.innerHTML = '<p class="text-sm text-gray-500 dark:text-gray-400 text-center py-4">加载中...</p>';

    try {
        const response = await fetch('{{ route("admin.update.backups") }}');
        const data = await response.json();

        if (data.success && data.data.length > 0) {
            list.innerHTML = data.data.map(b => `
                <div class="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                    <div>
                        <p class="text-sm font-medium text-gray-800 dark:text-gray-100">${b.id}</p>
                        <p class="text-xs text-gray-500 dark:text-gray-400">${formatFileSize(b.size)} - ${new Date(b.created_at * 1000).toLocaleString()}</p>
                    </div>
                    <button onclick="rollback('${b.id}')" class="px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white text-xs font-medium rounded-lg transition-colors">
                        回滚
                    </button>
                </div>
            `).join('');
        } else {
            list.innerHTML = '<p class="text-sm text-gray-500 dark:text-gray-400 text-center py-4">暂无备份记录。</p>';
        }
    } catch (e) {
        list.innerHTML = '<p class="text-sm text-red-500 text-center py-4">加载失败</p>';
    }
}

function closeBackupModal() {
    const modal = document.getElementById('backupModal');
    modal.classList.add('hidden');
    modal.classList.remove('flex');
}

async function rollback(backupId) {
    if (!confirm('确定要回滚到此备份吗？此操作将恢复所有文件和数据库。')) return;

    try {
        const response = await fetch('{{ route("admin.update.rollback") }}', {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ backup_id: backupId })
        });
        const data = await response.json();

        if (data.success) {
            alert('回滚成功！');
            closeBackupModal();
            window.location.reload();
        } else {
            alert('回滚失败：' + data.message);
        }
    } catch (e) {
        alert('回滚失败：' + e.message);
    }
}

function formatFileSize(bytes) {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// 页面加载时自动检查一次
document.addEventListener('DOMContentLoaded', () => {
    checkUpdate();
});
</script>
@endpush
@endsection

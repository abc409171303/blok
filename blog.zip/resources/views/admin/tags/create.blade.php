@extends('layouts.admin')

@section('content')
<div class="mb-6 flex items-center justify-between">
    <h1 class="text-2xl font-bold text-gray-900">创建标签</h1>
    <a href="{{ route('admin.tags.index') }}" class="text-sm text-blue-600 hover:text-blue-800">返回列表</a>
</div>

<div class="rounded-lg bg-white p-6 shadow">
    <form action="{{ route('admin.tags.store') }}" method="POST">
        @csrf
        <div class="mb-4">
            <label class="mb-1 block text-sm font-medium text-gray-700">标签名称</label>
            <input type="text" name="name" value="{{ old('name') }}" class="w-full rounded-lg border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500" required>
            @error('name')<p class="mt-1 text-sm text-red-600">{{ $message }}</p>@enderror
        </div>
        <div class="mb-4">
            <label class="mb-1 block text-sm font-medium text-gray-700">所属分类 <span class="text-xs text-gray-400 font-normal">（不选则为一级大类）</span></label>
            <select name="parent_id" class="w-full rounded-lg border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500">
                <option value="">— 无（一级大类）—</option>
                @foreach($parents as $p)
                <option value="{{ $p->id }}" {{ old('parent_id') == $p->id ? 'selected' : '' }}>{{ $p->name }}</option>
                @endforeach
            </select>
            @error('parent_id')<p class="mt-1 text-sm text-red-600">{{ $message }}</p>@enderror
        </div>
        <button type="submit" class="rounded-lg bg-blue-600 px-4 py-2 text-white hover:bg-blue-700">保存</button>
    </form>
</div>
@endsection

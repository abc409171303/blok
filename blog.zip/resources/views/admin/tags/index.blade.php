@extends('layouts.admin')

@section('page-title', '标签管理')

@section('content')
<div>
    <div class="flex items-center justify-between mb-6">
        <h1 class="text-2xl font-bold text-gray-800">标签</h1>
    </div>

    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
        <h2 class="text-sm font-medium text-gray-700 mb-4">新建标签</h2>
        <form action="{{ route('admin.tags.store') }}" method="POST" class="flex flex-wrap gap-3 items-end">
            @csrf
            <div class="flex-1 min-w-[200px]">
                <label for="name" class="block text-sm font-medium text-gray-700 mb-1.5">名称 <span class="text-red-500">*</span></label>
                <input type="text" name="name" id="name" value="{{ old('name') }}" required
                    class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                    placeholder="标签名称">
                @error('name')<p class="mt-1 text-sm text-red-500">{{ $message }}</p>@enderror
            </div>
            <div class="w-full sm:w-64">
                <label for="parent_id" class="block text-sm font-medium text-gray-700 mb-1.5">所属分类 <span class="text-gray-400 font-normal">（不选则为一级大类）</span></label>
                <select name="parent_id" id="parent_id"
                    class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none">
                    <option value="">— 无（一级大类）—</option>
                    @foreach($parents as $p)
                    <option value="{{ $p->id }}" {{ old('parent_id') == $p->id ? 'selected' : '' }}>{{ $p->name }}</option>
                    @endforeach
                </select>
                @error('parent_id')<p class="mt-1 text-sm text-red-500">{{ $message }}</p>@enderror
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1.5">&nbsp;</label>
                <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2.5 rounded-lg text-sm font-medium transition-colors">
                    创建
                </button>
            </div>
        </form>
    </div>

    <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead>
                    <tr class="bg-gray-50 border-b border-gray-200">
                        <th class="text-left px-4 py-3 font-medium text-gray-600 w-12">ID</th>
                        <th class="text-left px-4 py-3 font-medium text-gray-600">名称</th>
                        <th class="text-left px-4 py-3 font-medium text-gray-600">类型</th>
                        <th class="text-left px-4 py-3 font-medium text-gray-600">别名</th>
                        <th class="text-left px-4 py-3 font-medium text-gray-600">文章数</th>
                        <th class="text-left px-4 py-3 font-medium text-gray-600 w-28">操作</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    @forelse($tags as $tag)
                    <tr class="hover:bg-gray-50 transition-colors">
                        <td class="px-4 py-3 text-gray-500">{{ $tag->id }}</td>
                        <td class="px-4 py-3">
                            <span class="font-medium {{ $tag->parent ? 'text-gray-800 pl-5' : 'text-blue-700' }}">{{ $tag->name }}</span>
                            @if($tag->parent)
                            <span class="ml-1 text-xs text-gray-400">{{ $tag->parent->name }}</span>
                            @endif
                        </td>
                        <td class="px-4 py-3">
                            @if($tag->parent)
                            <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs bg-gray-100 text-gray-600">二级子标签</span>
                            @else
                            <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs bg-blue-50 text-blue-600">一级大类</span>
                            @endif
                        </td>
                        <td class="px-4 py-3 text-gray-600">{{ $tag->slug }}</td>
                        <td class="px-4 py-3 text-gray-600">{{ $tag->posts_count }}</td>
                        <td class="px-4 py-3">
                            <div class="flex items-center gap-2">
                                <a href="{{ route('admin.tags.edit', $tag) }}" class="text-blue-600 hover:text-blue-800 text-sm">编辑</a>
                                <form action="{{ route('admin.tags.destroy', $tag) }}" method="POST" onsubmit="return confirm('{{ $tag->children()->exists() ? '删除后其子标签将提升为一级标签，确定删除吗？' : '确定要删除这个标签吗？' }}')" class="inline">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="text-red-600 hover:text-red-800 text-sm">删除</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="6" class="px-4 py-12 text-center text-gray-500">
                            <div class="flex flex-col items-center gap-2">
                                <svg class="w-12 h-12 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z"/></svg>
                                <span>暂无标签</span>
                            </div>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if($tags->hasPages())
        <div class="px-4 py-3 border-t border-gray-200">
            {{ $tags->links() }}
        </div>
        @endif
    </div>
</div>
@endsection

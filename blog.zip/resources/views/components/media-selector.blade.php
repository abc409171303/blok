@props(['editorId' => 'vditor'])

<div x-data="mediaSelector('{{ $editorId }}')" x-show="showModal" class="fixed inset-0 z-50 overflow-y-auto" style="display: none;">
    {{-- Backdrop --}}
    <div class="fixed inset-0 bg-black/50 transition-opacity" @click="closeModal()"></div>

    {{-- Modal --}}
    <div class="flex min-h-full items-center justify-center p-4">
        <div class="relative bg-white rounded-xl shadow-2xl w-full max-w-6xl" 
             @click.stop 
             x-effect="showModal ? $el.style.display = 'block' : $el.style.display = 'none'">
            
            {{-- Header --}}
            <div class="flex items-center justify-between px-6 py-4 border-b border-gray-200">
                <h3 class="text-lg font-bold text-gray-800">选择图片/视频</h3>
                <div class="flex items-center gap-3">
                    <div class="flex rounded-lg border border-gray-300 overflow-hidden">
                        <button @click="activeTab = 'library'" 
                                :class="activeTab === 'library' ? 'bg-blue-50 text-blue-600' : 'text-gray-600 hover:bg-gray-50'"
                                class="px-4 py-1.5 text-sm font-medium transition-colors">
                            文件库
                        </button>
                        <button @click="activeTab = 'custom'" 
                                :class="activeTab === 'custom' ? 'bg-blue-50 text-blue-600' : 'text-gray-600 hover:bg-gray-50'"
                                class="px-4 py-1.5 text-sm font-medium transition-colors border-l border-gray-300">
                            自定义链接
                        </button>
                    </div>
                    <button @click="closeModal()" class="text-gray-400 hover:text-gray-600">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                        </svg>
                    </button>
                </div>
            </div>

            {{-- Content --}}
            <div class="max-h-[70vh] overflow-y-auto">
                {{-- Library Tab --}}
                <div x-show="activeTab === 'library'" class="p-6">
                    <div class="flex gap-6">
                        {{-- Sidebar --}}
                        <div class="w-56 flex-shrink-0">
                            {{-- Search --}}
                            <div class="mb-4">
                                <div class="relative">
                                    <input type="text" x-model="search" @input.debounce.300ms="loadFiles()" 
                                           placeholder="搜索文件名..." 
                                           class="w-full pl-9 pr-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                                    <svg class="absolute left-2.5 top-2.5 w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                                    </svg>
                                </div>
                            </div>

                            {{-- Categories --}}
                            <div class="space-y-1">
                                <button @click="filterCategory = ''; loadFiles()" 
                                        :class="filterCategory === '' ? 'bg-blue-50 text-blue-600' : 'text-gray-700 hover:bg-gray-100'"
                                        class="w-full flex items-center justify-between px-3 py-2 text-sm rounded-lg transition-colors">
                                    <span>全部</span>
                                    <span class="text-xs" x-text="stats.total || '-'"></span>
                                </button>
                                <button @click="filterCategory = 'images'; loadFiles()" 
                                        :class="filterCategory === 'images' ? 'bg-blue-50 text-blue-600' : 'text-gray-700 hover:bg-gray-100'"
                                        class="w-full flex items-center justify-between px-3 py-2 text-sm rounded-lg transition-colors">
                                    <span>图片</span>
                                    <span class="text-xs" x-text="stats.images || '-'"></span>
                                </button>
                                <button @click="filterCategory = 'videos'; loadFiles()" 
                                        :class="filterCategory === 'videos' ? 'bg-blue-50 text-blue-600' : 'text-gray-700 hover:bg-gray-100'"
                                        class="w-full flex items-center justify-between px-3 py-2 text-sm rounded-lg transition-colors">
                                    <span>视频</span>
                                    <span class="text-xs" x-text="stats.videos || '-'"></span>
                                </button>
                            </div>

                            {{-- Upload Button --}}
                            <div class="mt-6">
                                <label class="block w-full">
                                    <input type="file" ref="fileInput" @change="uploadFile($event.target.files[0])" 
                                           accept="image/*,video/*" class="hidden" :disabled="uploading">
                                    <span class="flex items-center justify-center gap-2 w-full px-4 py-2.5 text-white text-sm font-medium rounded-lg cursor-pointer transition-colors"
                                          :class="uploading ? 'bg-blue-400 pointer-events-none' : 'bg-blue-600 hover:bg-blue-700'">
                                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"/>
                                        </svg>
                                        选择本地文件
                                    </span>
                                </label>
                                <p class="text-xs text-gray-500 text-center mt-2">支持图片、视频，最大 20MB</p>
                                <div x-show="uploading" class="mt-3">
                                    <div class="flex items-center justify-between gap-2 mb-1">
                                        <p class="text-xs text-gray-600 truncate" x-text="uploadFileName"></p>
                                        <p class="text-xs text-gray-500 flex-shrink-0" x-text="uploadPercent + '%'"></p>
                                    </div>
                                    <div class="w-full bg-gray-200 rounded-full h-1.5 overflow-hidden">
                                        <div class="bg-blue-600 h-1.5 rounded-full transition-all duration-150" :style="'width: ' + uploadPercent + '%'"></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {{-- File Grid Area --}}
                        <div class="flex-1 min-w-0">
                            {{-- 批量操作工具栏 - 独立常驻，位于标签页下方、图片网格上方 --}}
                            <div id="batch-toolbar" class="flex items-center gap-2 mb-4 px-1 py-2 border-b border-gray-200">
                                <button type="button" data-action="copy"
                                    @click="bulkCopyLinks"
                                    :disabled="selectedFiles.length === 0"
                                    class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors disabled:cursor-not-allowed"
                                    :class="selectedFiles.length > 0 ? 'bg-blue-500 text-white hover:bg-blue-600 shadow-sm' : 'bg-gray-100 text-gray-400 dark:bg-gray-700 dark:text-gray-500'">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"/></svg>
                                    复制链接
                                    <span x-show="selectedFiles.length > 0" class="text-xs opacity-80" x-text="'(' + selectedFiles.length + ')'"></span>
                                </button>
                                <button type="button" data-action="edit"
                                    @click="openBulkEdit"
                                    :disabled="selectedFiles.length === 0"
                                    class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors disabled:cursor-not-allowed"
                                    :class="selectedFiles.length > 0 ? 'bg-blue-500 text-white hover:bg-blue-600 shadow-sm' : 'bg-gray-100 text-gray-400 dark:bg-gray-700 dark:text-gray-500'">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
                                    编辑
                                    <span x-show="selectedFiles.length > 0" class="text-xs opacity-80" x-text="'(' + selectedFiles.length + ')'"></span>
                                </button>
                                <button type="button" data-action="delete"
                                    @click="bulkDelete"
                                    :disabled="selectedFiles.length === 0"
                                    class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors disabled:cursor-not-allowed"
                                    :class="selectedFiles.length > 0 ? 'bg-red-500 text-white hover:bg-red-600 shadow-sm' : 'bg-gray-100 text-gray-400 dark:bg-gray-700 dark:text-gray-500'">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                                    删除
                                    <span x-show="selectedFiles.length > 0" class="text-xs opacity-80" x-text="'(' + selectedFiles.length + ')'"></span>
                                </button>
                            </div>

                            {{-- Loading --}}
                            <div x-show="loading" class="flex items-center justify-center py-12">
                                <svg class="animate-spin h-8 w-8 text-blue-600" fill="none" viewBox="0 0 24 24">
                                    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                                    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                </svg>
                                <span class="ml-3 text-sm text-gray-600">加载中...</span>
                            </div>

                            {{-- Grid --}}
                            <div x-show="!loading" class="grid grid-cols-4 gap-3">
                                <template x-for="file in files" :key="file.id">
                                    <div class="group relative aspect-square rounded-lg border overflow-hidden transition-all cursor-pointer"
                                         :class="selectedFiles.includes(file.id) ? 'border-blue-500 ring-2 ring-blue-500' : 'border-gray-200 hover:shadow-md'"
                                         @click="toggleFile(file)">
                                        {{-- Thumbnail --}}
                                        <template x-if="file.file_type === 'image'">
                                            <img :src="file.url" :alt="file.file_name" class="w-full h-full object-cover">
                                        </template>
                                        <template x-else>
                                            <div class="w-full h-full bg-gray-100 flex items-center justify-center">
                                                <svg class="w-12 h-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M15 10l4.553-2.276M10 15L5.447 12.724M19 21V7a2 2 0 00-2-2H7a2 2 0 00-2 2v14m0 0h12M7 21V9m12 12V9"/>
                                                </svg>
                                            </div>
                                        </template>

                                        {{-- Selected Checkmark --}}
                                        <div x-show="selectedFiles.includes(file.id)" class="absolute top-2 right-2 w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center">
                                            <svg class="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7"/>
                                            </svg>
                                        </div>

                                        {{-- Overlay Actions (hover or selected) --}}
                                        <div x-show="selectedFiles.includes(file.id)"
                                             class="absolute inset-0 bg-black/50 flex items-center justify-center gap-2">
                                            <button @click.stop="editFile(file)" title="编辑" class="p-2 rounded bg-white/20 hover:bg-white/40 text-white transition-colors">
                                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/>
                                                </svg>
                                            </button>
                                            <button @click.stop="copyLink(file.url)" title="复制链接" class="p-2 rounded bg-white/20 hover:bg-white/40 text-white transition-colors">
                                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"/>
                                                </svg>
                                            </button>
                                            <button @click.stop="deleteFile(file.id)" title="删除" class="p-2 rounded bg-red-500 hover:bg-red-600 text-white transition-colors">
                                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                                                </svg>
                                            </button>
                                        </div>

                                        {{-- Info --}}
                                        <div class="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/60 to-transparent p-2">
                                            <p class="text-white text-xs truncate" x-text="file.title || file.file_name"></p>
                                        </div>
                                    </div>
                                </template>
                            </div>

                            {{-- Empty State --}}
                            <div x-show="!loading && files.length === 0" class="text-center py-12">
                                <svg class="w-16 h-16 text-gray-300 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                                </svg>
                                <p class="text-gray-500 text-sm">暂无文件，请上传或选择其他分类</p>
                            </div>

                            {{-- Pagination --}}
                            <div x-show="pagination.last_page > 1" class="mt-4 flex items-center justify-between">
                                <p class="text-sm text-gray-600">
                                    共 <span x-text="pagination.total"></span> 条，第 <span x-text="pagination.current_page"></span>/<span x-text="pagination.last_page"></span> 页
                                </p>
                                <div class="flex gap-2">
                                    <button @click="loadFiles(pagination.current_page - 1)" :disabled="pagination.current_page <= 1"
                                            class="px-3 py-1.5 text-sm border border-gray-300 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50">
                                        上一页
                                    </button>
                                    <button @click="loadFiles(pagination.current_page + 1)" :disabled="pagination.current_page >= pagination.last_page"
                                            class="px-3 py-1.5 text-sm border border-gray-300 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50">
                                        下一页
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {{-- Custom Link Tab --}}
                <div x-show="activeTab === 'custom'" class="p-6">
                    <div class="max-w-2xl mx-auto">
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            输入图片或视频 URL
                        </label>
                        <input type="text" x-model="customUrl" placeholder="https://example.com/image.jpg"
                               class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                        <div class="mt-4 flex items-center justify-end gap-3">
                            <button @click="activeTab = 'library'" class="px-4 py-2 text-sm text-gray-600 hover:text-gray-800">
                                返回文件库
                            </button>
                            <button @click="insertCustomUrl()" :disabled="!customUrl.trim()"
                                    class="px-6 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white text-sm font-medium rounded-lg transition-colors">
                                确认插入
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            {{-- Footer --}}
            <div class="px-6 py-4 border-t border-gray-200 flex items-center justify-between">
                <div class="text-sm text-gray-600">
                    <span x-show="selectedFile">已选择：<span class="font-medium text-gray-800" x-text="selectedFile?.file_name"></span></span>
                </div>
                <div class="flex gap-3">
                    <button @click="closeModal()" class="px-4 py-2 text-sm text-gray-600 hover:text-gray-800">
                        取消
                    </button>
                    <button @click="insertToEditor()" :disabled="!selectedFile && activeTab === 'library'"
                            class="px-6 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white text-sm font-medium rounded-lg transition-colors">
                        <span x-text="footerButtonText"></span>
                    </button>
                </div>
            </div>
        </div>
    </div>

    {{-- Edit Modal --}}
    <div x-show="editingFile" class="fixed inset-0 z-[60] overflow-y-auto" style="display: none;">
        <div class="fixed inset-0 bg-black/50" @click="editingFile = null"></div>
        <div class="flex min-h-full items-center justify-center p-4">
            <div class="relative bg-white rounded-xl shadow-xl w-full max-w-md p-6" @click.stop>
                <h4 class="text-lg font-bold mb-4" x-text="bulkEditMode ? '批量编辑 (' + bulkEditIds.length + ' 个)' : '编辑素材信息'"></h4>
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">标题/备注</label>
                        <input type="text" x-model="editForm.title" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">分类</label>
                        <select x-model="editForm.category" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                            <option value="uncategorized">未分类</option>
                            <option value="images">图片</option>
                            <option value="videos">视频</option>
                        </select>
                    </div>
                </div>
                <div class="mt-6 flex items-center justify-end gap-3">
                    <button @click="editingFile = null" class="px-4 py-2 text-sm text-gray-600 hover:text-gray-800">
                        取消
                    </button>
                    <button @click="saveEdit()" class="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium rounded-lg">
                        保存
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('alpine:init', () => {
    Alpine.data('mediaSelector', (editorIdParam) => ({
        showModal: false,
        activeTab: 'library',
        loading: false,
        files: [],
        selectedFile: null,
        selectedFiles: [],
        search: '',
        filterCategory: '',
        currentPage: 1,
        pagination: {
            current_page: 1,
            last_page: 1,
            per_page: 24,
            total: 0,
        },
        stats: {
            total: 0,
            images: 0,
            videos: 0,
        },
        customUrl: '',
        editingFile: null,
        bulkEditMode: false,
        bulkEditIds: [],
        editForm: {
            title: '',
            category: '',
        },
        editorId: editorIdParam,
        uploading: false,
        uploadPercent: 0,
        uploadFileName: '',

        get footerButtonText() {
            if (this.editorId === 'editor' || this.editorId === 'vditor') {
                return '插入到编辑器';
            }
            return '确认选择';
        },

        init() {
            const self = this;
            
            // 全局暴露打开方法
            window.openMediaSelector = function(field = 'editor') {
                self.editorId = field;
                self.openModal();
            };
        },

        openModal() {
            this.showModal = true;
            this.activeTab = 'library';
            this.selectedFile = null;
            this.selectedFiles = [];
            this.search = '';
            this.filterCategory = '';
            this.currentPage = 1;
            this.loadFiles();
        },

        closeModal() {
            this.showModal = false;
            this.editingFile = null;
            this.bulkEditMode = false;
            this.bulkEditIds = [];
        },

        async loadFiles(page = 1) {
            this.loading = true;
            this.currentPage = page;

            try {
                const params = new URLSearchParams({
                    page: page,
                    type: this.filterCategory || 'all',
                    search: this.search,
                });

                const resp = await fetch(`/admin/media-library?${params}`);
                const data = await resp.json();

                if (data.success) {
                    this.files = data.data.files;
                    this.pagination = data.data.pagination;
                    this.stats = data.data.stats;
                } else {
                    console.error('加载文件失败:', data.message);
                }
            } catch (e) {
                console.error('加载文件失败:', e);
            } finally {
                this.loading = false;
            }
        },

        uploadFile(file) {
            if (!file || this.uploading) return;

            const formData = new FormData();
            formData.append('file', file);
            formData.append('category', file.type.startsWith('video/') ? 'videos' : 'images');

            this.uploading = true;
            this.uploadPercent = 0;
            this.uploadFileName = file.name;

            const xhr = new XMLHttpRequest();
            xhr.open('POST', '/admin/media-library/upload');
            xhr.setRequestHeader('X-CSRF-TOKEN', document.querySelector('meta[name="csrf-token"]').getAttribute('content'));
            xhr.setRequestHeader('Accept', 'application/json');

            xhr.upload.onprogress = (e) => {
                if (e.lengthComputable) {
                    this.uploadPercent = Math.round((e.loaded / e.total) * 100);
                }
            };

            xhr.onload = () => {
                this.uploading = false;
                this.uploadPercent = 0;
                this.uploadFileName = '';
                if (this.$refs.fileInput) this.$refs.fileInput.value = '';

                let data = null;
                try {
                    data = JSON.parse(xhr.responseText);
                } catch (e) {
                    alert('上传失败：响应解析错误');
                    return;
                }

                if (xhr.status >= 200 && xhr.status < 300 && data.success) {
                    alert('上传成功');
                    this.loadFiles();
                } else {
                    alert('上传失败：' + (data.message || '未知错误'));
                }
            };

            xhr.onerror = () => {
                this.uploading = false;
                this.uploadPercent = 0;
                this.uploadFileName = '';
                if (this.$refs.fileInput) this.$refs.fileInput.value = '';
                alert('上传失败：网络错误');
            };

            xhr.send(formData);
        },

        toggleFile(file) {
            const idx = this.selectedFiles.indexOf(file.id);
            if (idx >= 0) {
                this.selectedFiles.splice(idx, 1);
                if (this.selectedFile && this.selectedFile.id === file.id) {
                    this.selectedFile = null;
                }
            } else {
                this.selectedFiles.push(file.id);
                this.selectedFile = file;
            }
        },

        async bulkCopyLinks() {
            if (this.selectedFiles.length === 0) return;
            try {
                const resp = await fetch('/admin/media-library/bulk-copy', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                    },
                    body: JSON.stringify({ ids: this.selectedFiles }),
                });
                const data = await resp.json();
                if (data.success) {
                    const text = data.urls.join('\n');
                    await navigator.clipboard.writeText(text);
                    alert('已复制 ' + data.urls.length + ' 个链接');
                } else {
                    alert('复制失败：' + (data.message || '未知错误'));
                }
            } catch (e) {
                alert('复制失败：' + e.message);
            }
        },

        openBulkEdit() {
            if (this.selectedFiles.length === 0) return;
            this.bulkEditMode = true;
            this.bulkEditIds = [...this.selectedFiles];
            this.editingFile = this.files.find(f => f.id === this.selectedFiles[0]);
            this.editForm = {
                title: '',
                category: this.editingFile?.category || 'uncategorized',
            };
        },

        async bulkDelete() {
            if (this.selectedFiles.length === 0) return;
            if (!confirm('确定要删除选中的 ' + this.selectedFiles.length + ' 个文件吗？')) return;

            try {
                const resp = await fetch('/admin/media-library/bulk-destroy', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                    },
                    body: JSON.stringify({ ids: this.selectedFiles }),
                });
                const data = await resp.json();
                if (data.success) {
                    alert(data.message || '删除成功');
                    this.selectedFiles = [];
                    this.selectedFile = null;
                    this.loadFiles();
                } else {
                    alert('删除失败：' + (data.message || '未知错误'));
                }
            } catch (e) {
                alert('删除失败：' + e.message);
            }
        },

        selectFile(file) {
            this.selectedFile = file;
        },

        insertToEditor() {
            if (!this.selectedFile && this.activeTab === 'library') return;

            const file = this.selectedFile;
            const url = file ? file.url : this.customUrl;
            const type = file ? file.file_type : (/\.(mp4|webm|ogg)$/i.test(this.customUrl) ? 'video' : 'image');
            const content = type === 'image' ? `<img src="${url}" alt="${file?.file_name || ''}" />` : `<video controls src="${url}"></video>`;
            
            if (this.editorId === 'editor' || this.editorId === 'vditor') {
                this.insertContent(content);
            } else {
                window.dispatchEvent(new CustomEvent('media-selected', {
                    detail: { url: url, file: file, field: this.editorId }
                }));
            }
            this.closeModal();
        },

        insertCustomUrl() {
            if (!this.customUrl.trim()) return;

            const isVideo = /\.(mp4|webm|ogg)$/i.test(this.customUrl);

            if (this.editorId === 'editor' || this.editorId === 'vditor') {
                // 编辑器场景：插入到 Vditor
                this.insertContent(isVideo ? `<video controls src="${this.customUrl}"></video>` : `![image](${this.customUrl})`);
            } else {
                // 非编辑器场景（如幻灯片/友链/设置页字段）：派发事件，由页面监听器填充对应字段
                const file = {
                    url: this.customUrl,
                    file_path: this.customUrl,
                    file_name: this.customUrl.split('/').pop() || this.customUrl,
                    file_type: isVideo ? 'video' : 'image',
                };
                window.dispatchEvent(new CustomEvent('media-selected', {
                    detail: { url: this.customUrl, file: file, field: this.editorId }
                }));
            }
            this.closeModal();
        },

        insertContent(content) {
            const vditor = window.vditor || window.editorVditor;
            if (vditor) {
                vditor.insertValue(content);
            } else {
                console.warn('Vditor 编辑器未找到');
                alert('请先激活编辑器');
            }
        },

        copyLink(url) {
            navigator.clipboard.writeText(url).then(() => {
                alert('链接已复制');
            }).catch(() => {
                const input = document.createElement('input');
                input.value = url;
                document.body.appendChild(input);
                input.select();
                document.execCommand('copy');
                document.body.removeChild(input);
                alert('链接已复制');
            });
        },

        editFile(file) {
            this.editingFile = file;
            this.editForm = {
                title: file.title || '',
                category: file.category || 'uncategorized',
            };
        },

        async saveEdit() {
            if (!this.editingFile) return;

            try {
                const url = this.bulkEditMode ? '/admin/media-library/bulk-update' : `/admin/media-library/${this.editingFile.id}`;
                const method = this.bulkEditMode ? 'POST' : 'PATCH';
                const body = this.bulkEditMode
                    ? JSON.stringify({ ids: this.bulkEditIds, title: this.editForm.title, category: this.editForm.category })
                    : JSON.stringify(this.editForm);

                const resp = await fetch(url, {
                    method: method,
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                    },
                    body: body,
                });

                const data = await resp.json();
                if (data.success) {
                    alert(data.message || '保存成功');
                    this.editingFile = null;
                    this.bulkEditMode = false;
                    this.bulkEditIds = [];
                    this.selectedFiles = [];
                    this.selectedFile = null;
                    this.loadFiles();
                } else {
                    alert('保存失败：' + (data.message || '未知错误'));
                }
            } catch (e) {
                alert('保存失败：' + e.message);
            }
        },

        async deleteFile(id) {
            if (!confirm('确定要删除这个文件吗？')) return;

            try {
                const resp = await fetch(`/admin/media-library/${id}`, {
                    method: 'DELETE',
                    headers: {
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                    },
                });
                const data = await resp.json();
                if (data.success) {
                    alert(data.message || '删除成功');
                    if (this.selectedFile?.id === id) {
                        this.selectedFile = null;
                    }
                    this.selectedFiles = this.selectedFiles.filter(fid => fid !== id);
                    this.loadFiles();
                } else {
                    alert('删除失败：' + (data.message || '未知错误'));
                }
            } catch (e) {
                alert('删除失败：' + e.message);
            }
        },
    }));
});
</script>

@props(['scene', 'containerClass' => ''])

@if(\App\Services\Captcha::enabled($scene))
@php $captchaId = 'captcha_img_' . $scene . '_' . uniqid(); @endphp
<div class="flex items-center gap-2 flex-wrap {{ $containerClass }}">
    <input type="text" name="captcha" value="{{ old('captcha') }}" placeholder="验证码"
           required maxlength="6" autocomplete="off"
           class="px-3 py-2 text-base border border-gray-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-400 focus:border-blue-400 {{ $attributes->get('class') }}" {{ $attributes }}>
    <img src="{{ route('captcha.image', ['scene' => $scene]) }}?v={{ time() }}"
         alt="验证码" title="点击刷新验证码" style="cursor:pointer;height:40px;border-radius:6px;flex-shrink:0;"
         onclick="this.src='{{ route('captcha.image', ['scene' => $scene]) }}?v='+Date.now();">
    {{ $slot }}
</div>
@error('captcha')<p class="text-sm text-red-500 mt-1">{{ $message }}</p>@enderror
@endif

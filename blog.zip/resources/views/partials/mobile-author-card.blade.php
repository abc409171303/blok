<div class="bg-white rounded-lg shadow-sm overflow-hidden">
    <div class="px-5 py-8 text-center">
        <div class="avatar-ring w-32 h-32 mx-auto rounded-full shadow flex items-center justify-center">
            @if($config->site_avatar)
            <img src="{{ Storage::url($config->site_avatar) }}" alt="" class="w-28 h-28 rounded-full object-cover">
            @else
            <div class="w-28 h-28 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center text-white text-3xl font-bold">
                {{ mb_substr($config->site_name ?? 'B', 0, 1) }}
            </div>
            @endif
        </div>
        <div class="text-xl font-semibold text-gray-800 mt-4">{{ $config->site_name ?? '博客' }}</div>
        <div class="text-gray-400 mt-3 text-base leading-relaxed">{{ $config->site_tagline ?: ($config->site_description ?? "记录点滴，分享生活") }}</div>
        @if(count($contactItems) > 0)
        <div class="mt-4 pt-4 border-t {{ $enableDark ? 'border-[#2a2d42]' : 'border-gray-100' }} space-y-2 text-base text-gray-500">
            @foreach($contactItems as $item)
            <div class="flex items-center justify-center gap-2">
                <i class="{{ $item['icon'] }} {{ $item['color'] }}"></i>
                <span>{{ $item['name'] }}</span>
                @if($item['url'])
                <a href="{{ $item['url'] }}" target="_blank" rel="noopener" class="truncate max-w-[220px] {{ $enableDark ? 'hover:text-[#9197ed]' : 'hover:text-blue-600' }} transition-colors">{{ $item['label'] }}</a>
                @else
                <span class="truncate max-w-[220px]">{{ $item['label'] }}</span>
                @endif
            </div>
            @endforeach
        </div>
        @endif
    </div>
</div>

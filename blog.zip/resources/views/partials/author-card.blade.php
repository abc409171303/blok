{{-- 博主头像卡片：有轮播时高度拉伸与轮播齐平，无轮播时自然高度 --}}
<div class="px-5 py-6 text-center">
    <div class="avatar-ring w-32 h-32 mx-auto rounded-full shadow flex items-center justify-center">
        @if($config->site_avatar)
        <img src="{{ Storage::url($config->site_avatar) }}" alt="" class="w-28 h-28 rounded-full object-cover">
        @else
        <div class="w-28 h-28 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center text-white text-3xl font-bold">
            {{ mb_substr($config->site_name ?? 'B', 0, 1) }}
        </div>
        @endif
    </div>
    <div class="text-xl font-semibold text-gray-800 mt-4">{{ $config->site_name ?? '博客' }}</div>
    <div class="text-gray-400 mt-3 text-sm leading-relaxed">{{ $config->site_tagline ?: ($config->site_description ?? "记录点滴，分享生活") }}</div>
</div>

@extends('layouts.app')
@section('title', '搜索：' . $keyword)

@section('content')
<div class="bg-white rounded-lg shadow-sm mb-4">
    <div class="p-4 text-sm text-gray-500">
        搜索 "<span class="text-gray-800 font-medium">{{ $keyword }}</span>" 共找到 {{ $posts->total() }} 篇文章
    </div>
</div>

<div class="bg-white rounded-lg shadow-sm">
    <div class="p-3 sm:p-4">
        @forelse($posts as $post)
        <div class="{{ !$loop->last ? 'border-b border-gray-100 pb-5 mb-5' : '' }}">
            <div class="flex flex-col lg:flex-row">
                <div class="flex-1 min-w-0">
                    <h2 class="text-lg font-semibold leading-6 mb-2">
                        <a href="{{ route('blog.show', $post->slug) }}" class="text-gray-800 hover:text-blue-600 transition-colors line-clamp-2">
                            @if($keyword !== '')
                            {!! preg_replace('/(' . preg_quote($keyword, '/') . ')/iu', '<span class="text-blue-600 bg-yellow-50">$1</span>', e($post->title)) !!}
                            @else
                            {{ $post->title }}
                            @endif
                        </a>
                    </h2>
                    <div class="text-gray-400 text-sm mb-2 flex flex-wrap items-center gap-x-3 gap-y-1">
                        @if($post->category)
                            <span><i class="fa-solid fa-folder mr-1"></i>{{ $post->category->name }}</span>
                        @endif
                        <span><i class="fa-regular fa-clock mr-1"></i>{{ $post->published_at ? $post->published_at->format('Y-m-d H:i') : '' }}</span>
                        <span><i class="fa-regular fa-eye mr-1"></i>{{ $post->views }}</span>
                    </div>
                    @if($post->summary)
                        <div class="text-gray-500 text-sm leading-relaxed line-clamp-2">
                            @if($keyword !== '')
                            {!! preg_replace('/(' . preg_quote($keyword, '/') . ')/iu', '<span class="text-blue-600 bg-yellow-50">$1</span>', e($post->summary)) !!}
                            @else
                            {{ $post->summary }}
                            @endif
                        </div>
                    @endif
                </div>
                @php
                    $coverUrl = $post->cover_url;
                    if (!$coverUrl && preg_match('/<img[^>]+src=["\']([^"\']+)["\']/i', $post->content_html, $m)) {
                        $coverUrl = $m[1];
                    }
                @endphp
                @if($coverUrl)
                <a href="{{ route('blog.show', $post->slug) }}" class="lg:w-36 lg:ml-4 shrink-0 mb-3 lg:mb-0">
                    <div class="w-full lg:w-36 aspect-[3/2] rounded overflow-hidden bg-gray-200">
                        <img src="{{ $coverUrl }}" alt="{{ $post->title }}" class="w-full h-full object-cover hover:scale-110 transition-transform duration-300">
                    </div>
                </a>
                @endif
            </div>
        </div>
        @empty
        <div class="py-16 text-center text-gray-400">
            <i class="fa-solid fa-search text-4xl mb-3 block"></i>
            <p>未找到与 "{{ $keyword }}" 相关的文章</p>
        </div>
        @endforelse
        <div class="mt-4">{{ $posts->links() }}</div>
    </div>
</div>
@endsection

@extends('layouts.app')
@section('title', '首页')
@php
    $slides = App\Models\Slide::active()->ordered()->get();
@endphp

@section('hero')
@if($slides->count() > 0)
<div class="bg-white rounded-lg shadow-sm overflow-hidden">
    <div class="relative w-full hero-slider-frame">
        <div id="hero-slider" class="absolute inset-0 overflow-hidden">
            @foreach($slides as $i => $slide)
            <div class="hero-slide {{ $i === 0 ? 'active' : '' }} absolute inset-0 transition-opacity duration-700 {{ $i === 0 ? 'opacity-100 z-10' : 'opacity-0 z-0' }}">
                @if($slide->video_url)
                    @if(str_contains($slide->video_url, 'bilibili.com') || str_contains($slide->video_url, 'b23.tv'))
                        <iframe src="{{ str_replace('www.bilibili.com/video', 'player.bilibili.com/player.html', $slide->video_url) }}" 
                            class="absolute inset-0 w-full h-full" frameborder="0" allowfullscreen>
                        </iframe>
                    @else
                        <video src="{{ $slide->video_url }}" 
                            poster="{{ $slide->video_cover_url }}" 
                            class="absolute inset-0 w-full h-full object-cover" 
                            controls muted autoplay loop>
                        </video>
                    @endif
                @elseif($slide->image)
                <img src="{{ $slide->image_url }}" alt="{{ $slide->title }}" class="absolute inset-0 w-full h-full object-cover">
                @else
                <div class="absolute inset-0 bg-gradient-to-r from-gray-800 to-gray-900"></div>
                @endif
                <div class="absolute inset-0 bg-black/30"></div>
                <div class="absolute inset-0 flex items-center px-8 md:px-12">
                    <div class="max-w-md">
                        <div class="text-2xl md:text-3xl font-bold text-white mb-2 drop-shadow-lg">{{ $slide->title }}</div>
                        @if($slide->subtitle)
                        <div class="text-gray-200 text-base drop-shadow mb-4 leading-relaxed">{{ \Illuminate\Support\Str::limit($slide->subtitle, 80) }}</div>
                        @endif
                        @if($slide->link_url)
                        <a href="{{ $slide->link_url }}" class="inline-block px-5 py-1.5 border border-white/50 text-white text-base rounded hover:bg-white/20 transition-all">立即查看</a>
                        @endif
                    </div>
                </div>
            </div>
            @endforeach

            @if($slides->count() > 1)
            <div class="absolute bottom-4 left-1/2 -translate-x-1/2 z-20 flex space-x-2">
                @foreach($slides as $i => $slide)
                <span class="hero-dot w-2 h-2 rounded-full cursor-pointer {{ $i === 0 ? 'bg-white' : 'bg-white/50' }}" data-index="{{ $i }}"></span>
                @endforeach
            </div>
            <button id="hero-prev" class="hero-nav-btn absolute left-3 top-1/2 -translate-y-1/2 z-20 w-8 h-8 rounded-full bg-white/20 hover:bg-white/40 flex items-center justify-center text-white transition-all"><i class="fa-solid fa-chevron-left text-sm"></i></button>
            <button id="hero-next" class="hero-nav-btn absolute right-3 top-1/2 -translate-y-1/2 z-20 w-8 h-8 rounded-full bg-white/20 hover:bg-white/40 flex items-center justify-center text-white transition-all"><i class="fa-solid fa-chevron-right text-sm"></i></button>
            @endif
        </div>
    </div>
</div>
@endif
@endsection

@section('content')
<div id="posts" class="bg-white rounded-lg shadow-sm">
    <div class="px-4 sm:px-5">
        @forelse($posts as $post)
        <div class="py-4 border-b border-gray-100 last:border-b-0">
            <div class="flex flex-col lg:flex-row lg:items-start">
                <div class="flex-1 min-w-0">
                    <div class="lg:truncate">
                        @if($post->is_top)
                        <span class="align-top inline-block leading-6 px-3 rounded text-base bg-red-100 text-red-500 mr-2">
                            <i class="fa-solid fa-fire"></i> 热门
                        </span>
                        @endif
                        <h2 class="align-top inline-block leading-6 text-xl font-medium">
                            <a href="{{ route('blog.show', $post->slug) }}" class="text-gray-800 hover:text-blue-600 transition-colors">{{ $post->title }}</a>
                        </h2>
                    </div>
                        <div class="text-gray-400 text-sm mt-2 flex flex-wrap items-center gap-x-3 gap-y-1">
                        @if($post->category)
                            <span><i class="fa-solid fa-folder mr-1"></i>{{ $post->category->name }}</span>
                        @endif
                        <span><i class="fa-regular fa-clock mr-1"></i>{{ $post->published_at ? $post->published_at->format('Y-m-d H:i') : '' }}</span>
                        <span><i class="fa-regular fa-eye mr-1"></i>{{ $post->views }}</span>
                        @if(\App\Models\SiteConfig::getInstance()->enable_comments ?? true)
                        <span><i class="fa-regular fa-comment mr-1"></i>{{ $post->comments()->where("status", "approved")->count() }}</span>
                        @endif
                    </div>
                    @if($post->summary)
                        <div class="text-gray-500 text-base leading-relaxed line-clamp-2 mt-2">{{ $post->summary }}</div>
                    @endif
                </div>
                @php
                    $coverUrl = $post->cover_url;
                    if (!$coverUrl && preg_match('/<img[^>]+src=["\']([^"\']+)["\']/i', $post->content_html, $m)) {
                        $coverUrl = $m[1];
                    }
                @endphp
                @if($coverUrl)
                <a href="{{ route('blog.show', $post->slug) }}" class="w-full lg:w-40 lg:ml-4 shrink-0 mb-3 lg:mb-0">
                    <div class="w-full lg:w-40 aspect-[3/2] rounded-lg overflow-hidden bg-gray-200">
                        <img src="{{ $coverUrl }}" alt="{{ $post->title }}" class="w-full h-full object-cover hover:scale-110 transition-transform duration-300">
                    </div>
                </a>
                @endif
            </div>
        </div>
        @empty
        <div class="py-16 text-center text-gray-400">
            <i class="fa-solid fa-inbox text-4xl mb-3 block"></i>
            <p>还没有发布任何文章</p>
        </div>
        @endforelse

        <div class="py-4">
            {{ $posts->links() }}
        </div>
    </div>
</div>
@endsection

@push('styles')
<style>
    /* 轮播容器：桌面端维持原 40% 宽高比高度 */
    .hero-slider-frame {
        padding-bottom: 40%;
    }

    /* 仅手机移动端：轮播与下方文章封面同高（JS 按封面实测高度精确同步，此处兜底） */
    @media (max-width: 768px) {
        .hero-slider-frame {
            padding-bottom: 0;
            height: 220px;
            margin-bottom: 16px;
        }

        /* 画面铺满不变形（img/video 均已带 object-cover，此处兜底） */
        .hero-slide img,
        .hero-slide video {
            object-fit: cover;
        }
    }
</style>
@endpush

@push('scripts')
@if($slides->count() > 0)
<script>
// 手机端让轮播高度与下方文章封面(3:2)实际高度保持一致；桌面端交给 CSS padding-bottom
(function () {
    var mqMobile = window.matchMedia('(max-width: 768px)');
    var frame = document.querySelector('.hero-slider-frame');

    function syncHeroHeight() {
        if (!frame) return;
        if (!mqMobile.matches) {
            frame.style.height = '';
            return;
        }
        var covers = document.querySelectorAll('#posts div[class*="aspect-"]');
        for (var i = 0; i < covers.length; i++) {
            var h = covers[i].getBoundingClientRect().height;
            if (h > 0) {
                frame.style.height = h + 'px';
                return;
            }
        }
        frame.style.height = '';
    }

    if (frame) {
        syncHeroHeight();
        window.addEventListener('resize', syncHeroHeight);
        window.addEventListener('load', syncHeroHeight);
        // CSS/图片加载完成引起封面尺寸变化时自动重新同步
        if (typeof ResizeObserver !== 'undefined') {
            new ResizeObserver(syncHeroHeight).observe(document.body);
        }
    }
})();
</script>
@endif
@if($slides->count() > 1)
<script>
(function() {
    var slides = document.querySelectorAll('.hero-slide');
    var dots = document.querySelectorAll('.hero-dot');
    var current = 0, total = slides.length, timer;

    function showSlide(i) {
        slides.forEach(function(s, idx) {
            s.classList.toggle('opacity-100', idx === i);
            s.classList.toggle('opacity-0', idx !== i);
            s.classList.toggle('z-10', idx === i);
            s.classList.toggle('z-0', idx !== i);
        });
        dots.forEach(function(d, idx) {
            d.classList.toggle('bg-white', idx === i);
            d.classList.toggle('bg-opacity-50', idx !== i);
        });
        current = i;
    }
    function next() { showSlide((current + 1) % total); }
    function prev() { showSlide((current - 1 + total) % total); }
    document.getElementById('hero-next')?.addEventListener('click', next);
    document.getElementById('hero-prev')?.addEventListener('click', prev);
    dots.forEach(function(d) { d.addEventListener('click', function() { showSlide(parseInt(this.dataset.index)); }); });
    timer = setInterval(next, 5000);
    document.getElementById('hero-slider')?.addEventListener('mouseenter', function() { clearInterval(timer); });
    document.getElementById('hero-slider')?.addEventListener('mouseleave', function() { timer = setInterval(next, 5000); });
})();
</script>
@endif
@endpush

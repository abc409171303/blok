@extends('layouts.app')
@section('title', '留言')

@section('content')
<div class="max-w-3xl mx-auto">
    <div class="bg-white rounded-lg shadow-sm">
        <div class="px-6 sm:px-8 py-6 sm:py-8">
            <div class="flex items-center gap-2 mb-5 pb-5 border-b border-gray-100">
                <i class="fa-solid fa-comment-dots text-blue-500"></i>
                <h1 class="text-lg font-semibold text-gray-800">留言</h1>
            </div>

            @if(session('success'))
            <div class="mb-5 px-4 py-3 bg-green-50 border border-green-200 text-green-700 text-base rounded-lg">
                {{ session('success') }}
            </div>
            @endif

            {{-- 留言列表 --}}
            @if($messages->count() > 0)
            <div class="space-y-4 mb-8">
                @foreach($messages as $message)
                <div class="flex items-start gap-3 bg-white rounded-lg shadow-sm p-4 sm:p-5">
                    <div class="flex-shrink-0 w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center text-base font-semibold">
                        {{ mb_substr($message->author ?? '匿', 0, 1) }}
                    </div>
                    <div class="flex-1 min-w-0">
                        <div class="text-base font-semibold text-gray-800 leading-snug mb-0.5">{{ $message->author }}</div>
                        <div class="text-[12px] text-gray-400 mb-1.5">{{ $message->created_at->format('Y-m-d H:i') }} · {{ $message->created_at->locale('zh')->diffForHumans() }}</div>
                        <p class="text-base leading-normal text-gray-600 whitespace-pre-wrap break-words">{{ $message->content }}</p>
                        @if($message->reply)
                        <div class="mt-2 bg-blue-50 border border-gray-100 rounded-lg px-3 py-2.5">
                            <div class="flex items-center gap-1.5 mb-1">
                                <i class="fa-solid fa-reply text-sm text-blue-500"></i>
                                <span class="text-sm font-medium text-blue-600">博主回复</span>
                            </div>
                            <p class="text-base text-gray-600 leading-normal whitespace-pre-wrap break-words">{{ $message->reply }}</p>
                        </div>
                        @endif
                    </div>
                </div>
                @endforeach
            </div>

            {{ $messages->links() }}
            @else
            <div class="text-center py-12 text-gray-400">
                <i class="fa-regular fa-comment-dots text-4xl mb-3"></i>
                <p class="text-base">暂无留言，来抢沙发吧~</p>
            </div>
            @endif

            {{-- 留言表单 --}}
            <div class="pt-6 border-t border-gray-100">
                <h2 class="text-base font-semibold text-gray-700 mb-4">发表留言</h2>
                <form action="{{ route('blog.guestbook.store') }}" method="POST" class="space-y-3">
                    @csrf
                    <div class="flex gap-3">
                        <div class="flex-1">
                            <input type="text" name="author" value="{{ old('author') }}" placeholder="昵称 *"
                                   class="w-full px-3 py-2 text-base border border-gray-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-400 focus:border-blue-400" required maxlength="100">
                            @error('author')<p class="text-sm text-red-500 mt-1">{{ $message }}</p>@enderror
                        </div>
                        <div class="flex-1">
                            <input type="email" name="email" value="{{ old('email') }}" placeholder="邮箱 *（不公开显示）"
                                   class="w-full px-3 py-2 text-base border border-gray-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-400 focus:border-blue-400" required maxlength="100">
                            @error('email')<p class="text-sm text-red-500 mt-1">{{ $message }}</p>@enderror
                        </div>
                    </div>
                    <div>
                        <textarea name="content" rows="4" placeholder="说点什么吧..." required maxlength="1000"
                                  class="w-full px-3 py-2 text-base border border-gray-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-400 focus:border-blue-400 resize-none">{{ old('content') }}</textarea>
                        @error('content')<p class="text-sm text-red-500 mt-1">{{ $message }}</p>@enderror
                    </div>
                    <div>
                        <x-captcha-input scene="message" class="flex-1 min-w-0" />
                    </div>
                    <div class="flex items-center justify-between">
                        <p class="text-sm text-gray-400">留言需审核通过后展示</p>
                        <button type="submit"
                                class="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white text-base font-medium rounded-lg transition-colors">
                            提交留言
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection

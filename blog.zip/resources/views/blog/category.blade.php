@extends('layouts.app')
@section('title', $category->name)

@section('content')
<div class="bg-white rounded-lg shadow-sm mb-4">
    <div class="p-4 flex items-center gap-2 text-sm text-gray-500">
        <a href="{{ route('blog.index') }}" class="hover:text-blue-600">首页</a>
        <span>/</span>
        <span class="text-gray-800 font-medium">{{ $category->name }}</span>
        <span class="text-gray-400">({{ $posts->total() }})</span>
    </div>
    @if($category->description)
        <div class="px-4 pb-3 text-sm text-gray-400">{{ $category->description }}</div>
    @endif
</div>

<div class="bg-white rounded-lg shadow-sm">
    <div class="p-3 sm:p-4">
        @forelse($posts as $post)
        <div class="{{ !$loop->last ? 'border-b border-gray-100 pb-5 mb-5' : '' }}">
            <div class="flex flex-col lg:flex-row">
                <div class="flex-1 min-w-0">
                    <h2 class="text-lg font-semibold leading-6 mb-2">
                        <a href="{{ route('blog.show', $post->slug) }}" class="text-gray-800 hover:text-blue-600 transition-colors line-clamp-2">{{ $post->title }}</a>
                    </h2>
                    <div class="text-gray-400 text-sm mb-2 flex flex-wrap items-center gap-x-3 gap-y-1">
                        <span><i class="fa-regular fa-clock mr-1"></i>{{ $post->published_at ? $post->published_at->format('Y-m-d H:i') : '' }}</span>
                        <span><i class="fa-regular fa-eye mr-1"></i>{{ $post->views }}</span>
                        @if(\App\Models\SiteConfig::getInstance()->enable_comments ?? true)
                        <span><i class="fa-regular fa-comment mr-1"></i>{{ $post->comments()->where("status", "approved")->count() }}</span>
                        @endif
                    </div>
                </div>
                @php
                    $coverUrl = $post->cover_url;
                    if (!$coverUrl && preg_match('/<img[^>]+src=["\']([^"\']+)["\']/i', $post->content_html, $m)) {
                        $coverUrl = $m[1];
                    }
                @endphp
                @if($coverUrl)
                <a href="{{ route('blog.show', $post->slug) }}" class="lg:w-36 lg:ml-4 shrink-0 mb-3 lg:mb-0">
                    <div class="w-full lg:w-36 aspect-[3/2] rounded overflow-hidden bg-gray-200">
                        <img src="{{ $coverUrl }}" alt="{{ $post->title }}" class="w-full h-full object-cover hover:scale-110 transition-transform duration-300">
                    </div>
                </a>
                @endif
            </div>
        </div>
        @empty
        <div class="py-16 text-center text-gray-400">该分类下暂无文章</div>
        @endforelse
        <div class="mt-4">{{ $posts->links() }}</div>
    </div>
</div>
@endsection

@extends('layouts.app')
@section('title', $post->title)

@section('content')
<article class="bg-white rounded-lg shadow-sm overflow-hidden">
    <!-- Cover Image -->
    @if($post->cover)
        <div class="w-full max-h-96 overflow-hidden">
            <img src="{{ $post->cover_url }}" alt="{{ $post->title }}" class="w-full h-96 object-cover">
        </div>
    @endif

    <div class="p-5 sm:p-8">
        <!-- Title -->
        <h1 class="text-2xl sm:text-3xl font-bold text-gray-900 mb-4">{{ $post->title }}</h1>

        <!-- Meta -->
        <div class="flex items-center flex-wrap gap-3 text-base text-gray-500 mb-6 pb-4 border-b border-gray-100">
            @if($post->category)
                <a href="{{ route('blog.category', $post->category->slug) }}" class="px-3 py-1 bg-blue-50 text-blue-600 rounded text-sm hover:bg-blue-100 transition-colors">{{ $post->category->name }}</a>
            @endif
            <span>{{ $post->published_at ? $post->published_at->format('Y-m-d H:i') : '' }}</span>
            <span class="flex items-center"><i class="fa-regular fa-eye mr-1"></i>{{ $post->views }}</span>
        </div>

        <!-- Password Gate -->
        <div class="flex flex-col items-center justify-center py-10 sm:py-16 px-4">
            <div class="w-full max-w-md bg-gray-50 rounded-xl border border-gray-200 p-6 sm:p-8">
                <div class="flex flex-col items-center text-center">
                    <div class="w-14 h-14 rounded-full bg-amber-100 flex items-center justify-center mb-4">
                        <svg class="w-7 h-7 text-amber-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/>
                        </svg>
                    </div>
                    <h2 class="text-lg font-semibold text-gray-900 mb-1">该文章受密码保护</h2>
                    <p class="text-base text-gray-500 mb-6">请输入访问密码查看正文</p>

                    @if($post->summary)
                        <p class="text-base text-gray-400 mb-6 leading-relaxed">{{ $post->summary }}</p>
                    @endif

                    <form action="{{ route('blog.access', $post->slug) }}" method="POST" class="w-full">
                        @csrf
                        <input type="password" name="access_password" required placeholder="请输入访问密码"
                            autocomplete="current-password" autofocus
                            class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-base focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none bg-white">
                        @error('access_password')
                            <p class="mt-2 text-base text-red-500 flex items-center justify-center gap-1">
                                <svg class="w-4 h-4 inline" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M18 10A8 8 0 11 2 10a8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/></svg>
                                {{ $message }}
                            </p>
                        @enderror
                        <button type="submit"
                            class="w-full mt-4 px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-base font-medium rounded-lg transition-colors">
                            解锁文章
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</article>
@endsection

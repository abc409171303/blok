@extends('layouts.app')
@section('title', $post->title)

@section('content')
<article class="bg-white rounded-lg shadow-sm overflow-hidden">
    <div class="p-5 sm:p-8">
        <!-- Title -->
        <h1 class="text-2xl sm:text-3xl font-bold text-gray-900 mb-4">{{ $post->title }}</h1>

        <!-- Meta -->
        <div class="flex items-center flex-wrap gap-3 text-base text-gray-500 mb-6 pb-4 border-b border-gray-100">
            @if($post->category)
                <a href="{{ route('blog.category', $post->category->slug) }}" class="px-3 py-1 bg-blue-50 text-blue-600 rounded text-sm hover:bg-blue-100 transition-colors">{{ $post->category->name }}</a>
            @endif
            <span>{{ $post->published_at ? $post->published_at->format('Y-m-d H:i') : '' }}</span>
            <span class="flex items-center"><i class="fa-regular fa-eye mr-1"></i>{{ $post->views }}</span>
            @if($config->enable_comments ?? true)
            <span class="flex items-center"><i class="fa-regular fa-comment mr-1"></i>{{ $post->comments()->where('status', 'approved')->count() }}</span>
            @endif
        </div>

        <!-- Cover Image -->
        @if($post->cover)
        <div class="w-full mb-6 overflow-hidden">
            <img src="{{ $post->cover_url }}" alt="{{ $post->title }}" class="w-full h-auto object-cover">
        </div>
        @endif

        <!-- Content with images -->
        <div class="prose prose-gray max-w-none text-gray-700 leading-relaxed text-base space-y-4 article-content">
            {!! $post->content_html !!}
        </div>

        <!-- Tags -->
        @if($post->tags->count() > 0)
        <div class="mt-6 pt-4 border-t border-gray-100 flex flex-wrap gap-2">
            @foreach($post->tags as $tag)
                <a href="{{ route('blog.search', ['q' => $tag->name]) }}" class="inline-block px-3 py-1 text-sm rounded-full bg-gray-100 text-gray-500 hover:bg-blue-50 hover:text-blue-600 transition-colors">
                    {{ $tag->name }}
                </a>
            @endforeach
        </div>
        @endif

        <!-- Share -->
        @php
            $shareUrl = url()->current();
            $shareTitle = $post->title;
        @endphp
        <div class="mt-6 pt-5 border-t border-gray-100 flex flex-wrap items-center justify-center gap-3">
            <span class="text-sm text-gray-400 dark:text-gray-500 mr-1">分享到：</span>
            <a href="https://service.weibo.com/share/share.php?url={{ urlencode($shareUrl) }}&title={{ urlencode($shareTitle) }}"
                target="_blank" rel="noopener" title="分享到微博"
                class="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-[#E6162D] hover:bg-[#c80f24] text-white text-sm transition-colors">
                <i class="fa-brands fa-weibo"></i>微博
            </a>
            <a href="https://connect.qq.com/widget/shareqq/index.html?url={{ urlencode($shareUrl) }}&title={{ urlencode($shareTitle) }}"
                target="_blank" rel="noopener" title="分享到QQ"
                class="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-[#12B7F5] hover:bg-[#0aa5e0] text-white text-sm transition-colors">
                <i class="fa-brands fa-qq"></i>QQ
            </a>
            <a href="https://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url={{ urlencode($shareUrl) }}&title={{ urlencode($shareTitle) }}"
                target="_blank" rel="noopener" title="分享到QQ空间"
                class="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-[#FFCE00] hover:bg-[#e8ba00] text-[#5a4300] text-sm font-medium transition-colors">
                <i class="fa-brands fa-qq"></i>QQ空间
            </a>
            <button type="button" onclick="openWechatShare()" title="分享到微信"
                class="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-[#07C160] hover:bg-[#06ad56] text-white text-sm transition-colors cursor-pointer">
                <i class="fa-brands fa-weixin"></i>微信
            </button>
        </div>

        <!-- Prev / Next Navigation -->
        <div class="mt-8 pt-4 border-t border-gray-100 flex flex-col sm:flex-row justify-between gap-2 text-base">
            @php
                $prev = App\Models\Post::where('status', 'published')->where('id', '<', $post->id)->orderBy('id', 'desc')->first();
                $next = App\Models\Post::where('status', 'published')->where('id', '>', $post->id)->orderBy('id', 'asc')->first();
            @endphp
            <div class="flex-1">
                @if($prev)
                    <span class="text-gray-400">上一篇</span>
                    <br>
                    <a href="{{ route('blog.show', $prev->slug) }}" class="text-blue-600 hover:text-blue-800 transition-colors">{{ $prev->title }}</a>
                @else
                    <span class="text-gray-400">上一篇</span>
                    <br>
                    <span class="text-gray-300">没有了</span>
                @endif
            </div>
            <div class="flex-1 text-left sm:text-right">
                @if($next)
                    <span class="text-gray-400">下一篇</span>
                    <br>
                    <a href="{{ route('blog.show', $next->slug) }}" class="text-blue-600 hover:text-blue-800 transition-colors">{{ $next->title }}</a>
                @else
                    <span class="text-gray-400">下一篇</span>
                    <br>
                    <span class="text-gray-300">没有了</span>
                @endif
            </div>
        </div>
    </div>
</article>

<!-- Comments Section -->
@if($config->enable_comments ?? true)
<div class="bg-white rounded-lg shadow-sm mt-5 p-5 sm:p-8">
    <h3 class="text-base font-semibold text-gray-800 mb-4 pb-2 border-b border-gray-100">博客评论</h3>

    @if($comments->count() > 0)
        <div class="space-y-4 mb-6">
            @foreach($comments as $comment)
            <div class="border-b border-gray-50 pb-4 last:border-0 {{ $comment->parent_id ? 'ml-8 pl-4 border-l-2 border-gray-100' : '' }}">
                <div class="flex items-center gap-2 mb-1.5">
                    <div class="w-7 h-7 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center text-white text-sm font-bold">
                        {{ mb_substr($comment->author ?? '匿', 0, 1) }}
                    </div>
                    <span class="text-base font-medium text-gray-700">{{ $comment->author ?? '匿名' }}</span>
                    <span class="text-sm text-gray-400">{{ $comment->created_at->format('Y-m-d H:i') }}</span>
                </div>
                <p class="text-lg text-gray-600 ml-9">{{ $comment->content }}</p>
                <button class="text-sm text-gray-400 hover:text-blue-500 transition-colors ml-9 mt-1" onclick="replyTo({{ $comment->id }}, '{{ $comment->author ?? '匿名' }}')">
                    <i class="fa-solid fa-reply mr-1"></i>回复
                </button>

                <!-- Nested replies -->
                @foreach($comment->replies()->approved()->latest()->get() as $reply)
                <div class="ml-9 mt-3 pl-4 border-l-2 border-gray-100">
                    <div class="flex items-center gap-2 mb-1">
                        <div class="w-6 h-6 rounded-full bg-gradient-to-br from-gray-300 to-gray-400 flex items-center justify-center text-white text-sm font-bold">
                            {{ mb_substr($reply->author ?? '匿', 0, 1) }}
                        </div>
                        <span class="text-sm font-medium text-gray-600">{{ $reply->author ?? '匿名' }}</span>
                        <span class="text-sm text-gray-400">{{ $reply->created_at->format('Y-m-d H:i') }}</span>
                    </div>
                    <p class="text-base text-gray-500 ml-8">{{ $reply->content }}</p>
                </div>
                @endforeach
            </div>
            @endforeach
        </div>
    @else
        <p class="text-base text-gray-400 mb-6">还没有人评论，赶紧抢个沙发~</p>
    @endif

    <!-- Comment Form -->
    <div class="border-t border-gray-100 pt-4">
        <h4 class="text-base font-semibold text-gray-700 mb-4">发表评论</h4>
        <form action="{{ route('blog.comment', $post->slug) }}" method="POST" id="comment-form">
            @csrf
            <input type="hidden" name="parent_id" id="parent_id" value="">
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-3">
                <div>
                    <input type="text" name="author" value="{{ old('author') }}" placeholder="昵称 *" class="w-full px-3 py-2 text-base border border-gray-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-400 focus:border-blue-400" required>
                    @error('author')<p class="text-sm text-red-500 mt-1">{{ $message }}</p>@enderror
                </div>
                <div>
                    <input type="email" name="email" value="{{ old('email') }}" placeholder="邮箱 *" class="w-full px-3 py-2 text-base border border-gray-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-400 focus:border-blue-400" required>
                    @error('email')<p class="text-sm text-red-500 mt-1">{{ $message }}</p>@enderror
                </div>
            </div>
            <div class="mb-3" id="reply-hint" style="display:none;">
                <span class="text-sm text-blue-600">回复 <strong id="reply-target"></strong>：<button type="button" onclick="cancelReply()" class="text-gray-400 hover:text-red-500 ml-2"><i class="fa-solid fa-times"></i></button></span>
            </div>
            <div class="mb-3">
                <textarea name="content" rows="5" placeholder="说点什么吧..." class="w-full px-3 py-2 text-base border border-gray-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-400 focus:border-blue-400" required>{{ old('content') }}</textarea>
                @error('content')<p class="text-sm text-red-500 mt-1">{{ $message }}</p>@enderror
            </div>
            <div class="mb-3">
                <x-captcha-input scene="comment" class="w-20 sm:w-32">
                    <button type="submit" class="px-5 py-2 bg-blue-600 text-white text-base rounded-lg hover:bg-blue-700 transition-colors shrink-0 ml-auto">
                        提交
                    </button>
                </x-captcha-input>
            </div>
        </form>
        <p class="text-sm text-gray-400 mt-3">说明：请文明发言，共建和谐网络，您的个人信息不会被公开显示。</p>
    </div>
</div>
@endif

@if(session('success'))
<div id="flash-msg" class="fixed top-20 right-4 bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg shadow-lg text-base z-50 transition-opacity">
    {{ session('success') }}
</div>
@endif
@endsection

@push('scripts')
<script>
function replyTo(id, name) {
    document.getElementById('parent_id').value = id;
    document.getElementById('reply-hint').style.display = 'block';
    document.getElementById('reply-target').textContent = name;
    document.querySelector('textarea[name="content"]').focus();
}
function cancelReply() {
    document.getElementById('parent_id').value = '';
    document.getElementById('reply-hint').style.display = 'none';
}
// Flash message auto-hide
var flash = document.getElementById('flash-msg');
if (flash) {
    setTimeout(function() { flash.style.opacity = '0'; setTimeout(function() { flash.remove(); }, 300); }, 3000);
}
</script>
@endpush

@push('scripts')
@vite(['resources/js/article-lightbox.js'])
@endpush

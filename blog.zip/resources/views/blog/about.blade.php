@extends('layouts.app')
@section('title', '关于博主')

@section('content')
<div class="bg-white rounded-lg shadow-sm">
    <div class="px-6 sm:px-8 py-6 sm:py-8">
        <div class="flex items-center gap-2 mb-5 pb-5 border-b border-gray-100">
            <i class="fa-solid fa-user text-blue-500"></i>
            <h1 class="text-lg font-semibold text-gray-800">关于博主</h1>
        </div>

        <div class="about-content text-gray-700 max-w-none" style="line-height: 1.9;">
            {!! $config->about_content !!}
        </div>
    </div>
</div>
@endsection

@push('styles')
<style>
    .about-content h1, .about-content h2, .about-content h3, .about-content h4,
    .about-content h5, .about-content h6 {
        font-weight: 600;
        color: #1f2937;
        margin: 1.2em 0 0.5em;
        line-height: 1.4;
    }
    .about-content h1 { font-size: 1.4em; }
    .about-content h2 { font-size: 1.25em; }
    .about-content h3 { font-size: 1.1em; }
    .about-content h4 { font-size: 1em; }
    .about-content p { margin: 0.9em 0; }
    .about-content ul, .about-content ol { margin: 0.9em 0; padding-left: 1.6em; }
    .about-content ul { list-style: disc; }
    .about-content ol { list-style: decimal; }
    .about-content pre {
        background: #f3f4f6;
        border-radius: 6px;
        padding: 10px 14px;
        overflow-x: auto;
        font-size: 0.85em;
        margin: 0.8em 0;
        white-space: pre-wrap;
        word-break: break-word;
    }
    .about-content code {
        background: #f3f4f6;
        border-radius: 4px;
        padding: 1px 5px;
        font-size: 0.9em;
        color: #be185d;
    }
    .about-content pre code { background: none; padding: 0; color: inherit; }
    .about-content a { color: #2563eb; text-decoration: underline; }
    .about-content blockquote {
        border-left: 3px solid #d1d5db;
        padding-left: 12px;
        margin: 0.8em 0;
        color: #6b7280;
    }
    .about-content img { max-width: 100%; border-radius: 6px; margin: 0.8em 0; }
    .about-content li { margin: 0.3em 0; }

    /* 暗黑模式适配 */
    .theme-dark .about-content h1, .theme-dark .about-content h2,
    .theme-dark .about-content h3, .theme-dark .about-content h4,
    .theme-dark .about-content h5, .theme-dark .about-content h6 {
        color: var(--color-theme-title);
    }
    .theme-dark .about-content pre {
        background: #23263a;
        color: var(--color-theme-text);
        border: 1px solid var(--color-theme-line);
    }
    .theme-dark .about-content code {
        background: #23263a;
        color: #f0abfc;
    }
    .theme-dark .about-content pre code { color: inherit; }
    .theme-dark .about-content a { color: var(--color-theme-primary-hover); }
    .theme-dark .about-content blockquote {
        border-left-color: #3a3e58;
        color: var(--color-theme-muted);
    }
    .theme-dark .about-content hr { border-color: var(--color-theme-line); }
    .theme-dark .about-content table, .theme-dark .about-content th, .theme-dark .about-content td {
        border-color: var(--color-theme-line);
    }
</style>
@endpush

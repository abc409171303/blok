<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>网站已安装 - 禁止重复安装</title>
    <style>
        * { box-sizing: border-box; }
        body {
            margin: 0;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif;
            background: #f1f5f9;
            color: #1e293b;
        }
        .card {
            width: 100%;
            max-width: 520px;
            background: #ffffff;
            border: 1px solid #e2e8f0;
            border-radius: 16px;
            padding: 40px 32px;
            text-align: center;
            box-shadow: 0 10px 30px rgba(15, 23, 42, 0.06);
        }
        .icon {
            width: 64px;
            height: 64px;
            margin: 0 auto 20px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #fee2e2;
            color: #dc2626;
            font-size: 32px;
            font-weight: 700;
        }
        h1 { font-size: 20px; margin: 0 0 12px; }
        p { margin: 0 0 8px; font-size: 14px; color: #64748b; line-height: 1.7; }
        .actions { margin-top: 28px; }
        a {
            display: inline-block;
            padding: 10px 24px;
            border-radius: 8px;
            background: #2563eb;
            color: #ffffff;
            text-decoration: none;
            font-size: 14px;
        }
        a:hover { background: #1d4ed8; }
    </style>
</head>
<body>
    <div class="card">
        <div class="icon">!</div>
        <h1>网站已安装，禁止重复安装</h1>
        <p>系统检测到网站已完成安装，安装向导已失效。</p>
        <p>如需重新安装，请先手动删除项目根目录的 <strong>install.lock</strong> 锁文件，再访问安装向导。</p>
        <div class="actions">
            <a href="/">返回网站首页</a>
        </div>
    </div>
</body>
</html>

@php
    $config = App\Models\SiteConfig::getInstance();
    $headerNavs = App\Models\Navigation::head()->active()->ordered()->get();
    $footerNavs = App\Models\Navigation::foot()->active()->ordered()->get();
    $friendLinks = App\Models\FriendLink::where('status', 1)->orderBy('sort_order')->get();
    $sidebarCategories = App\Models\Category::withCount(['posts' => function ($q) { $q->where('status', 'published'); }])->orderBy('sort_order')->get()->filter(fn($c) => (int) $c->posts_count > 0);
    $sidebarTags = App\Models\Tag::withCount('posts')->orderBy('posts_count', 'desc')->when(($config->sidebar_tag_count ?? 0) > 0, fn($q) => $q->limit((int) $config->sidebar_tag_count))->get()->filter(fn($t) => (int) $t->posts_count > 0);
    $sidebarHot = App\Models\Post::where('status', 'published')->orderBy('views', 'desc')->limit(6)->get();
    $isAdmin = \Illuminate\Support\Facades\Auth::check() && \Illuminate\Support\Facades\Auth::user()->isAdmin();
    $enableDark = (bool) ($config->enable_dark_mode ?? true);
    $searchDriver = $config->search_driver ?? 'builtin';
    $searchAction = match ($searchDriver) {
        'baidu' => 'https://www.baidu.com/s',
        'google' => 'https://www.google.com/search',
        'bing' => 'https://www.bing.com/search',
        default => route('blog.search'),
    };
    $searchField = $searchDriver === 'baidu' ? 'wd' : 'q';
    // 暗黑模式：始终开启 / 始终关闭 / 定时（时间段，支持跨午夜）
    $darkModeMode = $config->dark_mode_mode ?? (($config->enable_dark_mode ?? true) ? 'always' : 'never');
    if (!in_array($darkModeMode, ['always', 'never', 'schedule'], true)) {
        $darkModeMode = 'always';
    }
    $darkStart = $config->dark_mode_start ?: '19:00';
    $darkEnd = $config->dark_mode_end ?: '07:00';
    $darkInRange = function (string $now, string $start, string $end): bool {
        if (!$start || !$end || !preg_match('/^\d{2}:\d{2}$/', $start) || !preg_match('/^\d{2}:\d{2}$/', $end)) {
            return false;
        }
        $t = ((int) substr($now, 0, 2)) * 60 + (int) substr($now, 3, 2);
        $s = ((int) substr($start, 0, 2)) * 60 + (int) substr($start, 3, 2);
        $e = ((int) substr($end, 0, 2)) * 60 + (int) substr($end, 3, 2);
        if ($s === $e) {
            return true;
        }
        return $s < $e ? ($t >= $s && $t < $e) : ($t >= $s || $t < $e);
    };
    $enableDark = match ($darkModeMode) {
        'never' => false,
        'schedule' => $darkInRange(now()->format('H:i'), $darkStart, $darkEnd),
        default => true,
    };
    $headerBg = $enableDark ? 'bg-[#1b1e32] border-[#2a2d42]' : 'bg-white border-gray-200';
    $headerLink = $enableDark ? 'text-[#a3a7bb] hover:text-[#9197ed]' : 'text-gray-600 hover:text-blue-600';
    $headerLinkActive = $enableDark ? 'bg-[#656DE6]/15 text-[#9197ed]' : 'bg-blue-50 text-blue-600';
    $searchInput = $enableDark ? 'bg-[#151728] border-[#3a3e58] text-[#e6e8ef] placeholder:text-[#80859f]' : 'bg-gray-50 border-gray-300 text-gray-800 placeholder:text-gray-400';
    $searchIcon = $enableDark ? 'text-[#80859f] hover:text-[#9197ed]' : 'text-gray-400 hover:text-blue-600';
    // 文章详情页纯净阅读开关：仅详情页受控；关闭后隐藏侧边博主卡片与联系方式，首页/列表始终完整展示
    $isPostDetailPage = request()->routeIs('blog.show');
    $postDetailShowAuthorCard = !$isPostDetailPage || (bool) ($config->post_detail_sidebar_author ?? true);
    // 博主联系方式（QQ/邮箱/电话/微信/地址，侧边栏展示）
    $contactItems = [];
    if (!empty($config->contact_qq)) {
        $contactItems[] = ['name' => 'QQ', 'icon' => 'fa-brands fa-qq', 'color' => 'text-blue-500', 'label' => $config->contact_qq, 'url' => 'https://wpa.qq.com/msgrd?v=3&uin=' . urlencode($config->contact_qq) . '&site=qq&menu=yes'];
    }
    if (!empty($config->contact_email)) {
        $contactItems[] = ['name' => '邮箱', 'icon' => 'fa-regular fa-envelope', 'color' => 'text-blue-500', 'label' => $config->contact_email, 'url' => 'mailto:' . $config->contact_email];
    }
    if (!empty($config->contact_phone)) {
        $contactItems[] = ['name' => '电话', 'icon' => 'fa-solid fa-phone', 'color' => 'text-green-600', 'label' => $config->contact_phone, 'url' => 'tel:' . preg_replace('/\s+/', '', $config->contact_phone)];
    }
    if (!empty($config->contact_wechat)) {
        $contactItems[] = ['name' => '微信', 'icon' => 'fa-brands fa-weixin', 'color' => 'text-green-500', 'label' => $config->contact_wechat, 'url' => null];
    }
    if (!empty($config->contact_address)) {
        $contactItems[] = ['name' => '地址', 'icon' => 'fa-solid fa-location-dot', 'color' => 'text-red-500', 'label' => $config->contact_address, 'url' => null];
    }
@endphp
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" class="{{ $enableDark ? 'dark' : '' }} theme-front">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=yes">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="description" content="{{ $config->site_description ?? '' }}">
    <meta name="keywords" content="{{ $config->site_keywords ?? '' }}">
    @if($config->site_favicon)
        <link rel="icon" href="{{ \Illuminate\Support\Facades\Storage::url($config->site_favicon) }}">
    @endif
    <title>@yield('title', '')@if(trim($__env->yieldContent('title'))) | @endif{{ $config->site_seo_title ?: ($config->site_name ?? '博客') }}</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        :root {
            --color-theme-primary: {{ $config->site_color ?: '#2563eb' }};
            --color-theme-primary-hover: color-mix(in srgb, var(--color-theme-primary) 85%, #ffffff);
        }
    </style>
    @vite(['resources/css/app.css'])
    @stack('styles')
    @if($config->custom_header_html)
    {!! $config->custom_header_html !!}
    @endif
</head>
<body class="{{ $enableDark ? 'theme-dark' : '' }} min-h-screen flex flex-col text-base">

    <header class="{{ $enableDark ? 'bg-[#1b1e32] border-b border-[#2a2d42]' : 'bg-white border-b border-gray-200' }}">
        <div class="max-w-7xl mx-auto px-4 flex items-center justify-start sm:justify-between h-14">
            <button id="mobile-menu-toggle" class="md:hidden p-1 {{ $headerLink }}">
                <i class="fa-solid fa-bars"></i>
            </button>
            <div class="flex items-center justify-center flex-none md:flex-none ml-2">
                @if($config->site_logo)
                    <a href="{{ route('blog.index') }}">
                        <img src="{{ \Illuminate\Support\Facades\Storage::url($config->site_logo) }}" alt="{{ $config->site_name }}" class="h-10">
                    </a>
                @else
                    <a href="{{ route('blog.index') }}" class="text-lg font-bold {{ $enableDark ? 'text-[#e6e8ef]' : 'text-gray-800' }} {{ $enableDark ? 'hover:text-[#9197ed]' : 'hover:text-blue-600' }} transition-colors">
                        {{ $config->site_name ?? '博客' }}
                    </a>
                @endif
            </div>
            <nav class="hidden md:flex items-center space-x-1 ml-8">
                @foreach($headerNavs as $nav)
                <a href="{{ $nav->url }}" target="{{ $nav->target }}" class="px-4 py-1.5 text-lg rounded {{ request()->is(trim($nav->url, '/')) || request()->is(trim($nav->url, '/').'/*') ? $headerLinkActive : $headerLink }} transition-colors">
                    @if($nav->icon)<i class="{{ $nav->icon }} mr-1.5"></i>@endif
                    {{ $nav->name }}
                </a>
                @endforeach
            </nav>
            <div class="hidden md:flex items-center ml-auto">
                <form action="{{ $searchAction }}" method="GET" @if($searchDriver !== 'builtin') target="_blank" @endif>
                    <div class="relative">
                        <input type="text" name="{{ $searchField }}" value="{{ request($searchField, '') }}" placeholder="关键词搜索" class="w-36 pl-8 pr-3 py-1.5 text-sm border rounded-full focus:outline-none focus:ring-1 focus:ring-[#656DE6] focus:border-[#656DE6] {{ $searchInput }}">
                        <button type="submit" class="absolute left-2.5 top-1/2 -translate-y-1/2 {{ $searchIcon }}"><i class="fa-solid fa-search text-sm"></i></button>
                    </div>
                </form>
            </div>
            <div class="md:hidden w-4"></div>
        </div>
        <div id="mobile-menu" class="hidden md:hidden border-t {{ $enableDark ? 'border-[#2a2d42]' : 'border-gray-200' }} px-4 py-2 space-y-1">
            @foreach($headerNavs as $nav)
            <a href="{{ $nav->url }}" target="{{ $nav->target }}" class="block px-3 py-1.5 text-lg {{ request()->is(trim($nav->url, '/')) || request()->is(trim($nav->url, '/').'/*') ? ($enableDark ? 'text-[#9197ed]' : 'text-blue-600') : $headerLink }}">
                @if($nav->icon)<i class="{{ $nav->icon }} mr-2"></i>@endif
                {{ $nav->name }}
            </a>
            @endforeach
            <form action="{{ $searchAction }}" method="GET" @if($searchDriver !== 'builtin') target="_blank" @endif class="mt-2">
                <input type="text" name="{{ $searchField }}" value="{{ request($searchField, '') }}" placeholder="关键词搜索" class="w-full px-3 py-1.5 text-sm border rounded-full focus:outline-none focus:ring-1 focus:ring-[#656DE6] {{ $searchInput }}">
            </form>
        </div>
    </header>

    @hasSection('banner')
        <section class="w-full overflow-hidden">@yield('banner')</section>
    @endif

    <main class="flex-1 max-w-7xl mx-auto px-4 py-5 w-full">
        <!-- Mobile: profile card + admin zone -->
        @php
            $isArticleListPage = request()->routeIs('blog.index', 'blog.list', 'blog.category');
            $hideMobileAuthorCard = $isArticleListPage || request()->routeIs('blog.show', 'blog.guestbook');
        @endphp
        <div class="lg:hidden space-y-4 {{ ($hideMobileAuthorCard && !$isAdmin) ? '' : 'mb-5' }}">
            @unless($hideMobileAuthorCard)
            @include('partials.mobile-author-card')
            @endunless

            @if($isAdmin)
            <div class="bg-white rounded-lg shadow-sm overflow-hidden">
                <div class="px-5 py-5">
                    <div class="flex items-center gap-1.5 mb-3">
                        <i class="fa-solid fa-gauge text-blue-500 text-base w-4"></i>
                        <span class="text-base font-semibold text-gray-800">管理专区</span>
                    </div>
                    <div class="grid grid-cols-2 gap-3">
                        <a href="{{ route('admin.posts.create') }}" class="flex items-center justify-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-base rounded-lg transition-colors">
                            <i class="fa-solid fa-pen-to-square"></i>发布博客
                        </a>
                        <a href="{{ route('admin.dashboard') }}" class="flex items-center justify-center gap-2 px-4 py-2.5 bg-gray-700 hover:bg-gray-800 text-white text-base rounded-lg transition-colors">
                            <i class="fa-solid fa-gear"></i>后台管理
                        </a>
                    </div>
                </div>
            </div>
            @endif
        </div>

        @php
            $hasHero = trim($__env->yieldContent('hero')) !== '';
        @endphp
        <div class="flex flex-col lg:grid lg:grid-cols-[minmax(0,1fr)_24rem] lg:gap-6">
            @if($hasHero)
            <!-- 行1 左：幻灯片轮播 -->
            <div class="min-w-0 lg:col-start-1 lg:row-start-1">@yield('hero')</div>

            <!-- 行1 右：博主头像卡片（拉伸至与轮播等高，底部齐平） -->
            <div class="hidden lg:block lg:col-start-2 lg:row-start-1">
                <div class="bg-white rounded-lg shadow-sm overflow-hidden h-full">
                    @include('partials.author-card')
                </div>
            </div>
            @endif

            <!-- 行2 左：内容（文章列表） -->
            <div class="min-w-0 {{ $hasHero ? 'lg:col-start-1 lg:row-start-2' : 'lg:col-start-1 lg:row-start-1 lg:row-span-2' }}">
                @yield('content')
            </div>

            <!-- 行2 右：联系方式及以下模块（与文章列表对齐） -->
            <div class="hidden lg:block lg:col-start-2 {{ $hasHero ? 'lg:row-start-2' : 'lg:row-start-1 lg:row-span-2' }}">
                <div class="space-y-4">
                    @unless($hasHero)
                    @if($postDetailShowAuthorCard)
                    <!-- Author card（无轮播页面显示在侧边栏顶部，自然高度） -->
                    <div class="bg-white rounded-lg shadow-sm overflow-hidden">
                        @include('partials.author-card')
                    </div>
                    @endif
                    @endunless

                    @if($isAdmin)
                    <div class="bg-white rounded-lg shadow-sm overflow-hidden">
                        <div class="px-5 py-5">
                            <div class="text-base font-medium text-gray-800 mb-3">
                                <i class="fa-solid fa-gauge text-blue-500 mr-1.5"></i>管理专区
                            </div>
                            <div class="grid grid-cols-2 gap-3">
                                <a href="{{ route('admin.posts.create') }}" class="flex items-center justify-center gap-2 px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white text-base rounded-lg transition-colors">
                                    <i class="fa-solid fa-pen-to-square"></i>发布博客
                                </a>
                                <a href="{{ route('admin.dashboard') }}" class="flex items-center justify-center gap-2 px-3 py-2 bg-gray-700 hover:bg-gray-800 text-white text-base rounded-lg transition-colors">
                                    <i class="fa-solid fa-gear"></i>后台管理
                                </a>
                            </div>
                        </div>
                    </div>
                    @endif

                    <!-- Contact -->
                    @if($postDetailShowAuthorCard && count($contactItems) > 0)
                    <div class="bg-white rounded-lg shadow-sm">
                        <div class="px-5 py-5">
                            <div class="flex items-center gap-1.5 mb-3">
                                <i class="fa-solid fa-address-book text-blue-500 text-base w-4"></i>
                                <span class="text-base font-semibold text-gray-800">联系方式</span>
                            </div>
                            <div class="space-y-2.5">
                                @foreach($contactItems as $item)
                                <div class="flex items-center gap-2 text-base">
                                    <i class="{{ $item['icon'] }} {{ $item['color'] }} w-4 text-center"></i>
                                    <span class="text-gray-500 shrink-0">{{ $item['name'] }}</span>
                                    @if($item['url'])
                                    <a href="{{ $item['url'] }}" target="_blank" rel="noopener" class="truncate text-gray-600 {{ $enableDark ? 'hover:text-[#9197ed]' : 'hover:text-blue-600' }} transition-colors">{{ $item['label'] }}</a>
                                    @else
                                    <span class="truncate text-gray-600">{{ $item['label'] }}</span>
                                    @endif
                                </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                    @endif

                    <!-- Categories -->
                    @if($sidebarCategories->count() > 0)
                    <div class="bg-white rounded-lg shadow-sm">
                        <div class="px-5 py-5">
                            <div class="flex items-center gap-1.5 mb-3">
                                <i class="fa-solid fa-layer-group text-blue-500 text-base w-4"></i>
                                <span class="text-base font-semibold text-gray-800">分类</span>
                            </div>
                            <div class="grid grid-cols-2 gap-2">
                                @foreach($sidebarCategories as $cat)
                                    <a href="{{ route('blog.category', $cat->slug) }}" class="inline-flex items-center justify-center leading-normal px-2 py-1 text-base text-gray-600 bg-gray-50 border border-gray-400 hover:bg-blue-50 hover:text-blue-600 rounded-full truncate transition-colors">
                                        {{ $cat->name }} ({{ $cat->posts_count }})
                                    </a>
                                @endforeach
                            </div>
                        </div>
                    </div>
                    @endif

                    <!-- Tags -->
                    @if($sidebarTags->count() > 0)
                    <div class="bg-white rounded-lg shadow-sm">
                        <div class="px-5 py-5">
                            <div class="flex items-center gap-1.5 mb-3">
                                <i class="fa-solid fa-tags text-blue-500 text-base w-4"></i>
                                <span class="text-base font-semibold text-gray-800">标签</span>
                            </div>
                            <div class="flex flex-wrap gap-2">
                                @foreach($sidebarTags as $tagItem)
                                    <a href="{{ route('blog.search', ['q' => $tagItem->name]) }}" class="inline-flex items-center justify-center leading-normal px-2 py-1 text-base rounded-full border border-gray-400 text-gray-500 hover:border-blue-300 hover:text-blue-600 hover:bg-blue-50 transition-colors">
                                        {{ $tagItem->name }}
                                        <span class="ml-1 text-gray-400 text-sm">{{ $tagItem->posts_count }}</span>
                                    </a>
                                @endforeach
                            </div>
                        </div>
                    </div>
                    @endif

                    <!-- Hot posts -->
                    <div class="bg-white rounded-lg shadow-sm">
                        <div class="px-5 py-5">
                            <div class="flex items-center gap-1.5 mb-3">
                                <i class="fa-solid fa-fire text-blue-500 text-base w-4"></i>
                                <span class="text-base font-semibold text-gray-800">热门博客</span>
                            </div>
                            <div class="space-y-2">
                                @forelse($sidebarHot as $item)
                                    <a href="{{ route('blog.show', $item->slug) }}" class="block text-base text-gray-600 hover:text-blue-600 transition-colors truncate">
                                        {{ $item->title }}
                                    </a>
                                @empty
<span class="text-base text-gray-400">暂无文章</span>
                                @endforelse
                            </div>
                        </div>
                    </div>

                    <!-- Friend links -->
                    <div class="bg-white rounded-lg shadow-sm">
                        <div class="px-5 py-5">
                            <div class="flex items-center gap-1.5 mb-3">
                                <i class="fa-solid fa-link text-blue-500 text-base w-4"></i>
                                <span class="text-base font-semibold text-gray-800">友情链接</span>
                            </div>
                            <div class="flex flex-wrap gap-2">
                                @forelse($friendLinks as $link)
                                <a href="{{ $link->site_url }}" target="_blank" rel="noopener"
                                    class="inline-flex items-center px-3 py-1.5 rounded-md border border-gray-200 bg-gray-50 text-sm text-gray-600 hover:text-blue-600 hover:border-blue-300 hover:bg-blue-50 transition-colors">{{ $link->site_name }}</a>
                                @empty
                                <span class="block text-base text-gray-400">暂无友情链接</span>
                                @endforelse
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        @if($isArticleListPage)
        <!-- Mobile: 博主信息卡（文章列表页移至文章列表下方、分类上方） -->
        <div class="lg:hidden mt-5">
            @include('partials.mobile-author-card')
        </div>
        @endif

        <!-- Mobile: sidebar items (bottom) -->
        <div class="lg:hidden space-y-4 mt-5">
            <!-- Categories -->
            @if($sidebarCategories->count() > 0)
            <div class="bg-white rounded-lg shadow-sm">
                <div class="px-5 py-5">
                    <div class="flex items-center gap-1.5 mb-3">
                        <i class="fa-solid fa-layer-group text-blue-500 text-base w-4"></i>
                        <span class="text-base font-semibold text-gray-800">分类</span>
                    </div>
                    <div class="grid grid-cols-2 gap-2">
                        @foreach($sidebarCategories as $cat)
                            <a href="{{ route('blog.category', $cat->slug) }}" class="inline-flex items-center justify-center leading-normal px-2 py-1 text-base text-gray-600 bg-gray-50 border border-gray-400 hover:bg-blue-50 hover:text-blue-600 rounded-full truncate transition-colors">
                                {{ $cat->name }} ({{ $cat->posts_count }})
                            </a>
                        @endforeach
                    </div>
                </div>
            </div>
            @endif

            <!-- Tags -->
            @if($sidebarTags->count() > 0)
            <div class="bg-white rounded-lg shadow-sm">
                <div class="px-5 py-5">
                    <div class="flex items-center gap-1.5 mb-3">
                        <i class="fa-solid fa-tags text-blue-500 text-base w-4"></i>
                        <span class="text-base font-semibold text-gray-800">标签</span>
                    </div>
                    <div class="flex flex-wrap gap-2">
                        @foreach($sidebarTags as $tagItem)
                            <a href="{{ route('blog.search', ['q' => $tagItem->name]) }}" class="inline-flex items-center justify-center leading-normal px-2 py-1 text-base rounded-full border border-gray-400 text-gray-500 hover:border-blue-300 hover:text-blue-600 hover:bg-blue-50 transition-colors">
                                {{ $tagItem->name }}
                                <span class="ml-1 text-gray-400 text-sm">{{ $tagItem->posts_count }}</span>
                            </a>
                        @endforeach
                    </div>
                </div>
            </div>
            @endif

            <!-- Hot posts -->
            <div class="bg-white rounded-lg shadow-sm">
                <div class="px-5 py-5">
                    <div class="flex items-center gap-1.5 mb-3">
                        <i class="fa-solid fa-fire text-blue-500 text-base w-4"></i>
                        <span class="text-base font-semibold text-gray-800">热门博客</span>
                    </div>
                    <div class="space-y-2">
                        @forelse($sidebarHot as $item)
                            <a href="{{ route('blog.show', $item->slug) }}" class="block text-base text-gray-600 hover:text-blue-600 transition-colors truncate">
                                {{ $item->title }}
                            </a>
                        @empty
                            <span class="text-base text-gray-400">暂无文章</span>
                        @endforelse
                    </div>
                </div>
            </div>

            <!-- Friend links -->
            <div class="bg-white rounded-lg shadow-sm">
                <div class="px-5 py-5">
                    <div class="flex items-center gap-1.5 mb-3">
                        <i class="fa-solid fa-link text-blue-500 text-base w-4"></i>
                        <span class="text-base font-semibold text-gray-800">友情链接</span>
                    </div>
                    <div class="flex flex-wrap gap-2">
                        @forelse($friendLinks as $link)
                        <a href="{{ $link->site_url }}" target="_blank" rel="noopener"
                            class="inline-flex items-center px-3 py-1.5 rounded-md border border-gray-200 bg-gray-50 text-sm text-gray-600 hover:text-blue-600 hover:border-blue-300 hover:bg-blue-50 transition-colors">{{ $link->site_name }}</a>
                        @empty
                        <span class="block text-base text-gray-400">暂无友情链接</span>
                        @endforelse
                    </div>
                </div>
            </div>
        </div>
    </main>

    <footer class="bg-white border-t border-gray-200 mt-auto">
        <div class="max-w-7xl mx-auto px-4 py-6 text-center">
            <div class="mb-2 text-sm flex flex-wrap items-center justify-center gap-x-4 gap-y-1">
                @forelse($footerNavs as $nav)
                <a href="{{ $nav->url }}" target="{{ $nav->target }}" class="text-gray-500 hover:text-blue-600 transition-colors">{{ $nav->name }}</a>
                @empty
                <span class="text-gray-400">暂无底部导航</span>
                @endforelse
            </div>
            @if($config->icp_number || $config->police_record_text)
            <div class="text-sm text-gray-400 space-x-4 mb-1">
                @if($config->icp_number)
                <a href="https://beian.miit.gov.cn" target="_blank" rel="noopener" class="text-gray-400 hover:text-blue-600 transition-colors">{{ $config->icp_number }}</a>
                @endif
                @if($config->police_record_text)
                <a href="{{ $config->police_record_link ?: '#' }}" target="{{ $config->police_record_link ? '_blank' : '_self' }}" rel="noopener" class="text-gray-400 hover:text-blue-600 transition-colors">
                    {{ $config->police_record_text }}
                </a>
                @endif
            </div>
            @endif
            <div class="text-sm text-gray-400 space-y-1">
                @if($config->site_start_date)
                <p>{{ $config->site_name ?? '博客' }} 已稳定运行：<span id="runtime" class="text-blue-500 font-medium"></span></p>
                @endif
                <p>{!! $config->site_copyright ?? '' !!}</p>
            </div>
        </div>
    </footer>

    <script>
        // 暗黑模式：按客户端本地时间定时校正（支持跨午夜时间段）
        (function() {
            var cfg = {
                mode: '{{ $darkModeMode }}',
                start: '{{ $darkStart }}',
                end: '{{ $darkEnd }}'
            };

            function inRange(now, start, end) {
                if (!start || !end) return false;
                function toMin(t) {
                    var p = t.split(':');
                    return parseInt(p[0], 10) * 60 + parseInt(p[1], 10);
                }
                var t = now.getHours() * 60 + now.getMinutes();
                var s = toMin(start), e = toMin(end);
                if (s === e) return true;
                return s < e ? (t >= s && t < e) : (t >= s || t < e);
            }

            function applyDark() {
                var enable = cfg.mode === 'always'
                    || (cfg.mode === 'schedule' && inRange(new Date(), cfg.start, cfg.end));
                document.documentElement.classList.toggle('dark', enable);
                document.body.classList.toggle('theme-dark', enable);
            }

            applyDark();
            setInterval(applyDark, 60000);
        })();

        document.getElementById('mobile-menu-toggle')?.addEventListener('click', function () {
            document.getElementById('mobile-menu').classList.toggle('hidden');
        });
        (function() {
            var startDate = '{{ $config->site_start_date ?? "" }}';
            if (!startDate) return;
            var start = new Date(startDate).getTime();
            if (isNaN(start)) return;
            var el = document.getElementById('runtime');
            if (!el) return;
            function update() {
                var now = Date.now();
                var diff = Math.floor((now - start) / 1000);
                var d = Math.floor(diff / 86400);
                var h = Math.floor((diff % 86400) / 3600);
                var m = Math.floor((diff % 3600) / 60);
                var s = diff % 60;
                el.textContent = d + '天 ' + h + '小时 ' + m + '分钟 ' + s + '秒';
            }
            update();
            setInterval(update, 1000);
        })();
    </script>
    @stack('scripts')

    {{-- 微信分享二维码弹窗（全局，供首页/详情页复用） --}}
    <div id="wechat-share-modal" class="hidden fixed inset-0 z-[60] flex items-center justify-center">
        <div class="absolute inset-0 bg-black/60" onclick="closeWechatShare()"></div>
        <div class="relative bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-6 w-72 mx-4 text-center">
            <button type="button" onclick="closeWechatShare()"
                class="absolute top-3 right-3 w-7 h-7 flex items-center justify-center rounded-full text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors text-lg leading-none">&times;</button>
            <p class="text-base font-semibold text-gray-800 dark:text-white mb-1">分享到微信</p>
            <p class="text-xs text-gray-400 dark:text-gray-400 mb-4">打开微信「扫一扫」，扫描二维码即可分享</p>
            <img id="wechat-share-qr" src="" alt="微信二维码" class="w-44 h-44 mx-auto border border-gray-100 dark:border-gray-700 rounded-lg">
        </div>
    </div>
    <script>
    function openWechatShare(url) {
        var modal = document.getElementById('wechat-share-modal');
        var img = document.getElementById('wechat-share-qr');
        if (!modal) return;
        var target = url || window.location.href;
        img.src = 'https://api.qrserver.com/v1/create-qr-code/?size=260x260&margin=6&data=' + encodeURIComponent(target);
        modal.classList.remove('hidden');
    }
    function closeWechatShare() {
        var modal = document.getElementById('wechat-share-modal');
        if (modal) modal.classList.add('hidden');
    }
    </script>

    @if($config->custom_footer_js)
    {!! $config->custom_footer_js !!}
    @endif
</body>
</html>
